import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = composeWarningsGuard3.level(jSError9);
        com.google.javascript.jscomp.JSError jSError11 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = composeWarningsGuard3.level(jSError11);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNull(checkLevel10);
        org.junit.Assert.assertNull(checkLevel12);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        java.lang.String str23 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean25 = closureCodingConvention0.isConstant("(JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.exportProperty" + "'", str23.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(28, "JSC_NODE_TRAVERSAL_ERROR: {0}");
        boolean boolean3 = node2.isLocalResultCall();
        boolean boolean4 = node2.isQualifiedName();
        com.google.javascript.rhino.Node node6 = node2.getAncestor(30);
        com.google.javascript.rhino.Node node7 = node2.removeFirstChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter27 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = diagnosticType31.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType34, strArray36);
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray40 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make(diagnosticType38, strArray40);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make(diagnosticType34, strArray40);
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel32, diagnosticType33, strArray40);
        int int44 = jSError43.lineNumber;
        try {
            java.lang.String str45 = lightweightMessageFormatter27.formatWarning(jSError43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 32 + "'", int44 == 32);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        java.lang.Class<?> wildcardClass15 = diagnosticType11.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.level;
        diagnosticType11.level = checkLevel19;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard21 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel19);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup10;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = diagnosticType26.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        java.lang.String[] strArray31 = null;
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (short) 0, 20, checkLevel27, diagnosticType30, strArray31);
        boolean boolean33 = diagnosticGroup10.matches(diagnosticType30);
        java.lang.String str34 = diagnosticType30.toString();
        java.text.MessageFormat messageFormat35 = diagnosticType30.format;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + ": " + "'", str34.equals(": "));
        org.junit.Assert.assertNotNull(messageFormat35);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection6 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node2);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(42, node11);
        boolean boolean13 = node12.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = null;
        node12.setJSDocInfo(jSDocInfo14);
        boolean boolean16 = node2.isEquivalentTo(node12);
        int int17 = node2.getType();
        node2.setOptionalArg(false);
        com.google.javascript.rhino.Node node20 = node2.removeChildren();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        java.lang.Object obj4 = compilerOptions0.clone();
        compilerOptions0.setSummaryDetailLevel(13);
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make(diagnosticType29, strArray31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType34, strArray36);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray38 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType29, diagnosticType33, diagnosticType34 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray38);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray42 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray42);
        java.lang.Class<?> wildcardClass44 = diagnosticType40.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel48 = diagnosticType47.level;
        diagnosticType40.level = checkLevel48;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard50 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup39, checkLevel48);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray51 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard27, diagnosticGroupWarningsGuard50 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList52 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList52, warningsGuardArray51);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard54 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList52);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard55 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList52);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(diagnosticTypeArray38);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(warningsGuardArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        try {
            com.google.javascript.rhino.Context.reportWarning("JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        compilerOptions0.setTweakToNumberLiteral("URSH ", 0);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = compilerOptions0.sourceMapDetailLevel;
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setColorizeErrorOutput(false);
        compilerOptions0.crossModuleCodeMotion = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(detailLevel6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean11 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.nameReferenceGraphPath = "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n";
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        int int5 = context0.getOptimizationLevel();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 1L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler11, (java.util.List<com.google.javascript.rhino.Node>) nodeList13, callback15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler11.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset24);
        java.lang.String str26 = jSSourceFile25.getOriginalPath();
        java.lang.String str27 = jSSourceFile25.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst30 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile29);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst30, false);
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler();
        compilerInput32.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler33);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray37 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray37);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray41 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make(diagnosticType39, strArray41);
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compiler33.getErrorLevel(jSError43);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt45 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter46 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler33, sourceExcerpt45);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter47 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler33);
        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList50 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList50, nodeArray49);
        com.google.javascript.jscomp.NodeTraversal.Callback callback52 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler48, (java.util.List<com.google.javascript.rhino.Node>) nodeList50, callback52);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter54 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler48);
        java.nio.charset.Charset charset56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset56);
        java.lang.String str58 = jSSourceFile57.getOriginalPath();
        com.google.javascript.rhino.Node node59 = compiler48.parse(jSSourceFile57);
        com.google.javascript.jscomp.JsAst jsAst60 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile57);
        com.google.javascript.rhino.Node node61 = compiler33.parse(jSSourceFile57);
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions62.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result65 = compiler11.compile(jSSourceFile25, jSSourceFile57, compilerOptions62);
        compilerOptions62.locale = "error reporter";
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str27.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNull(checkLevel44);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str58.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertNull(node61);
        org.junit.Assert.assertNotNull(result65);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        boolean boolean5 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.isGeneratingSource();
        int int4 = context0.getInstructionObserverThreshold();
        long long5 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        context0.addActivationName("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        jSSourceFile5.setOriginalPath("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5 };
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler10, (java.util.List<com.google.javascript.rhino.Node>) nodeList12, callback14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10);
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler10.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler20, (java.util.List<com.google.javascript.rhino.Node>) nodeList22, callback24);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker26 = compiler20.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt27 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, sourceExcerpt27);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter29 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset33);
        java.lang.String str35 = jSSourceFile34.getOriginalPath();
        java.lang.String str36 = jSSourceFile34.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst39, false);
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler();
        compilerInput41.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make(diagnosticType48, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray50);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compiler42.getErrorLevel(jSError52);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt54 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter55 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42, sourceExcerpt54);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter56 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42);
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler57, (java.util.List<com.google.javascript.rhino.Node>) nodeList59, callback61);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter63 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler57);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset65);
        java.lang.String str67 = jSSourceFile66.getOriginalPath();
        com.google.javascript.rhino.Node node68 = compiler57.parse(jSSourceFile66);
        com.google.javascript.jscomp.JsAst jsAst69 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.rhino.Node node70 = compiler42.parse(jSSourceFile66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result74 = compiler20.compile(jSSourceFile34, jSSourceFile66, compilerOptions71);
        java.nio.charset.Charset charset76 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset76);
        com.google.javascript.jscomp.CompilerInput compilerInput78 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray79 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile66, jSSourceFile77 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions80 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions80.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions80.aliasableGlobals = "TypeError: <No stack trace available>";
        com.google.javascript.jscomp.Result result85 = compiler0.compile(jSSourceFileArray8, jSSourceFileArray79, compilerOptions80);
        boolean boolean86 = compilerOptions80.inlineGetters;
        compilerOptions80.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(messageFormatter19);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(performanceTracker26);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str35.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str36.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNull(checkLevel53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str67.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNull(node70);
        org.junit.Assert.assertNotNull(result74);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertNotNull(jSSourceFileArray79);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection6 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node2);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(42, node11);
        boolean boolean13 = node12.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = null;
        node12.setJSDocInfo(jSDocInfo14);
        boolean boolean16 = node2.isEquivalentTo(node12);
        int int17 = node2.getType();
        node2.putIntProp(24, 45);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        boolean boolean4 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = null;
        node9.setJSDocInfo(jSDocInfo29);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.convertToDottedProperties = true;
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        java.lang.String str9 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = null;
        compilerOptions0.setCodingConvention(codingConvention10);
        compilerOptions0.setDefineToDoubleLiteral("Unknown class name", (double) 40);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        compilerOptions0.checkRequires = checkLevel15;
        compilerOptions0.devirtualizePrototypeMethods = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.setRemoveAbstractMethods(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType11.level;
        boolean boolean16 = diagnosticGroup10.matches(diagnosticType11);
        java.lang.String str17 = diagnosticGroup10.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setOutputCharset("EOF ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(format4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        compilerOptions0.checkFunctions = checkLevel10;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.siblings();
        boolean boolean7 = node5.isNoSideEffectsCall();
        java.lang.String str8 = node1.checkTreeEquals(node5);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node10 = null;
        boolean boolean11 = closureCodingConvention9.isVarArgsParameter(node10);
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        closureCodingConvention9.applyDelegateRelationship(objectType12, objectType13, objectType14, functionType15, functionType16);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType20 = null;
        closureCodingConvention9.applySubclassRelationship(functionType18, functionType19, subclassType20);
        boolean boolean23 = closureCodingConvention9.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj27 = node25.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj32 = node30.getProp((int) (short) 1);
        boolean boolean33 = node30.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj37 = node35.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = node40.siblings();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((-1), node30, node35, node40);
        boolean boolean43 = node40.wasEmptyNode();
        java.lang.String str44 = closureCodingConvention9.extractClassNameIfProvide(node25, node40);
        com.google.javascript.rhino.Node node45 = node5.clonePropsFrom(node40);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str8.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("0", "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name", 16, "goog.global", 41);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter27 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        boolean boolean28 = compiler14.acceptEcmaScript5();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray12);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType4, strArray12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = diagnosticType19.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray24 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make(diagnosticType22, strArray24);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray28 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make(diagnosticType26, strArray28);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make(diagnosticType22, strArray28);
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel20, diagnosticType21, strArray28);
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray28);
        boolean boolean33 = diagnosticGroup0.matches(diagnosticType4);
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripNamePrefixes;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        boolean boolean5 = compilerInput4.isExtern();
        boolean boolean6 = compilerInput4.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceAst7);
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput8.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(sourceAst9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node3.getLastSibling();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str11 = node7.toString(true, false, true);
        boolean boolean12 = node7.isSyntheticBlock();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node7);
        int int14 = node7.getType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(42, node19);
        boolean boolean21 = node7.isEquivalentTo(node19);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR" + "'", str11.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        boolean boolean5 = compilerInput4.isExtern();
        boolean boolean6 = compilerInput4.isExtern();
        java.lang.String str7 = compilerInput4.getName();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "error reporter" + "'", str7.equals("error reporter"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        jSSourceFile5.setOriginalPath("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5 };
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler10, (java.util.List<com.google.javascript.rhino.Node>) nodeList12, callback14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10);
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler10.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler20, (java.util.List<com.google.javascript.rhino.Node>) nodeList22, callback24);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker26 = compiler20.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt27 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, sourceExcerpt27);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter29 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset33);
        java.lang.String str35 = jSSourceFile34.getOriginalPath();
        java.lang.String str36 = jSSourceFile34.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst39, false);
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler();
        compilerInput41.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make(diagnosticType48, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray50);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compiler42.getErrorLevel(jSError52);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt54 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter55 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42, sourceExcerpt54);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter56 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42);
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler57, (java.util.List<com.google.javascript.rhino.Node>) nodeList59, callback61);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter63 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler57);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset65);
        java.lang.String str67 = jSSourceFile66.getOriginalPath();
        com.google.javascript.rhino.Node node68 = compiler57.parse(jSSourceFile66);
        com.google.javascript.jscomp.JsAst jsAst69 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.rhino.Node node70 = compiler42.parse(jSSourceFile66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result74 = compiler20.compile(jSSourceFile34, jSSourceFile66, compilerOptions71);
        java.nio.charset.Charset charset76 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset76);
        com.google.javascript.jscomp.CompilerInput compilerInput78 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray79 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile66, jSSourceFile77 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions80 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions80.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions80.aliasableGlobals = "TypeError: <No stack trace available>";
        com.google.javascript.jscomp.Result result85 = compiler0.compile(jSSourceFileArray8, jSSourceFileArray79, compilerOptions80);
        boolean boolean86 = compilerOptions80.inlineGetters;
        compilerOptions80.setNameAnonymousFunctionsOnly(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy89 = compilerOptions80.variableRenaming;
        boolean boolean90 = compilerOptions80.generateExports;
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(messageFormatter19);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(performanceTracker26);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str35.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str36.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNull(checkLevel53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str67.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNull(node70);
        org.junit.Assert.assertNotNull(result74);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertNotNull(jSSourceFileArray79);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy89 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy89.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.Object obj1 = null;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("", obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = closureCodingConvention0.getClassesDefinedByCall(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", "Not declared as a constructor", 130);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        node1.setQuotedString();
        int int3 = node1.getCharno();
        node1.setOptionalArg(true);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.abstractMethod");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType9 = null;
        closureCodingConvention0.applySubclassRelationship(functionType7, functionType8, subclassType9);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler11 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler11, callback12);
        com.google.javascript.rhino.Node node14 = nodeTraversal13.getCurrentNode();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = node16.getJSDocInfo();
        java.lang.String str20 = node16.toString();
        boolean boolean21 = node16.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node22 = node16.getLastSibling();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean25 = closureCodingConvention23.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str31 = node27.toString(true, false, true);
        boolean boolean32 = node27.hasOneChild();
        boolean boolean33 = closureCodingConvention23.isVarArgsParameter(node27);
        node16.addChildToFront(node27);
        boolean boolean36 = node27.getBooleanProp((int) 'a');
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast37 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal13, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BITXOR" + "'", str20.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BITXOR" + "'", str31.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.generateExports = true;
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean7 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        boolean boolean10 = node7.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((-1), node7, node12, node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType20.level;
        java.lang.String str25 = diagnosticType20.toString();
        java.lang.String str26 = diagnosticType20.toString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node29, diagnosticType32, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node12, diagnosticType20, strArray35);
        java.lang.String str39 = jSError38.toString();
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str25.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str39.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        boolean boolean3 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.setPropertyAffinity(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node2.getAncestors();
        com.google.javascript.rhino.Context context8 = new com.google.javascript.rhino.Context();
        context8.addActivationName("goog.abstractMethod");
        boolean boolean11 = context8.hasCompileFunctionsWithDynamicScope();
        int int12 = context8.getLanguageVersion();
        int int13 = context8.getOptimizationLevel();
        context8.setCompileFunctionsWithDynamicScope(false);
        node2.putProp((int) (byte) 100, (java.lang.Object) context8);
        int int17 = context8.getOptimizationLevel();
        com.google.javascript.rhino.Context context18 = new com.google.javascript.rhino.Context();
        java.util.Locale locale19 = context18.getLocale();
        java.util.Locale locale20 = context8.setLocale(locale19);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNull(locale20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.removeEmptyFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj5 = node3.getProp((int) (short) 1);
        boolean boolean6 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1), node3, node8, node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = null;
        node8.setJSDocInfo(jSDocInfo16);
        boolean boolean18 = detailLevel0.apply(node8);
        com.google.javascript.rhino.Node node19 = node8.getFirstChild();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(node19);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setThrows();
        boolean boolean3 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesArguments();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.inlineConstantVars = false;
        java.util.Set<java.lang.String> strSet6 = compilerOptions3.stripNamePrefixes;
        compilerOptions0.aliasableStrings = strSet6;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("JSC_NODE_TRAVERSAL_ERROR: {0}", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", 44);
        java.lang.String str4 = evaluatorException3.getScriptStackTrace();
        evaluatorException3.initLineSource("// Input %num%");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        boolean boolean7 = closureCodingConvention0.isConstantKey("JSC_NODE_TRAVERSAL_ERROR");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("language version");
        int int10 = node9.getLineno();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        boolean boolean15 = node13.isNoSideEffectsCall();
        java.lang.String str16 = node9.checkTreeEquals(node13);
        java.lang.String str17 = node13.toString();
        boolean boolean18 = node13.wasEmptyNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str20 = closureCodingConvention19.getExportPropertyFunction();
        boolean boolean22 = closureCodingConvention19.isPrivate("");
        boolean boolean24 = closureCodingConvention19.isPrivate("hi!");
        java.lang.String str25 = closureCodingConvention19.getAbstractMethodName();
        boolean boolean27 = closureCodingConvention19.isExported("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention28 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str29 = closureCodingConvention28.getExportPropertyFunction();
        boolean boolean31 = closureCodingConvention28.isPrivate("");
        boolean boolean33 = closureCodingConvention28.isPrivate("hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean37 = closureCodingConvention28.isOptionalParameter(node36);
        java.lang.String str38 = closureCodingConvention19.identifyTypeDefAssign(node36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newExpr(node36);
        node36.setLineno(160);
        java.lang.String str42 = closureCodingConvention0.extractClassNameIfRequire(node13, node36);
        node13.setSourcePositionForTree(33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str16.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "EOF " + "'", str17.equals("EOF "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportProperty" + "'", str20.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "goog.abstractMethod" + "'", str25.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.exportProperty" + "'", str29.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions5.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions5.checkUnusedPropertiesEarly = false;
        boolean boolean12 = compilerOptions5.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig13 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions5);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap14 = compilerOptions5.customPasses;
        com.google.javascript.jscomp.SourceMap.Format format15 = compilerOptions5.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format15;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap14);
        org.junit.Assert.assertNotNull(format15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        int int4 = node1.getIntProp(24);
        boolean boolean5 = node1.isQuotedString();
        com.google.javascript.rhino.Node node6 = node1.removeChildren();
        node1.setLineno(40);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.inlineConstantVars = true;
        compilerOptions0.checkTypedPropertyCalls = true;
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup10;
        java.lang.String str12 = diagnosticGroup10.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setColorizeErrorOutput(false);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy4, propertyRenamingPolicy5);
        boolean boolean7 = compilerOptions0.closurePass;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy4.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj8 = node6.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = node6.getJSDocInfo();
        node6.setIsSyntheticBlock(false);
        com.google.javascript.rhino.EvaluatorException evaluatorException16 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException16.addSuppressed((java.lang.Throwable) runtimeException18);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        boolean boolean25 = node22.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node26 = node22.getLastChild();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("language version");
        int int29 = node28.getLineno();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        boolean boolean34 = node32.isNoSideEffectsCall();
        java.lang.String str35 = node28.checkTreeEquals(node32);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(110, node22, node28);
        com.google.javascript.rhino.Node node38 = node36.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException39 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException18, (java.lang.Object) node38);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) 10);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(42, node46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(17, node38, node41, node47, 49, 45);
        try {
            com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(24, node1, node4, node6, node41, (-86), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str35.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(runtimeException39);
        org.junit.Assert.assertNotNull(node46);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        boolean boolean3 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.checkSuspiciousCode = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        boolean boolean5 = node2.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj6 = node4.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node4.setJSType(jSType7);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        boolean boolean12 = closureCodingConvention0.isPrivate("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        try {
//            com.google.javascript.rhino.Context.reportError("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("goog.global", ": ");
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray13 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType4, diagnosticType8, diagnosticType9 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray17);
        java.lang.Class<?> wildcardClass19 = diagnosticType15.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.level;
        diagnosticType15.level = checkLevel23;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = diagnosticType29.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray34 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(diagnosticType32, strArray34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray38 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make(diagnosticType36, strArray38);
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(diagnosticType32, strArray38);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel30, diagnosticType31, strArray38);
        java.lang.String str42 = jSError41.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = diagnosticGroupWarningsGuard25.level(jSError41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel43, "(goog.exportProperty)");
        int int46 = diagnosticType2.compareTo(diagnosticType45);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticTypeArray13);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 11 + "'", int46 == 11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.lineBreak = true;
        java.lang.String str4 = compilerOptions0.inputDelimiter;
        boolean boolean5 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "// Input %num%" + "'", str4.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        node2.detachChildren();
        java.lang.Object obj5 = null;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node2, obj5);
        java.lang.String str7 = runtimeException6.toString();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: null is not a function, it is com.google.javascript.rhino.Node$StringNode." + "'", str7.equals("com.google.javascript.rhino.EcmaError: TypeError: null is not a function, it is com.google.javascript.rhino.Node$StringNode."));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setAllFlags();
        int int4 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        node2.putIntProp(0, (int) 'a');
        try {
            int int10 = node2.getExistingIntProp(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setReturnsTainted();
        sideEffectFlags0.setMutatesThis();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("JSC_NODE_TRAVERSAL_ERROR", "URSH ", "BITXOR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean6 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertNotNull(context5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode3;
        java.lang.String str5 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean4 = closureCodingConvention1.isPrivate("");
        boolean boolean6 = closureCodingConvention1.isPrivate("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean10 = closureCodingConvention1.isOptionalParameter(node9);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder11 = node9.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node14.setVarArgs(true);
        com.google.javascript.rhino.Node node17 = node14.getParent();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention18 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node19 = null;
        boolean boolean20 = closureCodingConvention18.isVarArgsParameter(node19);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = node22.getJSDocInfo();
        java.lang.String str26 = node22.toString();
        boolean boolean27 = node22.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node28 = node22.getLastSibling();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention29 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean31 = closureCodingConvention29.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str37 = node33.toString(true, false, true);
        boolean boolean38 = node33.hasOneChild();
        boolean boolean39 = closureCodingConvention29.isVarArgsParameter(node33);
        node22.addChildToFront(node33);
        java.lang.String str41 = closureCodingConvention18.getSingletonGetterClassName(node22);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(37, node9, node14, node22, 4095, 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "BITXOR" + "'", str26.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "BITXOR" + "'", str37.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean4 = closureCodingConvention1.isPrivate("");
        boolean boolean6 = closureCodingConvention1.isPrivate("hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        node13.detachChildren();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(24, node10, node13, 6, (int) ' ');
        java.lang.String str19 = closureCodingConvention1.getSingletonGetterClassName(node18);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        boolean boolean25 = node22.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj29 = node27.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((-1), node22, node27, node32);
        node22.detachChildren();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj39 = node37.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = node37.getJSDocInfo();
        node37.setIsSyntheticBlock(false);
        java.lang.String str43 = node22.checkTreeEquals(node37);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable51 = node50.siblings();
        node50.detachChildren();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(24, node47, node50, 6, (int) ' ');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj60 = node58.getProp((int) (short) 1);
        boolean boolean61 = node58.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj65 = node63.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable69 = node68.siblings();
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((-1), node58, node63, node68);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = null;
        node63.setJSDocInfo(jSDocInfo71);
        try {
            com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(14, node18, node22, node50, node63, 4095, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(jSDocInfo40);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeIterable51);
        org.junit.Assert.assertNull(obj60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeIterable69);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        java.lang.Class<?> wildcardClass1 = diagnosticGroup0.getClass();
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        boolean boolean3 = compilerOptions0.foldConstants;
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) 0, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray7;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        java.lang.String str14 = compiler0.getSourceLine("(Node tree inequality:\\nTree1:\\nSTRING language version\\n\\n\\nTree2:\\nEOF \\n\\n\\nSubtree1: STRING language version\\n\\n\\nSubtree2: EOF \\n)", 0);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(42, node18);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node21 = null;
        boolean boolean22 = closureCodingConvention20.isVarArgsParameter(node21);
        com.google.javascript.rhino.jstype.ObjectType objectType23 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType24 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType25 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType26 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = null;
        closureCodingConvention20.applyDelegateRelationship(objectType23, objectType24, objectType25, functionType26, functionType27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType31 = null;
        closureCodingConvention20.applySubclassRelationship(functionType29, functionType30, subclassType31);
        boolean boolean34 = closureCodingConvention20.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj38 = node36.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj43 = node41.getProp((int) (short) 1);
        boolean boolean44 = node41.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj48 = node46.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable52 = node51.siblings();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((-1), node41, node46, node51);
        boolean boolean54 = node51.wasEmptyNode();
        java.lang.String str55 = closureCodingConvention20.extractClassNameIfProvide(node36, node51);
        boolean boolean56 = node19.hasChild(node36);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship57 = closureCodingConvention0.getClassesDefinedByCall(node36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeIterable52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(26, "error reporter", (int) (short) 100, 3);
        node4.setString("(Node tree inequality:\\nTree1:\\nSTRING language version\\n\\n\\nTree2:\\nEOF \\n\\n\\nSubtree1: STRING language version\\n\\n\\nSubtree2: EOF \\n)");
        node4.setWasEmptyNode(true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node10 = null;
        boolean boolean11 = closureCodingConvention9.isVarArgsParameter(node10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj15 = node13.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        node13.setJSType(jSType16);
        boolean boolean18 = node13.hasOneChild();
        boolean boolean19 = closureCodingConvention9.isVarArgsParameter(node13);
        com.google.javascript.rhino.Node node20 = node4.copyInformationFromForTree(node13);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(20, "");
        java.util.Set<java.lang.String> strSet3 = node2.getDirectives();
        boolean boolean4 = node2.hasSideEffects();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler6 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler6, callback7);
        boolean boolean9 = nodeTraversal8.hasScope();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray20);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler23 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler23, callback24);
        com.google.javascript.jscomp.Compiler compiler26 = nodeTraversal25.getCompiler();
        com.google.javascript.rhino.Node node27 = nodeTraversal25.getEnclosingFunction();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj32 = node30.getProp((int) (short) 1);
        boolean boolean33 = node30.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj37 = node35.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = node40.siblings();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((-1), node30, node35, node40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray45 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError46 = com.google.javascript.jscomp.JSError.make(diagnosticType43, strArray45);
        com.google.javascript.jscomp.CheckLevel checkLevel47 = diagnosticType43.level;
        java.lang.String str48 = diagnosticType43.toString();
        java.lang.String str49 = diagnosticType43.toString();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray58 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make(diagnosticType56, strArray58);
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node52, diagnosticType55, strArray58);
        com.google.javascript.jscomp.JSError jSError61 = nodeTraversal25.makeError(node35, diagnosticType43, strArray58);
        com.google.javascript.jscomp.JSError jSError62 = nodeTraversal8.makeError(node12, checkLevel13, diagnosticType14, strArray58);
        node2.putProp(0, (java.lang.Object) jSError62);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNull(compiler26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str48.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str49.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(jSError62);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        int int5 = context0.getOptimizationLevel();
        boolean boolean6 = context0.isGeneratingSource();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.jsOutputFile;
        compilerOptions0.lineBreak = true;
        boolean boolean5 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        sideEffectFlags0.clearAllFlags();
        sideEffectFlags0.setMutatesArguments();
        sideEffectFlags0.setAllFlags();
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        compilerOptions0.renamePrefix = "JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)";
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler5 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean11 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean12 = compilerOptions0.generatePseudoNames;
        boolean boolean13 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("EOF ");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy9 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy9;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy9.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setChainCalls(true);
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: <No stack trace available>", "TypeError", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "JSC_NODE_TRAVERSAL_ERROR", "BITXOR", "(goog.exportProperty)", "Unknown class name", "<No stack trace available>", "8", "com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)", "@IMPLEMENTATION.VERSION@", "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions0.stripTypePrefixes = strSet18;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean22 = compilerOptions0.inlineVariables;
        boolean boolean23 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.rhino.Context context5 = new com.google.javascript.rhino.Context();
        java.util.Locale locale6 = context5.getLocale();
        java.util.Locale locale7 = context0.setLocale(locale6);
        int int8 = context0.getLanguageVersion();
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = closureCodingConvention0.isConstant("1100100");
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler13 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal15 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler13, callback14);
        com.google.javascript.rhino.Node node16 = nodeTraversal15.getCurrentNode();
        java.lang.String str17 = nodeTraversal15.getSourceName();
        com.google.javascript.rhino.Node node18 = nodeTraversal15.getEnclosingFunction();
        com.google.javascript.rhino.Node node19 = nodeTraversal15.getCurrentNode();
        java.lang.String str20 = nodeTraversal15.getSourceName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node22 = null;
        boolean boolean23 = closureCodingConvention21.isVarArgsParameter(node22);
        com.google.javascript.rhino.jstype.ObjectType objectType24 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType25 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        closureCodingConvention21.applyDelegateRelationship(objectType24, objectType25, objectType26, functionType27, functionType28);
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = null;
        closureCodingConvention21.applyDelegateRelationship(objectType30, objectType31, objectType32, functionType33, functionType34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(42, node40);
        boolean boolean42 = node41.isLocalResultCall();
        com.google.javascript.rhino.Node node43 = node41.cloneNode();
        java.lang.String str44 = closureCodingConvention21.identifyTypeDefAssign(node41);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast45 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal15, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setColorizeErrorOutput(false);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy4, propertyRenamingPolicy5);
        boolean boolean7 = compilerOptions0.closurePass;
        compilerOptions0.instrumentationTemplate = "EOF \n";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy4.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node6 = node2.getLastChild();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("language version");
        int int9 = node8.getLineno();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        boolean boolean14 = node12.isNoSideEffectsCall();
        java.lang.String str15 = node8.checkTreeEquals(node12);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(110, node2, node8);
        com.google.javascript.rhino.Node node18 = node16.getAncestor((int) (byte) 0);
        try {
            node16.setDouble((-0.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: SWITCH is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str15.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray15);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray19 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray19);
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray19);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel11, diagnosticType12, strArray19);
        compilerOptions0.checkShadowVars = checkLevel11;
        compilerOptions0.syntheticBlockStartMarker = "Named type with empty name component";
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node8.setVarArgs(true);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        com.google.javascript.rhino.Node node12 = node8.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = closureCodingConvention0.getDelegateRelationship(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention0.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj22 = node20.getProp((int) (short) 1);
        boolean boolean23 = node20.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node24 = node20.getLastChild();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("language version");
        int int27 = node26.getLineno();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable31 = node30.siblings();
        boolean boolean32 = node30.isNoSideEffectsCall();
        java.lang.String str33 = node26.checkTreeEquals(node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node20, node26);
        com.google.javascript.rhino.Node node36 = node34.getAncestor((int) (byte) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = closureCodingConvention0.getDelegateRelationship(node36);
        node36.setType((int) (byte) 100);
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = node36.getJSDocInfo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeIterable31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str33.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(delegateRelationship37);
        org.junit.Assert.assertNull(jSDocInfo40);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node15.setVarArgs(true);
        com.google.javascript.rhino.Node node18 = node15.getParent();
        node15.putIntProp(0, (int) 'a');
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean24 = closureCodingConvention22.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str30 = node26.toString(true, false, true);
        boolean boolean31 = node26.hasOneChild();
        boolean boolean32 = closureCodingConvention22.isVarArgsParameter(node26);
        java.lang.String str33 = closureCodingConvention0.extractClassNameIfProvide(node15, node26);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "BITXOR" + "'", str30.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        boolean boolean3 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        int int4 = node1.getIntProp(24);
        boolean boolean5 = node1.isQuotedString();
        boolean boolean6 = node1.hasSideEffects();
        boolean boolean7 = node1.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode3;
        compilerOptions0.checkControlStructures = true;
        compilerOptions0.setDefineToBooleanLiteral("8", true);
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.gatherCssNames = true;
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.io.FilenameFilter filenameFilter10 = null;
        java.lang.String str11 = ecmaError6.getScriptStackTrace(filenameFilter10);
        java.io.FilenameFilter filenameFilter12 = null;
        java.lang.String str13 = ecmaError6.getScriptStackTrace(filenameFilter12);
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "<No stack trace available>" + "'", str11.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "<No stack trace available>" + "'", str13.equals("<No stack trace available>"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node16.setJSType(jSType19);
        boolean boolean21 = node16.hasOneChild();
        try {
            boolean boolean22 = closureCodingConvention0.isPropertyTestFunction(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str8 = node4.toString(true, false, true);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(42, node15);
        boolean boolean17 = node16.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = null;
        node16.setJSDocInfo(jSDocInfo18);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder20 = node16.new FileLevelJsDocBuilder();
        node16.setLineno(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention23, "goog.global", 41, 13);
        com.google.javascript.rhino.Node node28 = node16.copyInformationFromForTree(node27);
        int int29 = node16.getCharno();
        java.util.List<java.lang.String> strList30 = closureCodingConvention0.identifyTypeDeclarationCall(node16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR" + "'", str8.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
        org.junit.Assert.assertNull(strList30);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        boolean boolean4 = compilerOptions0.lineBreak;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(detailLevel6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 100, node2, 26, 31);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(20, "");
        java.util.Set<java.lang.String> strSet12 = node11.getDirectives();
        node8.addChildToFront(node11);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(strSet12);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        node1.setQuotedString();
        int int3 = node1.getCharno();
        boolean boolean4 = node1.isNoSideEffectsCall();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node1.children();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeIterable5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean13 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        java.lang.String[] strArray4 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node7 = null;
        boolean boolean8 = closureCodingConvention6.isVarArgsParameter(node7);
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean8, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean12 = jSError5.equals((java.lang.Object) (-1.0f));
        com.google.javascript.jscomp.CheckLevel checkLevel13 = jSError5.level;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str8 = node4.toString(true, false, true);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        com.google.javascript.rhino.Node node11 = node4.removeFirstChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(42, node16);
        boolean boolean18 = node17.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = null;
        node17.setJSDocInfo(jSDocInfo19);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node17.new FileLevelJsDocBuilder();
        node17.setLineno(0);
        try {
            node11.removeChild(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR" + "'", str8.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.instrumentationTemplate = "bitor";
        compilerOptions4.setNameAnonymousFunctionsOnly(true);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions4.checkMissingGetCssNameLevel;
        compilerOptions0.setWarningLevel(diagnosticGroup3, checkLevel9);
        boolean boolean11 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.setAcceptConstKeyword(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.io.FilenameFilter filenameFilter10 = null;
        java.lang.String str11 = ecmaError6.getScriptStackTrace(filenameFilter10);
        com.google.javascript.rhino.EcmaError ecmaError13 = com.google.javascript.rhino.ScriptRuntime.typeError("<No stack trace available>");
        com.google.javascript.rhino.EvaluatorException evaluatorException15 = new com.google.javascript.rhino.EvaluatorException("hi!");
        java.io.FilenameFilter filenameFilter16 = null;
        java.lang.String str17 = evaluatorException15.getScriptStackTrace(filenameFilter16);
        evaluatorException15.initLineSource("hi!");
        ecmaError13.addSuppressed((java.lang.Throwable) evaluatorException15);
        java.lang.String str21 = ecmaError13.details();
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError13);
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "<No stack trace available>" + "'", str11.equals("<No stack trace available>"));
        org.junit.Assert.assertNotNull(ecmaError13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "<No stack trace available>" + "'", str17.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TypeError: <No stack trace available>" + "'", str21.equals("TypeError: <No stack trace available>"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.siblings();
        boolean boolean7 = node5.isNoSideEffectsCall();
        java.lang.String str8 = node1.checkTreeEquals(node5);
        java.lang.String str9 = node5.toString();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str11 = closureCodingConvention10.getExportPropertyFunction();
        boolean boolean13 = closureCodingConvention10.isPrivate("");
        boolean boolean15 = closureCodingConvention10.isPrivate("hi!");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj20 = node18.getProp((int) (short) 1);
        boolean boolean21 = node18.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj25 = node23.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable29 = node28.siblings();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1), node18, node23, node28);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention31 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node32 = null;
        boolean boolean33 = closureCodingConvention31.isVarArgsParameter(node32);
        com.google.javascript.rhino.jstype.ObjectType objectType34 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType36 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType37 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType38 = null;
        closureCodingConvention31.applyDelegateRelationship(objectType34, objectType35, objectType36, functionType37, functionType38);
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType41 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType42 = null;
        closureCodingConvention31.applySubclassRelationship(functionType40, functionType41, subclassType42);
        boolean boolean45 = closureCodingConvention31.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj49 = node47.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj54 = node52.getProp((int) (short) 1);
        boolean boolean55 = node52.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj59 = node57.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable63 = node62.siblings();
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node52, node57, node62);
        boolean boolean65 = node62.wasEmptyNode();
        java.lang.String str66 = closureCodingConvention31.extractClassNameIfProvide(node47, node62);
        com.google.javascript.rhino.Node node67 = node18.copyInformationFromForTree(node47);
        boolean boolean68 = closureCodingConvention10.isOptionalParameter(node47);
        node5.addChildrenToFront(node47);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str8.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "EOF " + "'", str9.equals("EOF "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeIterable29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertNull(obj54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeIterable63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions3.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions3.checkUnusedPropertiesEarly = false;
        boolean boolean10 = compilerOptions3.coalesceVariableNames;
        boolean boolean11 = compilerOptions3.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy12 = compilerOptions3.anonymousFunctionNaming;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy12;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy12 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy12.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode3;
        compilerOptions0.inferTypesInGlobalScope = true;
        compilerOptions0.labelRenaming = false;
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(100.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        java.lang.String str3 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode4 = compilerOptions0.tracer;
        compilerOptions0.smartNameRemoval = false;
        compilerOptions0.setOutputCharset("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + tracerMode4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode4.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.optimizeCalls;
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setAcceptConstKeyword(true);
        compilerOptions0.setDefineToDoubleLiteral("goog.exportSymbol", (double) 46);
        boolean boolean6 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.SourceFile sourceFile3 = jsAst2.getSourceFile();
        jsAst2.clearAst();
        jsAst2.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = jsAst2.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node3.getLastSibling();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str11 = node7.toString(true, false, true);
        boolean boolean12 = node7.isSyntheticBlock();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node7);
        boolean boolean14 = node7.isQuotedString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR" + "'", str11.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 8L);
        context0.addActivationName("goog.global");
        context0.setGeneratingSource(false);
        java.lang.Object obj12 = null;
        try {
            context0.putThreadLocal((java.lang.Object) 150, obj12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.instrumentationTemplate = "bitor";
        compilerOptions4.setNameAnonymousFunctionsOnly(true);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions4.checkMissingGetCssNameLevel;
        compilerOptions0.setWarningLevel(diagnosticGroup3, checkLevel9);
        boolean boolean11 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.aliasKeywords = false;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(42, node4);
        boolean boolean6 = node5.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = null;
        node5.setJSDocInfo(jSDocInfo7);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node5.new FileLevelJsDocBuilder();
        node5.setLineno(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention12, "goog.global", 41, 13);
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node18 = node16.getParent();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        compilerOptions0.strictMessageReplacement = false;
        compilerOptions0.optimizeReturns = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.lineBreak = true;
        java.lang.String str4 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions5.checkShadowVars;
        java.lang.String str7 = compilerOptions5.appNameStr;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.make("1100100", checkLevel10, "EOL");
        compilerOptions5.checkFunctions = checkLevel10;
        compilerOptions0.checkRequires = checkLevel10;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "// Input %num%" + "'", str4.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType12);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = node2.getJSDocInfo();
        java.lang.String str6 = node2.toString();
        boolean boolean7 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj12 = node10.getProp((int) (short) 1);
        boolean boolean13 = node10.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj17 = node15.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((-1), node10, node15, node20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable26 = node25.siblings();
        boolean boolean27 = node25.isNoSideEffectsCall();
        java.lang.String str28 = node25.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection29 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node25);
        node20.addChildrenToFront(node25);
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(10, node2, node20, 42, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(jSDocInfo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeIterable26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection29);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        compilerOptions0.renamePrefix = "JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)";
        boolean boolean5 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        java.lang.String str5 = node1.toString();
        boolean boolean6 = node1.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node8.setJSType(jSType11);
        boolean boolean13 = node8.hasOneChild();
        node8.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node16 = node1.copyInformationFrom(node8);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(format4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        java.lang.String str3 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode4 = compilerOptions0.tracer;
        compilerOptions0.smartNameRemoval = false;
        java.lang.String str7 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + tracerMode4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode4.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        boolean boolean3 = compilerOptions0.foldConstants;
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) 0, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray7;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.instrumentForCoverage = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        boolean boolean4 = compilerOptions0.lineBreak;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.inlineConstantVars = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean11 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean12 = compilerOptions0.generatePseudoNames;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str6 = node2.toString(true, false, true);
        boolean boolean7 = node2.isSyntheticBlock();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable11 = node10.siblings();
        node10.detachChildren();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) ' ', node2, node10, 0, (int) (short) 1);
        node15.detachChildren();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(42, node21);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node24 = null;
        boolean boolean25 = closureCodingConvention23.isVarArgsParameter(node24);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        closureCodingConvention23.applyDelegateRelationship(objectType26, objectType27, objectType28, functionType29, functionType30);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType34 = null;
        closureCodingConvention23.applySubclassRelationship(functionType32, functionType33, subclassType34);
        boolean boolean37 = closureCodingConvention23.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj41 = node39.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj46 = node44.getProp((int) (short) 1);
        boolean boolean47 = node44.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj51 = node49.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable55 = node54.siblings();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((-1), node44, node49, node54);
        boolean boolean57 = node54.wasEmptyNode();
        java.lang.String str58 = closureCodingConvention23.extractClassNameIfProvide(node39, node54);
        boolean boolean59 = node22.hasChild(node39);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable60 = node39.children();
        node15.addChildToBack(node39);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeIterable11);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeIterable55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(nodeIterable60);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.setTweakToNumberLiteral("com.google.javascript.rhino.EcmaError: TypeError: null is not a function, it is com.google.javascript.rhino.Node$StringNode.", 150);
        compilerOptions0.setOutputCharset("goog.global");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        compilerOptions0.setTweakToNumberLiteral("URSH ", 0);
        compilerOptions0.checkCaja = false;
        boolean boolean8 = compilerOptions0.groupVariableDeclarations;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing9 = compilerOptions0.getTweakProcessing();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing9.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(42, node5);
        com.google.javascript.rhino.Node node7 = node6.cloneTree();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup9;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray11 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8, diagnosticGroup9 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray11);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        boolean boolean18 = diagnosticGroup12.matches(diagnosticType14);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = diagnosticType24.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray28 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make(diagnosticType26, strArray28);
        com.google.javascript.jscomp.JSError jSError30 = nodeTraversal21.makeError(node23, diagnosticType24, strArray28);
        java.lang.Class<?> wildcardClass31 = strArray28.getClass();
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", node6, diagnosticType14, strArray28);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj37 = node35.getProp((int) (short) 1);
        boolean boolean38 = node35.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node39 = node35.getLastChild();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("language version");
        int int42 = node41.getLineno();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable46 = node45.siblings();
        boolean boolean47 = node45.isNoSideEffectsCall();
        java.lang.String str48 = node41.checkTreeEquals(node45);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(110, node35, node41);
        node6.addChildToFront(node49);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNotNull(diagnosticGroupArray11);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeIterable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str48.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(140);
        sideEffectFlags1.setMutatesGlobalState();
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node3.setVarArgs(true);
        com.google.javascript.rhino.Node node6 = node3.getParent();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(42, node11);
        boolean boolean13 = node3.isEquivalentTo(node12);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean16 = closureCodingConvention14.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str22 = node18.toString(true, false, true);
        boolean boolean23 = node18.hasOneChild();
        boolean boolean24 = closureCodingConvention14.isVarArgsParameter(node18);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node27.setVarArgs(true);
        com.google.javascript.rhino.Node node30 = node27.getParent();
        node27.putIntProp(0, (int) 'a');
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node3, node18, node27 };
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(3, nodeArray34);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString(100, "error reporter");
        com.google.javascript.rhino.Node node39 = node35.copyInformationFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(42, node44);
        com.google.javascript.rhino.Node node46 = node45.cloneTree();
        boolean boolean47 = node46.wasEmptyNode();
        boolean boolean48 = node35.hasChild(node46);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BITXOR" + "'", str22.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setChainCalls(true);
        compilerOptions0.checkTypedPropertyCalls = false;
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        context0.removeActivationName("");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.isGeneratingSource();
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node11 = null;
        boolean boolean12 = closureCodingConvention10.isVarArgsParameter(node11);
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean12, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean16 = jSError9.equals((java.lang.Object) (-1.0f));
        context0.seal((java.lang.Object) jSError9);
        com.google.javascript.rhino.Context context18 = com.google.javascript.rhino.Context.enter(context0);
        java.util.Locale locale19 = context18.getLocale();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(context18);
        org.junit.Assert.assertNotNull(locale19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, false);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter21 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15);
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(logger23);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = loggerErrorManager24.getErrors();
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        loggerErrorManager24.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray28 = loggerErrorManager24.getWarnings();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        com.google.javascript.jscomp.JSModule jSModule30 = null;
        try {
            java.lang.String[] strArray31 = compiler0.toSourceArray(jSModule30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(jSErrorArray28);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        compilerOptions0.reportPath = "0";
        compilerOptions0.instrumentationTemplate = "Not declared as a type name";
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "eof";
        compilerOptions0.jsOutputFile = "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        try {
            com.google.javascript.jscomp.JSModule jSModule4 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        java.lang.String str4 = node3.toString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NUMBER 0.0 35" + "'", str4.equals("NUMBER 0.0 35"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.nameReferenceReportPath = "JSC_NODE_TRAVERSAL_ERROR: {0}";
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str10 = closureCodingConvention9.getExportPropertyFunction();
        boolean boolean12 = closureCodingConvention9.isPrivate("");
        boolean boolean14 = closureCodingConvention9.isPrivate("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean18 = closureCodingConvention9.isOptionalParameter(node17);
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node17);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        boolean boolean25 = node22.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj29 = node27.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((-1), node22, node27, node32);
        node22.detachChildren();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj39 = node37.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = node37.getJSDocInfo();
        node37.setIsSyntheticBlock(false);
        java.lang.String str43 = node22.checkTreeEquals(node37);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("language version");
        node45.setQuotedString();
        int int47 = node45.getCharno();
        boolean boolean48 = node45.isNoSideEffectsCall();
        node22.addChildToFront(node45);
        boolean boolean50 = closureCodingConvention0.isVarArgsParameter(node22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(jSDocInfo40);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        java.lang.String str3 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode4 = compilerOptions0.tracer;
        com.google.javascript.jscomp.MessageBundle messageBundle5 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + tracerMode4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode4.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(messageBundle5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        boolean boolean3 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node2.getAncestors();
        com.google.javascript.rhino.Context context8 = new com.google.javascript.rhino.Context();
        context8.addActivationName("goog.abstractMethod");
        boolean boolean11 = context8.hasCompileFunctionsWithDynamicScope();
        int int12 = context8.getLanguageVersion();
        int int13 = context8.getOptimizationLevel();
        context8.setCompileFunctionsWithDynamicScope(false);
        node2.putProp((int) (byte) 100, (java.lang.Object) context8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention17 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str18 = closureCodingConvention17.getExportPropertyFunction();
        boolean boolean20 = closureCodingConvention17.isPrivate("");
        boolean boolean22 = closureCodingConvention17.isPrivate("hi!");
        java.lang.String str23 = closureCodingConvention17.getAbstractMethodName();
        boolean boolean25 = closureCodingConvention17.isExported("language version");
        com.google.javascript.rhino.jstype.FunctionType functionType26 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType28 = null;
        closureCodingConvention17.applySubclassRelationship(functionType26, functionType27, subclassType28);
        java.lang.RuntimeException runtimeException30 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) (byte) 100, (java.lang.Object) closureCodingConvention17);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "goog.exportProperty" + "'", str18.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.abstractMethod" + "'", str23.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(runtimeException30);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        node1.setQuotedString();
        int int3 = node1.getCharno();
        com.google.javascript.rhino.Node node4 = node1.cloneNode();
        boolean boolean5 = node1.isLocalResultCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup29 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup29;
        boolean boolean31 = composeWarningsGuard27.disables(diagnosticGroup29);
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup29;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup29;
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState12 = compiler3.getState();
        compiler0.setState(intermediateState12);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", charset15);
        jSSourceFile16.clearCachedSource();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler18, (java.util.List<com.google.javascript.rhino.Node>) nodeList20, callback22);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter24 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler18);
        java.nio.charset.Charset charset26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset26);
        java.lang.String str28 = jSSourceFile27.getOriginalPath();
        com.google.javascript.rhino.Node node29 = compiler18.parse(jSSourceFile27);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27, false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions32.checkShadowVars;
        boolean boolean34 = compilerOptions32.removeUnusedVars;
        compilerOptions32.renamePrefix = "JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)";
        com.google.javascript.jscomp.Result result37 = compiler0.compile(jSSourceFile16, jSSourceFile27, compilerOptions32);
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
        org.junit.Assert.assertNotNull(intermediateState12);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str28.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(result37);
    }
}

