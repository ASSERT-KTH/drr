import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        boolean boolean11 = closureCodingConvention0.isSuperClassReference("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        java.lang.String str5 = node3.getString();
        boolean boolean6 = detailLevel0.apply(node3);
        com.google.javascript.rhino.Node node8 = node3.getAncestor(39);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        int int2 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setMutatesGlobalState();
        boolean boolean6 = sideEffectFlags0.areAllFlagsSet();
        sideEffectFlags0.setMutatesArguments();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config6 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false);
        com.google.javascript.jscomp.parsing.Config config8 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter9 = null;
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", config8, errorReporter9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode4 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode4.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config6);
        org.junit.Assert.assertNotNull(config8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str16 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray26);
        com.google.javascript.jscomp.JSError jSError28 = nodeTraversal19.makeError(node21, diagnosticType22, strArray26);
        com.google.javascript.jscomp.Scope scope29 = nodeTraversal19.getScope();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention30 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str31 = closureCodingConvention30.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention30.isPrivate("");
        boolean boolean35 = closureCodingConvention30.isPrivate("hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node38.setVarArgs(true);
        com.google.javascript.rhino.Node node41 = node38.getParent();
        com.google.javascript.rhino.Node node42 = node38.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship43 = closureCodingConvention30.getDelegateRelationship(node38);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType45 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType46 = null;
        closureCodingConvention30.applySubclassRelationship(functionType44, functionType45, subclassType46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj52 = node50.getProp((int) (short) 1);
        boolean boolean53 = node50.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node54 = node50.getLastChild();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("language version");
        int int57 = node56.getLineno();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable61 = node60.siblings();
        boolean boolean62 = node60.isNoSideEffectsCall();
        java.lang.String str63 = node56.checkTreeEquals(node60);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(110, node50, node56);
        com.google.javascript.rhino.Node node66 = node64.getAncestor((int) (byte) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship67 = closureCodingConvention30.getDelegateRelationship(node66);
        node66.setType((int) (byte) 100);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast70 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal19, node66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNull(scope29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "goog.exportProperty" + "'", str31.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNull(node42);
        org.junit.Assert.assertNull(delegateRelationship43);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeIterable61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str63.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(delegateRelationship67);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("Unknown class name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Unknown class name" + "'", str1.equals("Unknown class name"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node1.setJSType(jSType4);
        int int6 = node1.getSideEffectFlags();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = closureCodingConvention0.isConstant("1100100");
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str13 = closureCodingConvention12.getExportPropertyFunction();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str20 = node16.toString(true, false, true);
        boolean boolean21 = node16.isSyntheticBlock();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable25 = node24.siblings();
        node24.detachChildren();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) ' ', node16, node24, 0, (int) (short) 1);
        boolean boolean30 = node16.isOnlyModifiesThisCall();
        boolean boolean31 = closureCodingConvention12.isVarArgsParameter(node16);
        try {
            java.util.List<java.lang.String> strList32 = closureCodingConvention0.identifyTypeDeclarationCall(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.exportProperty" + "'", str13.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BITXOR" + "'", str20.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeIterable25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt17 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, sourceExcerpt17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray26);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray30 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray30);
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray30);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType22, strArray30);
        try {
            java.lang.String str34 = lightweightMessageFormatter18.formatError(jSError33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str6 = node2.toString(true, false, true);
        boolean boolean7 = node2.isSyntheticBlock();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable11 = node10.siblings();
        node10.detachChildren();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) ' ', node2, node10, 0, (int) (short) 1);
        boolean boolean16 = node2.isOnlyModifiesThisCall();
        try {
            java.lang.String str17 = node2.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeIterable11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 41, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 0.");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        node2.detachChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("language version");
        int int18 = node17.getLineno();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        boolean boolean23 = node21.isNoSideEffectsCall();
        java.lang.String str24 = node17.checkTreeEquals(node21);
        java.lang.String str25 = node2.checkTreeEquals(node21);
        com.google.javascript.rhino.Node node26 = null;
        try {
            java.lang.String str27 = node2.checkTreeEquals(node26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str24.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n" + "'", str25.equals("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("EOF ", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection6 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node8 = null;
        boolean boolean9 = closureCodingConvention7.isVarArgsParameter(node8);
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        closureCodingConvention7.applyDelegateRelationship(objectType10, objectType11, objectType12, functionType13, functionType14);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        closureCodingConvention7.applySubclassRelationship(functionType16, functionType17, subclassType18);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection20 = closureCodingConvention7.getAssertionFunctions();
        boolean boolean22 = closureCodingConvention7.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str23 = closureCodingConvention7.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node24 = null;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable28 = node27.siblings();
        boolean boolean29 = node27.isNoSideEffectsCall();
        java.lang.String str30 = node27.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection31 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node27);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder32 = node27.new FileLevelJsDocBuilder();
        java.lang.String str33 = closureCodingConvention7.extractClassNameIfRequire(node24, node27);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean36 = node35.hasChildren();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection37 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node35);
        boolean boolean38 = closureCodingConvention7.isOptionalParameter(node35);
        try {
            boolean boolean39 = closureCodingConvention0.isPropertyTestFunction(node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeIterable28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(nodeCollection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        boolean boolean17 = compiler5.isIdeMode();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler18, (java.util.List<com.google.javascript.rhino.Node>) nodeList20, callback22);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker24 = compiler18.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt25 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter26 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler18, sourceExcerpt25);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState27 = compiler18.getState();
        compiler5.setState(intermediateState27);
        int int29 = compiler5.getWarningCount();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(performanceTracker24);
        org.junit.Assert.assertNotNull(intermediateState27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst2.getSourceFile();
        com.google.javascript.jscomp.SourceFile sourceFile6 = jsAst2.getSourceFile();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset15);
        java.lang.String str17 = jSSourceFile16.getOriginalPath();
        com.google.javascript.rhino.Node node18 = compiler7.parse(jSSourceFile16);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16, false);
        try {
            jsAst2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str17.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "goog.global", 41, 13);
        node4.setSourcePositionForTree((int) ' ');
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        boolean boolean4 = context0.isGeneratingSource();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node17.setVarArgs(true);
        com.google.javascript.rhino.Node node20 = node17.getParent();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(42, node25);
        boolean boolean27 = node17.isEquivalentTo(node26);
        com.google.javascript.jscomp.NodeTraversal.Callback callback28 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node26, callback28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        boolean boolean27 = compiler14.isIdeMode();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset29);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray31 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile30 };
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("<No stack trace available>", charset33);
        com.google.javascript.jscomp.Compiler compiler35 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList37 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList37, nodeArray36);
        com.google.javascript.jscomp.NodeTraversal.Callback callback39 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler35, (java.util.List<com.google.javascript.rhino.Node>) nodeList37, callback39);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter41 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler35);
        java.nio.charset.Charset charset43 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset43);
        java.lang.String str45 = jSSourceFile44.getOriginalPath();
        com.google.javascript.rhino.Node node46 = compiler35.parse(jSSourceFile44);
        com.google.javascript.jscomp.JsAst jsAst47 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile44);
        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList50 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList50, nodeArray49);
        com.google.javascript.jscomp.NodeTraversal.Callback callback52 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler48, (java.util.List<com.google.javascript.rhino.Node>) nodeList50, callback52);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter54 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler48);
        java.nio.charset.Charset charset56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset56);
        java.lang.String str58 = jSSourceFile57.getOriginalPath();
        com.google.javascript.rhino.Node node59 = compiler48.parse(jSSourceFile57);
        com.google.javascript.jscomp.CompilerInput compilerInput61 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile34, jSSourceFile44, jSSourceFile57 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = null;
        try {
            com.google.javascript.jscomp.Result result64 = compiler14.compile(jSSourceFileArray31, jSSourceFileArray62, compilerOptions63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str45.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str58.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        boolean boolean27 = compiler14.isIdeMode();
        com.google.javascript.jscomp.JSError jSError28 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel29 = compiler14.getErrorLevel(jSError28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        java.lang.String str2 = evaluatorException1.details();
        int int3 = evaluatorException1.lineNumber();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))" + "'", str2.equals("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.JSModule jSModule0 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj5 = node3.getProp((int) (short) 1);
        boolean boolean6 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1), node3, node8, node13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = null;
        node8.setJSDocInfo(jSDocInfo16);
        boolean boolean18 = detailLevel0.apply(node8);
        int int19 = node8.getType();
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray6);
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray6);
        java.lang.String str9 = jSError8.toString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", 19, 0);
        boolean boolean14 = jSError8.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str9.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "", (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("com.google.javascript.rhino.EvaluatorException: hi!", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node6 = node4.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        java.lang.String[] strArray12 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray26);
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray26);
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel18, diagnosticType19, strArray26);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("TypeError: <No stack trace available>", node6, checkLevel7, diagnosticType8, strArray26);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("Unknown class name");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, false);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter21 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15);
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(logger23);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = loggerErrorManager24.getErrors();
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        loggerErrorManager24.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray28 = loggerErrorManager24.getWarnings();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        try {
            com.google.javascript.jscomp.Region region32 = compiler0.getSourceRegion("", 47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(jSErrorArray28);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        int int3 = node2.getLineno();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] { node2, node6 };
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray7, 40, 0);
        int int11 = node10.getType();
        java.util.Set<java.lang.String> strSet12 = node10.getDirectives();
        boolean boolean13 = node10.isOptionalArg();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node2.setJSType(jSType4);
        java.lang.Object obj7 = node2.getProp(29);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = node9.getJSDocInfo();
        java.lang.String str13 = node9.toString();
        boolean boolean14 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node16.setJSType(jSType19);
        boolean boolean21 = node16.hasOneChild();
        node16.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node24 = node9.copyInformationFrom(node16);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder25 = node16.getJsDocBuilderForNode();
        node2.addChildToBack(node16);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BITXOR" + "'", str13.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder25);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.abstractMethod");
        java.lang.Throwable[] throwableArray2 = evaluatorException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node2, diagnosticType5, strArray8);
        node2.setString("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags13 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags13.setAllFlags();
        sideEffectFlags13.clearAllFlags();
        try {
            node2.setSideEffectFlags(sideEffectFlags13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(jSError10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("<No stack trace available>", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray11);
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType3, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = jSError14.getType();
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(diagnosticType15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(20, "");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString(28, "JSC_NODE_TRAVERSAL_ERROR: {0}");
        boolean boolean19 = node18.isLocalResultCall();
        java.lang.String str20 = closureCodingConvention0.extractClassNameIfRequire(node15, node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder25 = node24.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable29 = node28.siblings();
        boolean boolean30 = node28.isNoSideEffectsCall();
        java.lang.String str31 = node28.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection32 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node28);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(42, node37);
        boolean boolean39 = node38.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = null;
        node38.setJSDocInfo(jSDocInfo40);
        boolean boolean42 = node28.isEquivalentTo(node38);
        java.lang.String str43 = closureCodingConvention0.extractClassNameIfProvide(node24, node28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeIterable29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(str43);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.isGeneratingSource();
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node11 = null;
        boolean boolean12 = closureCodingConvention10.isVarArgsParameter(node11);
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean12, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean16 = jSError9.equals((java.lang.Object) (-1.0f));
        context0.seal((java.lang.Object) jSError9);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter19 = context0.setErrorReporter(errorReporter18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = compilerInput4.getSourceFile();
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        compilerInput4.setModule(jSModule8);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.siblings();
        boolean boolean7 = node5.isNoSideEffectsCall();
        java.lang.String str8 = node1.checkTreeEquals(node5);
        node1.setIsSyntheticBlock(true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str12 = closureCodingConvention11.getExportPropertyFunction();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str19 = node15.toString(true, false, true);
        boolean boolean20 = node15.isSyntheticBlock();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = node23.siblings();
        node23.detachChildren();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) ' ', node15, node23, 0, (int) (short) 1);
        boolean boolean29 = node15.isOnlyModifiesThisCall();
        boolean boolean30 = closureCodingConvention11.isVarArgsParameter(node15);
        try {
            com.google.javascript.rhino.Node node31 = node1.clonePropsFrom(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Node has existing properties.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str8.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BITXOR" + "'", str19.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeIterable24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "com.google.javascript.rhino.EcmaError: Unknown class name: hi! (JSC_NODE_TRAVERSAL_ERROR#11)", "goog.exportProperty");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean4 = closureCodingConvention1.isPrivate("");
        boolean boolean6 = closureCodingConvention1.isPrivate("hi!");
        java.lang.String str7 = closureCodingConvention1.getAbstractMethodName();
        boolean boolean9 = closureCodingConvention1.isExported("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str11 = closureCodingConvention10.getExportPropertyFunction();
        boolean boolean13 = closureCodingConvention10.isPrivate("");
        boolean boolean15 = closureCodingConvention10.isPrivate("hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean19 = closureCodingConvention10.isOptionalParameter(node18);
        java.lang.String str20 = closureCodingConvention1.identifyTypeDefAssign(node18);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable25 = node24.siblings();
        node24.detachChildren();
        node24.addSuppression("JSC_NODE_TRAVERSAL_ERROR: {0}");
        com.google.javascript.rhino.Node node29 = null;
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node32.setVarArgs(true);
        try {
            com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 0, node21, node24, node29, node32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeIterable25);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(42, node4);
        boolean boolean6 = node5.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = null;
        node5.setJSDocInfo(jSDocInfo7);
        com.google.javascript.rhino.jstype.JSType jSType9 = node5.getJSType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSType9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("1100100", generator1);
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1100100" + "'", str3.equals("1100100"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str8 = node4.toString(true, false, true);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        boolean boolean11 = node4.hasSideEffects();
        boolean boolean12 = node4.isSyntheticBlock();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR" + "'", str8.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup29 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup29;
        boolean boolean31 = composeWarningsGuard27.disables(diagnosticGroup29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        java.lang.String[] strArray40 = null;
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (short) 0, 20, checkLevel36, diagnosticType39, strArray40);
        com.google.javascript.jscomp.CheckLevel checkLevel42 = composeWarningsGuard27.level(jSError41);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNull(checkLevel42);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        node12.detachChildren();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(24, node9, node12, 6, (int) ' ');
        java.lang.String str18 = closureCodingConvention0.getSingletonGetterClassName(node17);
        com.google.javascript.rhino.Node node19 = null;
        try {
            node17.removeChild(node19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node6.siblings();
        node6.detachChildren();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(24, node3, node6, 6, (int) ' ');
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = null;
        node3.setJSDocInfo(jSDocInfo12);
        java.util.Set<java.lang.String> strSet14 = node3.getDirectives();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(nodeIterable7);
        org.junit.Assert.assertNull(strSet14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setMutatesArguments();
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "goog.global", 41, 13);
        int int5 = node4.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(42, node18);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node21 = null;
        boolean boolean22 = closureCodingConvention20.isVarArgsParameter(node21);
        com.google.javascript.rhino.jstype.ObjectType objectType23 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType24 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType25 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType26 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = null;
        closureCodingConvention20.applyDelegateRelationship(objectType23, objectType24, objectType25, functionType26, functionType27);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType31 = null;
        closureCodingConvention20.applySubclassRelationship(functionType29, functionType30, subclassType31);
        boolean boolean34 = closureCodingConvention20.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj38 = node36.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj43 = node41.getProp((int) (short) 1);
        boolean boolean44 = node41.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj48 = node46.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable52 = node51.siblings();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((-1), node41, node46, node51);
        boolean boolean54 = node51.wasEmptyNode();
        java.lang.String str55 = closureCodingConvention20.extractClassNameIfProvide(node36, node51);
        boolean boolean56 = node19.hasChild(node36);
        try {
            boolean boolean57 = closureCodingConvention0.isPropertyTestFunction(node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeIterable52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray2 = new java.lang.String[] { "" };
//        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType0.level;
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        diagnosticType0.level = checkLevel5;
//        java.text.MessageFormat messageFormat7 = diagnosticType0.format;
//        org.junit.Assert.assertNotNull(diagnosticType0);
//        org.junit.Assert.assertNotNull(strArray2);
//        org.junit.Assert.assertNotNull(jSError3);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(messageFormat7);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt17 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, sourceExcerpt17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray24 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList25 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList25, nodeArray24);
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler23, (java.util.List<com.google.javascript.rhino.Node>) nodeList25, callback27);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter29 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler23);
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset31);
        java.lang.String str33 = jSSourceFile32.getOriginalPath();
        com.google.javascript.rhino.Node node34 = compiler23.parse(jSSourceFile32);
        com.google.javascript.jscomp.JsAst jsAst35 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile32);
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset37);
        java.nio.charset.Charset charset40 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("<No stack trace available>", charset40);
        jSSourceFile41.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile20, jSSourceFile22, jSSourceFile32, jSSourceFile38, jSSourceFile41, jSSourceFile44 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray46 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = null;
        try {
            compiler5.init(jSSourceFileArray45, jSSourceFileArray46, compilerOptions47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(nodeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str33.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertNotNull(jSSourceFileArray46);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        boolean boolean5 = composeWarningsGuard3.disables(diagnosticGroup4);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.Node node9 = null;
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(26, "error reporter", (int) (short) 100, 3);
        java.lang.String str16 = closureCodingConvention0.identifyTypeDefAssign(node15);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("Unknown class name", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler0, nodeList1, callback2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.siblings();
        boolean boolean7 = node5.isNoSideEffectsCall();
        java.lang.String str8 = node1.checkTreeEquals(node5);
        java.lang.String str9 = node5.toString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean12 = node11.hasChildren();
        node11.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        boolean boolean19 = node17.isNoSideEffectsCall();
        node11.addChildrenToBack(node17);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder25 = node24.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node26 = node24.getLastSibling();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str32 = node28.toString(true, false, true);
        boolean boolean33 = node28.isSyntheticBlock();
        com.google.javascript.rhino.Node node34 = node26.copyInformationFromForTree(node28);
        node34.setVarArgs(true);
        try {
            node5.addChildBefore(node17, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str8.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "EOF " + "'", str9.equals("EOF "));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BITXOR" + "'", str32.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder10 = node8.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node8.setJSType(jSType11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.rhino.Node node9 = compiler0.getRoot();
        try {
            compiler0.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        java.lang.String str5 = node1.toString();
        boolean boolean6 = node1.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node8.setJSType(jSType11);
        boolean boolean13 = node8.hasOneChild();
        node8.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node16 = node1.copyInformationFrom(node8);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node8.getJsDocBuilderForNode();
        fileLevelJsDocBuilder17.append("");
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = node2.getJSDocInfo();
        java.lang.String str6 = node2.toString();
        boolean boolean7 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node9.setJSType(jSType12);
        boolean boolean14 = node9.hasOneChild();
        node9.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node17 = node2.copyInformationFrom(node9);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("language version");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node21, node25 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray26, 40, 0);
        node29.detachChildren();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(1, node9, node29);
        java.lang.String str32 = node31.toString();
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(jSDocInfo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "EOL" + "'", str32.equals("EOL"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getScriptStackTrace();
        java.lang.String str8 = ecmaError6.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("com.google.javascript.rhino.EvaluatorException: hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "com.google.javascript.rhino.EvaluatorException: hi!" + "'", str1.equals("com.google.javascript.rhino.EvaluatorException: hi!"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray12);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel4, diagnosticType5, strArray12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.defaultLevel;
        java.lang.String[] strArray20 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType16, strArray20);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType25.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray30 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray34 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(diagnosticType32, strArray34);
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray34);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel26, diagnosticType27, strArray34);
        diagnosticType16.level = checkLevel26;
        diagnosticType5.level = checkLevel26;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.Scope scope6 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        try {
            java.lang.String str8 = compiler0.toSource(jSModule7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        node2.detachChildren();
        boolean boolean5 = node2.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("<No stack trace available>", "EOL", "EOL", 24, "eof", 140);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (short) 0, 20, checkLevel4, diagnosticType7, strArray8);
        int int10 = jSError9.getCharno();
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray6);
        java.lang.String str8 = jSError7.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard3.level(jSError7);
        java.lang.String str10 = composeWarningsGuard3.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str8.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(42, node4);
        boolean boolean6 = node5.isLocalResultCall();
        node5.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("language version");
        int int11 = node10.getLineno();
        node10.removeProp(7);
        try {
            node5.removeChild(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType5.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.JSError jSError11 = nodeTraversal2.makeError(node4, diagnosticType5, strArray9);
        com.google.javascript.jscomp.Scope scope12 = nodeTraversal2.getScope();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(42, node17);
        com.google.javascript.rhino.Node node19 = node18.cloneTree();
        com.google.javascript.rhino.Node node20 = node19.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray26);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make(diagnosticType29, strArray31);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray33 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType24, diagnosticType28, diagnosticType29 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray33);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray37 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray37);
        java.lang.Class<?> wildcardClass39 = diagnosticType35.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel43 = diagnosticType42.level;
        diagnosticType35.level = checkLevel43;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard45 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup34, checkLevel43);
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler47 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback48 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal49 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler47, callback48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = diagnosticType52.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray56 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make(diagnosticType54, strArray56);
        com.google.javascript.jscomp.JSError jSError58 = nodeTraversal49.makeError(node51, diagnosticType52, strArray56);
        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make("goog.abstractMethod", (int) (short) -1, 8, checkLevel43, diagnosticType46, strArray56);
        com.google.javascript.jscomp.CheckLevel checkLevel60 = diagnosticType46.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType64 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel65 = diagnosticType64.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray69 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make(diagnosticType67, strArray69);
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray73 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make(diagnosticType71, strArray73);
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make(diagnosticType67, strArray73);
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel65, diagnosticType66, strArray73);
        com.google.javascript.jscomp.JSError jSError77 = nodeTraversal2.makeError(node20, diagnosticType46, strArray73);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNull(scope12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticTypeArray33);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType64);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(strArray69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(jSError75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertNotNull(jSError77);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a constructor", "", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(42, node11);
        boolean boolean13 = node12.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = null;
        node12.setJSDocInfo(jSDocInfo14);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder16 = node12.new FileLevelJsDocBuilder();
        node12.setLineno(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node23 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention19, "goog.global", 41, 13);
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node12, callback25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler3 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler3, callback4);
        com.google.javascript.rhino.Node node6 = nodeTraversal5.getCurrentNode();
        java.lang.String str7 = nodeTraversal5.getSourceName();
        com.google.javascript.rhino.Node node8 = nodeTraversal5.getEnclosingFunction();
        java.lang.String str9 = nodeTraversal5.getSourceName();
        com.google.javascript.rhino.Node node10 = nodeTraversal5.getEnclosingFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        node13.detachChildren();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast16 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal5, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            com.google.javascript.rhino.Context.reportError("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: <No stack trace available>");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = composeWarningsGuard3.level(jSError9);
        java.lang.String str11 = composeWarningsGuard3.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNull(checkLevel10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter17 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5);
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler18, (java.util.List<com.google.javascript.rhino.Node>) nodeList20, callback22);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter24 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler18);
        java.nio.charset.Charset charset26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset26);
        java.lang.String str28 = jSSourceFile27.getOriginalPath();
        com.google.javascript.rhino.Node node29 = compiler18.parse(jSSourceFile27);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile27, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = null;
        try {
            com.google.javascript.jscomp.Result result34 = compiler5.compile(jSSourceFile27, jSSourceFileArray32, compilerOptions33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str28.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        try {
            int int10 = compiler0.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler0.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType6, objectType7, objectType8, functionType9, functionType10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(34);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "setprop" + "'", str1.equals("setprop"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str8 = node4.toString(true, false, true);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        boolean boolean11 = node4.hasSideEffects();
        java.lang.String str12 = node4.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR" + "'", str8.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BITXOR" + "'", str12.equals("BITXOR"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput4.setModule(jSModule7);
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(1.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString(0.0d, 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("(goog.exportProperty)", "JSC_NODE_TRAVERSAL_ERROR: {0}");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (goog.exportProperty)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            com.google.javascript.rhino.Context.reportError("goog.exportProperty", "Named type with empty name component", 10, "JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)", 46);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportProperty (Named type with empty name component#10)");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj6 = node4.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node4.setJSType(jSType7);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.sourceName();
        try {
            ecmaError6.initSourceName("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType5.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.JSError jSError11 = nodeTraversal2.makeError(node4, diagnosticType5, strArray9);
        com.google.javascript.jscomp.Scope scope12 = nodeTraversal2.getScope();
        java.lang.String str13 = nodeTraversal2.getSourceName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNull(scope12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean13 = closureCodingConvention0.isOptionalParameter(node12);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection14 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection14);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("<No stack trace available>");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!");
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = evaluatorException3.getScriptStackTrace(filenameFilter4);
        evaluatorException3.initLineSource("hi!");
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException3);
        java.lang.Throwable[] throwableArray9 = ecmaError1.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.JSModule jSModule5 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("JSC_NODE_TRAVERSAL_ERROR: {0}", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", 44);
        try {
            evaluatorException3.initLineNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNull(errorReporter1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable8 = node7.siblings();
        node7.detachChildren();
        com.google.javascript.rhino.Node node10 = null;
        boolean boolean11 = node7.hasChild(node10);
        context0.seal((java.lang.Object) node10);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeIterable8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        try {
            context5.setLanguageVersion((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("error reporter", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection6 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(42, node11);
        com.google.javascript.rhino.Node node13 = node12.cloneTree();
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        java.lang.String str15 = closureCodingConvention0.identifyTypeDefAssign(node13);
        com.google.javascript.rhino.Node node16 = null;
        try {
            com.google.javascript.rhino.Node node17 = node13.copyInformationFrom(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str16 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection17 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.global" + "'", str16.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection17);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            com.google.javascript.rhino.Context.reportWarning("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", (int) 'a', "eof", 7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable29 = node9.getAncestors();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(ancestorIterable29);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        int int2 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setAllFlags();
        sideEffectFlags0.setMutatesGlobalState();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.rhino.Node node3 = compiler1.getRoot();
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj6 = node4.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node4.setJSType(jSType7);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        com.google.javascript.rhino.EvaluatorException evaluatorException15 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException17 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException15.addSuppressed((java.lang.Throwable) runtimeException17);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj23 = node21.getProp((int) (short) 1);
        boolean boolean24 = node21.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node25 = node21.getLastChild();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("language version");
        int int28 = node27.getLineno();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        boolean boolean33 = node31.isNoSideEffectsCall();
        java.lang.String str34 = node27.checkTreeEquals(node31);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(110, node21, node27);
        com.google.javascript.rhino.Node node37 = node35.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException38 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException17, (java.lang.Object) node37);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 10);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(42, node45);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(17, node37, node40, node46, 49, 45);
        com.google.javascript.rhino.Node node50 = node37.getLastChild();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString(26, "error reporter", (int) (short) 100, 3);
        com.google.javascript.rhino.Node node56 = node37.copyInformationFromForTree(node55);
        java.util.List<java.lang.String> strList57 = closureCodingConvention0.identifyTypeDeclarationCall(node37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(runtimeException17);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str34.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(runtimeException38);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(strList57);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(32);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 1.0d, (java.lang.Object) jSSourceFile6);
        try {
            jsAst3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        int int3 = node2.getLineno();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] { node2, node6 };
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray7, 40, 0);
        int int11 = node10.getType();
        boolean boolean12 = node10.hasSideEffects();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node10);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable14 = node10.getAncestors();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(ancestorIterable14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection6 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(42, node11);
        com.google.javascript.rhino.Node node13 = node12.cloneTree();
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        java.lang.String str15 = closureCodingConvention0.identifyTypeDefAssign(node13);
        int int16 = node13.getChildCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        compiler5.reportCodeChange();
        boolean boolean8 = compiler5.isIdeMode();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        try {
            int int3 = diagnosticType0.compareTo(diagnosticType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection12 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str13 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.abstractMethod" + "'", str13.equals("goog.abstractMethod"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        boolean boolean10 = diagnosticGroup4.matches(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) (short) 0, 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        compiler5.reportCodeChange();
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("Named type with empty name component", charset9);
        com.google.javascript.rhino.Node node11 = compiler5.parse(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(42, node4);
        boolean boolean6 = node5.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = null;
        node5.setJSDocInfo(jSDocInfo7);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node5.new FileLevelJsDocBuilder();
        node5.setLineno(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention12, "goog.global", 41, 13);
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        int int18 = node16.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        try {
            compiler0.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        jsAst3.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        try {
            java.lang.String[] strArray12 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        compiler5.reportCodeChange();
        try {
            compiler5.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            boolean boolean6 = compiler0.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        node2.setJSType(jSType15);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        java.lang.String str4 = jSError3.description;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst7, false);
        boolean boolean10 = compilerInput9.isExtern();
        boolean boolean11 = compilerInput9.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst12 = compilerInput9.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst12);
        context0.seal((java.lang.Object) sourceAst12);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(sourceAst12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        boolean boolean4 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)", "goog.exportSymbol");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) "goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray15);
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray15);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType7, strArray15);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray21 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType19, strArray21);
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("error reporter", 120, 3, checkLevel3, diagnosticType7, strArray21);
        java.lang.RuntimeException runtimeException25 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        boolean boolean26 = jSError23.equals((java.lang.Object) runtimeException25);
        java.lang.String str27 = jSError23.sourceName;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(runtimeException25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "error reporter" + "'", str27.equals("error reporter"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        java.lang.String[] strArray13 = null;
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (short) 0, 20, checkLevel9, diagnosticType12, strArray13);
        boolean boolean15 = diagnosticGroup4.matches(jSError14);
        int int16 = jSError14.getCharno();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceAst5, "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", false);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst5, false);
        com.google.javascript.jscomp.JSModule jSModule11 = compilerInput10.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceAst5);
        org.junit.Assert.assertNull(jSModule11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.text.MessageFormat messageFormat1 = diagnosticType0.format;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(messageFormat1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = null;
        compiler5.tracker = performanceTracker17;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset22);
        com.google.javascript.jscomp.Region region25 = jSSourceFile23.getRegion(2);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile20, jSSourceFile23 };
        com.google.javascript.jscomp.JSModule jSModule27 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray28 = new com.google.javascript.jscomp.JSModule[] { jSModule27 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = null;
        try {
            compiler5.init(jSSourceFileArray26, jSModuleArray28, compilerOptions29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(region25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray28);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        boolean boolean15 = node12.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node16 = node12.getLastChild();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("language version");
        int int19 = node18.getLineno();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable23 = node22.siblings();
        boolean boolean24 = node22.isNoSideEffectsCall();
        java.lang.String str25 = node18.checkTreeEquals(node22);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(110, node12, node18);
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node18, callback27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeIterable23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str25.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(42, node10);
        boolean boolean12 = node2.isEquivalentTo(node11);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder13 = node2.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("1100100", "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup10;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        int int5 = context0.getOptimizationLevel();
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("JSC_NODE_TRAVERSAL_ERROR: {0}", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", 44);
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("<No stack trace available>");
        com.google.javascript.rhino.EvaluatorException evaluatorException7 = new com.google.javascript.rhino.EvaluatorException("hi!");
        java.io.FilenameFilter filenameFilter8 = null;
        java.lang.String str9 = evaluatorException7.getScriptStackTrace(filenameFilter8);
        evaluatorException7.initLineSource("hi!");
        ecmaError5.addSuppressed((java.lang.Throwable) evaluatorException7);
        java.lang.String str13 = ecmaError5.details();
        ecmaError5.initSourceName("");
        ecmaError5.initColumnNumber(10);
        evaluatorException3.addSuppressed((java.lang.Throwable) ecmaError5);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TypeError: <No stack trace available>" + "'", str13.equals("TypeError: <No stack trace available>"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        int int2 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setAllFlags();
        sideEffectFlags0.setReturnsTainted();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter8, logger9);
        com.google.javascript.jscomp.JSError jSError11 = null;
        try {
            java.lang.String str12 = lightweightMessageFormatter8.formatWarning(jSError11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node2.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor7 = ancestorIterable6.iterator();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor8 = ancestorIterable6.iterator();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertNotNull(nodeItor7);
        org.junit.Assert.assertNotNull(nodeItor8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str16 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node17 = null;
        boolean boolean18 = closureCodingConvention0.isVarArgsParameter(node17);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(runtimeException19);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "(goog.exportProperty)", 120, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException4.addSuppressed((java.lang.Throwable) runtimeException6);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj12 = node10.getProp((int) (short) 1);
        boolean boolean13 = node10.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = node10.getLastChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("language version");
        int int17 = node16.getLineno();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        boolean boolean22 = node20.isNoSideEffectsCall();
        java.lang.String str23 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(110, node10, node16);
        com.google.javascript.rhino.Node node26 = node24.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException6, (java.lang.Object) node26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(42, node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(17, node26, node29, node35, 49, 45);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj43 = node41.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(33, node41);
        try {
            com.google.javascript.rhino.Node node45 = node38.removeChildAfter(node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str23.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(obj43);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst2.getSourceFile();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList8 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList8, nodeArray7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler6, (java.util.List<com.google.javascript.rhino.Node>) nodeList8, callback10);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter12 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
        java.nio.charset.Charset charset14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset14);
        java.lang.String str16 = jSSourceFile15.getOriginalPath();
        com.google.javascript.rhino.Node node17 = compiler6.parse(jSSourceFile15);
        com.google.javascript.rhino.Node node18 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str16.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNull(node18);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter8, logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (byte) 100, node2, 26, 31);
        try {
            java.lang.String str9 = node2.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)", "com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node3.getLastSibling();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str11 = node7.toString(true, false, true);
        boolean boolean12 = node7.isSyntheticBlock();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node7);
        node13.setVarArgs(true);
        node13.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR" + "'", str11.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        context0.removeActivationName("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n");
        java.lang.String str5 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray10 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray14);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.jscomp.Compiler compiler20 = nodeTraversal19.getCompiler();
        com.google.javascript.rhino.Node node21 = nodeTraversal19.getEnclosingFunction();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj26 = node24.getProp((int) (short) 1);
        boolean boolean27 = node24.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj31 = node29.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((-1), node24, node29, node34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray39 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(diagnosticType37, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = diagnosticType37.level;
        java.lang.String str42 = diagnosticType37.toString();
        java.lang.String str43 = diagnosticType37.toString();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray52 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node46, diagnosticType49, strArray52);
        com.google.javascript.jscomp.JSError jSError55 = nodeTraversal19.makeError(node29, diagnosticType37, strArray52);
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal2.makeError(node6, checkLevel7, diagnosticType8, strArray52);
        try {
            com.google.javascript.jscomp.JSModule jSModule57 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNull(compiler20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str42.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str43.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(jSError56);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        java.lang.String str5 = node1.toString();
        boolean boolean6 = node1.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = node1.getLastSibling();
        boolean boolean8 = node1.isNoSideEffectsCall();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler14, callback27);
        boolean boolean29 = compiler14.acceptConstKeyword();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("goog.abstractMethod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection5 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str7 = closureCodingConvention6.getExportPropertyFunction();
        boolean boolean9 = closureCodingConvention6.isPrivate("");
        boolean boolean11 = closureCodingConvention6.isPrivate("hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean15 = closureCodingConvention6.isOptionalParameter(node14);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention6.getAssertionFunctions();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean19 = closureCodingConvention6.isOptionalParameter(node18);
        java.lang.String str20 = node4.checkTreeEquals(node18);
        com.google.javascript.rhino.Node node21 = node18.getParent();
        boolean boolean22 = node18.isOptionalArg();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder23 = node18.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean26 = node25.hasChildren();
        node25.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        boolean boolean33 = node31.isNoSideEffectsCall();
        node25.addChildrenToBack(node31);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray35 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList36 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList36, warningsGuardArray35);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard38 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList36);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst41 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile40);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst41, false);
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler();
        compilerInput43.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler44);
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make(diagnosticType46, strArray48);
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray52 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make(diagnosticType46, strArray52);
        com.google.javascript.jscomp.CheckLevel checkLevel55 = compiler44.getErrorLevel(jSError54);
        boolean boolean56 = compiler44.isIdeMode();
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler57, (java.util.List<com.google.javascript.rhino.Node>) nodeList59, callback61);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker63 = compiler57.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler57, sourceExcerpt64);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState66 = compiler57.getState();
        compiler44.setState(intermediateState66);
        try {
            java.lang.String str68 = com.google.javascript.rhino.ScriptRuntime.getMessage4("JSC_NODE_TRAVERSAL_ERROR", (java.lang.Object) node18, (java.lang.Object) node25, (java.lang.Object) composeWarningsGuard38, (java.lang.Object) intermediateState66);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeCollection5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportProperty" + "'", str7.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n" + "'", str20.equals("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n"));
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNull(checkLevel55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(performanceTracker63);
        org.junit.Assert.assertNotNull(intermediateState66);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset8);
        java.lang.String str10 = jSSourceFile9.getOriginalPath();
        com.google.javascript.rhino.Node node11 = compiler0.parse(jSSourceFile9);
        boolean boolean12 = compiler0.acceptEcmaScript5();
        try {
            compiler0.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str10.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("Named type with empty name component", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        try {
            int int3 = compiler1.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            java.lang.String[] strArray6 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("setprop", "error reporter", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        java.lang.Class<?> wildcardClass15 = diagnosticType11.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.level;
        diagnosticType11.level = checkLevel19;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard21 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType25.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray30 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray34 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(diagnosticType32, strArray34);
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray34);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel26, diagnosticType27, strArray34);
        java.lang.String str38 = jSError37.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticGroupWarningsGuard21.level(jSError37);
        java.lang.String str40 = jSError37.sourceName;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = closureCodingConvention0.isConstant("1100100");
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bitor" + "'", str1.equals("bitor"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        int int7 = ecmaError6.lineNumber();
        java.lang.String str8 = ecmaError6.sourceName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 150 + "'", int7 == 150);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("language version", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "language version" + "'", str3.equals("language version"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter27 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        com.google.javascript.jscomp.Scope scope28 = compiler14.getTopScope();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNull(scope28);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str6 = closureCodingConvention5.getExportPropertyFunction();
        boolean boolean8 = closureCodingConvention5.isPrivate("");
        boolean boolean10 = closureCodingConvention5.isPrivate("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean14 = closureCodingConvention5.isOptionalParameter(node13);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection15 = closureCodingConvention5.getAssertionFunctions();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean18 = closureCodingConvention5.isOptionalParameter(node17);
        java.lang.String str19 = node3.checkTreeEquals(node17);
        com.google.javascript.rhino.Node node20 = node17.getParent();
        boolean boolean21 = node17.isOptionalArg();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder22 = node17.getJsDocBuilderForNode();
        java.lang.String str23 = node17.toStringTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeCollection4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n" + "'", str19.equals("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n"));
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "OR\n" + "'", str23.equals("OR\n"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        boolean boolean4 = context0.isGeneratingSource();
        context0.setCompileFunctionsWithDynamicScope(false);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = context0.getErrorReporter();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(errorReporter7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node2.setJSType(jSType4);
        java.lang.Object obj7 = node2.getProp(29);
        node2.setSourcePositionForTree(0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNull(obj7);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray2 = new java.lang.String[] { "" };
//        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray7 = new java.lang.String[] { "" };
//        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray13 = new java.lang.String[] { "" };
//        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
//        java.lang.Class<?> wildcardClass15 = diagnosticType11.getClass();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
//        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.level;
//        diagnosticType11.level = checkLevel19;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard21 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel19);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
//        boolean boolean23 = diagnosticGroupWarningsGuard21.disables(diagnosticGroup22);
//        org.junit.Assert.assertNotNull(diagnosticType0);
//        org.junit.Assert.assertNotNull(strArray2);
//        org.junit.Assert.assertNotNull(jSError3);
//        org.junit.Assert.assertNotNull(diagnosticType4);
//        org.junit.Assert.assertNotNull(diagnosticType5);
//        org.junit.Assert.assertNotNull(strArray7);
//        org.junit.Assert.assertNotNull(jSError8);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
//        org.junit.Assert.assertNotNull(diagnosticType11);
//        org.junit.Assert.assertNotNull(strArray13);
//        org.junit.Assert.assertNotNull(jSError14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(diagnosticType18);
//        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNull(diagnosticGroup22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler0.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler1, callback2);
        boolean boolean4 = nodeTraversal3.hasScope();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray15);
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray15);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler18 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler18, callback19);
        com.google.javascript.jscomp.Compiler compiler21 = nodeTraversal20.getCompiler();
        com.google.javascript.rhino.Node node22 = nodeTraversal20.getEnclosingFunction();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj27 = node25.getProp((int) (short) 1);
        boolean boolean28 = node25.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj32 = node30.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable36 = node35.siblings();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((-1), node25, node30, node35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray40 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make(diagnosticType38, strArray40);
        com.google.javascript.jscomp.CheckLevel checkLevel42 = diagnosticType38.level;
        java.lang.String str43 = diagnosticType38.toString();
        java.lang.String str44 = diagnosticType38.toString();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray53 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make(diagnosticType51, strArray53);
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node47, diagnosticType50, strArray53);
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal20.makeError(node30, diagnosticType38, strArray53);
        com.google.javascript.jscomp.JSError jSError57 = nodeTraversal3.makeError(node7, checkLevel8, diagnosticType9, strArray53);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.make("1100100", checkLevel8, "EOF ");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNull(compiler21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeIterable36);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str43.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str44.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertNotNull(diagnosticType59);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        boolean boolean15 = compiler7.isTypeCheckingEnabled();
        boolean boolean16 = compiler7.isTypeCheckingEnabled();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.rhino.EvaluatorException evaluatorException8 = new com.google.javascript.rhino.EvaluatorException("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        int int9 = evaluatorException8.lineNumber();
        java.lang.String str10 = evaluatorException8.lineSource();
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) diagnosticGroup4, (java.lang.Object) str10);
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(runtimeException11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput4.getSourceFile();
        java.lang.String str7 = sourceFile6.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceAst5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "error reporter" + "'", str7.equals("error reporter"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray6);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType4.level;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node13.setVarArgs(true);
        boolean boolean16 = detailLevel10.apply(node13);
        boolean boolean17 = node13.hasOneChild();
        java.lang.String str18 = node13.getQualifiedName();
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType25, strArray27);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray29 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType20, diagnosticType24, diagnosticType25 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray33 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType31, strArray33);
        java.lang.Class<?> wildcardClass35 = diagnosticType31.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticType38.level;
        diagnosticType31.level = checkLevel39;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard41 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup30, checkLevel39);
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.make("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", checkLevel39, "Unknown class name");
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.CheckLevel checkLevel48 = diagnosticType44.level;
        java.lang.String str49 = diagnosticType44.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = diagnosticType50.defaultLevel;
        java.lang.String[] strArray54 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray54);
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", node13, checkLevel39, diagnosticType44, strArray54);
        diagnosticType4.level = checkLevel39;
        boolean boolean58 = diagnosticGroup0.matches(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(diagnosticTypeArray29);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str49.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj23 = node21.getProp((int) (short) 1);
        boolean boolean24 = node21.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj28 = node26.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((-1), node21, node26, node31);
        boolean boolean34 = node31.wasEmptyNode();
        java.lang.String str35 = closureCodingConvention0.extractClassNameIfProvide(node16, node31);
        node16.putIntProp(0, 43);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        boolean boolean10 = node7.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((-1), node7, node12, node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType20.level;
        java.lang.String str25 = diagnosticType20.toString();
        java.lang.String str26 = diagnosticType20.toString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node29, diagnosticType32, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node12, diagnosticType20, strArray35);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        node42.removeProp(8);
        try {
            nodeTraversal2.traverse(node42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str25.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(node42);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            com.google.javascript.rhino.Context.reportWarning("language version", "goog.exportProperty", 3, "language version", 12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        java.lang.Object obj4 = context0.getDebuggerContextData();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.defaultLevel;
        java.lang.String[] strArray11 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray11);
        java.lang.String str13 = lightweightMessageFormatter6.formatWarning(jSError12);
        lightweightMessageFormatter6.setColorize(false);
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter6, logger16);
        double double18 = loggerErrorManager17.getTypedPercent();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n" + "'", str13.equals("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback11);
        try {
            com.google.javascript.jscomp.Result result13 = compiler0.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("EOF ", "setprop", "goog.global");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter9, logger10);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        java.lang.String str4 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node5 = nodeTraversal2.getEnclosingFunction();
        java.lang.String str6 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node7 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.rhino.Node node8 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.Node node9 = null;
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("language version");
        int int13 = node12.getLineno();
        node12.setType(32);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship16 = closureCodingConvention0.getClassesDefinedByCall(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("bitor", "setprop");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray3 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType1, strArray3);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray10 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType1, diagnosticType5, diagnosticType6 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        java.lang.Class<?> wildcardClass16 = diagnosticType12.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel20 = diagnosticType19.level;
        diagnosticType12.level = checkLevel20;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel20);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.make("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", checkLevel20, "Unknown class name");
        java.lang.String str25 = diagnosticType24.toString();
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(jSError4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(diagnosticTypeArray10);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name" + "'", str25.equals("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt17 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, sourceExcerpt17);
        compiler5.disableThreads();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n)" + "'", str1.equals("(Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n)"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType10, functionType11, objectType12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("JSC_NODE_TRAVERSAL_ERROR: {0}", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", 44);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean6 = node5.hasChildren();
        node5.setType(0);
        node5.removeProp((int) 'a');
        com.google.javascript.rhino.EcmaError ecmaError17 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str18 = ecmaError17.getLineSource();
        java.lang.String str19 = ecmaError17.getName();
        ecmaError17.initColumnNumber(3);
        java.lang.RuntimeException runtimeException22 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) "JSC_NODE_TRAVERSAL_ERROR: {0}", (java.lang.Object) node5, (java.lang.Object) ecmaError17);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(ecmaError17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BITXOR" + "'", str19.equals("BITXOR"));
        org.junit.Assert.assertNotNull(runtimeException22);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        context0.setCompileFunctionsWithDynamicScope(false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray4 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup("EOL", diagnosticGroupArray4);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroupArray4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.rhino.Context context5 = new com.google.javascript.rhino.Context();
        java.util.Locale locale6 = context5.getLocale();
        java.util.Locale locale7 = context0.setLocale(locale6);
        boolean boolean8 = context0.hasCompileFunctionsWithDynamicScope();
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        node7.setJSDocInfo(jSDocInfo15);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel18 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node21.setVarArgs(true);
        boolean boolean24 = detailLevel18.apply(node21);
        boolean boolean25 = node21.isVarArgs();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel26 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node29.setVarArgs(true);
        boolean boolean32 = detailLevel26.apply(node29);
        boolean boolean33 = node29.isVarArgs();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(0, node21, node29, 36, 140);
        try {
            node7.addChildrenToFront(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(detailLevel18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(detailLevel26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(42, node10);
        boolean boolean12 = node2.isEquivalentTo(node11);
        java.lang.RuntimeException runtimeException13 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node11);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(runtimeException13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str16 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node17 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        boolean boolean22 = node20.isNoSideEffectsCall();
        java.lang.String str23 = node20.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection24 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node20);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder25 = node20.new FileLevelJsDocBuilder();
        java.lang.String str26 = closureCodingConvention0.extractClassNameIfRequire(node17, node20);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("language version");
        int int29 = node28.getLineno();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        boolean boolean34 = node32.isNoSideEffectsCall();
        java.lang.String str35 = node28.checkTreeEquals(node32);
        node28.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node38 = node28.removeFirstChild();
        try {
            java.lang.String str39 = closureCodingConvention0.identifyTypeDefAssign(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str35.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNull(node38);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        boolean boolean4 = context0.isGeneratingSource();
        context0.setCompileFunctionsWithDynamicScope(false);
        java.lang.Object obj7 = null;
        context0.seal(obj7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        java.lang.String str4 = jSError3.toString();
        java.lang.String str5 = jSError3.sourceName;
        java.lang.String str6 = jSError3.description;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = jSError3.getType();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str4.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            compiler0.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean13 = closureCodingConvention0.isOptionalParameter(node12);
        com.google.javascript.rhino.Node node14 = node12.getLastChild();
        com.google.javascript.rhino.Node node16 = node12.getChildAtIndex(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node16);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("goog.global", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        try {
            int int7 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        java.lang.String str5 = node3.getString();
        boolean boolean6 = detailLevel0.apply(node3);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node13 = node9.getLastChild();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("language version");
        int int16 = node15.getLineno();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        boolean boolean21 = node19.isNoSideEffectsCall();
        java.lang.String str22 = node15.checkTreeEquals(node19);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(110, node9, node15);
        com.google.javascript.rhino.Node node25 = node23.getAncestor((int) (byte) 0);
        boolean boolean26 = detailLevel0.apply(node23);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str22.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Compiler compiler4 = nodeTraversal2.getCompiler();
        try {
            com.google.javascript.jscomp.JSModule jSModule5 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(compiler4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        compiler5.reportCodeChange();
        com.google.javascript.jscomp.JSError[] jSErrorArray8 = compiler5.getWarnings();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSErrorArray8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        java.lang.Object obj4 = context0.getDebuggerContextData();
        context0.addActivationName("com.google.javascript.rhino.EcmaError: Unknown class name: hi! (JSC_NODE_TRAVERSAL_ERROR#11)");
        try {
            context0.setLanguageVersion(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        java.lang.String[] strArray4 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node7 = null;
        boolean boolean8 = closureCodingConvention6.isVarArgsParameter(node7);
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean8, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean12 = jSError5.equals((java.lang.Object) (-1.0f));
        int int13 = jSError5.getCharno();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", "");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = node2.getJSDocInfo();
        java.lang.String str6 = node2.toString();
        boolean boolean7 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node9.setJSType(jSType12);
        boolean boolean14 = node9.hasOneChild();
        node9.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node17 = node2.copyInformationFrom(node9);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("language version");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node21, node25 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray26, 40, 0);
        node29.detachChildren();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(1, node9, node29);
        com.google.javascript.rhino.Node node33 = node31.getAncestor(120);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(jSDocInfo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(node33);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState14 = compiler13.getState();
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = compiler15.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, sourceExcerpt22);
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter23, logger24);
        compiler13.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        try {
            java.lang.String[] strArray28 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(intermediateState14);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(performanceTracker21);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = node2.getJSDocInfo();
        java.lang.String str6 = node2.toString();
        boolean boolean7 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        node9.setJSType(jSType12);
        boolean boolean14 = node9.hasOneChild();
        node9.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node17 = node2.copyInformationFrom(node9);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder18 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("language version");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node21, node25 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray26, 40, 0);
        node29.detachChildren();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(1, node9, node29);
        int int32 = node9.getSourcePosition();
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(jSDocInfo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        boolean boolean4 = context0.isGeneratingSource();
        context0.removeActivationName("JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node6 = node2.getLastChild();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("language version");
        int int9 = node8.getLineno();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        boolean boolean14 = node12.isNoSideEffectsCall();
        java.lang.String str15 = node8.checkTreeEquals(node12);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(110, node2, node8);
        com.google.javascript.rhino.Node node18 = node16.getAncestor((int) (byte) 0);
        try {
            double double19 = node16.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: SWITCH is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str15.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback11);
        com.google.javascript.jscomp.Scope scope13 = nodeTraversal12.getScope();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNull(scope13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        boolean boolean7 = closureCodingConvention0.isConstantKey("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("(goog.exportProperty)", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.aliasExternals = true;
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj23 = node21.getProp((int) (short) 1);
        boolean boolean24 = node21.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj28 = node26.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((-1), node21, node26, node31);
        boolean boolean34 = node31.wasEmptyNode();
        java.lang.String str35 = closureCodingConvention0.extractClassNameIfProvide(node16, node31);
        java.lang.String str36 = node31.toStringTree();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "EOF \n" + "'", str36.equals("EOF \n"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(42, node6);
        boolean boolean8 = node7.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node7.setJSDocInfo(jSDocInfo9);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder11 = node7.new FileLevelJsDocBuilder();
        node7.setLineno(0);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) -1, node7);
        try {
            com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-3), node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        int int2 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesThis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node2.getAncestors();
        com.google.javascript.rhino.Context context8 = new com.google.javascript.rhino.Context();
        context8.addActivationName("goog.abstractMethod");
        boolean boolean11 = context8.hasCompileFunctionsWithDynamicScope();
        int int12 = context8.getLanguageVersion();
        int int13 = context8.getOptimizationLevel();
        context8.setCompileFunctionsWithDynamicScope(false);
        node2.putProp((int) (byte) 100, (java.lang.Object) context8);
        int int17 = context8.getOptimizationLevel();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        try {
            context8.removePropertyChangeListener(propertyChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        node9.putBooleanProp((int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = closureCodingConvention0.isConstant("1100100");
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str12 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean14 = closureCodingConvention0.isPrivate("EOF \n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportProperty" + "'", str12.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj23 = node21.getProp((int) (short) 1);
        boolean boolean24 = node21.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj28 = node26.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((-1), node21, node26, node31);
        boolean boolean34 = node31.wasEmptyNode();
        java.lang.String str35 = closureCodingConvention0.extractClassNameIfProvide(node16, node31);
        java.lang.String str36 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "goog.exportProperty" + "'", str36.equals("goog.exportProperty"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException4.addSuppressed((java.lang.Throwable) runtimeException6);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj12 = node10.getProp((int) (short) 1);
        boolean boolean13 = node10.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = node10.getLastChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("language version");
        int int17 = node16.getLineno();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        boolean boolean22 = node20.isNoSideEffectsCall();
        java.lang.String str23 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(110, node10, node16);
        com.google.javascript.rhino.Node node26 = node24.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException6, (java.lang.Object) node26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(42, node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(17, node26, node29, node35, 49, 45);
        com.google.javascript.rhino.Node node39 = node26.getLastChild();
        com.google.javascript.rhino.Node node41 = node39.getAncestor(37);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str23.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(node41);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 8L);
        com.google.javascript.rhino.Context context7 = com.google.javascript.rhino.Context.enter(context0);
        context0.setInstructionObserverThreshold((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(context7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.SourceFile sourceFile3 = jsAst2.getSourceFile();
        jsAst2.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst2.getSourceFile();
        java.lang.String str6 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) jsAst2);
        jsAst2.clearAst();
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset9);
        try {
            jsAst2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState13 = compiler12.getState();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker20 = compiler14.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt21 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter22 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14, sourceExcerpt21);
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter22, logger23);
        compiler12.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList28 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList28, nodeArray27);
        com.google.javascript.jscomp.NodeTraversal.Callback callback30 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler26, (java.util.List<com.google.javascript.rhino.Node>) nodeList28, callback30);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker32 = compiler26.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt33 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter34 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler26, sourceExcerpt33);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState35 = compiler26.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState36 = compiler26.getState();
        com.google.javascript.jscomp.ErrorManager errorManager37 = compiler26.getErrorManager();
        java.io.PrintStream printStream38 = null;
        com.google.javascript.jscomp.Compiler compiler39 = new com.google.javascript.jscomp.Compiler(printStream38);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState40 = compiler39.getState();
        com.google.javascript.jscomp.Compiler compiler41 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList43 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList43, nodeArray42);
        com.google.javascript.jscomp.NodeTraversal.Callback callback45 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler41, (java.util.List<com.google.javascript.rhino.Node>) nodeList43, callback45);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker47 = compiler41.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt48 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter49 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler41, sourceExcerpt48);
        java.util.logging.Logger logger50 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager51 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter49, logger50);
        compiler39.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager51);
        compiler26.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager51);
        double double54 = loggerErrorManager51.getTypedPercent();
        compiler12.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager51);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager51);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
        org.junit.Assert.assertNotNull(intermediateState13);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(performanceTracker20);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(performanceTracker32);
        org.junit.Assert.assertNotNull(intermediateState35);
        org.junit.Assert.assertNotNull(intermediateState36);
        org.junit.Assert.assertNotNull(errorManager37);
        org.junit.Assert.assertNotNull(intermediateState40);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(performanceTracker47);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("error reporter", "TypeError: <No stack trace available>");
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = ecmaError2.getScriptStackTrace(filenameFilter3);
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler11, (java.util.List<com.google.javascript.rhino.Node>) nodeList13, callback15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler11.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput24 = compiler11.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(messageFormatter22);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        java.lang.String str5 = node3.getString();
        boolean boolean6 = detailLevel0.apply(node3);
        node3.setCharno(34);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = compilerInput4.getSourceFile();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler9.getState();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler11, (java.util.List<com.google.javascript.rhino.Node>) nodeList13, callback15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler11.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt18);
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter19, logger20);
        compiler9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        try {
            compiler9.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(performanceTracker17);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.printInputDelimiter = true;
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        java.lang.String str4 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node5 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput6 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(node5);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("goog.exportProperty", "(goog.exportProperty)", 15, "", 12);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportProperty ((goog.exportProperty)#15)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("setprop", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        boolean boolean10 = node7.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((-1), node7, node12, node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType20.level;
        java.lang.String str25 = diagnosticType20.toString();
        java.lang.String str26 = diagnosticType20.toString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node29, diagnosticType32, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node12, diagnosticType20, strArray35);
        boolean boolean39 = node12.hasMoreThanOneChild();
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str25.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "goog.global", 41, 13);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        node8.removeProp(8);
        try {
            node4.removeChild(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        node1.removeProp(31);
        com.google.javascript.rhino.jstype.JSType jSType6 = node1.getJSType();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSType6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node8.setVarArgs(true);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        com.google.javascript.rhino.Node node12 = node8.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = closureCodingConvention0.getDelegateRelationship(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention0.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj22 = node20.getProp((int) (short) 1);
        boolean boolean23 = node20.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node24 = node20.getLastChild();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("language version");
        int int27 = node26.getLineno();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable31 = node30.siblings();
        boolean boolean32 = node30.isNoSideEffectsCall();
        java.lang.String str33 = node26.checkTreeEquals(node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node20, node26);
        com.google.javascript.rhino.Node node36 = node34.getAncestor((int) (byte) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = closureCodingConvention0.getDelegateRelationship(node36);
        node36.setType((int) (byte) 100);
        try {
            node36.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeIterable31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str33.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(delegateRelationship37);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        boolean boolean10 = diagnosticGroup4.matches(diagnosticType6);
        java.lang.String str11 = diagnosticGroup4.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder11 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str12 = codeBuilder11.toString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        node17.removeProp(8);
        boolean boolean21 = node17.getBooleanProp(45);
        compiler0.toSource(codeBuilder11, 13, node17);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(errorManager10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean13 = closureCodingConvention0.isOptionalParameter(node12);
        java.lang.String str14 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.global" + "'", str14.equals("goog.global"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList0 = null;
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies1 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>(compilerInputList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback7);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention9 = compiler0.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.isGeneratingSource();
        int int4 = context0.getInstructionObserverThreshold();
        java.lang.String str5 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset8);
        java.lang.String str10 = jSSourceFile9.getOriginalPath();
        com.google.javascript.rhino.Node node11 = compiler0.parse(jSSourceFile9);
        com.google.javascript.rhino.Node node12 = compiler0.getRoot();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str10.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean4 = closureCodingConvention0.isConstantKey("language version");
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        boolean boolean10 = node7.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((-1), node7, node12, node17);
        try {
            boolean boolean20 = closureCodingConvention0.isPropertyTestFunction(node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig1 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback7);
        try {
            com.google.javascript.jscomp.Region region11 = compiler0.getSourceRegion("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", 38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst10, false);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter21 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15);
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler15);
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager(logger23);
        com.google.javascript.jscomp.JSError[] jSErrorArray25 = loggerErrorManager24.getErrors();
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        loggerErrorManager24.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray28 = loggerErrorManager24.getWarnings();
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        int int30 = compiler0.getWarningCount();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSErrorArray25);
        org.junit.Assert.assertNotNull(jSErrorArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("JSC_NODE_TRAVERSAL_ERROR", "JSC_NODE_TRAVERSAL_ERROR: {0}", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        boolean boolean4 = node1.hasMoreThanOneChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node1.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("language version");
        int int9 = node8.getLineno();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node8, node12 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray13, 40, 0);
        int int17 = node16.getType();
        boolean boolean18 = node16.hasSideEffects();
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node16);
        com.google.javascript.rhino.Node node20 = node16.getNext();
        try {
            com.google.javascript.rhino.Node node21 = node1.copyInformationFrom(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 8L);
        com.google.javascript.rhino.Context context7 = com.google.javascript.rhino.Context.enter(context0);
        context0.setGeneratingSource(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(context7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isExported("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("language version", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("<No stack trace available>");
        java.lang.String str2 = ecmaError1.getLineSource();
        java.lang.String str3 = ecmaError1.getName();
        com.google.javascript.rhino.EvaluatorException evaluatorException7 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException7.addSuppressed((java.lang.Throwable) runtimeException9);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj15 = node13.getProp((int) (short) 1);
        boolean boolean16 = node13.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node17 = node13.getLastChild();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("language version");
        int int20 = node19.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = node23.siblings();
        boolean boolean25 = node23.isNoSideEffectsCall();
        java.lang.String str26 = node19.checkTreeEquals(node23);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(110, node13, node19);
        com.google.javascript.rhino.Node node29 = node27.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException30 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException9, (java.lang.Object) node29);
        ecmaError1.addSuppressed((java.lang.Throwable) runtimeException9);
        ecmaError1.initLineSource("(goog.exportProperty)");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeIterable24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str26.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(runtimeException30);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder9 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        try {
            compiler0.toSource(codeBuilder9, 0, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("<No stack trace available>", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        try {
            com.google.javascript.rhino.Context.reportWarning("EOL");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection9 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getDefineReplacements();
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.rhino.Node node16 = null;
        try {
            java.lang.String str17 = closureCodingConvention0.identifyTypeDefAssign(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray11);
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType3, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType25, strArray27);
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray27);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel19, diagnosticType20, strArray27);
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray27);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler32 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback33 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal34 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler32, callback33);
        boolean boolean35 = nodeTraversal34.hasScope();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel39 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray42 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray46);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler49 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback50 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal51 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler49, callback50);
        com.google.javascript.jscomp.Compiler compiler52 = nodeTraversal51.getCompiler();
        com.google.javascript.rhino.Node node53 = nodeTraversal51.getEnclosingFunction();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj58 = node56.getProp((int) (short) 1);
        boolean boolean59 = node56.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj63 = node61.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable67 = node66.siblings();
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1), node56, node61, node66);
        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray71 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make(diagnosticType69, strArray71);
        com.google.javascript.jscomp.CheckLevel checkLevel73 = diagnosticType69.level;
        java.lang.String str74 = diagnosticType69.toString();
        java.lang.String str75 = diagnosticType69.toString();
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType81 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType82 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray84 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError85 = com.google.javascript.jscomp.JSError.make(diagnosticType82, strArray84);
        com.google.javascript.jscomp.JSError jSError86 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node78, diagnosticType81, strArray84);
        com.google.javascript.jscomp.JSError jSError87 = nodeTraversal51.makeError(node61, diagnosticType69, strArray84);
        com.google.javascript.jscomp.JSError jSError88 = nodeTraversal34.makeError(node38, checkLevel39, diagnosticType40, strArray84);
        com.google.javascript.jscomp.JSError jSError89 = com.google.javascript.jscomp.JSError.make(diagnosticType3, strArray84);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNull(compiler52);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(obj63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeIterable67);
        org.junit.Assert.assertNotNull(diagnosticType69);
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertTrue("'" + checkLevel73 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel73.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str74.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str75.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(diagnosticType81);
        org.junit.Assert.assertNotNull(diagnosticType82);
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertNotNull(jSError85);
        org.junit.Assert.assertNotNull(jSError86);
        org.junit.Assert.assertNotNull(jSError87);
        org.junit.Assert.assertNotNull(jSError88);
        org.junit.Assert.assertNotNull(jSError89);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(logger15);
        com.google.javascript.jscomp.JSError[] jSErrorArray17 = loggerErrorManager16.getErrors();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        node2.detachChildren();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj19 = node17.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = node17.getJSDocInfo();
        node17.setIsSyntheticBlock(false);
        java.lang.String str23 = node2.checkTreeEquals(node17);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("language version");
        node25.setQuotedString();
        int int27 = node25.getCharno();
        boolean boolean28 = node25.isNoSideEffectsCall();
        node2.addChildToFront(node25);
        try {
            int int31 = node25.getExistingIntProp(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNull(jSDocInfo20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        try {
            int int8 = compiler0.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.rhino.Node node9 = compiler0.getRoot();
        try {
            java.lang.String str12 = compiler0.getSourceLine("", 49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(34, 4, 45);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj8 = node6.getProp((int) (short) 1);
        boolean boolean9 = node6.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj13 = node11.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node16.siblings();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((-1), node6, node11, node16);
        node6.detachChildren();
        com.google.javascript.rhino.Node node20 = null;
        try {
            node3.replaceChildAfter(node6, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeIterable17);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = evaluatorException3.getScriptStackTrace(filenameFilter4);
        java.lang.String str6 = evaluatorException3.details();
        java.lang.String str7 = evaluatorException3.details();
        evaluatorException3.initColumnNumber((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = diagnosticType1.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", checkLevel2, "");
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setThrows();
        boolean boolean3 = sideEffectFlags0.areAllFlagsSet();
        boolean boolean4 = sideEffectFlags0.areAllFlagsSet();
        int int5 = sideEffectFlags0.valueOf();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 0L, 0, 44);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 8L);
        boolean boolean8 = context0.isActivationNeeded("bitor");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.Scope scope27 = compiler14.getTopScope();
        boolean boolean28 = compiler14.hasErrors();
        try {
            compiler14.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNull(scope27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        node2.detachChildren();
        java.lang.Object obj5 = null;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node2, obj5);
        boolean boolean7 = node2.hasOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        evaluatorException1.initLineSource("");
        int int4 = evaluatorException1.columnNumber();
        try {
            evaluatorException1.initLineSource("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        boolean boolean3 = compilerOptions0.ignoreCajaProperties;
        boolean boolean4 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.optimizeCalls;
        compilerOptions0.setDefineToDoubleLiteral("OR\n", (double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "((JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)))" + "'", str1.equals("((JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)))"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        boolean boolean9 = compilerOptions0.removeUnusedLocalVars;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(cssRenamingMap10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        node2.detachChildren();
        java.lang.Object obj5 = null;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node2, obj5);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node2.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        java.lang.String str12 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.global" + "'", str12.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "Named type with empty name component", "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n", 45, "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", 35);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.collapseVariableDeclarations = true;
        boolean boolean10 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        try {
//            com.google.javascript.rhino.Context.reportError("URSH ", "goog.abstractMethod", (int) (byte) 0, "EOF ", (-86));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -86");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = null;
        compiler5.tracker = performanceTracker17;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst21 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile20);
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst21, false);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        compilerInput23.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler24);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray28 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make(diagnosticType26, strArray28);
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray32 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(diagnosticType30, strArray32);
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType26, strArray32);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compiler24.getErrorLevel(jSError34);
        boolean boolean36 = compiler24.isIdeMode();
        com.google.javascript.jscomp.Compiler compiler37 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList39 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList39, nodeArray38);
        com.google.javascript.jscomp.NodeTraversal.Callback callback41 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler37, (java.util.List<com.google.javascript.rhino.Node>) nodeList39, callback41);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker43 = compiler37.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt44 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler37, sourceExcerpt44);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState46 = compiler37.getState();
        compiler24.setState(intermediateState46);
        compiler5.setState(intermediateState46);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNull(checkLevel35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(performanceTracker43);
        org.junit.Assert.assertNotNull(intermediateState46);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        try {
            com.google.javascript.jscomp.Region region29 = compiler14.getSourceRegion("JSC_NODE_TRAVERSAL_ERROR", 44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.Node node9 = null;
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(42, node15);
        boolean boolean17 = node16.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = null;
        node16.setJSDocInfo(jSDocInfo18);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder20 = node16.new FileLevelJsDocBuilder();
        try {
            boolean boolean21 = closureCodingConvention0.isPropertyTestFunction(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList13 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList13, nodeArray12);
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler11, (java.util.List<com.google.javascript.rhino.Node>) nodeList13, callback15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler11.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter22 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset24);
        java.lang.String str26 = jSSourceFile25.getOriginalPath();
        java.lang.String str27 = jSSourceFile25.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst30 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile29);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst30, false);
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler();
        compilerInput32.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler33);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray37 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray37);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray41 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make(diagnosticType39, strArray41);
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType35, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compiler33.getErrorLevel(jSError43);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt45 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter46 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler33, sourceExcerpt45);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter47 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler33);
        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList50 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList50, nodeArray49);
        com.google.javascript.jscomp.NodeTraversal.Callback callback52 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler48, (java.util.List<com.google.javascript.rhino.Node>) nodeList50, callback52);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter54 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler48);
        java.nio.charset.Charset charset56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset56);
        java.lang.String str58 = jSSourceFile57.getOriginalPath();
        com.google.javascript.rhino.Node node59 = compiler48.parse(jSSourceFile57);
        com.google.javascript.jscomp.JsAst jsAst60 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile57);
        com.google.javascript.rhino.Node node61 = compiler33.parse(jSSourceFile57);
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions62.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result65 = compiler11.compile(jSSourceFile25, jSSourceFile57, compilerOptions62);
        java.lang.String str66 = jSSourceFile25.getOriginalPath();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(messageFormatter22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str27.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNull(checkLevel44);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str58.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertNull(node61);
        org.junit.Assert.assertNotNull(result65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str66.equals("JSC_NODE_TRAVERSAL_ERROR"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "goog.global", 41, 13);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj8 = node6.getProp((int) (short) 1);
        node6.removeProp(31);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = closureCodingConvention0.getDelegateRelationship(node6);
        com.google.javascript.rhino.Node node12 = node6.removeChildren();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj17 = node15.getProp((int) (short) 1);
        boolean boolean18 = node15.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj22 = node20.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable26 = node25.siblings();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((-1), node15, node20, node25);
        node15.detachChildren();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("language version");
        int int31 = node30.getLineno();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        boolean boolean36 = node34.isNoSideEffectsCall();
        java.lang.String str37 = node30.checkTreeEquals(node34);
        java.lang.String str38 = node15.checkTreeEquals(node34);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj43 = node41.getProp((int) (short) 1);
        boolean boolean44 = node41.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (byte) 100, node41, 26, 31);
        node34.addChildrenToBack(node47);
        node6.addChildToBack(node34);
        try {
            double double50 = node6.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeIterable26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str37.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n" + "'", str38.equals("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(26, "error reporter", (int) (short) 100, 3);
        boolean boolean7 = node1.isEquivalentTo(node6);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        lightweightMessageFormatter8.setColorize(false);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str6 = node2.toString(true, false, true);
        boolean boolean7 = node2.isSyntheticBlock();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(19, node2, 41, 4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR" + "'", str6.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("0", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, true);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node8.setVarArgs(true);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        com.google.javascript.rhino.Node node12 = node8.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = closureCodingConvention0.getDelegateRelationship(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention0.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj22 = node20.getProp((int) (short) 1);
        boolean boolean23 = node20.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node24 = node20.getLastChild();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("language version");
        int int27 = node26.getLineno();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable31 = node30.siblings();
        boolean boolean32 = node30.isNoSideEffectsCall();
        java.lang.String str33 = node26.checkTreeEquals(node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node20, node26);
        com.google.javascript.rhino.Node node36 = node34.getAncestor((int) (byte) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = closureCodingConvention0.getDelegateRelationship(node36);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = null;
        com.google.javascript.jscomp.Scope scope39 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray40 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList41 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList41, objectTypeArray40);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry38, scope39, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList41);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType45 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType44, functionType45, objectType46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeIterable31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str33.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(delegateRelationship37);
        org.junit.Assert.assertNotNull(objectTypeArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        jSSourceFile5.setOriginalPath("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5 };
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler10, (java.util.List<com.google.javascript.rhino.Node>) nodeList12, callback14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10);
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler10.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler20, (java.util.List<com.google.javascript.rhino.Node>) nodeList22, callback24);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker26 = compiler20.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt27 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, sourceExcerpt27);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter29 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset33);
        java.lang.String str35 = jSSourceFile34.getOriginalPath();
        java.lang.String str36 = jSSourceFile34.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst39, false);
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler();
        compilerInput41.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make(diagnosticType48, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray50);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compiler42.getErrorLevel(jSError52);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt54 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter55 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42, sourceExcerpt54);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter56 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42);
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler57, (java.util.List<com.google.javascript.rhino.Node>) nodeList59, callback61);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter63 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler57);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset65);
        java.lang.String str67 = jSSourceFile66.getOriginalPath();
        com.google.javascript.rhino.Node node68 = compiler57.parse(jSSourceFile66);
        com.google.javascript.jscomp.JsAst jsAst69 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.rhino.Node node70 = compiler42.parse(jSSourceFile66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result74 = compiler20.compile(jSSourceFile34, jSSourceFile66, compilerOptions71);
        java.nio.charset.Charset charset76 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset76);
        com.google.javascript.jscomp.CompilerInput compilerInput78 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray79 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile66, jSSourceFile77 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions80 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions80.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions80.aliasableGlobals = "TypeError: <No stack trace available>";
        com.google.javascript.jscomp.Result result85 = compiler0.compile(jSSourceFileArray8, jSSourceFileArray79, compilerOptions80);
        java.lang.String str86 = compilerOptions80.renamePrefix;
        compilerOptions80.setTweakToNumberLiteral("EOF \n", 6);
        compilerOptions80.convertToDottedProperties = false;
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(messageFormatter19);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(performanceTracker26);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str35.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str36.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNull(checkLevel53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str67.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNull(node70);
        org.junit.Assert.assertNotNull(result74);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertNotNull(jSSourceFileArray79);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertNull(str86);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType0.level;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        diagnosticType0.level = checkLevel5;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "com.google.javascript.rhino.EcmaError: Unknown class name: hi! (JSC_NODE_TRAVERSAL_ERROR#11)");
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType5.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.JSError jSError11 = nodeTraversal2.makeError(node4, diagnosticType5, strArray9);
        com.google.javascript.jscomp.Scope scope12 = nodeTraversal2.getScope();
        com.google.javascript.jscomp.Compiler compiler13 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node14 = nodeTraversal2.getCurrentNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNull(scope12);
        org.junit.Assert.assertNull(compiler13);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        try {
            com.google.javascript.rhino.Context.reportWarning("(Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n)", "language version", (int) (byte) 1, "EOF \n", 100);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(130);
        sideEffectFlags1.setMutatesArguments();
        int int3 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 130 + "'", int3 == 130);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node11.setVarArgs(true);
        boolean boolean14 = detailLevel8.apply(node11);
        compilerOptions0.sourceMapDetailLevel = detailLevel8;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(detailLevel8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        java.lang.String str5 = node1.toString();
        boolean boolean6 = node1.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node8.setJSType(jSType11);
        boolean boolean13 = node8.hasOneChild();
        node8.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node16 = node1.copyInformationFrom(node8);
        int int17 = node16.getChildCount();
        boolean boolean18 = node16.isQuotedString();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.SourceFile sourceFile7 = compilerInput4.getSourceFile();
        java.util.Collection<java.lang.String> strCollection8 = compilerInput4.getRequires();
        java.util.Collection<java.lang.String> strCollection9 = compilerInput4.getProvides();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(strCollection8);
        org.junit.Assert.assertNotNull(strCollection9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getErrors();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager1.getWarnings();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        boolean boolean11 = node8.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj15 = node13.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable19 = node18.siblings();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((-1), node8, node13, node18);
        node8.detachChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("language version");
        int int24 = node23.getLineno();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable28 = node27.siblings();
        boolean boolean29 = node27.isNoSideEffectsCall();
        java.lang.String str30 = node23.checkTreeEquals(node27);
        java.lang.String str31 = node8.checkTreeEquals(node27);
        boolean boolean32 = node27.hasSideEffects();
        java.lang.RuntimeException runtimeException33 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) loggerErrorManager1, (java.lang.Object) boolean32);
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertNotNull(jSErrorArray5);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeIterable19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeIterable28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str30.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n" + "'", str31.equals("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(runtimeException33);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        try {
//            com.google.javascript.rhino.Context.reportError("error reporter", "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", 100, "Not declared as a constructor", 3);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: error reporter (Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n#100)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = compiler15.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, sourceExcerpt22);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState24 = compiler15.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState25 = compiler15.getState();
        com.google.javascript.jscomp.ErrorManager errorManager26 = compiler15.getErrorManager();
        java.io.PrintStream printStream27 = null;
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler(printStream27);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState29 = compiler28.getState();
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList32 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList32, nodeArray31);
        com.google.javascript.jscomp.NodeTraversal.Callback callback34 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler30, (java.util.List<com.google.javascript.rhino.Node>) nodeList32, callback34);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker36 = compiler30.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt37 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter38 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler30, sourceExcerpt37);
        java.util.logging.Logger logger39 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager40 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter38, logger39);
        compiler28.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager40);
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager40);
        double double43 = loggerErrorManager40.getTypedPercent();
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager40);
        int int45 = loggerErrorManager40.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler46 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager40);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile48);
        com.google.javascript.jscomp.JSModule[] jSModuleArray50 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.collapseAnonymousFunctions;
        compilerOptions51.setLooseTypes(false);
        boolean boolean55 = compilerOptions51.lineBreak;
        boolean boolean56 = compilerOptions51.optimizeParameters;
        try {
            com.google.javascript.jscomp.Result result57 = compiler46.compile(jSSourceFile48, jSModuleArray50, compilerOptions51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(performanceTracker21);
        org.junit.Assert.assertNotNull(intermediateState24);
        org.junit.Assert.assertNotNull(intermediateState25);
        org.junit.Assert.assertNotNull(errorManager26);
        org.junit.Assert.assertNotNull(intermediateState29);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(performanceTracker36);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertNotNull(jSModuleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(28, "JSC_NODE_TRAVERSAL_ERROR: {0}");
        boolean boolean3 = node2.isLocalResultCall();
        boolean boolean4 = node2.hasOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.rhino.EvaluatorException evaluatorException8 = new com.google.javascript.rhino.EvaluatorException("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        int int9 = evaluatorException8.lineNumber();
        java.lang.String str10 = evaluatorException8.lineSource();
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) diagnosticGroup4, (java.lang.Object) str10);
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(runtimeException11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        jsAst2.clearAst();
        jsAst2.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable6 = node2.getAncestors();
        com.google.javascript.rhino.Context context8 = new com.google.javascript.rhino.Context();
        context8.addActivationName("goog.abstractMethod");
        boolean boolean11 = context8.hasCompileFunctionsWithDynamicScope();
        int int12 = context8.getLanguageVersion();
        int int13 = context8.getOptimizationLevel();
        context8.setCompileFunctionsWithDynamicScope(false);
        node2.putProp((int) (byte) 100, (java.lang.Object) context8);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        boolean boolean21 = node19.isNoSideEffectsCall();
        java.lang.String str22 = node19.getString();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable23 = node19.getAncestors();
        com.google.javascript.rhino.Context context25 = new com.google.javascript.rhino.Context();
        context25.addActivationName("goog.abstractMethod");
        boolean boolean28 = context25.hasCompileFunctionsWithDynamicScope();
        int int29 = context25.getLanguageVersion();
        int int30 = context25.getOptimizationLevel();
        context25.setCompileFunctionsWithDynamicScope(false);
        node19.putProp((int) (byte) 100, (java.lang.Object) context25);
        context8.seal((java.lang.Object) (byte) 100);
        try {
            context8.removeActivationName("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(ancestorIterable23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        compilerOptions0.setTweakToNumberLiteral("URSH ", 0);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean7 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.aliasableGlobals = "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(detailLevel6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.isGeneratingSource();
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node11 = null;
        boolean boolean12 = closureCodingConvention10.isVarArgsParameter(node11);
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean12, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean16 = jSError9.equals((java.lang.Object) (-1.0f));
        context0.seal((java.lang.Object) jSError9);
        com.google.javascript.rhino.Context context18 = com.google.javascript.rhino.Context.enter(context0);
        try {
            context0.setLanguageVersion(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(context18);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("((JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)))", "OR\n", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", 29, ": ", 44);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.ambiguateProperties = true;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = null;
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        java.lang.String str4 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node5 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node6 = nodeTraversal2.getCurrentNode();
        com.google.javascript.rhino.Node node7 = nodeTraversal2.getCurrentNode();
        com.google.javascript.rhino.Node node8 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        java.lang.Class<?> wildcardClass13 = diagnosticType9.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.level;
        diagnosticType9.level = checkLevel17;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel23 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj28 = node26.getProp((int) (short) 1);
        boolean boolean29 = node26.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj33 = node31.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable37 = node36.siblings();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((-1), node26, node31, node36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = null;
        node31.setJSDocInfo(jSDocInfo39);
        boolean boolean41 = detailLevel23.apply(node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray44 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make(diagnosticType42, strArray44);
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray49 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType47, strArray49);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray51 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType42, diagnosticType46, diagnosticType47 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup52 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray55 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make(diagnosticType53, strArray55);
        java.lang.Class<?> wildcardClass57 = diagnosticType53.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel61 = diagnosticType60.level;
        diagnosticType53.level = checkLevel61;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard63 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup52, checkLevel61);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup52;
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = diagnosticType68.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType72 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        java.lang.String[] strArray73 = null;
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (short) 0, 20, checkLevel69, diagnosticType72, strArray73);
        boolean boolean75 = diagnosticGroup52.matches(diagnosticType72);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler76 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback77 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal78 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler76, callback77);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType81 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel82 = diagnosticType81.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType83 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray85 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError86 = com.google.javascript.jscomp.JSError.make(diagnosticType83, strArray85);
        com.google.javascript.jscomp.JSError jSError87 = nodeTraversal78.makeError(node80, diagnosticType81, strArray85);
        java.lang.Class<?> wildcardClass88 = strArray85.getClass();
        com.google.javascript.jscomp.JSError jSError89 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n", node31, diagnosticType72, strArray85);
        try {
            com.google.javascript.jscomp.JSError jSError90 = nodeTraversal2.makeError(node8, checkLevel17, diagnosticType21, strArray85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(detailLevel23);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeIterable37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(diagnosticTypeArray51);
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType68);
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType72);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(diagnosticType81);
        org.junit.Assert.assertTrue("'" + checkLevel82 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel82.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType83);
        org.junit.Assert.assertNotNull(strArray85);
        org.junit.Assert.assertNotNull(jSError86);
        org.junit.Assert.assertNotNull(jSError87);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertNotNull(jSError89);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile8 = null;
        try {
            compilerInput4.setSourceFile(sourceFile8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("(Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Node tree inequality:\\nTree1:\\nSTRING language version\\n\\n\\nTree2:\\nEOF \\n\\n\\nSubtree1: STRING language version\\n\\n\\nSubtree2: EOF \\n)" + "'", str1.equals("(Node tree inequality:\\nTree1:\\nSTRING language version\\n\\n\\nTree2:\\nEOF \\n\\n\\nSubtree1: STRING language version\\n\\n\\nSubtree2: EOF \\n)"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        int int5 = context0.getOptimizationLevel();
        int int6 = context0.getInstructionObserverThreshold();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        node2.detachChildren();
        java.lang.Object obj5 = null;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node2, obj5);
        node2.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNotNull(runtimeException6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap9 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap9);
        org.junit.Assert.assertNull(codingConvention10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray3 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType1, strArray3);
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray10 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType1, diagnosticType5, diagnosticType6 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        java.lang.Class<?> wildcardClass16 = diagnosticType12.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel20 = diagnosticType19.level;
        diagnosticType12.level = checkLevel20;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup11, checkLevel20);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray26 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup11 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = new com.google.javascript.jscomp.DiagnosticGroup("JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)", diagnosticGroupArray26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray26);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(jSError4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(diagnosticTypeArray10);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroupArray26);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        boolean boolean10 = node7.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((-1), node7, node12, node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType20.level;
        java.lang.String str25 = diagnosticType20.toString();
        java.lang.String str26 = diagnosticType20.toString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node29, diagnosticType32, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node12, diagnosticType20, strArray35);
        java.lang.String str39 = jSError38.description;
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str25.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        jSSourceFile1.setOriginalPath("(goog.exportProperty)");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getDefineReplacements();
        boolean boolean10 = compilerOptions0.removeTryCatchFinally;
        boolean boolean11 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray3);
        org.junit.Assert.assertNotNull(jSErrorArray4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean2 = node1.hasChildren();
        node1.setIsSyntheticBlock(false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = node1.getJSDocInfo();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSDocInfo5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("JSC_NODE_TRAVERSAL_ERROR", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        java.lang.String str9 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray11);
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType3, strArray11);
        java.lang.String str15 = jSError14.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = jSError14.getType();
        java.lang.String str17 = jSError14.description;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32" + "'", str15.equals("JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32"));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        compilerOptions0.setTweakToNumberLiteral("URSH ", 0);
        boolean boolean6 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.jsOutputFile;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        java.lang.String str5 = node1.toString();
        boolean boolean6 = node1.hasMoreThanOneChild();
        node1.putBooleanProp(2, true);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        lightweightMessageFormatter6.setColorize(false);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        node2.putIntProp(0, (int) 'a');
        boolean boolean9 = node2.isLocalResultCall();
        boolean boolean10 = node2.wasEmptyNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        boolean boolean5 = compilerInput4.isExtern();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput4.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        int int5 = context0.getOptimizationLevel();
        context0.setCompileFunctionsWithDynamicScope(false);
        context0.setGeneratingSource(true);
        try {
            context0.setLanguageVersion(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        java.lang.Object obj4 = context0.getDebuggerContextData();
        java.lang.Object obj5 = null;
        java.lang.Object obj6 = context0.getThreadLocal(obj5);
        context0.addActivationName("error reporter");
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        java.lang.Class<?> wildcardClass13 = diagnosticType9.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.level;
        diagnosticType9.level = checkLevel17;
        context0.removeThreadLocal((java.lang.Object) checkLevel17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        compiler0.reportCodeChange();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) 'a', nodeArray2, 49, 45);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', nodeArray2);
        org.junit.Assert.assertNotNull(nodeArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst7, false);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst14 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst14, false);
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler();
        compilerInput16.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList21 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList21, nodeArray20);
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler19, (java.util.List<com.google.javascript.rhino.Node>) nodeList21, callback23);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler19);
        compilerInput16.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler19);
        java.util.logging.Logger logger27 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager28 = new com.google.javascript.jscomp.LoggerErrorManager(logger27);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = loggerErrorManager28.getErrors();
        compiler19.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager28);
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler19);
        boolean boolean32 = compiler19.isIdeMode();
        com.google.javascript.rhino.Node node33 = jsAst2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler19);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(node33);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        boolean boolean4 = compilerOptions0.lineBreak;
        boolean boolean5 = compilerOptions0.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setTweakToDoubleLiteral("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", (double) 17);
        boolean boolean13 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("Unknown class name", "hi!", "JSC_NODE_TRAVERSAL_ERROR", 11, "language version", (int) (byte) 0);
        java.lang.String str7 = ecmaError6.toString();
        java.lang.String str8 = ecmaError6.getScriptStackTrace();
        java.lang.String str9 = ecmaError6.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "com.google.javascript.rhino.EcmaError: Unknown class name: hi! (JSC_NODE_TRAVERSAL_ERROR#11)" + "'", str7.equals("com.google.javascript.rhino.EcmaError: Unknown class name: hi! (JSC_NODE_TRAVERSAL_ERROR#11)"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<No stack trace available>" + "'", str8.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str9.equals("JSC_NODE_TRAVERSAL_ERROR"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType0.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType5.level;
        diagnosticType0.level = checkLevel9;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph3.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        try {
            java.lang.String str3 = compilerInput2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: Not declared as a constructor (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "");
        int int3 = ecmaError2.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        java.lang.String str23 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean25 = closureCodingConvention0.isSuperClassReference("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.exportProperty" + "'", str23.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        java.lang.String[] strArray9 = new java.lang.String[] { "URSH ", "" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        compilerOptions0.stripTypePrefixes = strSet10;
        compilerOptions0.setSummaryDetailLevel(12);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        boolean boolean17 = compiler5.isIdeMode();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList20 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList20, nodeArray19);
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler18, (java.util.List<com.google.javascript.rhino.Node>) nodeList20, callback22);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker24 = compiler18.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt25 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter26 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler18, sourceExcerpt25);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState27 = compiler18.getState();
        compiler5.setState(intermediateState27);
        com.google.javascript.rhino.Node node29 = compiler5.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap30 = compiler5.getSourceMap();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(performanceTracker24);
        org.junit.Assert.assertNotNull(intermediateState27);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNull(sourceMap30);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        int int3 = context0.getInstructionObserverThreshold();
        int int4 = context0.getLanguageVersion();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(20, "");
        java.util.Set<java.lang.String> strSet3 = node2.getDirectives();
        boolean boolean4 = node2.hasSideEffects();
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        node2.setJSType(jSType5);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(20, "");
        java.util.Set<java.lang.String> strSet10 = node9.getDirectives();
        java.lang.String str14 = node9.toString(false, true, false);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("language version");
        int int17 = node16.getLineno();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        boolean boolean22 = node20.isNoSideEffectsCall();
        java.lang.String str23 = node16.checkTreeEquals(node20);
        java.lang.String str24 = node20.toString();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel26 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node29.setVarArgs(true);
        boolean boolean32 = detailLevel26.apply(node29);
        boolean boolean33 = node29.hasOneChild();
        java.lang.String str34 = node29.getQualifiedName();
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray38 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make(diagnosticType36, strArray38);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray43 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError44 = com.google.javascript.jscomp.JSError.make(diagnosticType41, strArray43);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray45 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType36, diagnosticType40, diagnosticType41 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup46 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray45);
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray49 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType47, strArray49);
        java.lang.Class<?> wildcardClass51 = diagnosticType47.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel55 = diagnosticType54.level;
        diagnosticType47.level = checkLevel55;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard57 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup46, checkLevel55);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.DiagnosticType.make("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", checkLevel55, "Unknown class name");
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray62 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make(diagnosticType60, strArray62);
        com.google.javascript.jscomp.CheckLevel checkLevel64 = diagnosticType60.level;
        java.lang.String str65 = diagnosticType60.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel67 = diagnosticType66.defaultLevel;
        java.lang.String[] strArray70 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make(diagnosticType66, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("goog.exportSymbol", node29, checkLevel55, diagnosticType60, strArray70);
        com.google.javascript.rhino.Node node73 = node20.clonePropsFrom(node29);
        try {
            node2.replaceChild(node9, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(strSet10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "URSH " + "'", str14.equals("URSH "));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str23.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "EOF " + "'", str24.equals("EOF "));
        org.junit.Assert.assertNotNull(detailLevel26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jSError44);
        org.junit.Assert.assertNotNull(diagnosticTypeArray45);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertNotNull(jSError63);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str65.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(node73);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        boolean boolean10 = closureCodingConvention0.isConstant("1100100");
        java.lang.String str11 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = null;
        com.google.javascript.jscomp.Scope scope13 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray14 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList15, objectTypeArray14);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry12, scope13, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportProperty" + "'", str11.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(objectTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        try {
            java.lang.String str7 = compiler0.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getDefineReplacements();
        boolean boolean10 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.setProcessObjectPropertyString(false);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str8 = node4.toString(true, false, true);
        boolean boolean9 = node4.isSyntheticBlock();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        node12.detachChildren();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node4, node12, 0, (int) (short) 1);
        boolean boolean18 = node4.isOnlyModifiesThisCall();
        boolean boolean19 = closureCodingConvention0.isVarArgsParameter(node4);
        com.google.javascript.rhino.Node node21 = node4.getChildAtIndex(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR" + "'", str8.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.convertToDottedProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.instrumentationTemplate = "bitor";
        compilerOptions2.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions2.customPasses = customPassExecutionTimeMultimap7;
        java.lang.String[] strArray11 = new java.lang.String[] { "URSH ", "" };
        java.util.LinkedHashSet<java.lang.String> strSet12 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet12, strArray11);
        compilerOptions2.stripTypePrefixes = strSet12;
        compilerOptions0.stripNameSuffixes = strSet12;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("8");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, false);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        compilerInput5.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.SourceFile sourceFile8 = compilerInput5.getSourceFile();
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState11 = compiler10.getState();
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler12, (java.util.List<com.google.javascript.rhino.Node>) nodeList14, callback16);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = compiler12.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, sourceExcerpt19);
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter20, logger21);
        compiler10.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager22);
        compilerInput5.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.MessageFormatter messageFormatter26 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertNotNull(intermediateState11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(performanceTracker18);
        org.junit.Assert.assertNotNull(messageFormatter26);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.Node node9 = null;
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str13 = closureCodingConvention0.identifyTypeDefAssign(node12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        boolean boolean5 = compilerOptions0.checkTypedPropertyCalls;
        boolean boolean6 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap7;
        java.lang.String str9 = compilerOptions0.locale;
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setAcceptConstKeyword(true);
        compilerOptions0.setDefineToDoubleLiteral("goog.exportSymbol", (double) 46);
        compilerOptions0.setDefineToStringLiteral("1100100", "TypeError: <No stack trace available>");
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str10 = closureCodingConvention9.getExportPropertyFunction();
        boolean boolean12 = closureCodingConvention9.isPrivate("");
        boolean boolean14 = closureCodingConvention9.isPrivate("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean18 = closureCodingConvention9.isOptionalParameter(node17);
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType22 = null;
        closureCodingConvention0.applySubclassRelationship(functionType20, functionType21, subclassType22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.groupVariableDeclarations = true;
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.instrumentationTemplate = "bitor";
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.ideMode = false;
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        java.lang.String str4 = sourceFile2.getLine((int) (short) 1);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig8 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap9 = compilerOptions0.customPasses;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap10 = compilerOptions0.getTweakReplacements();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap9);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("(Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n)");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setChainCalls(true);
        java.lang.String[] strArray17 = new java.lang.String[] { "TypeError: <No stack trace available>", "TypeError", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "JSC_NODE_TRAVERSAL_ERROR", "BITXOR", "(goog.exportProperty)", "Unknown class name", "<No stack trace available>", "8", "com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)", "@IMPLEMENTATION.VERSION@", "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions0.stripTypePrefixes = strSet18;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions0.checkProvides;
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        java.lang.Class<?> wildcardClass15 = compiler1.getClass();
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset8);
        java.lang.String str10 = jSSourceFile9.getOriginalPath();
        com.google.javascript.rhino.Node node11 = compiler0.parse(jSSourceFile9);
        com.google.javascript.jscomp.JsAst jsAst12 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(logger15);
        int int17 = loggerErrorManager16.getWarningCount();
        compilerInput14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str10.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("error reporter", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray6 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray13 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType4, diagnosticType8, diagnosticType9 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray17);
        java.lang.Class<?> wildcardClass19 = diagnosticType15.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.level;
        diagnosticType15.level = checkLevel23;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler27 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback28 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal29 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler27, callback28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = diagnosticType32.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType34, strArray36);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal29.makeError(node31, diagnosticType32, strArray36);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("goog.abstractMethod", (int) (short) -1, 8, checkLevel23, diagnosticType26, strArray36);
        int int40 = diagnosticType0.compareTo(diagnosticType26);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticTypeArray13);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.clearAllFlags();
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        int int4 = loggerErrorManager1.getWarningCount();
        int int5 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        java.lang.String str9 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType10, functionType11, objectType12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean11 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean12 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray34 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(diagnosticType32, strArray34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray39 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(diagnosticType37, strArray39);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray41 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType32, diagnosticType36, diagnosticType37 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup42 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray45 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError46 = com.google.javascript.jscomp.JSError.make(diagnosticType43, strArray45);
        java.lang.Class<?> wildcardClass47 = diagnosticType43.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel51 = diagnosticType50.level;
        diagnosticType43.level = checkLevel51;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard53 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup42, checkLevel51);
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler55 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback56 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal57 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler55, callback56);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType60 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = diagnosticType60.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray64 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make(diagnosticType62, strArray64);
        com.google.javascript.jscomp.JSError jSError66 = nodeTraversal57.makeError(node59, diagnosticType60, strArray64);
        com.google.javascript.jscomp.JSError jSError67 = com.google.javascript.jscomp.JSError.make("goog.abstractMethod", (int) (short) -1, 8, checkLevel51, diagnosticType54, strArray64);
        com.google.javascript.jscomp.CheckLevel checkLevel68 = composeWarningsGuard27.level(jSError67);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup69 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup69;
        boolean boolean71 = composeWarningsGuard27.disables(diagnosticGroup69);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup69;
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(diagnosticTypeArray41);
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(diagnosticType60);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType62);
        org.junit.Assert.assertNotNull(strArray64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(jSError66);
        org.junit.Assert.assertNotNull(jSError67);
        org.junit.Assert.assertNull(checkLevel68);
        org.junit.Assert.assertNotNull(diagnosticGroup69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 0, 32, 49);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        org.junit.Assert.assertNotNull(nodeIterable4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput4.getSourceFile();
        compilerInput4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceAst5);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList6 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList6, nodeArray5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler4, (java.util.List<com.google.javascript.rhino.Node>) nodeList6, callback8);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter10 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = diagnosticType11.defaultLevel;
        java.lang.String[] strArray15 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray15);
        java.lang.String str17 = lightweightMessageFormatter10.formatWarning(jSError16);
        lightweightMessageFormatter10.setColorize(false);
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter10, logger20);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler22 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler22, callback23);
        boolean boolean25 = nodeTraversal24.hasScope();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel29 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray32 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(diagnosticType30, strArray32);
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType34, strArray36);
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(diagnosticType30, strArray36);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.jscomp.Compiler compiler42 = nodeTraversal41.getCompiler();
        com.google.javascript.rhino.Node node43 = nodeTraversal41.getEnclosingFunction();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj48 = node46.getProp((int) (short) 1);
        boolean boolean49 = node46.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj53 = node51.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable57 = node56.siblings();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((-1), node46, node51, node56);
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray61 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make(diagnosticType59, strArray61);
        com.google.javascript.jscomp.CheckLevel checkLevel63 = diagnosticType59.level;
        java.lang.String str64 = diagnosticType59.toString();
        java.lang.String str65 = diagnosticType59.toString();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType72 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray74 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make(diagnosticType72, strArray74);
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node68, diagnosticType71, strArray74);
        com.google.javascript.jscomp.JSError jSError77 = nodeTraversal41.makeError(node51, diagnosticType59, strArray74);
        com.google.javascript.jscomp.JSError jSError78 = nodeTraversal24.makeError(node28, checkLevel29, diagnosticType30, strArray74);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile80 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst81 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile80);
        com.google.javascript.jscomp.CompilerInput compilerInput83 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst81, false);
        com.google.javascript.jscomp.Compiler compiler84 = new com.google.javascript.jscomp.Compiler();
        compilerInput83.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler84);
        com.google.javascript.jscomp.DiagnosticType diagnosticType86 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray88 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError89 = com.google.javascript.jscomp.JSError.make(diagnosticType86, strArray88);
        com.google.javascript.jscomp.DiagnosticType diagnosticType90 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray92 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make(diagnosticType90, strArray92);
        com.google.javascript.jscomp.JSError jSError94 = com.google.javascript.jscomp.JSError.make(diagnosticType86, strArray92);
        com.google.javascript.jscomp.CheckLevel checkLevel95 = compiler84.getErrorLevel(jSError94);
        loggerErrorManager21.report(checkLevel29, jSError94);
        com.google.javascript.jscomp.CheckLevel checkLevel97 = composeWarningsGuard3.level(jSError94);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n" + "'", str17.equals("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNull(compiler42);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeIterable57);
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertTrue("'" + checkLevel63 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel63.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str64.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str65.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(diagnosticType72);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertNotNull(jSError75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertNotNull(jSError77);
        org.junit.Assert.assertNotNull(jSError78);
        org.junit.Assert.assertNotNull(jSSourceFile80);
        org.junit.Assert.assertNotNull(diagnosticType86);
        org.junit.Assert.assertNotNull(strArray88);
        org.junit.Assert.assertNotNull(jSError89);
        org.junit.Assert.assertNotNull(diagnosticType90);
        org.junit.Assert.assertNotNull(strArray92);
        org.junit.Assert.assertNotNull(jSError93);
        org.junit.Assert.assertNotNull(jSError94);
        org.junit.Assert.assertNull(checkLevel95);
        org.junit.Assert.assertNull(checkLevel97);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        boolean boolean2 = compilerOptions0.removeUnusedVars;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        java.lang.Object obj4 = compilerOptions0.clone();
        compilerOptions0.setSummaryDetailLevel(13);
        boolean boolean7 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset4);
        jSSourceFile5.setOriginalPath("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5 };
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler10, (java.util.List<com.google.javascript.rhino.Node>) nodeList12, callback14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10);
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler10.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler20, (java.util.List<com.google.javascript.rhino.Node>) nodeList22, callback24);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker26 = compiler20.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt27 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, sourceExcerpt27);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter29 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset33);
        java.lang.String str35 = jSSourceFile34.getOriginalPath();
        java.lang.String str36 = jSSourceFile34.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst39, false);
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler();
        compilerInput41.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make(diagnosticType48, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray50);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compiler42.getErrorLevel(jSError52);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt54 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter55 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42, sourceExcerpt54);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter56 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42);
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler57, (java.util.List<com.google.javascript.rhino.Node>) nodeList59, callback61);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter63 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler57);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset65);
        java.lang.String str67 = jSSourceFile66.getOriginalPath();
        com.google.javascript.rhino.Node node68 = compiler57.parse(jSSourceFile66);
        com.google.javascript.jscomp.JsAst jsAst69 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.rhino.Node node70 = compiler42.parse(jSSourceFile66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result74 = compiler20.compile(jSSourceFile34, jSSourceFile66, compilerOptions71);
        java.nio.charset.Charset charset76 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset76);
        com.google.javascript.jscomp.CompilerInput compilerInput78 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile77);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray79 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile66, jSSourceFile77 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions80 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions80.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions80.aliasableGlobals = "TypeError: <No stack trace available>";
        com.google.javascript.jscomp.Result result85 = compiler0.compile(jSSourceFileArray8, jSSourceFileArray79, compilerOptions80);
        boolean boolean86 = compilerOptions80.inlineGetters;
        compilerOptions80.setNameAnonymousFunctionsOnly(true);
        compilerOptions80.setGenerateExports(true);
        java.util.Set<java.lang.String> strSet91 = null;
        compilerOptions80.stripNameSuffixes = strSet91;
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(messageFormatter19);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(performanceTracker26);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str35.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str36.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNull(checkLevel53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str67.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNull(node70);
        org.junit.Assert.assertNotNull(result74);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertNotNull(jSSourceFileArray79);
        org.junit.Assert.assertNotNull(result85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        java.lang.String str4 = node2.getString();
        boolean boolean5 = node2.hasSideEffects();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        java.lang.Object obj6 = context0.getThreadLocal((java.lang.Object) 6);
        context0.setGeneratingSource(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        java.lang.String str7 = compiler5.toSource();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection6 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        int int3 = node2.getLineno();
        int int5 = node2.getIntProp(24);
        boolean boolean6 = node2.isQuotedString();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = node9.getJSDocInfo();
        java.lang.String str13 = node9.toString();
        boolean boolean14 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node16.setJSType(jSType19);
        boolean boolean21 = node16.hasOneChild();
        node16.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node24 = node9.copyInformationFrom(node16);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder25 = node16.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("language version");
        int int29 = node28.getLineno();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] { node28, node32 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray33, 40, 0);
        node36.detachChildren();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(1, node16, node36);
        try {
            com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(28, node2, node16, 46, 48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BITXOR" + "'", str13.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray33);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(42, node5);
        com.google.javascript.rhino.Node node7 = node6.cloneTree();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup8;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.defaultLevel;
        java.lang.String[] strArray14 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray14);
        boolean boolean16 = diagnosticGroup8.matches(diagnosticType10);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.jscomp.Compiler compiler20 = nodeTraversal19.getCompiler();
        com.google.javascript.rhino.Node node21 = nodeTraversal19.getEnclosingFunction();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj26 = node24.getProp((int) (short) 1);
        boolean boolean27 = node24.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj31 = node29.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((-1), node24, node29, node34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray39 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(diagnosticType37, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = diagnosticType37.level;
        java.lang.String str42 = diagnosticType37.toString();
        java.lang.String str43 = diagnosticType37.toString();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray52 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node46, diagnosticType49, strArray52);
        com.google.javascript.jscomp.JSError jSError55 = nodeTraversal19.makeError(node29, diagnosticType37, strArray52);
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray52);
        com.google.javascript.jscomp.CheckLevel checkLevel57 = diagnosticType10.level;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel66 = diagnosticType65.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray69 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make(diagnosticType67, strArray69);
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray73 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make(diagnosticType71, strArray73);
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make(diagnosticType67, strArray73);
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType65, strArray73);
        com.google.javascript.jscomp.DiagnosticType diagnosticType77 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray79 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError80 = com.google.javascript.jscomp.JSError.make(diagnosticType77, strArray79);
        com.google.javascript.jscomp.JSError jSError81 = com.google.javascript.jscomp.JSError.make("error reporter", 120, 3, checkLevel61, diagnosticType65, strArray79);
        com.google.javascript.jscomp.JSError jSError82 = com.google.javascript.jscomp.JSError.make("com.google.javascript.rhino.EvaluatorException: hi!", node7, diagnosticType10, strArray79);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(compiler20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str42.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str43.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertTrue("'" + checkLevel66 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel66.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(strArray69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(jSError75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertNotNull(diagnosticType77);
        org.junit.Assert.assertNotNull(strArray79);
        org.junit.Assert.assertNotNull(jSError80);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertNotNull(jSError82);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.aliasableGlobals = "TypeError: <No stack trace available>";
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean7 = compilerOptions0.coalesceVariableNames;
        boolean boolean8 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.Object obj0 = null;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = null;
        boolean boolean3 = closureCodingConvention1.isVarArgsParameter(node2);
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        closureCodingConvention1.applyDelegateRelationship(objectType4, objectType5, objectType6, functionType7, functionType8);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType12 = null;
        closureCodingConvention1.applySubclassRelationship(functionType10, functionType11, subclassType12);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection14 = closureCodingConvention1.getAssertionFunctions();
        boolean boolean16 = closureCodingConvention1.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str17 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection22 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node21);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str24 = closureCodingConvention23.getExportPropertyFunction();
        boolean boolean26 = closureCodingConvention23.isPrivate("");
        boolean boolean28 = closureCodingConvention23.isPrivate("hi!");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean32 = closureCodingConvention23.isOptionalParameter(node31);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection33 = closureCodingConvention23.getAssertionFunctions();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean36 = closureCodingConvention23.isOptionalParameter(node35);
        java.lang.String str37 = node21.checkTreeEquals(node35);
        java.lang.RuntimeException runtimeException38 = com.google.javascript.rhino.ScriptRuntime.undefWriteError(obj0, (java.lang.Object) str17, (java.lang.Object) node21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.global" + "'", str17.equals("goog.global"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeCollection22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "goog.exportProperty" + "'", str24.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n" + "'", str37.equals("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n"));
        org.junit.Assert.assertNotNull(runtimeException38);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node4.setVarArgs(true);
        boolean boolean7 = detailLevel1.apply(node4);
        boolean boolean8 = node4.isVarArgs();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node12.setVarArgs(true);
        boolean boolean15 = detailLevel9.apply(node12);
        boolean boolean16 = node12.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, node4, node12, 36, 140);
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList12 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList12, nodeArray11);
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler10, (java.util.List<com.google.javascript.rhino.Node>) nodeList12, callback14);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10);
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler10.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList22 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList22, nodeArray21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler20, (java.util.List<com.google.javascript.rhino.Node>) nodeList22, callback24);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker26 = compiler20.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt27 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter28 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, sourceExcerpt27);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter29 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20);
        com.google.javascript.jscomp.MessageFormatter messageFormatter31 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler20, true);
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset33);
        java.lang.String str35 = jSSourceFile34.getOriginalPath();
        java.lang.String str36 = jSSourceFile34.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst39, false);
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler();
        compilerInput41.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make(diagnosticType48, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make(diagnosticType44, strArray50);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compiler42.getErrorLevel(jSError52);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt54 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter55 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42, sourceExcerpt54);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter56 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler42);
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList59 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList59, nodeArray58);
        com.google.javascript.jscomp.NodeTraversal.Callback callback61 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler57, (java.util.List<com.google.javascript.rhino.Node>) nodeList59, callback61);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter63 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler57);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset65);
        java.lang.String str67 = jSSourceFile66.getOriginalPath();
        com.google.javascript.rhino.Node node68 = compiler57.parse(jSSourceFile66);
        com.google.javascript.jscomp.JsAst jsAst69 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.rhino.Node node70 = compiler42.parse(jSSourceFile66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.inlineConstantVars = false;
        com.google.javascript.jscomp.Result result74 = compiler20.compile(jSSourceFile34, jSSourceFile66, compilerOptions71);
        com.google.javascript.jscomp.CompilerOptions compilerOptions75 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean76 = compilerOptions75.collapseAnonymousFunctions;
        compilerOptions75.lineBreak = true;
        com.google.javascript.jscomp.Result result79 = compiler5.compile(jSSourceFile8, jSSourceFile66, compilerOptions75);
        compilerOptions75.jsOutputFile = "1100100";
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(messageFormatter19);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(performanceTracker26);
        org.junit.Assert.assertNotNull(messageFormatter31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str35.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str36.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNull(checkLevel53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str67.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNull(node70);
        org.junit.Assert.assertNotNull(result74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(result79);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 8L);
        context0.addActivationName("goog.global");
        context0.setGeneratingSource(false);
        boolean boolean11 = context0.isSealed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        boolean boolean4 = node2.isNoSideEffectsCall();
        java.lang.String str5 = node2.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection6 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node2);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node2.new FileLevelJsDocBuilder();
        java.lang.String str8 = node2.toStringTree();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "EOF \n" + "'", str8.equals("EOF \n"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str8 = node4.toString(true, false, true);
        boolean boolean9 = node4.isSyntheticBlock();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        node12.detachChildren();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node4, node12, 0, (int) (short) 1);
        boolean boolean18 = node4.isOnlyModifiesThisCall();
        boolean boolean19 = closureCodingConvention0.isVarArgsParameter(node4);
        java.lang.String str20 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR" + "'", str8.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportSymbol" + "'", str20.equals("goog.exportSymbol"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray10 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray14);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler17 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler17, callback18);
        com.google.javascript.jscomp.Compiler compiler20 = nodeTraversal19.getCompiler();
        com.google.javascript.rhino.Node node21 = nodeTraversal19.getEnclosingFunction();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj26 = node24.getProp((int) (short) 1);
        boolean boolean27 = node24.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj31 = node29.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((-1), node24, node29, node34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray39 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(diagnosticType37, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = diagnosticType37.level;
        java.lang.String str42 = diagnosticType37.toString();
        java.lang.String str43 = diagnosticType37.toString();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray52 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node46, diagnosticType49, strArray52);
        com.google.javascript.jscomp.JSError jSError55 = nodeTraversal19.makeError(node29, diagnosticType37, strArray52);
        com.google.javascript.jscomp.JSError jSError56 = nodeTraversal2.makeError(node6, checkLevel7, diagnosticType8, strArray52);
        java.lang.String str57 = nodeTraversal2.getSourceName();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNull(compiler20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str42.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str43.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("com.google.javascript.rhino.EvaluatorException: hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EvaluatorException: hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.defaultLevel;
        java.lang.String[] strArray6 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray6);
        boolean boolean8 = diagnosticGroup0.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        java.lang.String[] strArray4 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray4);
        int int6 = jSError5.lineNumber;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.Region region10 = jSSourceFile8.getRegion(40);
        boolean boolean11 = jSError5.equals((java.lang.Object) jSSourceFile8);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(region10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        node2.putIntProp(0, (int) 'a');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str15 = node11.toString(true, false, true);
        boolean boolean16 = node11.isSyntheticBlock();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        node19.detachChildren();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) ' ', node11, node19, 0, (int) (short) 1);
        node24.detachChildren();
        node2.addChildToBack(node24);
        com.google.javascript.rhino.jstype.JSType jSType27 = node24.getJSType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BITXOR" + "'", str15.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertNull(jSType27);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("<No stack trace available>");
        java.lang.String str2 = ecmaError1.getLineSource();
        java.lang.String str3 = ecmaError1.getName();
        com.google.javascript.rhino.EvaluatorException evaluatorException7 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException7.addSuppressed((java.lang.Throwable) runtimeException9);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj15 = node13.getProp((int) (short) 1);
        boolean boolean16 = node13.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node17 = node13.getLastChild();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("language version");
        int int20 = node19.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = node23.siblings();
        boolean boolean25 = node23.isNoSideEffectsCall();
        java.lang.String str26 = node19.checkTreeEquals(node23);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(110, node13, node19);
        com.google.javascript.rhino.Node node29 = node27.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException30 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException9, (java.lang.Object) node29);
        ecmaError1.addSuppressed((java.lang.Throwable) runtimeException9);
        java.lang.String str32 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeIterable24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str26.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(runtimeException30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "<No stack trace available>" + "'", str32.equals("<No stack trace available>"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node7.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node9 = node7.getLastSibling();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str15 = node11.toString(true, false, true);
        boolean boolean16 = node11.isSyntheticBlock();
        com.google.javascript.rhino.Node node17 = node9.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node18 = node17.getParent();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj23 = node21.getProp((int) (short) 1);
        boolean boolean24 = node21.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 100, node21, 26, 31);
        java.lang.String str28 = closureCodingConvention0.extractClassNameIfRequire(node18, node27);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BITXOR" + "'", str15.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        int int6 = context0.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.markNoSideEffectCalls = false;
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(42, node4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node7 = null;
        boolean boolean8 = closureCodingConvention6.isVarArgsParameter(node7);
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        closureCodingConvention6.applyDelegateRelationship(objectType9, objectType10, objectType11, functionType12, functionType13);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType17 = null;
        closureCodingConvention6.applySubclassRelationship(functionType15, functionType16, subclassType17);
        boolean boolean20 = closureCodingConvention6.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj29 = node27.getProp((int) (short) 1);
        boolean boolean30 = node27.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj34 = node32.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable38 = node37.siblings();
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((-1), node27, node32, node37);
        boolean boolean40 = node37.wasEmptyNode();
        java.lang.String str41 = closureCodingConvention6.extractClassNameIfProvide(node22, node37);
        boolean boolean42 = node5.hasChild(node22);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable43 = node22.children();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean46 = node45.hasChildren();
        node22.addChildToFront(node45);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeIterable38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(nodeIterable43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.rhino.Node node9 = compiler0.getRoot();
        try {
            boolean boolean10 = compiler0.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32)" + "'", str1.equals("(JSC_NODE_TRAVERSAL_ERROR.  at JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column) line 0 : 32)"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setLooseTypes(false);
        boolean boolean4 = compilerOptions0.lineBreak;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.setAcceptConstKeyword(true);
        compilerOptions0.checkSuspiciousCode = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) (short) 1);
        int int4 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.isGeneratingSource();
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node11 = null;
        boolean boolean12 = closureCodingConvention10.isVarArgsParameter(node11);
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean12, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean16 = jSError9.equals((java.lang.Object) (-1.0f));
        context0.seal((java.lang.Object) jSError9);
        com.google.javascript.rhino.Context context18 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = context18.getErrorReporter();
        boolean boolean20 = context18.isGeneratingDebugChanged();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(context18);
        org.junit.Assert.assertNull(errorReporter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj5 = node3.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = node3.getJSDocInfo();
        java.lang.String str7 = node3.toString();
        boolean boolean8 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj12 = node10.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node10.setJSType(jSType13);
        boolean boolean15 = node10.hasOneChild();
        node10.addSuppression("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.rhino.Node node18 = node3.copyInformationFrom(node10);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node10.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("language version");
        int int23 = node22.getLineno();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node22, node26 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray27, 40, 0);
        node30.detachChildren();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(1, node10, node30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = null;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler34 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback35 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal36 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler34, callback35);
        boolean boolean37 = nodeTraversal36.hasScope();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.jscomp.CheckLevel checkLevel41 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray44 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make(diagnosticType42, strArray44);
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make(diagnosticType46, strArray48);
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType42, strArray48);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler51 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback52 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal53 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler51, callback52);
        com.google.javascript.jscomp.Compiler compiler54 = nodeTraversal53.getCompiler();
        com.google.javascript.rhino.Node node55 = nodeTraversal53.getEnclosingFunction();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj60 = node58.getProp((int) (short) 1);
        boolean boolean61 = node58.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj65 = node63.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable69 = node68.siblings();
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((-1), node58, node63, node68);
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray73 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make(diagnosticType71, strArray73);
        com.google.javascript.jscomp.CheckLevel checkLevel75 = diagnosticType71.level;
        java.lang.String str76 = diagnosticType71.toString();
        java.lang.String str77 = diagnosticType71.toString();
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType83 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType84 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray86 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError87 = com.google.javascript.jscomp.JSError.make(diagnosticType84, strArray86);
        com.google.javascript.jscomp.JSError jSError88 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node80, diagnosticType83, strArray86);
        com.google.javascript.jscomp.JSError jSError89 = nodeTraversal53.makeError(node63, diagnosticType71, strArray86);
        com.google.javascript.jscomp.JSError jSError90 = nodeTraversal36.makeError(node40, checkLevel41, diagnosticType42, strArray86);
        try {
            com.google.javascript.jscomp.JSError jSError91 = com.google.javascript.jscomp.JSError.make("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", node10, diagnosticType33, strArray86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(jSDocInfo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BITXOR" + "'", str7.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNull(compiler54);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(obj60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeIterable69);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str76.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str77.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(diagnosticType83);
        org.junit.Assert.assertNotNull(diagnosticType84);
        org.junit.Assert.assertNotNull(strArray86);
        org.junit.Assert.assertNotNull(jSError87);
        org.junit.Assert.assertNotNull(jSError88);
        org.junit.Assert.assertNotNull(jSError89);
        org.junit.Assert.assertNotNull(jSError90);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("8", charset1);
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("hi!");
        evaluatorException4.initLineSource("");
        int int7 = evaluatorException4.columnNumber();
        evaluatorException4.initSourceName("Named type with empty name component");
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) charset1, (java.lang.Object) "Named type with empty name component");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst11 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler12, (java.util.List<com.google.javascript.rhino.Node>) nodeList14, callback16);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12);
        java.nio.charset.Charset charset20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset20);
        java.lang.String str22 = jSSourceFile21.getOriginalPath();
        com.google.javascript.rhino.Node node23 = compiler12.parse(jSSourceFile21);
        com.google.javascript.jscomp.JsAst jsAst24 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile21);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile21, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromCode("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "JSC_NODE_TRAVERSAL_ERROR: {0}");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile21, jSSourceFile29 };
        com.google.javascript.jscomp.JSModule jSModule31 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray32 = new com.google.javascript.jscomp.JSModule[] { jSModule31 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions33.checkShadowVars;
        java.lang.String str35 = compilerOptions33.appNameStr;
        compilerOptions33.setTweakToNumberLiteral("URSH ", 0);
        compilerOptions33.checkCaja = false;
        try {
            com.google.javascript.jscomp.Result result41 = compiler0.compile(jSSourceFileArray30, jSModuleArray32, compilerOptions33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str22.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(jSModuleArray32);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException4.addSuppressed((java.lang.Throwable) runtimeException6);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj12 = node10.getProp((int) (short) 1);
        boolean boolean13 = node10.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = node10.getLastChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("language version");
        int int17 = node16.getLineno();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        boolean boolean22 = node20.isNoSideEffectsCall();
        java.lang.String str23 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(110, node10, node16);
        com.google.javascript.rhino.Node node26 = node24.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException6, (java.lang.Object) node26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(42, node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(17, node26, node29, node35, 49, 45);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node41.setVarArgs(true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention44 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean46 = closureCodingConvention44.isSuperClassReference("Unknown class name");
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str52 = node48.toString(true, false, true);
        boolean boolean53 = node48.hasOneChild();
        boolean boolean54 = closureCodingConvention44.isVarArgsParameter(node48);
        boolean boolean55 = node48.hasSideEffects();
        node41.addChildToBack(node48);
        node35.addChildrenToBack(node41);
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str23.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "BITXOR" + "'", str52.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkShadowVars;
        java.lang.String str2 = compilerOptions0.appNameStr;
        compilerOptions0.setTweakToNumberLiteral("URSH ", 0);
        compilerOptions0.checkCaja = false;
        compilerOptions0.inputDelimiter = "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        compilerOptions0.generateExports = true;
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean6 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str6 = closureCodingConvention5.getExportPropertyFunction();
        boolean boolean8 = closureCodingConvention5.isPrivate("");
        boolean boolean10 = closureCodingConvention5.isPrivate("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean14 = closureCodingConvention5.isOptionalParameter(node13);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection15 = closureCodingConvention5.getAssertionFunctions();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean18 = closureCodingConvention5.isOptionalParameter(node17);
        java.lang.String str19 = node3.checkTreeEquals(node17);
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean23 = node22.hasChildren();
        try {
            node17.replaceChild(node20, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeCollection4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n" + "'", str19.equals("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        int int22 = compiler14.getWarningCount();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.JSModule jSModule24 = compilerInput4.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(jSModule24);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback7);
        try {
            boolean boolean9 = compiler0.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n: Unknown class name";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode3;
        compilerOptions0.aliasStringsBlacklist = "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n";
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(37);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        boolean boolean5 = node3.isNoSideEffectsCall();
        java.lang.String str6 = node3.getString();
        java.lang.String str7 = node3.getString();
        com.google.javascript.rhino.EcmaError ecmaError9 = com.google.javascript.rhino.ScriptRuntime.typeError("@IMPLEMENTATION.VERSION@");
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.collapseAnonymousFunctions;
        compilerOptions10.aliasKeywords = false;
        com.google.javascript.jscomp.SourceMap.Format format14 = compilerOptions10.sourceMapFormat;
        try {
            java.lang.String str15 = com.google.javascript.rhino.ScriptRuntime.getMessage3("// Input %num%", (java.lang.Object) node3, (java.lang.Object) "@IMPLEMENTATION.VERSION@", (java.lang.Object) compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property // Input %num%");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(ecmaError9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format14);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str5 = closureCodingConvention4.getExportPropertyFunction();
        boolean boolean7 = closureCodingConvention4.isPrivate("");
        boolean boolean9 = closureCodingConvention4.isPrivate("hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node12.setVarArgs(true);
        com.google.javascript.rhino.Node node15 = node12.getParent();
        com.google.javascript.rhino.Node node16 = node12.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship17 = closureCodingConvention4.getDelegateRelationship(node12);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType20 = null;
        closureCodingConvention4.applySubclassRelationship(functionType18, functionType19, subclassType20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj26 = node24.getProp((int) (short) 1);
        boolean boolean27 = node24.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node28 = node24.getLastChild();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("language version");
        int int31 = node30.getLineno();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        boolean boolean36 = node34.isNoSideEffectsCall();
        java.lang.String str37 = node30.checkTreeEquals(node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(110, node24, node30);
        com.google.javascript.rhino.Node node40 = node38.getAncestor((int) (byte) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship41 = closureCodingConvention4.getDelegateRelationship(node40);
        node40.setType((int) (byte) 100);
        java.lang.String str44 = node2.checkTreeEquals(node40);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNull(delegateRelationship17);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str37.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(delegateRelationship41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Node tree inequality:\nTree1:\nEOF \n\n\nTree2:\nOR\n    BITXOR\n    STRING language version\n\n\nSubtree1: EOF \n\n\nSubtree2: OR\n    BITXOR\n    STRING language version\n" + "'", str44.equals("Node tree inequality:\nTree1:\nEOF \n\n\nTree2:\nOR\n    BITXOR\n    STRING language version\n\n\nSubtree1: EOF \n\n\nSubtree2: OR\n    BITXOR\n    STRING language version\n"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        try {
            java.io.Reader reader4 = jSSourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: JSC_NODE_TRAVERSAL_ERROR (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str3.equals("JSC_NODE_TRAVERSAL_ERROR"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }
}

