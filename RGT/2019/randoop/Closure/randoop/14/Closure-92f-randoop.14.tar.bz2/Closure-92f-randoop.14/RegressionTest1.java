import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        boolean boolean4 = functionType3.isBooleanValueType();
        boolean boolean5 = functionType3.isRecordType();
        boolean boolean6 = functionType3.isDateType();
        boolean boolean7 = functionType3.isInterface();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = functionType3.getJSDocInfo();
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jSDocInfo8);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 16, (java.lang.Object) 48);
        com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str5 = ecmaError4.toString();
        runtimeException2.addSuppressed((java.lang.Throwable) ecmaError4);
        java.lang.String str7 = ecmaError4.sourceName();
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertNotNull(ecmaError4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: " + "'", str5.equals("com.google.javascript.rhino.EcmaError: TypeError: "));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(120, nodeArray2);
        node3.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(120, nodeArray7);
        com.google.javascript.rhino.Node node9 = node3.clonePropsFrom(node8);
        boolean boolean10 = node3.wasEmptyNode();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(120, nodeArray12);
        node13.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(120, nodeArray17);
        com.google.javascript.rhino.Node node19 = node13.clonePropsFrom(node18);
        node18.detachChildren();
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(120, nodeArray22);
        node23.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(120, nodeArray27);
        com.google.javascript.rhino.Node node29 = node23.clonePropsFrom(node28);
        node28.detachChildren();
        node28.setType((int) (byte) 0);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4', node3, node18, node28);
        java.lang.String str37 = node3.toString(false, false, false);
        node3.setLineno((int) (short) 100);
        com.google.javascript.rhino.Node node40 = node3.getLastChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder41 = node3.new FileLevelJsDocBuilder();
        boolean boolean42 = node3.hasChildren();
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "CATCH" + "'", str37.equals("CATCH"));
        org.junit.Assert.assertNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        boolean boolean4 = functionType3.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry6.getNativeFunctionType(jSTypeNative7);
        boolean boolean9 = functionType8.isBooleanValueType();
        boolean boolean10 = functionType8.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType3.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType8);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry13.getNativeFunctionType(jSTypeNative14);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry17.getNativeFunctionType(jSTypeNative18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry21.getNativeFunctionType(jSTypeNative22);
        boolean boolean24 = functionType23.isBooleanValueType();
        boolean boolean25 = functionType23.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry27.getNativeFunctionType(jSTypeNative28);
        boolean boolean30 = functionType29.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry32.getNativeFunctionType(jSTypeNative33);
        boolean boolean35 = functionType34.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry37.getNativeFunctionType(jSTypeNative38);
        boolean boolean40 = functionType39.isBooleanValueType();
        boolean boolean41 = functionType39.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry43.getNativeFunctionType(jSTypeNative44);
        boolean boolean46 = functionType45.isBooleanValueType();
        boolean boolean47 = functionType45.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] { functionType23, functionType29, functionType34, functionType39, functionType45 };
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry13.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType19, jSTypeArray48);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope51 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = functionType49.resolve(errorReporter50, jSTypeStaticScope51);
        boolean boolean53 = functionType3.isEquivalentTo(jSType52);
        boolean boolean54 = functionType3.isOrdinaryFunction();
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator1);
        java.lang.String str3 = jSSourceFile2.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        java.lang.String str7 = compilerInput5.getName();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, "", false);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "()" + "'", str3.equals("()"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "()" + "'", str7.equals("()"));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry5.getNativeFunctionType(jSTypeNative6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry9.getNativeFunctionType(jSTypeNative10);
        boolean boolean12 = functionType11.isBooleanValueType();
        boolean boolean13 = functionType11.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry15.getNativeFunctionType(jSTypeNative16);
        boolean boolean18 = functionType17.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry20.getNativeFunctionType(jSTypeNative21);
        boolean boolean23 = functionType22.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry25.getNativeFunctionType(jSTypeNative26);
        boolean boolean28 = functionType27.isBooleanValueType();
        boolean boolean29 = functionType27.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry31.getNativeFunctionType(jSTypeNative32);
        boolean boolean34 = functionType33.isBooleanValueType();
        boolean boolean35 = functionType33.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] { functionType11, functionType17, functionType22, functionType27, functionType33 };
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType7, jSTypeArray36);
        boolean boolean38 = functionType37.isDateType();
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("error reporter", "function (this:{1729365000}, {1382531955}): {650052274}");
        ecmaError2.initColumnNumber(13);
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(120, nodeArray1);
        node2.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(120, nodeArray6);
        com.google.javascript.rhino.Node node8 = node2.clonePropsFrom(node7);
        node7.detachChildren();
        boolean boolean10 = node7.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(120, nodeArray13);
        node14.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(120, nodeArray18);
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        boolean boolean21 = node14.wasEmptyNode();
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(120, nodeArray23);
        node24.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(120, nodeArray28);
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        node29.detachChildren();
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(120, nodeArray33);
        node34.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(120, nodeArray38);
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        node39.detachChildren();
        node39.setType((int) (byte) 0);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4', node14, node29, node39);
        java.lang.String str48 = node14.toString(false, false, false);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString(48, "NUMBER -1.0 10", 0, (int) (short) 100);
        try {
            node7.replaceChildAfter(node14, node53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(nodeArray23);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray33);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "CATCH" + "'", str48.equals("CATCH"));
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(120, nodeArray2);
        node3.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(120, nodeArray7);
        com.google.javascript.rhino.Node node9 = node3.clonePropsFrom(node8);
        boolean boolean10 = node3.wasEmptyNode();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(120, nodeArray12);
        node13.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(120, nodeArray17);
        com.google.javascript.rhino.Node node19 = node13.clonePropsFrom(node18);
        node18.detachChildren();
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(120, nodeArray22);
        node23.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(120, nodeArray27);
        com.google.javascript.rhino.Node node29 = node23.clonePropsFrom(node28);
        node28.detachChildren();
        node28.setType((int) (byte) 0);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4', node3, node18, node28);
        java.lang.String str37 = node3.toString(false, false, false);
        node3.setLineno((int) (short) 100);
        com.google.javascript.rhino.Node node40 = node3.getLastChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder41 = node3.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node42 = node3.removeChildren();
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "CATCH" + "'", str37.equals("CATCH"));
        org.junit.Assert.assertNull(node40);
        org.junit.Assert.assertNull(node42);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("ReferenceError");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ReferenceError");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet4 = jSTypeRegistry2.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry6.getNativeFunctionType(jSTypeNative7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry10.getNativeFunctionType(jSTypeNative11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry14.getNativeFunctionType(jSTypeNative15);
        boolean boolean17 = functionType16.isBooleanValueType();
        boolean boolean18 = functionType16.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry20.getNativeFunctionType(jSTypeNative21);
        boolean boolean23 = functionType22.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry25.getNativeFunctionType(jSTypeNative26);
        boolean boolean28 = functionType27.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry30.getNativeFunctionType(jSTypeNative31);
        boolean boolean33 = functionType32.isBooleanValueType();
        boolean boolean34 = functionType32.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry36.getNativeFunctionType(jSTypeNative37);
        boolean boolean39 = functionType38.isBooleanValueType();
        boolean boolean40 = functionType38.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { functionType16, functionType22, functionType27, functionType32, functionType38 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry6.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, jSTypeArray41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType42.resolve(errorReporter43, jSTypeStaticScope44);
        boolean boolean46 = functionType42.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = functionType42.getConstructor();
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        functionType42.setJSDocInfo(jSDocInfo48);
        com.google.javascript.rhino.Node node50 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType42, node50);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(120, nodeArray53);
        node54.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(120, nodeArray58);
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        java.lang.String str61 = node60.getQualifiedName();
        com.google.javascript.rhino.Node node62 = node60.cloneTree();
        java.util.Set<java.lang.String> strSet63 = node62.getDirectives();
        boolean boolean64 = functionType42.equals((java.lang.Object) strSet63);
        org.junit.Assert.assertNotNull(objectTypeSet4);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(strSet63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        boolean boolean4 = functionType3.isBooleanValueType();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet5 = functionType3.getPossibleToBooleanOutcomes();
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        boolean boolean7 = com.google.javascript.rhino.jstype.JSType.isEquivalent((com.google.javascript.rhino.jstype.JSType) functionType3, jSType6);
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet5 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet5.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, 0, 8);
        int int4 = scriptOrFnNode3.getEncodedSourceEnd();
        int int6 = scriptOrFnNode3.addVar("CATCH");
        int int7 = scriptOrFnNode3.getParamCount();
        int int8 = scriptOrFnNode3.getEncodedSourceEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        boolean boolean4 = functionType3.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry6.getNativeFunctionType(jSTypeNative7);
        boolean boolean9 = functionType8.isBooleanValueType();
        boolean boolean10 = functionType8.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType11 = functionType3.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType8);
        boolean boolean12 = functionType3.isArrayType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry14.getNativeFunctionType(jSTypeNative15);
        boolean boolean17 = functionType16.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry19.getNativeFunctionType(jSTypeNative20);
        boolean boolean22 = functionType21.isBooleanValueType();
        boolean boolean23 = functionType21.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType24 = functionType16.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType21);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair25 = functionType3.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType21);
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry27.getNativeFunctionType(jSTypeNative28);
        boolean boolean30 = functionType29.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry32.getNativeFunctionType(jSTypeNative33);
        boolean boolean35 = functionType34.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry37.getNativeFunctionType(jSTypeNative38);
        boolean boolean40 = functionType39.isBooleanValueType();
        boolean boolean41 = functionType39.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType42 = functionType34.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType39);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry44.getNativeFunctionType(jSTypeNative45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry48.getNativeFunctionType(jSTypeNative49);
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry52.getNativeFunctionType(jSTypeNative53);
        boolean boolean55 = functionType54.isBooleanValueType();
        boolean boolean56 = functionType54.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative59 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry58.getNativeFunctionType(jSTypeNative59);
        boolean boolean61 = functionType60.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative64 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry63.getNativeFunctionType(jSTypeNative64);
        boolean boolean66 = functionType65.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter67 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter67);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry68.getNativeFunctionType(jSTypeNative69);
        boolean boolean71 = functionType70.isBooleanValueType();
        boolean boolean72 = functionType70.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry74.getNativeFunctionType(jSTypeNative75);
        boolean boolean77 = functionType76.isBooleanValueType();
        boolean boolean78 = functionType76.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] { functionType54, functionType60, functionType65, functionType70, functionType76 };
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry44.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType50, jSTypeArray79);
        com.google.javascript.rhino.ErrorReporter errorReporter81 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope82 = null;
        com.google.javascript.rhino.jstype.JSType jSType83 = functionType80.resolve(errorReporter81, jSTypeStaticScope82);
        boolean boolean84 = functionType34.isEquivalentTo(jSType83);
        com.google.javascript.rhino.jstype.JSType jSType85 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.jstype.JSType jSType86 = functionType3.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) functionType29);
        boolean boolean87 = jSType86.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType88 = jSType86.unboxesTo();
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(typePair25);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative59 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative59.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative64 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative64.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(jSType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNull(jSType88);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry5.getNativeFunctionType(jSTypeNative6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry9.getNativeFunctionType(jSTypeNative10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry13.getNativeFunctionType(jSTypeNative14);
        boolean boolean16 = functionType15.isBooleanValueType();
        boolean boolean17 = functionType15.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry19.getNativeFunctionType(jSTypeNative20);
        boolean boolean22 = functionType21.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry24.getNativeFunctionType(jSTypeNative25);
        boolean boolean27 = functionType26.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry29.getNativeFunctionType(jSTypeNative30);
        boolean boolean32 = functionType31.isBooleanValueType();
        boolean boolean33 = functionType31.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry35.getNativeFunctionType(jSTypeNative36);
        boolean boolean38 = functionType37.isBooleanValueType();
        boolean boolean39 = functionType37.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { functionType15, functionType21, functionType26, functionType31, functionType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry5.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType11, jSTypeArray40);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry1.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry44.getNativeFunctionType(jSTypeNative45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry48.getNativeFunctionType(jSTypeNative49);
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry52.getNativeFunctionType(jSTypeNative53);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative57 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry56.getNativeFunctionType(jSTypeNative57);
        boolean boolean59 = functionType58.isBooleanValueType();
        boolean boolean60 = functionType58.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry62.getNativeFunctionType(jSTypeNative63);
        boolean boolean65 = functionType64.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry67.getNativeFunctionType(jSTypeNative68);
        boolean boolean70 = functionType69.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative73 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry72.getNativeFunctionType(jSTypeNative73);
        boolean boolean75 = functionType74.isBooleanValueType();
        boolean boolean76 = functionType74.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative79 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry78.getNativeFunctionType(jSTypeNative79);
        boolean boolean81 = functionType80.isBooleanValueType();
        boolean boolean82 = functionType80.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray83 = new com.google.javascript.rhino.jstype.JSType[] { functionType58, functionType64, functionType69, functionType74, functionType80 };
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry48.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType54, jSTypeArray83);
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry44.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType84);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] { functionType84 };
        com.google.javascript.rhino.Node node87 = jSTypeRegistry1.createParametersWithVarArgs(jSTypeArray86);
        com.google.javascript.rhino.Node node88 = node87.removeFirstChild();
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + jSTypeNative57 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative57.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative73 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative73.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative79 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative79.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(jSTypeArray83);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node88);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler1.getErrorManager();
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler1.getSourceMap();
        compiler1.reportCodeChange();
        int int5 = compiler1.getWarningCount();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = compiler1.getTypeRegistry();
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(jSTypeRegistry6);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        boolean boolean4 = diagnosticGroup2.matches(diagnosticType3);
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = null;
        boolean boolean8 = diagnosticGroup6.matches(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel11);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup10;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = null;
        boolean boolean16 = diagnosticGroup14.matches(diagnosticType15);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray20 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup2, diagnosticGroup6, diagnosticGroup10, diagnosticGroup14, diagnosticGroup18, diagnosticGroup19 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray20);
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup21;
        boolean boolean23 = composeWarningsGuard1.disables(diagnosticGroup21);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertNotNull(diagnosticGroupArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(0, 0, 8);
        scriptOrFnNode4.setSourceName("a");
        scriptOrFnNode4.setBaseLineno(47);
        boolean[] booleanArray9 = scriptOrFnNode4.getParamAndVarConst();
        int int10 = scriptOrFnNode4.getRegexpCount();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(10, (com.google.javascript.rhino.Node) scriptOrFnNode4, 48, (int) (short) 0);
        scriptOrFnNode4.addSuppression("()");
        int int16 = scriptOrFnNode4.getRegexpCount();
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet4 = jSTypeRegistry2.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry6.getNativeFunctionType(jSTypeNative7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry10.getNativeFunctionType(jSTypeNative11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry14.getNativeFunctionType(jSTypeNative15);
        boolean boolean17 = functionType16.isBooleanValueType();
        boolean boolean18 = functionType16.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry20.getNativeFunctionType(jSTypeNative21);
        boolean boolean23 = functionType22.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry25.getNativeFunctionType(jSTypeNative26);
        boolean boolean28 = functionType27.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry30.getNativeFunctionType(jSTypeNative31);
        boolean boolean33 = functionType32.isBooleanValueType();
        boolean boolean34 = functionType32.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry36.getNativeFunctionType(jSTypeNative37);
        boolean boolean39 = functionType38.isBooleanValueType();
        boolean boolean40 = functionType38.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { functionType16, functionType22, functionType27, functionType32, functionType38 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry6.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, jSTypeArray41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType42.resolve(errorReporter43, jSTypeStaticScope44);
        boolean boolean46 = functionType42.isTemplateType();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = functionType42.getConstructor();
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        functionType42.setJSDocInfo(jSDocInfo48);
        com.google.javascript.rhino.Node node50 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType42, node50);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder52 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(120, nodeArray54);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable56 = node55.children();
        java.lang.String[] strArray60 = new java.lang.String[] { "320", "320: hi!", "CATCH" };
        java.util.LinkedHashSet<java.lang.String> strSet61 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet61, strArray60);
        node55.setDirectives((java.util.Set<java.lang.String>) strSet61);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder64 = functionBuilder52.withParamsNode(node55);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = functionBuilder64.build();
        com.google.javascript.rhino.jstype.FunctionType functionType66 = functionType65.getConstructor();
        org.junit.Assert.assertNotNull(objectTypeSet4);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertNotNull(nodeArray54);
        org.junit.Assert.assertNotNull(nodeIterable56);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(functionBuilder64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(functionType66);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler1.getErrorManager();
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler1.getSourceMap();
        compiler1.reportCodeChange();
        java.lang.String str5 = compiler1.toSource();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler1.tracker;
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(120, nodeArray2);
        node3.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(120, nodeArray7);
        com.google.javascript.rhino.Node node9 = node3.clonePropsFrom(node8);
        com.google.javascript.rhino.Node node10 = node8.cloneTree();
        java.lang.String str11 = node10.toString();
        boolean boolean12 = node10.hasSideEffects();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(120, nodeArray15);
        node16.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(120, nodeArray20);
        com.google.javascript.rhino.Node node22 = node16.clonePropsFrom(node21);
        boolean boolean23 = node16.wasEmptyNode();
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(120, nodeArray25);
        node26.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(120, nodeArray30);
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        node31.detachChildren();
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(120, nodeArray35);
        node36.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(120, nodeArray40);
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        node41.detachChildren();
        node41.setType((int) (byte) 0);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4', node16, node31, node41);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(120, nodeArray48);
        node49.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(120, nodeArray53);
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        node54.detachChildren();
        node54.setType((int) (byte) 0);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (short) 100, node10, node46, node54);
        java.lang.String str63 = node10.toString(false, false, true);
        try {
            int int65 = node10.getExistingIntProp((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CATCH 0" + "'", str11.equals("CATCH 0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(nodeArray30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "CATCH" + "'", str63.equals("CATCH"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.rhino.Node node4 = nodeTraversal3.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.JSModule jSModule5 = nodeTraversal3.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry5.getNativeFunctionType(jSTypeNative6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry9.getNativeFunctionType(jSTypeNative10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry13.getNativeFunctionType(jSTypeNative14);
        boolean boolean16 = functionType15.isBooleanValueType();
        boolean boolean17 = functionType15.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry19.getNativeFunctionType(jSTypeNative20);
        boolean boolean22 = functionType21.isBooleanValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry24.getNativeFunctionType(jSTypeNative25);
        boolean boolean27 = functionType26.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry29.getNativeFunctionType(jSTypeNative30);
        boolean boolean32 = functionType31.isBooleanValueType();
        boolean boolean33 = functionType31.isRecordType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry35.getNativeFunctionType(jSTypeNative36);
        boolean boolean38 = functionType37.isBooleanValueType();
        boolean boolean39 = functionType37.isRecordType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { functionType15, functionType21, functionType26, functionType31, functionType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry5.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType11, jSTypeArray40);
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry1.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType41);
        java.lang.String str43 = functionType41.getTemplateTypeName();
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(120, nodeArray46);
        node47.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(120, nodeArray51);
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        boolean boolean54 = node47.wasEmptyNode();
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(120, nodeArray56);
        node57.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray61 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(120, nodeArray61);
        com.google.javascript.rhino.Node node63 = node57.clonePropsFrom(node62);
        node62.detachChildren();
        com.google.javascript.rhino.Node[] nodeArray66 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(120, nodeArray66);
        node67.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray71 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(120, nodeArray71);
        com.google.javascript.rhino.Node node73 = node67.clonePropsFrom(node72);
        node72.detachChildren();
        node72.setType((int) (byte) 0);
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) '4', node47, node62, node72);
        functionType41.setSource(node47);
        boolean boolean79 = functionType41.isConstructor();
        com.google.javascript.rhino.Node[] nodeArray81 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(120, nodeArray81);
        node82.setOptionalArg(false);
        com.google.javascript.rhino.Node[] nodeArray86 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(120, nodeArray86);
        com.google.javascript.rhino.Node node88 = node82.clonePropsFrom(node87);
        com.google.javascript.rhino.Node node89 = node87.cloneTree();
        functionType41.setSource(node87);
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType3);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertNotNull(nodeArray61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeArray66);
        org.junit.Assert.assertNotNull(nodeArray71);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(nodeArray81);
        org.junit.Assert.assertNotNull(nodeArray86);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node89);
    }
}

