import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("shne", "ge");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((-2));
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setAllFlags();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setMutatesGlobalState();
        int int6 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setThrows();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        node3.putProp((int) (byte) 10, (java.lang.Object) 150);
        node3.putBooleanProp(10, false);
        java.util.Set<java.lang.String> strSet12 = node3.getDirectives();
        boolean boolean13 = node3.hasChildren();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "", false);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getAbstractMethodName();
        boolean boolean3 = defaultCodingConvention0.isConstantKey("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "goog.abstractMethod", 10, 34);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        int int42 = node40.getChildCount();
        node40.putProp((int) (byte) 10, (java.lang.Object) 150);
        node40.putBooleanProp(10, false);
        boolean boolean49 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) ' ', node13, node30, node40);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship51 = defaultCodingConvention8.getClassesDefinedByCall(node30);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node55.detachChildren();
        boolean boolean57 = node55.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node61.detachChildren();
        boolean boolean63 = node61.isOnlyModifiesThisCall();
        int int65 = node61.getIntProp((int) 'a');
        boolean boolean66 = node55.isEquivalentTo(node61);
        node61.putIntProp(41, 4095);
        boolean boolean70 = node30.isEquivalentToTyped(node61);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship71 = defaultCodingConvention0.getDelegateRelationship(node30);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(subclassRelationship51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(delegateRelationship71);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean8 = compilerOptions0.generateExports;
        boolean boolean9 = compilerOptions0.decomposeExpressions;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy10;
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.specializeInitialModule = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        int int5 = loggerErrorManager3.getErrorCount();
        int int6 = loggerErrorManager3.getWarningCount();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler0.getErrorManager();
        java.lang.String str4 = compiler0.toSource();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat5.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, false);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node10 = compiler9.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat5.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray14 = compiler9.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str18 = jSSourceFile17.getName();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node20 = compiler19.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap21 = compiler19.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node25 = compiler19.parse(jSSourceFile24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile17, jSSourceFile24 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.inlineGetters;
        java.lang.String str31 = compilerOptions29.locale;
        com.google.javascript.jscomp.Result result32 = compiler9.compile(jSSourceFileArray26, jSModuleArray27, compilerOptions29);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        java.lang.String str37 = jSSourceFile35.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40);
        com.google.javascript.jscomp.Region region43 = jSSourceFile40.getRegion(31);
        java.lang.String str44 = jSSourceFile40.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput52 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile55 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        jSSourceFile55.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JsAst jsAst60 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile59);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile35, jSSourceFile40, jSSourceFile47, jSSourceFile51, jSSourceFile55, jSSourceFile59 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean63 = compilerOptions62.inlineGetters;
        java.lang.String str64 = compilerOptions62.locale;
        compilerOptions62.generateExports = false;
        com.google.javascript.jscomp.Result result67 = compiler0.compile(jSSourceFileArray26, jSSourceFileArray61, compilerOptions62);
        boolean boolean68 = compiler0.isTypeCheckingEnabled();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(errorManager3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(messageFormatter13);
        org.junit.Assert.assertNotNull(jSErrorArray14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING " + "'", str18.equals("STRING "));
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNull(sourceMap21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(result32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str37.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNull(region43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNotNull(jSSourceFile55);
        org.junit.Assert.assertNotNull(jSSourceFile59);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(result67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.decomposeExpressions = false;
        java.lang.String str14 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean8 = compilerOptions0.generateExports;
        boolean boolean9 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean5 = defaultCodingConvention2.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node6 = null;
        java.lang.String str7 = defaultCodingConvention2.identifyTypeDefAssign(node6);
        java.lang.String str8 = defaultCodingConvention2.getDelegateSuperclassName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean14 = node13.isUnscopedQualifiedName();
        int int15 = node13.getChildCount();
        node13.putProp((int) (byte) 10, (java.lang.Object) 150);
        node13.putBooleanProp(10, false);
        boolean boolean22 = node13.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = defaultCodingConvention9.getDelegateRelationship(node13);
        boolean boolean24 = defaultCodingConvention2.isPropertyTestFunction(node13);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node28.detachChildren();
        boolean boolean30 = node28.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '#', node13, node28);
        node13.setOptionalArg(false);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(32);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention36 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        int int42 = node40.getChildCount();
        node40.putProp((int) (byte) 10, (java.lang.Object) 150);
        node40.putBooleanProp(10, false);
        boolean boolean49 = node40.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship50 = defaultCodingConvention36.getDelegateRelationship(node40);
        com.google.javascript.rhino.Node node54 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention36, "language version", (-1), 40);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean60 = node59.isUnscopedQualifiedName();
        node59.detachChildren();
        java.lang.String[] strArray64 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet65 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet65, strArray64);
        node59.setDirectives((java.util.Set<java.lang.String>) strSet65);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(110, node59, 20, (int) (byte) -1);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship71 = defaultCodingConvention36.getClassesDefinedByCall(node59);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node75.detachChildren();
        boolean boolean77 = node75.isOnlyModifiesThisCall();
        int int79 = node75.getIntProp((int) 'a');
        boolean boolean80 = node75.isSyntheticBlock();
        com.google.javascript.rhino.Node node81 = node59.copyInformationFrom(node75);
        boolean boolean82 = node59.isLocalResultCall();
        int int83 = node59.getSideEffectFlags();
        node59.setLineno(34);
        com.google.javascript.rhino.Node node86 = null;
        try {
            com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node(38, node13, node35, node59, node86, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(delegateRelationship50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(strArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNull(subclassRelationship71);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
//        compiler0.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.inlineGetters;
//        java.lang.String str8 = compilerOptions6.locale;
//        compilerOptions6.checkCaja = true;
//        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
//        compiler0.initOptions(compilerOptions6);
//        compilerOptions6.removeTryCatchFinally = false;
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean23 = node22.isUnscopedQualifiedName();
//        int int24 = node22.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
//        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
//        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("error reporter", node22, checkLevel27, diagnosticType28, strArray36);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat48 = diagnosticType47.format;
//        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType47, strArray54);
//        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType43, strArray54);
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType28, strArray54);
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = diagnosticType28.level;
//        compilerOptions6.checkMissingReturn = checkLevel58;
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler60 = compilerOptions6.getAliasTransformationHandler();
//        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition62 = null;
//        try {
//            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation63 = aliasTransformationHandler60.logAliasTransformation("()", aliasTransformationSourcePosition62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNull(node3);
//        org.junit.Assert.assertNotNull(errorManager4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType28);
//        org.junit.Assert.assertNotNull(messageFormat29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(diagnosticType43);
//        org.junit.Assert.assertNotNull(diagnosticType47);
//        org.junit.Assert.assertNotNull(messageFormat48);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(jSError56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(aliasTransformationHandler60);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.checkCaja = true;
        boolean boolean43 = compilerOptions24.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions24.checkFunctions;
        compilerOptions24.removeUnusedLocalVars = false;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("window", "Named type with empty name component", "null(ERROR)", (int) (short) 1, "STRING ", (int) (byte) 1);
        java.lang.String str7 = ecmaError6.getErrorMessage();
        java.lang.String str8 = ecmaError6.lineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Named type with empty name component" + "'", str7.equals("Named type with empty name component"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING " + "'", str8.equals("STRING "));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        boolean boolean17 = closureCodingConvention0.isVarArgsParameter(node5);
        java.lang.String str18 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node20 = compiler19.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap21 = compiler19.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState22 = compiler19.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler19, callback23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean29 = node28.isUnscopedQualifiedName();
        int int30 = node28.getChildCount();
        java.util.Set<java.lang.String> strSet31 = node28.getDirectives();
        node28.removeProp(29);
        com.google.javascript.rhino.Node node34 = node28.removeChildren();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast35 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal24, node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "goog.abstractMethod" + "'", str18.equals("goog.abstractMethod"));
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNull(sourceMap21);
        org.junit.Assert.assertNotNull(intermediateState22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(strSet31);
        org.junit.Assert.assertNull(node34);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException5);
        int int7 = evaluatorException5.lineNumber();
        java.io.FilenameFilter filenameFilter8 = null;
        java.lang.String str9 = evaluatorException5.getScriptStackTrace(filenameFilter8);
        try {
            evaluatorException5.initLineNumber(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
//        java.lang.String str6 = context1.getImplementationVersion();
//        context1.removeActivationName("Named type with empty name component");
//        context1.removeActivationName("hi!");
//        boolean boolean11 = context1.isGeneratingDebug();
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter13 = context1.setErrorReporter(errorReporter12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(errorReporter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException5);
        java.io.FilenameFilter filenameFilter7 = null;
        java.lang.String str8 = ecmaError1.getScriptStackTrace(filenameFilter7);
        java.lang.String str9 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<No stack trace available>" + "'", str8.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("STRING  [empty_block: 1]\n", 36, 36);
        node3.addSuppression("goog.global");
        boolean boolean7 = node3.getBooleanProp((-3));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("TypeError: ", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap2 = compilerOptions0.cssRenamingMap;
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkMethods = checkLevel4;
        boolean boolean6 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(cssRenamingMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
//        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
//        java.lang.String str13 = jSSourceFile12.getName();
//        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean25 = compilerOptions24.inlineGetters;
//        java.lang.String str26 = compilerOptions24.locale;
//        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
//        compilerOptions24.unaliasableGlobals = "(())";
//        compilerOptions24.aliasStringsBlacklist = "null(ERROR)";
//        boolean boolean32 = compilerOptions24.ambiguateProperties;
//        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean41 = node40.isUnscopedQualifiedName();
//        int int42 = node40.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType43 = node40.getJSType();
//        com.google.javascript.rhino.Node node44 = node40.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel45 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat47 = diagnosticType46.format;
//        java.lang.String[] strArray54 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("error reporter", node40, checkLevel45, diagnosticType46, strArray54);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat66 = diagnosticType65.format;
//        java.lang.String[] strArray72 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType65, strArray72);
//        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType61, strArray72);
//        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType46, strArray72);
//        com.google.javascript.jscomp.CheckLevel checkLevel76 = diagnosticType46.level;
//        compilerOptions24.checkGlobalNamesLevel = checkLevel76;
//        java.lang.String str78 = compilerOptions24.aliasableGlobals;
//        boolean boolean79 = compilerOptions24.printInputDelimiter;
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertNotNull(messageFormatter3);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(errorManager6);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNotNull(jSErrorArray9);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertNull(sourceMap16);
//        org.junit.Assert.assertNotNull(jSSourceFile19);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertNotNull(jSSourceFileArray21);
//        org.junit.Assert.assertNotNull(jSModuleArray22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(result27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(node40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNull(jSType43);
//        org.junit.Assert.assertNotNull(node44);
//        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType46);
//        org.junit.Assert.assertNotNull(messageFormat47);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(diagnosticType61);
//        org.junit.Assert.assertNotNull(diagnosticType65);
//        org.junit.Assert.assertNotNull(messageFormat66);
//        org.junit.Assert.assertNotNull(strArray72);
//        org.junit.Assert.assertNotNull(jSError73);
//        org.junit.Assert.assertNotNull(jSError74);
//        org.junit.Assert.assertNotNull(jSError75);
//        org.junit.Assert.assertTrue("'" + checkLevel76 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel76.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNull(str78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        compilerOptions0.renamePrefix = "null(ERROR)";
        compilerOptions0.removeTryCatchFinally = true;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(byteArray6);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test026");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter6 = context1.setErrorReporter(errorReporter5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "STRING  [empty_block: 1]\n", false);
        try {
            java.lang.String str12 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager3.getErrors();
        int int6 = loggerErrorManager3.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = loggerErrorManager3.getErrors();
        loggerErrorManager3.setTypedPercent((double) 48);
        loggerErrorManager3.setTypedPercent((double) 30);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(jSErrorArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.checkCaja = true;
        boolean boolean43 = compilerOptions24.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions24.checkFunctions;
        compilerOptions24.setDefineToStringLiteral("shne", "hi!");
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: hi! at DiagnosticGroup<tweakValidation>(WARNING) line 41 : 0");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat6 = diagnosticType5.format;
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType5, strArray12);
        boolean boolean14 = diagnosticGroup0.matches(jSError13);
        java.lang.String str15 = jSError13.description;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(messageFormat6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Exceeded max number of optimization iterations: hi!" + "'", str15.equals("Exceeded max number of optimization iterations: hi!"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule10 = null;
        compilerInput3.setModule(jSModule10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node13 = compiler12.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager14 = compiler12.getErrorManager();
        com.google.javascript.jscomp.ErrorManager errorManager15 = compiler12.getErrorManager();
        compilerInput3.setErrorManager(errorManager15);
        com.google.javascript.jscomp.SourceAst sourceAst17 = compilerInput3.getSourceAst();
        boolean boolean18 = compilerInput3.isExtern();
        java.util.logging.Logger logger19 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager20 = new com.google.javascript.jscomp.LoggerErrorManager(logger19);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup25;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup25;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard29 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup25, checkLevel28);
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat31 = diagnosticType30.format;
        java.lang.String[] strArray32 = null;
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel28, diagnosticType30, strArray32);
        loggerErrorManager20.report(checkLevel21, jSError33);
        double double35 = loggerErrorManager20.getTypedPercent();
        loggerErrorManager20.setTypedPercent((double) 120);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager20);
        double double39 = loggerErrorManager20.getTypedPercent();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(errorManager14);
        org.junit.Assert.assertNotNull(errorManager15);
        org.junit.Assert.assertNull(sourceAst17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(messageFormat31);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 120.0d + "'", double39 == 120.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        compilerOptions0.setOutputCharset("Not declared as a type name");
        java.lang.String str8 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        node5.putProp((int) (byte) 10, (java.lang.Object) 150);
        node5.putBooleanProp(10, false);
        boolean boolean14 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean19 = node18.isUnscopedQualifiedName();
        int int20 = node18.getChildCount();
        java.util.Set<java.lang.String> strSet21 = node18.getDirectives();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node25.detachChildren();
        boolean boolean27 = node25.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node31.detachChildren();
        boolean boolean33 = node31.isOnlyModifiesThisCall();
        int int35 = node31.getIntProp((int) 'a');
        boolean boolean36 = node25.isEquivalentTo(node31);
        com.google.javascript.rhino.Node node37 = node18.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean42 = node41.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node43 = node18.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node47.detachChildren();
        boolean boolean49 = node47.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable50 = node47.siblings();
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node5, node41, node47 };
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, nodeArray51, 0, 18);
        try {
            com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (byte) 1, nodeArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(strSet21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(nodeIterable50);
        org.junit.Assert.assertNotNull(nodeArray51);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean3 = compilerOptions2.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = compilerOptions2.cssRenamingMap;
        compilerOptions2.instrumentForCoverage = false;
        boolean boolean7 = compilerOptions2.optimizeCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.inlineGetters;
        java.lang.String str10 = compilerOptions8.locale;
        compilerOptions8.setLooseTypes(false);
        boolean boolean13 = compilerOptions8.gatherCssNames;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str15 = closureCodingConvention14.getAbstractMethodName();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        int int45 = node19.getType();
        com.google.javascript.rhino.Node node46 = node19.getLastSibling();
        boolean boolean47 = node46.isLocalResultCall();
        boolean boolean48 = closureCodingConvention14.isVarArgsParameter(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean53 = node52.isUnscopedQualifiedName();
        node52.detachChildren();
        java.lang.String[] strArray57 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet58 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet58, strArray57);
        node52.setDirectives((java.util.Set<java.lang.String>) strSet58);
        node46.setDirectives((java.util.Set<java.lang.String>) strSet58);
        compilerOptions8.stripNameSuffixes = strSet58;
        compilerOptions2.stripNamePrefixes = strSet58;
        compilerOptions0.stripNamePrefixes = strSet58;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(cssRenamingMap4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 40 + "'", int45 == 40);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.reportPath = "Not declared as a constructor";
        compilerOptions0.checkUnusedPropertiesEarly = true;
        compilerOptions0.specializeInitialModule = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.setAcceptConstKeyword(false);
        compilerOptions0.nameReferenceGraphPath = "()";
        boolean boolean15 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.coalesceVariableNames = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy15 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy15;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy15 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy15.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean9 = node8.isUnscopedQualifiedName();
        int int10 = node8.getChildCount();
        java.util.Set<java.lang.String> strSet11 = node8.getDirectives();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node15.detachChildren();
        boolean boolean17 = node15.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node21.detachChildren();
        boolean boolean23 = node21.isOnlyModifiesThisCall();
        int int25 = node21.getIntProp((int) 'a');
        boolean boolean26 = node15.isEquivalentTo(node21);
        com.google.javascript.rhino.Node node27 = node8.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        int int33 = node31.getChildCount();
        node31.putProp((int) (byte) 10, (java.lang.Object) 150);
        node31.putBooleanProp(10, false);
        boolean boolean40 = node31.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) ' ', node4, node21, node31);
        int int42 = node41.getLineno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(strSet11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        java.lang.String str5 = composeWarningsGuard3.toString();
        com.google.javascript.rhino.EcmaError ecmaError8 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "TypeError: ");
        com.google.javascript.rhino.Context context9 = null;
        com.google.javascript.rhino.Context context10 = com.google.javascript.rhino.Context.enter(context9);
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        java.lang.Object obj13 = context10.getThreadLocal((java.lang.Object) loggerErrorManager12);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup14;
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) ecmaError8, (java.lang.Object) loggerErrorManager12, (java.lang.Object) diagnosticGroup14);
        boolean boolean19 = composeWarningsGuard3.disables(diagnosticGroup14);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup14;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(ecmaError8);
        org.junit.Assert.assertNotNull(context10);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("(())", "STRING  [empty_block: 1]\n", "hi!");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        compilerOptions0.collapseAnonymousFunctions = true;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("hi!");
//        int int4 = context1.getLanguageVersion();
//        context1.addActivationName("NOT 0\n    STRING \n    STRING \n    STRING \n    STRING \n");
//        boolean boolean8 = context1.isActivationNeeded("TypeError: ");
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup6;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat12 = diagnosticType11.format;
        java.lang.String[] strArray13 = null;
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel9, diagnosticType11, strArray13);
        loggerErrorManager1.report(checkLevel2, jSError14);
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = loggerErrorManager1.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray17 = loggerErrorManager1.getErrors();
        loggerErrorManager1.setTypedPercent((double) 1L);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(messageFormat12);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(jSErrorArray17);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap2 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap3 = compilerOptions0.cssRenamingMap;
        compilerOptions0.inlineGetters = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(cssRenamingMap2);
        org.junit.Assert.assertNull(cssRenamingMap3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap2 = compilerOptions0.cssRenamingMap;
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.checkMissingGetCssNameBlacklist = "window";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(cssRenamingMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test048");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("hi!");
//        boolean boolean4 = context1.hasCompileFunctionsWithDynamicScope();
//        context1.putThreadLocal((java.lang.Object) "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", (java.lang.Object) "DiagnosticGroup<tweakValidation>(WARNING)");
//        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler8.getState();
//        compiler8.disableThreads();
//        context1.removeThreadLocal((java.lang.Object) compiler8);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(intermediateState9);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (-1), 40);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean24 = node23.isUnscopedQualifiedName();
        node23.detachChildren();
        java.lang.String[] strArray28 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet29 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet29, strArray28);
        node23.setDirectives((java.util.Set<java.lang.String>) strSet29);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node23, 20, (int) (byte) -1);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship35 = defaultCodingConvention0.getClassesDefinedByCall(node23);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node39.detachChildren();
        boolean boolean41 = node39.isOnlyModifiesThisCall();
        int int43 = node39.getIntProp((int) 'a');
        boolean boolean44 = node39.isSyntheticBlock();
        com.google.javascript.rhino.Node node45 = node23.copyInformationFrom(node39);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node50.detachChildren();
        boolean boolean52 = node50.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node56.detachChildren();
        boolean boolean58 = node56.isOnlyModifiesThisCall();
        int int60 = node56.getIntProp((int) 'a');
        boolean boolean61 = node50.isEquivalentTo(node56);
        node56.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup65 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup65;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup65;
        com.google.javascript.jscomp.CheckLevel checkLevel68 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard69 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup65, checkLevel68);
        com.google.javascript.jscomp.DiagnosticType diagnosticType73 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat74 = diagnosticType73.format;
        java.lang.String[] strArray80 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError81 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType73, strArray80);
        java.lang.String[] strArray82 = null;
        com.google.javascript.jscomp.JSError jSError83 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node56, checkLevel68, diagnosticType73, strArray82);
        boolean boolean84 = node23.isEquivalentTo(node56);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(subclassRelationship35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup65);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType73);
        org.junit.Assert.assertNotNull(messageFormat74);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertNotNull(jSError83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        java.lang.String str3 = compilerOptions0.inputDelimiter;
        boolean boolean4 = compilerOptions0.checkEs5Strict;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "// Input %num%" + "'", str3.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback4);
        java.lang.String str6 = nodeTraversal5.getSourceName();
        java.lang.String str7 = nodeTraversal5.getSourceName();
        com.google.javascript.rhino.Node node8 = nodeTraversal5.getCurrentNode();
        try {
            com.google.javascript.rhino.Node node9 = nodeTraversal5.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(1);
        sideEffectFlags1.setThrows();
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3, composeWarningsGuard7, composeWarningsGuard11, composeWarningsGuard15 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup18;
        boolean boolean20 = composeWarningsGuard17.disables(diagnosticGroup18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        boolean boolean22 = composeWarningsGuard17.disables(diagnosticGroup21);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup23;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup23;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard27 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel26);
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup23;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup23;
        boolean boolean30 = composeWarningsGuard17.disables(diagnosticGroup23);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        java.lang.String str5 = composeWarningsGuard3.toString();
        java.lang.String str6 = composeWarningsGuard3.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = null;
        boolean boolean8 = composeWarningsGuard3.enables(diagnosticGroup7);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup2;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel5);
        java.lang.String str7 = diagnosticGroupWarningsGuard6.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean9 = diagnosticGroupWarningsGuard6.disables(diagnosticGroup8);
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray10 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup("JSC_OPTIMIZE_LOOP_ERROR", diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup("error reporter", diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup12;
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(diagnosticGroupArray10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkCaja;
        compilerOptions0.setDefineToBooleanLiteral("GETPROP 10", false);
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.groupVariableDeclarations = false;
        java.lang.String str7 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.inlineGetters;
        compilerOptions8.renamePrefix = "null(ERROR)";
        boolean boolean12 = compilerOptions8.devirtualizePrototypeMethods;
        compilerOptions8.foldConstants = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.inlineGetters;
        java.lang.String str17 = compilerOptions15.locale;
        compilerOptions15.setLooseTypes(false);
        boolean boolean20 = compilerOptions15.gatherCssNames;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str22 = closureCodingConvention21.getAbstractMethodName();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        int int28 = node26.getChildCount();
        java.util.Set<java.lang.String> strSet29 = node26.getDirectives();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node33.detachChildren();
        boolean boolean35 = node33.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node39.detachChildren();
        boolean boolean41 = node39.isOnlyModifiesThisCall();
        int int43 = node39.getIntProp((int) 'a');
        boolean boolean44 = node33.isEquivalentTo(node39);
        com.google.javascript.rhino.Node node45 = node26.copyInformationFromForTree(node39);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean50 = node49.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node51 = node26.copyInformationFromForTree(node49);
        int int52 = node26.getType();
        com.google.javascript.rhino.Node node53 = node26.getLastSibling();
        boolean boolean54 = node53.isLocalResultCall();
        boolean boolean55 = closureCodingConvention21.isVarArgsParameter(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean60 = node59.isUnscopedQualifiedName();
        node59.detachChildren();
        java.lang.String[] strArray64 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet65 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet65, strArray64);
        node59.setDirectives((java.util.Set<java.lang.String>) strSet65);
        node53.setDirectives((java.util.Set<java.lang.String>) strSet65);
        compilerOptions15.stripNameSuffixes = strSet65;
        compilerOptions8.stripTypePrefixes = strSet65;
        compilerOptions0.aliasableStrings = strSet65;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "goog.abstractMethod" + "'", str22.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(strSet29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 40 + "'", int52 == 40);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(strArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        compilerOptions24.unaliasableGlobals = "(())";
        boolean boolean30 = compilerOptions24.checkControlStructures;
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean32 = compilerOptions31.inlineGetters;
        java.lang.String str33 = compilerOptions31.locale;
        compilerOptions31.checkCaja = true;
        boolean boolean36 = compilerOptions31.instrumentForCoverageOnly;
        compilerOptions31.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions31.prettyPrint = false;
        boolean boolean41 = compilerOptions31.reserveRawExports;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup45 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup45;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup45;
        com.google.javascript.jscomp.CheckLevel checkLevel48 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard49 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup45, checkLevel48);
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat51 = diagnosticType50.format;
        java.lang.String[] strArray52 = null;
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel48, diagnosticType50, strArray52);
        compilerOptions31.checkProvides = checkLevel48;
        compilerOptions24.reportMissingOverride = checkLevel48;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup45);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(messageFormat51);
        org.junit.Assert.assertNotNull(jSError53);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(23);
        boolean boolean2 = node1.isVarArgs();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int2 = ecmaError1.lineNumber();
        int int3 = ecmaError1.lineNumber();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int6 = ecmaError5.lineNumber();
        int int7 = ecmaError5.lineNumber();
        java.lang.String str8 = ecmaError5.getName();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError1.addSuppressed((java.lang.Throwable) ecmaError5);
        java.lang.String str11 = ecmaError1.sourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TypeError" + "'", str8.equals("TypeError"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter3 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        node11.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup20;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup20;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard24 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType28, strArray35);
        java.lang.String[] strArray37 = null;
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node11, checkLevel23, diagnosticType28, strArray37);
        boolean boolean39 = diagnosticGroup0.matches(jSError38);
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(messageFormat29);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (int) (short) -1, (int) (byte) 0);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection8 = defaultCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        defaultCodingConvention0.applySingletonGetter(functionType9, functionType10, objectType11);
        java.lang.String str13 = defaultCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection8);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions0.prettyPrint = false;
        boolean boolean10 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup14;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard18 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat20 = diagnosticType19.format;
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel17, diagnosticType19, strArray21);
        compilerOptions0.checkProvides = checkLevel17;
        boolean boolean24 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(messageFormat20);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean11 = compilerOptions0.ideMode;
        java.lang.String str12 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.convertToDottedProperties = false;
        boolean boolean43 = compilerOptions24.removeTryCatchFinally;
        boolean boolean44 = compilerOptions24.recordFunctionInformation;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        java.util.Set<java.lang.String> strSet8 = node5.getDirectives();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node18.detachChildren();
        boolean boolean20 = node18.isOnlyModifiesThisCall();
        int int22 = node18.getIntProp((int) 'a');
        boolean boolean23 = node12.isEquivalentTo(node18);
        com.google.javascript.rhino.Node node24 = node5.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean29 = node28.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node28);
        int int31 = node5.getType();
        com.google.javascript.rhino.Node node32 = node5.getLastSibling();
        boolean boolean33 = node32.isLocalResultCall();
        boolean boolean34 = closureCodingConvention0.isVarArgsParameter(node32);
        com.google.javascript.rhino.Node node35 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship36 = closureCodingConvention0.getClassesDefinedByCall(node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 40 + "'", int31 == 40);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        java.util.Set<java.lang.String> strSet8 = node5.getDirectives();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node18.detachChildren();
        boolean boolean20 = node18.isOnlyModifiesThisCall();
        int int22 = node18.getIntProp((int) 'a');
        boolean boolean23 = node12.isEquivalentTo(node18);
        com.google.javascript.rhino.Node node24 = node5.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean29 = node28.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node28);
        int int31 = node5.getType();
        com.google.javascript.rhino.Node node32 = node5.getLastSibling();
        boolean boolean33 = node32.isLocalResultCall();
        boolean boolean34 = closureCodingConvention0.isVarArgsParameter(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean39 = node38.isUnscopedQualifiedName();
        int int40 = node38.getChildCount();
        java.util.Set<java.lang.String> strSet41 = node38.getDirectives();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder42 = node38.getJsDocBuilderForNode();
        java.lang.String str43 = closureCodingConvention0.identifyTypeDefAssign(node38);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 40 + "'", int31 == 40);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(strSet41);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder42);
        org.junit.Assert.assertNull(str43);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkRequires;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        node4.detachChildren();
        java.lang.String[] strArray9 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(110, node4, 20, (int) (byte) -1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        node32.setIsSyntheticBlock(true);
        node32.setOptionalArg(false);
        node4.addChildToFront(node32);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder44 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder44.append("Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder44);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
//        java.lang.String str6 = context1.getImplementationVersion();
//        context1.removeActivationName("hi!");
//        java.lang.String str9 = context1.getImplementationVersion();
//        com.google.javascript.rhino.ErrorReporter errorReporter10 = context1.getErrorReporter();
//        boolean boolean11 = context1.hasCompileFunctionsWithDynamicScope();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(errorReporter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str9.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNull(errorReporter10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions0.prettyPrint = false;
        boolean boolean10 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup14;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard18 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat20 = diagnosticType19.format;
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel17, diagnosticType19, strArray21);
        compilerOptions0.checkProvides = checkLevel17;
        compilerOptions0.setDefineToBooleanLiteral("", false);
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(messageFormat20);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
        compiler0.setErrorManager(errorManager4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.inlineGetters;
        java.lang.String str8 = compilerOptions6.locale;
        compilerOptions6.checkCaja = true;
        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
        compiler0.initOptions(compilerOptions6);
        compilerOptions6.removeTryCatchFinally = false;
        java.lang.String str15 = compilerOptions6.instrumentationTemplate;
        compilerOptions6.locale = "";
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(errorManager4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.ErrorManager errorManager3 = null;
        try {
            compiler0.setErrorManager(errorManager3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compiler0.getCodingConvention();
        boolean boolean4 = compiler0.acceptConstKeyword();
        boolean boolean5 = compiler0.hasErrors();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(codingConvention3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
//        compiler0.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.inlineGetters;
//        java.lang.String str8 = compilerOptions6.locale;
//        compilerOptions6.checkCaja = true;
//        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
//        compiler0.initOptions(compilerOptions6);
//        compilerOptions6.removeTryCatchFinally = false;
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean23 = node22.isUnscopedQualifiedName();
//        int int24 = node22.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
//        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
//        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("error reporter", node22, checkLevel27, diagnosticType28, strArray36);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat48 = diagnosticType47.format;
//        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType47, strArray54);
//        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType43, strArray54);
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType28, strArray54);
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = diagnosticType28.level;
//        compilerOptions6.checkMissingReturn = checkLevel58;
//        compilerOptions6.aliasableGlobals = "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: hi! at DiagnosticGroup<tweakValidation>(WARNING) line 41 : 0";
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNull(node3);
//        org.junit.Assert.assertNotNull(errorManager4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType28);
//        org.junit.Assert.assertNotNull(messageFormat29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(diagnosticType43);
//        org.junit.Assert.assertNotNull(diagnosticType47);
//        org.junit.Assert.assertNotNull(messageFormat48);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(jSError56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        node4.detachChildren();
        boolean boolean7 = detailLevel0.apply(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean12 = node11.isUnscopedQualifiedName();
        node11.putBooleanProp(36, false);
        boolean boolean16 = detailLevel0.apply(node11);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int2 = ecmaError1.lineNumber();
        int int3 = ecmaError1.lineNumber();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int6 = ecmaError5.lineNumber();
        int int7 = ecmaError5.lineNumber();
        java.lang.String str8 = ecmaError5.getName();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError1.addSuppressed((java.lang.Throwable) ecmaError5);
        java.lang.String str11 = ecmaError5.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TypeError" + "'", str8.equals("TypeError"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TypeError" + "'", str11.equals("TypeError"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("()", "STRING ", 23);
        java.lang.Throwable[] throwableArray4 = evaluatorException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compiler0.getCodingConvention();
        boolean boolean4 = compiler0.acceptEcmaScript5();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a type name");
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap9 = compiler7.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler7.getErrorManager();
        java.lang.String str11 = compiler7.toSource();
        com.google.javascript.jscomp.ErrorFormat errorFormat12 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat12.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node17 = compiler16.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter20 = errorFormat12.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler16, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler16.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str25 = jSSourceFile24.getName();
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node27 = compiler26.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap28 = compiler26.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node32 = compiler26.parse(jSSourceFile31);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24, jSSourceFile31 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray34 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph35 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray34);
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean37 = compilerOptions36.inlineGetters;
        java.lang.String str38 = compilerOptions36.locale;
        com.google.javascript.jscomp.Result result39 = compiler16.compile(jSSourceFileArray33, jSModuleArray34, compilerOptions36);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47);
        com.google.javascript.jscomp.Region region50 = jSSourceFile47.getRegion(31);
        java.lang.String str51 = jSSourceFile47.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput55 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile54);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile58 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput59 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile58);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        jSSourceFile62.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JsAst jsAst67 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray68 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47, jSSourceFile54, jSSourceFile58, jSSourceFile62, jSSourceFile66 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions69 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean70 = compilerOptions69.inlineGetters;
        java.lang.String str71 = compilerOptions69.locale;
        compilerOptions69.generateExports = false;
        com.google.javascript.jscomp.Result result74 = compiler7.compile(jSSourceFileArray33, jSSourceFileArray68, compilerOptions69);
        com.google.javascript.jscomp.CompilerOptions compilerOptions75 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean76 = compilerOptions75.inlineGetters;
        java.lang.String str77 = compilerOptions75.locale;
        com.google.javascript.jscomp.Result result78 = compiler0.compile(jSSourceFile6, jSSourceFileArray68, compilerOptions75);
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(codingConvention3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNull(sourceMap9);
        org.junit.Assert.assertNotNull(errorManager10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(errorFormat12);
        org.junit.Assert.assertNotNull(messageFormatter15);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(messageFormatter20);
        org.junit.Assert.assertNotNull(jSErrorArray21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "STRING " + "'", str25.equals("STRING "));
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNull(sourceMap28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertNotNull(jSModuleArray34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNull(region50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str51.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNotNull(jSSourceFile58);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertNotNull(jSSourceFileArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(result74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNotNull(result78);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        boolean boolean8 = closureCodingConvention0.isPrivate("goog.exportSymbol");
        boolean boolean10 = closureCodingConvention0.isSuperClassReference("goog.exportProperty");
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node12 = compiler11.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler11.getErrorManager();
        com.google.javascript.jscomp.CodingConvention codingConvention14 = compiler11.getCodingConvention();
        boolean boolean15 = compiler11.acceptEcmaScript5();
        compiler11.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState17 = compiler11.getState();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder18 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention20 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean23 = defaultCodingConvention20.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention20, "language version", (int) (short) -1, (int) (byte) 0);
        com.google.javascript.rhino.Node node28 = node27.cloneNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean33 = node32.isUnscopedQualifiedName();
        node32.detachChildren();
        java.lang.String[] strArray37 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet38 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet38, strArray37);
        node32.setDirectives((java.util.Set<java.lang.String>) strSet38);
        node28.setDirectives((java.util.Set<java.lang.String>) strSet38);
        compiler11.toSource(codeBuilder18, 27, node28);
        boolean boolean43 = closureCodingConvention0.isVarArgsParameter(node28);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(errorManager13);
        org.junit.Assert.assertNotNull(codingConvention14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(intermediateState17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        java.util.Locale locale5 = context1.getLocale();
//        int int6 = context1.getInstructionObserverThreshold();
//        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("@IMPLEMENTATION.VERSION@");
//        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable9 = node8.getAncestors();
//        context1.seal((java.lang.Object) ancestorIterable9);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNotNull(locale5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(node8);
//        org.junit.Assert.assertNotNull(ancestorIterable9);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: hi! at DiagnosticGroup<tweakValidation>(WARNING) line 41 : 0", generator6);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7 };
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter12 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, false);
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node14 = compiler13.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager15 = compiler13.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler13.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str22 = jSSourceFile21.getName();
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node24 = compiler23.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap25 = compiler23.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node29 = compiler23.parse(jSSourceFile28);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile21, jSSourceFile28 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph32 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean34 = compilerOptions33.inlineGetters;
        java.lang.String str35 = compilerOptions33.locale;
        com.google.javascript.jscomp.Result result36 = compiler13.compile(jSSourceFileArray30, jSModuleArray31, compilerOptions33);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean38 = compilerOptions37.inlineGetters;
        java.lang.String str39 = compilerOptions37.renamePrefix;
        boolean boolean40 = compilerOptions37.collapseVariableDeclarations;
        compiler0.init(jSSourceFileArray8, jSModuleArray31, compilerOptions37);
        boolean boolean42 = compilerOptions37.checkTypedPropertyCalls;
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(messageFormatter12);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(errorManager15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "STRING " + "'", str22.equals("STRING "));
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(sourceMap25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
//        compiler0.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.inlineGetters;
//        java.lang.String str8 = compilerOptions6.locale;
//        compilerOptions6.checkCaja = true;
//        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
//        compiler0.initOptions(compilerOptions6);
//        compilerOptions6.removeTryCatchFinally = false;
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean23 = node22.isUnscopedQualifiedName();
//        int int24 = node22.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
//        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
//        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("error reporter", node22, checkLevel27, diagnosticType28, strArray36);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat48 = diagnosticType47.format;
//        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType47, strArray54);
//        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType43, strArray54);
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType28, strArray54);
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = diagnosticType28.level;
//        compilerOptions6.checkMissingReturn = checkLevel58;
//        compilerOptions6.collapseProperties = true;
//        compilerOptions6.checkSuspiciousCode = true;
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNull(node3);
//        org.junit.Assert.assertNotNull(errorManager4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType28);
//        org.junit.Assert.assertNotNull(messageFormat29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(diagnosticType43);
//        org.junit.Assert.assertNotNull(diagnosticType47);
//        org.junit.Assert.assertNotNull(messageFormat48);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(jSError56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler28 = compilerOptions24.getAliasTransformationHandler();
        compilerOptions24.aliasKeywords = false;
        compilerOptions24.optimizeArgumentsArray = false;
        java.util.Set<java.lang.String> strSet33 = compilerOptions24.stripTypePrefixes;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(aliasTransformationHandler28);
        org.junit.Assert.assertNotNull(strSet33);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        compilerOptions0.setTweakToNumberLiteral("@IMPLEMENTATION.VERSION@", 23);
        boolean boolean6 = compilerOptions0.generatePseudoNames;
        compilerOptions0.instrumentForCoverage = false;
        boolean boolean9 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        compilerOptions24.unaliasableGlobals = "(())";
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions24.reportMissingOverride;
        compilerOptions24.rewriteFunctionExpressions = true;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        int int1 = context0.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (-1), 40);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean24 = node23.isUnscopedQualifiedName();
        node23.detachChildren();
        java.lang.String[] strArray28 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet29 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet29, strArray28);
        node23.setDirectives((java.util.Set<java.lang.String>) strSet29);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node23, 20, (int) (byte) -1);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship35 = defaultCodingConvention0.getClassesDefinedByCall(node23);
        node23.setCharno(42);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        node23.setJSType(jSType38);
        node23.setSourcePositionForTree(46);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(subclassRelationship35);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("hi!");
//        boolean boolean4 = context1.hasCompileFunctionsWithDynamicScope();
//        boolean boolean5 = context1.isGeneratingDebugChanged();
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter7 = context1.setErrorReporter(errorReporter6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.inlineConstantVars = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
        java.lang.String str2 = node1.toStringTree();
        com.google.javascript.rhino.Node node3 = node1.getParent();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING Named type with empty name component\n" + "'", str2.equals("STRING Named type with empty name component\n"));
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.checkControlStructures = false;
        boolean boolean12 = compilerOptions0.lineBreak;
        boolean boolean13 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        node3.detachChildren();
        int int6 = node3.getLineno();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup3 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup("Not declared as a constructor", diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup9;
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("error reporter", "(STRING  [label_id_prop: -1])");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        node3.setCharno(7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean13 = node12.isUnscopedQualifiedName();
        int int14 = node12.getChildCount();
        node12.putProp((int) (byte) 10, (java.lang.Object) 150);
        node3.addChildToBack(node12);
        java.util.Set<java.lang.String> strSet19 = node12.getDirectives();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(strSet19);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        boolean boolean7 = node3.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.checkCaja = true;
        boolean boolean43 = compilerOptions24.reserveRawExports;
        compilerOptions24.optimizeArgumentsArray = true;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("error reporter", 100, (int) (byte) 1);
        java.util.Set<java.lang.String> strSet4 = node3.getDirectives();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(strSet4);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test105");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
//        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler0.getErrorManager();
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler(errorManager3);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "null(ERROR)");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING  [empty_block: 1]\n");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.JsAst jsAst16 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile15);
//        java.nio.charset.Charset charset18 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
//        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("error reporter", generator21);
//        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node24 = compiler23.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap25 = compiler23.getSourceMap();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.rhino.Node node29 = compiler23.parse(jSSourceFile28);
//        jSSourceFile28.setOriginalPath("window");
//        java.io.Reader reader32 = jSSourceFile28.getCodeReader();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
//        com.google.javascript.jscomp.Region region38 = jSSourceFile35.getRegion(31);
//        java.lang.String str39 = jSSourceFile35.getName();
//        com.google.javascript.jscomp.Compiler compiler40 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node41 = compiler40.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap42 = compiler40.getSourceMap();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile45 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.rhino.Node node46 = compiler40.parse(jSSourceFile45);
//        jSSourceFile45.setOriginalPath("window");
//        java.lang.String str49 = jSSourceFile45.getOriginalPath();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile12, jSSourceFile15, jSSourceFile19, jSSourceFile22, jSSourceFile28, jSSourceFile35, jSSourceFile45 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray53 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList54 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList54, jSModuleArray53);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph56 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph57 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph58 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph59 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean61 = compilerOptions60.inlineGetters;
//        java.lang.String str62 = compilerOptions60.locale;
//        compilerOptions60.checkCaja = true;
//        boolean boolean65 = compilerOptions60.instrumentForCoverageOnly;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel67 = diagnosticType66.level;
//        compilerOptions60.reportMissingOverride = checkLevel67;
//        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap69 = null;
//        compilerOptions60.cssRenamingMap = cssRenamingMap69;
//        boolean boolean71 = compilerOptions60.isExternExportsEnabled();
//        compilerOptions60.checkTypedPropertyCalls = false;
//        com.google.javascript.jscomp.Result result74 = compiler4.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList54, compilerOptions60);
//        boolean boolean75 = compilerOptions60.crossModuleMethodMotion;
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNotNull(errorManager2);
//        org.junit.Assert.assertNotNull(errorManager3);
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertNotNull(jSSourceFile19);
//        org.junit.Assert.assertNotNull(jSSourceFile22);
//        org.junit.Assert.assertNull(node24);
//        org.junit.Assert.assertNull(sourceMap25);
//        org.junit.Assert.assertNotNull(jSSourceFile28);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNotNull(reader32);
//        org.junit.Assert.assertNotNull(jSSourceFile35);
//        org.junit.Assert.assertNull(region38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str39.equals("JSC_OPTIMIZE_LOOP_ERROR"));
//        org.junit.Assert.assertNull(node41);
//        org.junit.Assert.assertNull(sourceMap42);
//        org.junit.Assert.assertNotNull(jSSourceFile45);
//        org.junit.Assert.assertNotNull(node46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "window" + "'", str49.equals("window"));
//        org.junit.Assert.assertNotNull(jSSourceFileArray50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(diagnosticType66);
//        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(result74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        int int3 = compiler0.getErrorCount();
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler0.getSourceMap();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(sourceMap4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3, composeWarningsGuard7, composeWarningsGuard11, composeWarningsGuard15 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup18;
        boolean boolean20 = composeWarningsGuard17.disables(diagnosticGroup18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        boolean boolean22 = composeWarningsGuard17.disables(diagnosticGroup21);
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup21;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup24;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat30 = diagnosticType29.format;
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType29, strArray36);
        boolean boolean38 = diagnosticGroup24.matches(jSError37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean44 = node43.isUnscopedQualifiedName();
        int int45 = node43.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType46 = node43.getJSType();
        com.google.javascript.rhino.Node node47 = node43.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel48 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat50 = diagnosticType49.format;
        java.lang.String[] strArray57 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("error reporter", node43, checkLevel48, diagnosticType49, strArray57);
        com.google.javascript.jscomp.CheckLevel checkLevel59 = diagnosticType49.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard60 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup24, checkLevel59);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard61 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup21, checkLevel59);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(messageFormat30);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(messageFormat50);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType10 = node7.getJSType();
        com.google.javascript.rhino.Node node11 = node7.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat14 = diagnosticType13.format;
        java.lang.String[] strArray21 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("error reporter", node7, checkLevel12, diagnosticType13, strArray21);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType13.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat28 = diagnosticType27.format;
        java.lang.String[] strArray34 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType27, strArray34);
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("(STRING )", 42, 46, diagnosticType13, strArray34);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(messageFormat14);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(messageFormat28);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError36);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((-2));
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setAllFlags();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.clearSideEffectFlags();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("@IMPLEMENTATION.VERSION@");
        com.google.javascript.rhino.Node node2 = node1.getLastSibling();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        compilerOptions0.renamePrefix = "null(ERROR)";
        compilerOptions0.removeTryCatchFinally = true;
        boolean boolean6 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions0.prettyPrint = false;
        boolean boolean10 = compilerOptions0.reserveRawExports;
        boolean boolean11 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test113");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.inlineGetters;
//        java.lang.String str2 = compilerOptions0.locale;
//        compilerOptions0.checkCaja = true;
//        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel7 = diagnosticType6.level;
//        compilerOptions0.reportMissingOverride = checkLevel7;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy9 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
//        compilerOptions0.propertyRenaming = propertyRenamingPolicy9;
//        compilerOptions0.extractPrototypeMemberDeclarations = true;
//        compilerOptions0.optimizeArgumentsArray = false;
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy9.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback4);
        int int6 = nodeTraversal5.getLineNumber();
        com.google.javascript.jscomp.Scope scope7 = nodeTraversal5.getScope();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean13 = node12.isUnscopedQualifiedName();
        int int14 = node12.getChildCount();
        node12.putProp((int) (byte) 10, (java.lang.Object) 150);
        node12.putBooleanProp(10, false);
        boolean boolean21 = node12.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean26 = node25.isUnscopedQualifiedName();
        int int27 = node25.getChildCount();
        java.util.Set<java.lang.String> strSet28 = node25.getDirectives();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node38.detachChildren();
        boolean boolean40 = node38.isOnlyModifiesThisCall();
        int int42 = node38.getIntProp((int) 'a');
        boolean boolean43 = node32.isEquivalentTo(node38);
        com.google.javascript.rhino.Node node44 = node25.copyInformationFromForTree(node38);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node50 = node25.copyInformationFromForTree(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node54.detachChildren();
        boolean boolean56 = node54.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable57 = node54.siblings();
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] { node12, node48, node54 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(0, nodeArray58, 0, 18);
        try {
            nodeTraversal5.traverseRoots(nodeArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(scope7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(strSet28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeIterable57);
        org.junit.Assert.assertNotNull(nodeArray58);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        compilerOptions0.setTweakToBooleanLiteral("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str2 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean4 = closureCodingConvention0.isConstant("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(41);
        boolean boolean7 = closureCodingConvention0.isOptionalParameter(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean12 = node11.isUnscopedQualifiedName();
        int int13 = node11.getChildCount();
        java.util.Set<java.lang.String> strSet14 = node11.getDirectives();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node18.detachChildren();
        boolean boolean20 = node18.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        int int28 = node24.getIntProp((int) 'a');
        boolean boolean29 = node18.isEquivalentTo(node24);
        com.google.javascript.rhino.Node node30 = node11.copyInformationFromForTree(node24);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean40 = node39.isUnscopedQualifiedName();
        int int41 = node39.getChildCount();
        java.util.Set<java.lang.String> strSet42 = node39.getDirectives();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node46.detachChildren();
        boolean boolean48 = node46.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node52.detachChildren();
        boolean boolean54 = node52.isOnlyModifiesThisCall();
        int int56 = node52.getIntProp((int) 'a');
        boolean boolean57 = node46.isEquivalentTo(node52);
        com.google.javascript.rhino.Node node58 = node39.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean63 = node62.isUnscopedQualifiedName();
        int int64 = node62.getChildCount();
        node62.putProp((int) (byte) 10, (java.lang.Object) 150);
        node62.putBooleanProp(10, false);
        boolean boolean71 = node62.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) ' ', node35, node52, node62);
        boolean boolean73 = node11.hasChild(node52);
        boolean boolean74 = closureCodingConvention0.isOptionalParameter(node52);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(strSet14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(strSet42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (-1), 40);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean24 = node23.isUnscopedQualifiedName();
        node23.detachChildren();
        java.lang.String[] strArray28 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet29 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet29, strArray28);
        node23.setDirectives((java.util.Set<java.lang.String>) strSet29);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node23, 20, (int) (byte) -1);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship35 = defaultCodingConvention0.getClassesDefinedByCall(node23);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node39.detachChildren();
        boolean boolean41 = node39.isOnlyModifiesThisCall();
        int int43 = node39.getIntProp((int) 'a');
        boolean boolean44 = node39.isSyntheticBlock();
        com.google.javascript.rhino.Node node45 = node23.copyInformationFrom(node39);
        int int47 = node39.getIntProp(100);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(subclassRelationship35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("eq");
        try {
            node1.setDouble((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING eq is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isValidEnumKey("Not declared as a type name");
        boolean boolean4 = closureCodingConvention0.isPrivate("sheq");
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("goog.global");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("ge", "com.google.javascript.rhino.EcmaError: TypeError: 7 is not a function, it is com.google.javascript.jscomp.Compiler.", "goog.exportSymbol", "Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ge");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions0.prettyPrint = false;
        boolean boolean10 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup14;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard18 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat20 = diagnosticType19.format;
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel17, diagnosticType19, strArray21);
        compilerOptions0.checkProvides = checkLevel17;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean26 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(messageFormat20);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("ge", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.inlineGetters;
//        compilerOptions0.renamePrefix = "null(ERROR)";
//        compilerOptions0.instrumentationTemplate = "(JSC_OPTIMIZE_LOOP_ERROR)";
//        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node7 = compiler6.getRoot();
//        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node9 = compiler8.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler8.getErrorManager();
//        compiler6.setErrorManager(errorManager10);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean13 = compilerOptions12.inlineGetters;
//        java.lang.String str14 = compilerOptions12.locale;
//        compilerOptions12.checkCaja = true;
//        boolean boolean17 = compilerOptions12.instrumentForCoverageOnly;
//        compiler6.initOptions(compilerOptions12);
//        compilerOptions12.removeTryCatchFinally = false;
//        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean29 = node28.isUnscopedQualifiedName();
//        int int30 = node28.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType31 = node28.getJSType();
//        com.google.javascript.rhino.Node node32 = node28.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel33 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat35 = diagnosticType34.format;
//        java.lang.String[] strArray42 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make("error reporter", node28, checkLevel33, diagnosticType34, strArray42);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat54 = diagnosticType53.format;
//        java.lang.String[] strArray60 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType53, strArray60);
//        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType49, strArray60);
//        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType34, strArray60);
//        com.google.javascript.jscomp.CheckLevel checkLevel64 = diagnosticType34.level;
//        compilerOptions12.checkMissingReturn = checkLevel64;
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler66 = compilerOptions12.getAliasTransformationHandler();
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler67 = compilerOptions12.getAliasTransformationHandler();
//        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler67);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNull(node7);
//        org.junit.Assert.assertNull(node9);
//        org.junit.Assert.assertNotNull(errorManager10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNull(jSType31);
//        org.junit.Assert.assertNotNull(node32);
//        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType34);
//        org.junit.Assert.assertNotNull(messageFormat35);
//        org.junit.Assert.assertNotNull(strArray42);
//        org.junit.Assert.assertNotNull(jSError43);
//        org.junit.Assert.assertNotNull(diagnosticType49);
//        org.junit.Assert.assertNotNull(diagnosticType53);
//        org.junit.Assert.assertNotNull(messageFormat54);
//        org.junit.Assert.assertNotNull(strArray60);
//        org.junit.Assert.assertNotNull(jSError61);
//        org.junit.Assert.assertNotNull(jSError62);
//        org.junit.Assert.assertNotNull(jSError63);
//        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(aliasTransformationHandler66);
//        org.junit.Assert.assertNotNull(aliasTransformationHandler67);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap2 = compilerOptions0.cssRenamingMap;
        compilerOptions0.instrumentForCoverage = false;
        boolean boolean5 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.inlineGetters;
        java.lang.String str8 = compilerOptions6.locale;
        compilerOptions6.setLooseTypes(false);
        boolean boolean11 = compilerOptions6.gatherCssNames;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str13 = closureCodingConvention12.getAbstractMethodName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node42 = node17.copyInformationFromForTree(node40);
        int int43 = node17.getType();
        com.google.javascript.rhino.Node node44 = node17.getLastSibling();
        boolean boolean45 = node44.isLocalResultCall();
        boolean boolean46 = closureCodingConvention12.isVarArgsParameter(node44);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean51 = node50.isUnscopedQualifiedName();
        node50.detachChildren();
        java.lang.String[] strArray55 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet56 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet56, strArray55);
        node50.setDirectives((java.util.Set<java.lang.String>) strSet56);
        node44.setDirectives((java.util.Set<java.lang.String>) strSet56);
        compilerOptions6.stripNameSuffixes = strSet56;
        compilerOptions0.stripNamePrefixes = strSet56;
        compilerOptions0.setTweakToBooleanLiteral("goog.abstractMethod", true);
        compilerOptions0.setRemoveAbstractMethods(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(cssRenamingMap2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.abstractMethod" + "'", str13.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 40 + "'", int43 == 40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler28 = compilerOptions24.getAliasTransformationHandler();
        compilerOptions24.aliasKeywords = false;
        byte[] byteArray31 = compilerOptions24.inputVariableMapSerialized;
        boolean boolean32 = compilerOptions24.ignoreCajaProperties;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(aliasTransformationHandler28);
        org.junit.Assert.assertNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler28 = compilerOptions24.getAliasTransformationHandler();
        compilerOptions24.aliasKeywords = false;
        byte[] byteArray31 = compilerOptions24.inputVariableMapSerialized;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy32 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        compilerOptions24.variableRenaming = variableRenamingPolicy32;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy34 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions24.anonymousFunctionNaming = anonymousFunctionNamingPolicy34;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(aliasTransformationHandler28);
        org.junit.Assert.assertNull(byteArray31);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy32.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy34 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy34.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("window", "hi!", "DiagnosticGroup<tweakValidation>(WARNING)", 36, "eq", 7);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler0.getErrorManager();
        boolean boolean4 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node6 = compiler5.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager7 = compiler5.getErrorManager();
        java.lang.String str8 = compiler5.toSource();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler5.getState();
        compiler0.setState(intermediateState9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node12 = compiler11.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler11.getErrorManager();
        com.google.javascript.jscomp.ErrorManager errorManager14 = compiler11.getErrorManager();
        boolean boolean15 = compiler11.acceptConstKeyword();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node17 = compiler16.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        java.lang.String str19 = compiler16.toSource();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState20 = compiler16.getState();
        compiler11.setState(intermediateState20);
        compiler0.setState(intermediateState20);
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(errorManager3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(errorManager7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(errorManager13);
        org.junit.Assert.assertNotNull(errorManager14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(intermediateState20);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component");
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.level;
        compilerOptions0.aggressiveVarCheck = checkLevel8;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler12 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition14 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation15 = aliasTransformationHandler12.logAliasTransformation("", aliasTransformationSourcePosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(aliasTransformationHandler12);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("ge", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback4);
        java.lang.String str6 = nodeTraversal5.getSourceName();
        com.google.javascript.jscomp.Compiler compiler7 = nodeTraversal5.getCompiler();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean11 = defaultCodingConvention8.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention8, "language version", (int) (short) -1, (int) (byte) 0);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        try {
            nodeTraversal5.traverse(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(compiler7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
        compiler0.setErrorManager(errorManager4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.inlineGetters;
        java.lang.String str8 = compilerOptions6.locale;
        compilerOptions6.checkCaja = true;
        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
        compiler0.initOptions(compilerOptions6);
        compilerOptions6.removeTryCatchFinally = false;
        compilerOptions6.lineBreak = true;
        java.lang.String str17 = compilerOptions6.appNameStr;
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(errorManager4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
//        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
//        java.lang.String str5 = diagnosticGroupWarningsGuard4.toString();
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray7 = new com.google.javascript.jscomp.DiagnosticType[] {};
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray7);
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup8;
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        boolean boolean13 = defaultCodingConvention10.isExported("Named type with empty name component", true);
//        java.lang.RuntimeException runtimeException14 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 19, (java.lang.Object) diagnosticGroup8, (java.lang.Object) boolean13);
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean23 = node22.isUnscopedQualifiedName();
//        int int24 = node22.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
//        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
//        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("error reporter", node22, checkLevel27, diagnosticType28, strArray36);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat48 = diagnosticType47.format;
//        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType47, strArray54);
//        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType43, strArray54);
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType28, strArray54);
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = diagnosticType28.level;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard59 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel58);
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup8;
//        boolean boolean61 = diagnosticGroupWarningsGuard4.disables(diagnosticGroup8);
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticTypeArray7);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(runtimeException14);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType28);
//        org.junit.Assert.assertNotNull(messageFormat29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(diagnosticType43);
//        org.junit.Assert.assertNotNull(diagnosticType47);
//        org.junit.Assert.assertNotNull(messageFormat48);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(jSError56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        int int29 = node3.getType();
        com.google.javascript.rhino.Node node30 = node3.getLastSibling();
        boolean boolean31 = node30.isVarArgs();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection32 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node30);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 40 + "'", int29 == 40);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(nodeCollection32);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
        compiler0.setErrorManager(errorManager4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.inlineGetters;
        java.lang.String str8 = compilerOptions6.locale;
        compilerOptions6.checkCaja = true;
        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
        compiler0.initOptions(compilerOptions6);
        compilerOptions6.removeTryCatchFinally = false;
        compilerOptions6.lineBreak = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter20 = errorFormat17.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler18, false);
        com.google.javascript.jscomp.Compiler compiler21 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node22 = compiler21.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager23 = compiler21.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter25 = errorFormat17.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler21, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray26 = compiler21.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str30 = jSSourceFile29.getName();
        com.google.javascript.jscomp.Compiler compiler31 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node32 = compiler31.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap33 = compiler31.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node37 = compiler31.parse(jSSourceFile36);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray38 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile29, jSSourceFile36 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray39 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph40 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean42 = compilerOptions41.inlineGetters;
        java.lang.String str43 = compilerOptions41.locale;
        com.google.javascript.jscomp.Result result44 = compiler21.compile(jSSourceFileArray38, jSModuleArray39, compilerOptions41);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        node48.detachChildren();
        java.lang.String[] strArray53 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet54 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet54, strArray53);
        node48.setDirectives((java.util.Set<java.lang.String>) strSet54);
        compilerOptions41.stripTypePrefixes = strSet54;
        compilerOptions41.checkCaja = true;
        boolean boolean60 = compilerOptions41.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = compilerOptions41.checkFunctions;
        compilerOptions6.checkFunctions = checkLevel61;
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(errorManager4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertNotNull(messageFormatter20);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(errorManager23);
        org.junit.Assert.assertNotNull(messageFormatter25);
        org.junit.Assert.assertNotNull(jSErrorArray26);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "STRING " + "'", str30.equals("STRING "));
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNull(sourceMap33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(jSSourceFileArray38);
        org.junit.Assert.assertNotNull(jSModuleArray39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean8 = compilerOptions0.generateExports;
        compilerOptions0.optimizeCalls = false;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig11 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.convertToDottedProperties = false;
        java.lang.Object obj43 = compilerOptions24.clone();
        java.lang.String str44 = compilerOptions24.nameReferenceGraphPath;
        compilerOptions24.enableRuntimeTypeCheck("STRING  [empty_block: 1]\n");
        boolean boolean47 = compilerOptions24.checkCaja;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "Exceeded max number of optimization iterations: hi!", "Unknown class name", 33, "(JSC_OPTIMIZE_LOOP_ERROR)", 20);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.convertToDottedProperties = false;
        java.lang.String str43 = compilerOptions24.syntheticBlockStartMarker;
        compilerOptions24.checkControlStructures = false;
        byte[] byteArray51 = new byte[] { (byte) -1, (byte) -1, (byte) -1, (byte) 1, (byte) -1 };
        compilerOptions24.inputVariableMapSerialized = byteArray51;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(byteArray51);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.specializeInitialModule = true;
        com.google.javascript.jscomp.MessageBundle messageBundle14 = null;
        compilerOptions0.messageBundle = messageBundle14;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup16;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup16;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard20 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup16, checkLevel19);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup21;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat27 = diagnosticType26.format;
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType26, strArray33);
        boolean boolean35 = diagnosticGroup21.matches(jSError34);
        boolean boolean36 = diagnosticGroupWarningsGuard20.disables(diagnosticGroup21);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup37;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup37;
        boolean boolean40 = diagnosticGroupWarningsGuard20.disables(diagnosticGroup37);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) diagnosticGroupWarningsGuard20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(diagnosticGroup16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(messageFormat27);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node6 = compiler0.parse(jSSourceFile5);
        jSSourceFile5.setOriginalPath("window");
        java.lang.String str9 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        jsAst10.clearAst();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "window" + "'", str9.equals("window"));
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test143");
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray1 = new com.google.javascript.jscomp.DiagnosticType[] {};
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray1);
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup2;
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        boolean boolean7 = defaultCodingConvention4.isExported("Named type with empty name component", true);
//        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 19, (java.lang.Object) diagnosticGroup2, (java.lang.Object) boolean7);
//        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean17 = node16.isUnscopedQualifiedName();
//        int int18 = node16.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType19 = node16.getJSType();
//        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat23 = diagnosticType22.format;
//        java.lang.String[] strArray30 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("error reporter", node16, checkLevel21, diagnosticType22, strArray30);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat42 = diagnosticType41.format;
//        java.lang.String[] strArray48 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType41, strArray48);
//        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType37, strArray48);
//        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType22, strArray48);
//        com.google.javascript.jscomp.CheckLevel checkLevel52 = diagnosticType22.level;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard53 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel52);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray54 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList55 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList55, warningsGuardArray54);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard57 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList55);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray58 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList59 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList59, warningsGuardArray58);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard61 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList59);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray62 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList63 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList63, warningsGuardArray62);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard65 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList63);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray66 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList67 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList67, warningsGuardArray66);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard69 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList67);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray70 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard57, composeWarningsGuard61, composeWarningsGuard65, composeWarningsGuard69 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard71 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray70);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard72 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray70);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard73 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray70);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup74 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup74;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup74;
//        com.google.javascript.jscomp.CheckLevel checkLevel77 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard78 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup74, checkLevel77);
//        java.lang.String str79 = diagnosticGroupWarningsGuard78.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup80 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        boolean boolean81 = diagnosticGroupWarningsGuard78.disables(diagnosticGroup80);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType85 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat86 = diagnosticType85.format;
//        java.lang.String[] strArray92 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType85, strArray92);
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy94 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
//        boolean boolean95 = jSError93.equals((java.lang.Object) propertyRenamingPolicy94);
//        com.google.javascript.jscomp.CheckLevel checkLevel96 = diagnosticGroupWarningsGuard78.level(jSError93);
//        java.lang.String str97 = jSError93.toString();
//        com.google.javascript.jscomp.CheckLevel checkLevel98 = composeWarningsGuard73.level(jSError93);
//        boolean boolean99 = diagnosticGroup2.matches(jSError93);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(runtimeException8);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNull(jSType19);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType22);
//        org.junit.Assert.assertNotNull(messageFormat23);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(jSError31);
//        org.junit.Assert.assertNotNull(diagnosticType37);
//        org.junit.Assert.assertNotNull(diagnosticType41);
//        org.junit.Assert.assertNotNull(messageFormat42);
//        org.junit.Assert.assertNotNull(strArray48);
//        org.junit.Assert.assertNotNull(jSError49);
//        org.junit.Assert.assertNotNull(jSError50);
//        org.junit.Assert.assertNotNull(jSError51);
//        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(warningsGuardArray54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray70);
//        org.junit.Assert.assertNotNull(diagnosticGroup74);
//        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticGroup80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(diagnosticType85);
//        org.junit.Assert.assertNotNull(messageFormat86);
//        org.junit.Assert.assertNotNull(strArray92);
//        org.junit.Assert.assertNotNull(jSError93);
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy94 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy94.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//        org.junit.Assert.assertNull(checkLevel96);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: hi! at DiagnosticGroup<tweakValidation>(WARNING) line 41 : 0" + "'", str97.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: hi! at DiagnosticGroup<tweakValidation>(WARNING) line 41 : 0"));
//        org.junit.Assert.assertNull(checkLevel98);
//        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        java.lang.String str7 = compilerInput3.getName();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str7.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        compilerOptions0.setTweakToNumberLiteral("@IMPLEMENTATION.VERSION@", 23);
        boolean boolean6 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        boolean boolean8 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean9 = compilerOptions0.optimizeReturns;
        compilerOptions0.strictMessageReplacement = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean8 = compilerOptions0.generateExports;
        compilerOptions0.optimizeCalls = false;
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
        compiler0.setErrorManager(errorManager4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node7 = compiler6.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        java.lang.String str9 = compiler6.toSource();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler6.getState();
        compiler0.setState(intermediateState10);
        com.google.javascript.jscomp.Scope scope12 = compiler0.getTopScope();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(errorManager4);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNull(scope12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("DiagnosticGroup<checkTypes>(WARNING)");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "", 4, 43);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean12 = node11.isUnscopedQualifiedName();
        int int13 = node11.getChildCount();
        node11.putProp((int) (byte) 10, (java.lang.Object) 150);
        node11.putBooleanProp(10, false);
        boolean boolean20 = node11.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = defaultCodingConvention7.getDelegateRelationship(node11);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention7, "language version", (-1), 40);
        boolean boolean27 = defaultCodingConvention7.isPrivate("JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention7, "<No stack trace available>", 4095, 4);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean36 = node35.isUnscopedQualifiedName();
        int int37 = node35.getChildCount();
        java.util.Set<java.lang.String> strSet38 = node35.getDirectives();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node35.getJsDocBuilderForNode();
        boolean boolean40 = node35.isUnscopedQualifiedName();
        java.lang.String str41 = closureCodingConvention0.extractClassNameIfRequire(node31, node35);
        java.lang.Object obj42 = new java.lang.Object();
        com.google.javascript.jscomp.Compiler compiler45 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node46 = compiler45.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap47 = compiler45.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node51 = compiler45.parse(jSSourceFile50);
        jSSourceFile50.setOriginalPath("window");
        java.io.Reader reader54 = jSSourceFile50.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile55 = com.google.javascript.jscomp.SourceFile.fromReader("goog.global", reader54);
        com.google.javascript.jscomp.SourceFile sourceFile56 = com.google.javascript.jscomp.SourceFile.fromReader("true", reader54);
        java.lang.RuntimeException runtimeException57 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) closureCodingConvention0, obj42, (java.lang.Object) sourceFile56);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNull(sourceMap47);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(reader54);
        org.junit.Assert.assertNotNull(sourceFile55);
        org.junit.Assert.assertNotNull(sourceFile56);
        org.junit.Assert.assertNotNull(runtimeException57);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkCaja;
        boolean boolean6 = compilerOptions0.lineBreak;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        java.lang.String str4 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        try {
            com.google.javascript.rhino.Node node29 = node26.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("DiagnosticGroup<checkTypes>(WARNING)");
        java.lang.String str3 = closureCodingConvention0.getGlobalObject();
        java.lang.String str4 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getAbstractMethodName();
        boolean boolean8 = defaultCodingConvention5.isConstantKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean14 = node13.isUnscopedQualifiedName();
        int int15 = node13.getChildCount();
        java.util.Set<java.lang.String> strSet16 = node13.getDirectives();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node20.detachChildren();
        boolean boolean22 = node20.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        int int30 = node26.getIntProp((int) 'a');
        boolean boolean31 = node20.isEquivalentTo(node26);
        com.google.javascript.rhino.Node node32 = node13.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean37 = node36.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        int int44 = node42.getChildCount();
        java.util.Set<java.lang.String> strSet45 = node42.getDirectives();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node49.detachChildren();
        boolean boolean51 = node49.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node55.detachChildren();
        boolean boolean57 = node55.isOnlyModifiesThisCall();
        int int59 = node55.getIntProp((int) 'a');
        boolean boolean60 = node49.isEquivalentTo(node55);
        com.google.javascript.rhino.Node node61 = node42.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean66 = node65.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node67 = node42.copyInformationFromForTree(node65);
        int int68 = node42.getType();
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (short) -1, node13, node42, (-1), 44);
        com.google.javascript.jscomp.Compiler compiler72 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node73 = compiler72.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap74 = compiler72.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile77 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node78 = compiler72.parse(jSSourceFile77);
        node42.addChildToBack(node78);
        boolean boolean80 = defaultCodingConvention5.isOptionalParameter(node78);
        boolean boolean81 = closureCodingConvention0.isOptionalParameter(node78);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.global" + "'", str3.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(strSet16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(strSet45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 40 + "'", int68 == 40);
        org.junit.Assert.assertNull(node73);
        org.junit.Assert.assertNull(sourceMap74);
        org.junit.Assert.assertNotNull(jSSourceFile77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.inlineGetters;
//        java.lang.String str2 = compilerOptions0.locale;
//        compilerOptions0.checkCaja = true;
//        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel7 = diagnosticType6.level;
//        compilerOptions0.reportMissingOverride = checkLevel7;
//        java.util.Set<java.lang.String> strSet9 = compilerOptions0.stripNamePrefixes;
//        java.lang.String str10 = compilerOptions0.reportPath;
//        boolean boolean11 = compilerOptions0.aliasAllStrings;
//        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripTypePrefixes;
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(diagnosticType6);
//        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(strSet9);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(strSet12);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test155");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean1 = compilerOptions0.inlineGetters;
//        java.lang.String str2 = compilerOptions0.locale;
//        compilerOptions0.checkCaja = true;
//        boolean boolean5 = compilerOptions0.checkSymbols;
//        compilerOptions0.collapseAnonymousFunctions = true;
//        boolean boolean8 = compilerOptions0.generateExports;
//        compilerOptions0.optimizeCalls = false;
//        com.google.javascript.jscomp.ErrorFormat errorFormat11 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
//        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter14 = errorFormat11.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12, false);
//        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node16 = compiler15.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler15.getErrorManager();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat11.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, false);
//        com.google.javascript.jscomp.JSError[] jSErrorArray20 = compiler15.getMessages();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
//        java.lang.String str24 = jSSourceFile23.getName();
//        com.google.javascript.jscomp.Compiler compiler25 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node26 = compiler25.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap27 = compiler25.getSourceMap();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.rhino.Node node31 = compiler25.parse(jSSourceFile30);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile30 };
//        com.google.javascript.jscomp.JSModule[] jSModuleArray33 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph34 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray33);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean36 = compilerOptions35.inlineGetters;
//        java.lang.String str37 = compilerOptions35.locale;
//        com.google.javascript.jscomp.Result result38 = compiler15.compile(jSSourceFileArray32, jSModuleArray33, compilerOptions35);
//        compilerOptions35.unaliasableGlobals = "(())";
//        compilerOptions35.aliasStringsBlacklist = "null(ERROR)";
//        boolean boolean43 = compilerOptions35.ambiguateProperties;
//        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean52 = node51.isUnscopedQualifiedName();
//        int int53 = node51.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType54 = node51.getJSType();
//        com.google.javascript.rhino.Node node55 = node51.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel56 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat58 = diagnosticType57.format;
//        java.lang.String[] strArray65 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError66 = com.google.javascript.jscomp.JSError.make("error reporter", node51, checkLevel56, diagnosticType57, strArray65);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType72 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat77 = diagnosticType76.format;
//        java.lang.String[] strArray83 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType76, strArray83);
//        com.google.javascript.jscomp.JSError jSError85 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType72, strArray83);
//        com.google.javascript.jscomp.JSError jSError86 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType57, strArray83);
//        com.google.javascript.jscomp.CheckLevel checkLevel87 = diagnosticType57.level;
//        compilerOptions35.checkGlobalNamesLevel = checkLevel87;
//        compilerOptions0.checkRequires = checkLevel87;
//        compilerOptions0.appNameStr = "Not declared as a constructor";
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(errorFormat11);
//        org.junit.Assert.assertNotNull(messageFormatter14);
//        org.junit.Assert.assertNull(node16);
//        org.junit.Assert.assertNotNull(errorManager17);
//        org.junit.Assert.assertNotNull(messageFormatter19);
//        org.junit.Assert.assertNotNull(jSErrorArray20);
//        org.junit.Assert.assertNotNull(jSSourceFile23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "STRING " + "'", str24.equals("STRING "));
//        org.junit.Assert.assertNull(node26);
//        org.junit.Assert.assertNull(sourceMap27);
//        org.junit.Assert.assertNotNull(jSSourceFile30);
//        org.junit.Assert.assertNotNull(node31);
//        org.junit.Assert.assertNotNull(jSSourceFileArray32);
//        org.junit.Assert.assertNotNull(jSModuleArray33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNotNull(result38);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(node51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNull(jSType54);
//        org.junit.Assert.assertNotNull(node55);
//        org.junit.Assert.assertTrue("'" + checkLevel56 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel56.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType57);
//        org.junit.Assert.assertNotNull(messageFormat58);
//        org.junit.Assert.assertNotNull(strArray65);
//        org.junit.Assert.assertNotNull(jSError66);
//        org.junit.Assert.assertNotNull(diagnosticType72);
//        org.junit.Assert.assertNotNull(diagnosticType76);
//        org.junit.Assert.assertNotNull(messageFormat77);
//        org.junit.Assert.assertNotNull(strArray83);
//        org.junit.Assert.assertNotNull(jSError84);
//        org.junit.Assert.assertNotNull(jSError85);
//        org.junit.Assert.assertNotNull(jSError86);
//        org.junit.Assert.assertTrue("'" + checkLevel87 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel87.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.reportPath = "Not declared as a constructor";
        boolean boolean14 = compilerOptions0.labelRenaming;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component");
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.level;
        compilerOptions0.checkGlobalNamesLevel = checkLevel8;
        compilerOptions0.enableExternExports(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("STRING ", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        java.lang.String str3 = compilerOptions0.inputDelimiter;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean9 = node8.isUnscopedQualifiedName();
        int int10 = node8.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType11 = node8.getJSType();
        com.google.javascript.rhino.Node node12 = node8.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat15 = diagnosticType14.format;
        java.lang.String[] strArray22 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("error reporter", node8, checkLevel13, diagnosticType14, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType14.defaultLevel;
        compilerOptions0.checkMethods = checkLevel24;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "// Input %num%" + "'", str3.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(messageFormat15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.tightenTypes = false;
        boolean boolean17 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.optimizeCalls = false;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap2 = compilerOptions0.cssRenamingMap;
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkMethods = checkLevel4;
        boolean boolean6 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.inlineLocalFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(cssRenamingMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(17, "NOT 0\n    STRING \n    STRING \n    STRING \n    STRING \n");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("<No stack trace available>", 150, 30);
        java.lang.String str9 = closureCodingConvention0.extractClassNameIfProvide(node4, node8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(41);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node6.detachChildren();
        boolean boolean8 = node6.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        int int16 = node12.getIntProp((int) 'a');
        boolean boolean17 = node6.isEquivalentTo(node12);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean22 = node21.isUnscopedQualifiedName();
        int int23 = node21.getChildCount();
        java.util.Set<java.lang.String> strSet24 = node21.getDirectives();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node28.detachChildren();
        boolean boolean30 = node28.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node34.detachChildren();
        boolean boolean36 = node34.isOnlyModifiesThisCall();
        int int38 = node34.getIntProp((int) 'a');
        boolean boolean39 = node28.isEquivalentTo(node34);
        com.google.javascript.rhino.Node node40 = node21.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean45 = node44.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node46 = node21.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean51 = node50.isUnscopedQualifiedName();
        int int52 = node50.getChildCount();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean57 = node56.isUnscopedQualifiedName();
        int int58 = node56.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType59 = node56.getJSType();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(26, node12, node21, node50, node56, (int) (short) 0, (int) '4');
        boolean boolean63 = node62.wasEmptyNode();
        boolean boolean64 = node62.isOnlyModifiesThisCall();
        node62.removeProp(29);
        int int68 = node62.getIntProp(2);
        node1.addChildrenToFront(node62);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(strSet24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.convertToDottedProperties = false;
        compilerOptions24.setTweakToNumberLiteral("sheq", 40);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean11 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkMissingReturn;
        compilerOptions0.inferTypesInGlobalScope = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.setProcessObjectPropertyString(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean65 = node64.isUnscopedQualifiedName();
        int int66 = node64.getChildCount();
        java.util.Set<java.lang.String> strSet67 = node64.getDirectives();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node71.detachChildren();
        boolean boolean73 = node71.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node77.detachChildren();
        boolean boolean79 = node77.isOnlyModifiesThisCall();
        int int81 = node77.getIntProp((int) 'a');
        boolean boolean82 = node71.isEquivalentTo(node77);
        com.google.javascript.rhino.Node node83 = node64.copyInformationFromForTree(node77);
        boolean boolean84 = node10.isEquivalentTo(node83);
        java.lang.Class<?> wildcardClass85 = node10.getClass();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNull(strSet67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(wildcardClass85);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.convertToDottedProperties = false;
        java.lang.String str43 = compilerOptions24.syntheticBlockStartMarker;
        boolean boolean44 = compilerOptions24.checkTypes;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        compilerOptions0.renamePrefix = "null(ERROR)";
        boolean boolean4 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setPropertyAffinity(true);
        boolean boolean7 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean8 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test171");
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        boolean boolean4 = defaultCodingConvention1.isExported("Named type with empty name component", true);
//        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1, "language version", (int) (short) -1, (int) (byte) 0);
//        com.google.javascript.rhino.Node node9 = node8.cloneNode();
//        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean14 = node13.isUnscopedQualifiedName();
//        node13.detachChildren();
//        java.lang.String[] strArray18 = new java.lang.String[] { "language version", "" };
//        java.util.LinkedHashSet<java.lang.String> strSet19 = new java.util.LinkedHashSet<java.lang.String>();
//        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet19, strArray18);
//        node13.setDirectives((java.util.Set<java.lang.String>) strSet19);
//        node9.setDirectives((java.util.Set<java.lang.String>) strSet19);
//        com.google.javascript.rhino.EcmaError ecmaError24 = com.google.javascript.rhino.ScriptRuntime.typeError("");
//        int int25 = ecmaError24.lineNumber();
//        int int26 = ecmaError24.lineNumber();
//        java.lang.String str27 = ecmaError24.sourceName();
//        java.lang.String str28 = ecmaError24.getName();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel30 = diagnosticType29.level;
//        try {
//            java.lang.String str31 = com.google.javascript.rhino.ScriptRuntime.getMessage3("error reporter", (java.lang.Object) node9, (java.lang.Object) ecmaError24, (java.lang.Object) diagnosticType29);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(node8);
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNotNull(node13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(ecmaError24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TypeError" + "'", str28.equals("TypeError"));
//        org.junit.Assert.assertNotNull(diagnosticType29);
//        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions0.prettyPrint = false;
        boolean boolean10 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compiler4.getCodingConvention();
        com.google.javascript.rhino.Node node8 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler4);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node10 = compiler9.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        java.lang.String str12 = compiler9.toSource();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean17 = node16.isUnscopedQualifiedName();
        int int18 = node16.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType19 = node16.getJSType();
        node16.setCharno(7);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean31 = node30.isUnscopedQualifiedName();
        int int32 = node30.getChildCount();
        java.util.Set<java.lang.String> strSet33 = node30.getDirectives();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node37.detachChildren();
        boolean boolean39 = node37.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node43.detachChildren();
        boolean boolean45 = node43.isOnlyModifiesThisCall();
        int int47 = node43.getIntProp((int) 'a');
        boolean boolean48 = node37.isEquivalentTo(node43);
        com.google.javascript.rhino.Node node49 = node30.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean54 = node53.isUnscopedQualifiedName();
        int int55 = node53.getChildCount();
        node53.putProp((int) (byte) 10, (java.lang.Object) 150);
        node53.putBooleanProp(10, false);
        boolean boolean62 = node53.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) ' ', node26, node43, node53);
        boolean boolean64 = node16.hasChild(node43);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean69 = node68.isUnscopedQualifiedName();
        int int70 = node68.getChildCount();
        java.util.Set<java.lang.String> strSet71 = node68.getDirectives();
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node75.detachChildren();
        boolean boolean77 = node75.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node81.detachChildren();
        boolean boolean83 = node81.isOnlyModifiesThisCall();
        int int85 = node81.getIntProp((int) 'a');
        boolean boolean86 = node75.isEquivalentTo(node81);
        com.google.javascript.rhino.Node node87 = node68.copyInformationFromForTree(node81);
        node81.setIsSyntheticBlock(true);
        java.lang.RuntimeException runtimeException90 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compiler9, (java.lang.Object) node16, (java.lang.Object) node81);
        com.google.javascript.rhino.Node node91 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(strSet33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNull(strSet71);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(runtimeException90);
        org.junit.Assert.assertNull(node91);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((-2));
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setAllFlags();
        sideEffectFlags1.setMutatesThis();
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkSymbols;
        boolean boolean6 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray10 = compiler4.getWarnings();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler4.getSourceMap();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker12 = compiler4.tracker;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSErrorArray10);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNull(performanceTracker12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(43);
        boolean boolean2 = node1.isUnscopedQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "TypeError: ");
        java.lang.String str3 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!: TypeError: " + "'", str3.equals("hi!: TypeError: "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean5 = defaultCodingConvention2.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention2, "language version", (int) (short) -1, (int) (byte) 0);
        com.google.javascript.rhino.Node node10 = null;
        java.lang.String str11 = defaultCodingConvention2.identifyTypeDefAssign(node10);
        boolean boolean13 = defaultCodingConvention2.isPrivate("");
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection14 = defaultCodingConvention2.getAssertionFunctions();
        com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention2, "(STRING )", 23, 160);
        try {
            java.lang.String str19 = com.google.javascript.rhino.ScriptRuntime.getMessage2("NOT 0\n    STRING \n    STRING \n    STRING \n    STRING \n", (java.lang.Object) 16, (java.lang.Object) node18);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property NOT 0\n    STRING \n    STRING \n    STRING \n    STRING \n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection14);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        compilerOptions0.renamePrefix = "null(ERROR)";
        compilerOptions0.skipAllCompilerPasses();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        compilerOptions24.unaliasableGlobals = "(())";
        compilerOptions24.groupVariableDeclarations = true;
        boolean boolean32 = compilerOptions24.checkEs5Strict;
        compilerOptions24.setSummaryDetailLevel(2);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.setLooseTypes(false);
        boolean boolean5 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = compilerOptions0.cssRenamingMap;
        java.lang.String str7 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(cssRenamingMap6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "// Input %num%" + "'", str7.equals("// Input %num%"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler1.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler1.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node6 = compiler5.getRoot();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager9 = compiler7.getErrorManager();
        compiler5.setErrorManager(errorManager9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node12 = compiler11.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler11.getErrorManager();
        java.lang.String str14 = compiler11.toSource();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState15 = compiler11.getState();
        compiler5.setState(intermediateState15);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState17 = compiler5.getState();
        compiler1.setState(intermediateState17);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean26 = node25.isUnscopedQualifiedName();
        node25.detachChildren();
        java.lang.String[] strArray30 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet31 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet31, strArray30);
        node25.setDirectives((java.util.Set<java.lang.String>) strSet31);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(110, node25, 20, (int) (byte) -1);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast37 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal20, node36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(sourceMap3);
        org.junit.Assert.assertNotNull(errorManager4);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(errorManager9);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(errorManager13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(intermediateState15);
        org.junit.Assert.assertNotNull(intermediateState17);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test184");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager3.getErrors();
//        com.google.javascript.rhino.Context context6 = null;
//        com.google.javascript.rhino.Context context7 = com.google.javascript.rhino.Context.enter(context6);
//        context7.removeActivationName("hi!");
//        java.nio.charset.Charset charset11 = null;
//        com.google.javascript.jscomp.SourceFile sourceFile12 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset11);
//        com.google.javascript.jscomp.JsAst jsAst13 = new com.google.javascript.jscomp.JsAst(sourceFile12);
//        com.google.javascript.jscomp.Region region15 = sourceFile12.getRegion(24);
//        java.lang.Object obj16 = context7.getThreadLocal((java.lang.Object) 24);
//        java.lang.RuntimeException runtimeException17 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) loggerErrorManager3, (java.lang.Object) context7);
//        boolean boolean18 = context7.isGeneratingSource();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNotNull(jSErrorArray5);
//        org.junit.Assert.assertNotNull(context7);
//        org.junit.Assert.assertNotNull(sourceFile12);
//        org.junit.Assert.assertNull(region15);
//        org.junit.Assert.assertNull(obj16);
//        org.junit.Assert.assertNotNull(runtimeException17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.reportPath = "Not declared as a constructor";
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray14 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList15 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList15, warningsGuardArray14);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList15);
        java.lang.String str18 = composeWarningsGuard17.toString();
        java.lang.String str19 = composeWarningsGuard17.toString();
        com.google.javascript.rhino.EcmaError ecmaError22 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "TypeError: ");
        com.google.javascript.rhino.Context context23 = null;
        com.google.javascript.rhino.Context context24 = com.google.javascript.rhino.Context.enter(context23);
        java.util.logging.Logger logger25 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager26 = new com.google.javascript.jscomp.LoggerErrorManager(logger25);
        java.lang.Object obj27 = context24.getThreadLocal((java.lang.Object) loggerErrorManager26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup28;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup28;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup28;
        java.lang.RuntimeException runtimeException32 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) ecmaError22, (java.lang.Object) loggerErrorManager26, (java.lang.Object) diagnosticGroup28);
        boolean boolean33 = composeWarningsGuard17.disables(diagnosticGroup28);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup34 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup34;
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean44 = node43.isUnscopedQualifiedName();
        int int45 = node43.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType46 = node43.getJSType();
        com.google.javascript.rhino.Node node47 = node43.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel48 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat50 = diagnosticType49.format;
        java.lang.String[] strArray57 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("error reporter", node43, checkLevel48, diagnosticType49, strArray57);
        com.google.javascript.jscomp.DiagnosticType diagnosticType64 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat69 = diagnosticType68.format;
        java.lang.String[] strArray75 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType68, strArray75);
        com.google.javascript.jscomp.JSError jSError77 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType64, strArray75);
        com.google.javascript.jscomp.JSError jSError78 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType49, strArray75);
        com.google.javascript.jscomp.Compiler compiler79 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node80 = compiler79.getRoot();
        com.google.javascript.jscomp.Compiler compiler81 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node82 = compiler81.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager83 = compiler81.getErrorManager();
        compiler79.setErrorManager(errorManager83);
        boolean boolean85 = jSError78.equals((java.lang.Object) errorManager83);
        boolean boolean86 = diagnosticGroup34.matches(jSError78);
        int int87 = jSError78.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel88 = composeWarningsGuard17.level(jSError78);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard17);
        com.google.javascript.jscomp.CheckLevel checkLevel90 = compilerOptions0.checkGlobalNamesLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(warningsGuardArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(ecmaError22);
        org.junit.Assert.assertNotNull(context24);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(runtimeException32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup34);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(messageFormat50);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(diagnosticType64);
        org.junit.Assert.assertNotNull(diagnosticType68);
        org.junit.Assert.assertNotNull(messageFormat69);
        org.junit.Assert.assertNotNull(strArray75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertNotNull(jSError77);
        org.junit.Assert.assertNotNull(jSError78);
        org.junit.Assert.assertNull(node80);
        org.junit.Assert.assertNull(node82);
        org.junit.Assert.assertNotNull(errorManager83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 31 + "'", int87 == 31);
        org.junit.Assert.assertNull(checkLevel88);
        org.junit.Assert.assertTrue("'" + checkLevel90 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel90.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        node60.putIntProp(15, 0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        int int13 = node9.getIntProp((int) 'a');
        boolean boolean14 = node3.isEquivalentTo(node9);
        node3.putIntProp(0, (int) (byte) -1);
        java.lang.String str18 = node3.getQualifiedName();
        node3.setString("STRING ");
        boolean boolean21 = node3.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler4.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str13 = jSSourceFile12.getName();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap16 = compiler14.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node20 = compiler14.parse(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean25 = compilerOptions24.inlineGetters;
        java.lang.String str26 = compilerOptions24.locale;
        com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray21, jSModuleArray22, compilerOptions24);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        node31.detachChildren();
        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        node31.setDirectives((java.util.Set<java.lang.String>) strSet37);
        compilerOptions24.stripTypePrefixes = strSet37;
        compilerOptions24.convertToDottedProperties = false;
        compilerOptions24.sourceMapOutputPath = "(Named type with empty name component)";
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions24.brokenClosureRequiresLevel;
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(jSErrorArray9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING " + "'", str13.equals("STRING "));
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(sourceMap16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test190");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node3 = compiler2.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler2.getErrorManager();
//        compiler0.setErrorManager(errorManager4);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.inlineGetters;
//        java.lang.String str8 = compilerOptions6.locale;
//        compilerOptions6.checkCaja = true;
//        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
//        compiler0.initOptions(compilerOptions6);
//        compilerOptions6.removeTryCatchFinally = false;
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean23 = node22.isUnscopedQualifiedName();
//        int int24 = node22.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
//        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
//        java.lang.String[] strArray36 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("error reporter", node22, checkLevel27, diagnosticType28, strArray36);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat48 = diagnosticType47.format;
//        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType47, strArray54);
//        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType43, strArray54);
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType28, strArray54);
//        com.google.javascript.jscomp.CheckLevel checkLevel58 = diagnosticType28.level;
//        compilerOptions6.checkMissingReturn = checkLevel58;
//        boolean boolean60 = compilerOptions6.inlineFunctions;
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNull(node3);
//        org.junit.Assert.assertNotNull(errorManager4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType28);
//        org.junit.Assert.assertNotNull(messageFormat29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(diagnosticType43);
//        org.junit.Assert.assertNotNull(diagnosticType47);
//        org.junit.Assert.assertNotNull(messageFormat48);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(jSError56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        boolean boolean29 = node3.isLocalResultCall();
        node3.setLineno(140);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback4);
        int int6 = nodeTraversal5.getLineNumber();
        com.google.javascript.jscomp.Scope scope7 = nodeTraversal5.getScope();
        try {
            com.google.javascript.rhino.Node node8 = nodeTraversal5.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(scope7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.checkCaja;
        compilerOptions0.setDefineToBooleanLiteral("GETPROP 10", false);
        compilerOptions0.reportPath = "Not declared as a constructor: ERROR - Exceeded max number of optimization iterations: {0}\n";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean7 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.inlineGetters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = compilerOptions8.cssRenamingMap;
        boolean boolean11 = compilerOptions8.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions8.checkMethods = checkLevel12;
        compilerOptions0.checkMethods = checkLevel12;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(cssRenamingMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
        boolean boolean7 = context1.isActivationNeeded("@IMPLEMENTATION.VERSION@");
        boolean boolean9 = context1.isActivationNeeded("(JSC_OPTIMIZE_LOOP_ERROR)");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags11 = new com.google.javascript.rhino.Node.SideEffectFlags(1);
        java.lang.Object obj12 = context1.getThreadLocal((java.lang.Object) sideEffectFlags11);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(errorReporter5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node61 = node54.getParent();
        boolean boolean62 = node54.isVarArgs();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        compilerOptions0.prettyPrint = false;
        compilerOptions0.setDefineToDoubleLiteral("JSC_OPTIMIZE_LOOP_ERROR", (double) 160);
        compilerOptions0.setTweakToDoubleLiteral("sheq", (double) 7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        try {
            com.google.javascript.rhino.Context.reportWarning("STRING  [label_id_prop: -1]");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler0.getErrorManager();
        java.lang.String str4 = compiler0.toSource();
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat5.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, false);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node10 = compiler9.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat5.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray14 = compiler9.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str18 = jSSourceFile17.getName();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node20 = compiler19.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap21 = compiler19.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node25 = compiler19.parse(jSSourceFile24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile17, jSSourceFile24 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean30 = compilerOptions29.inlineGetters;
        java.lang.String str31 = compilerOptions29.locale;
        com.google.javascript.jscomp.Result result32 = compiler9.compile(jSSourceFileArray26, jSModuleArray27, compilerOptions29);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        java.lang.String str37 = jSSourceFile35.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40);
        com.google.javascript.jscomp.Region region43 = jSSourceFile40.getRegion(31);
        java.lang.String str44 = jSSourceFile40.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput52 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile55 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        jSSourceFile55.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JsAst jsAst60 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile59);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile35, jSSourceFile40, jSSourceFile47, jSSourceFile51, jSSourceFile55, jSSourceFile59 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean63 = compilerOptions62.inlineGetters;
        java.lang.String str64 = compilerOptions62.locale;
        compilerOptions62.generateExports = false;
        com.google.javascript.jscomp.Result result67 = compiler0.compile(jSSourceFileArray26, jSSourceFileArray61, compilerOptions62);
        boolean boolean68 = compilerOptions62.removeUnusedPrototypeProperties;
        boolean boolean69 = compilerOptions62.collapseVariableDeclarations;
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(errorManager3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(errorFormat5);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(messageFormatter13);
        org.junit.Assert.assertNotNull(jSErrorArray14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING " + "'", str18.equals("STRING "));
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNull(sourceMap21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(result32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str37.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNull(region43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNotNull(jSSourceFile55);
        org.junit.Assert.assertNotNull(jSSourceFile59);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(result67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node61 = node54.getParent();
        com.google.javascript.rhino.Node node62 = node54.getLastSibling();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineGetters;
        java.lang.String str2 = compilerOptions0.locale;
        compilerOptions0.checkCaja = true;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.debugFunctionSideEffectsPath = "DiagnosticGroup<checkTypes>(WARNING)";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        compilerOptions0.devirtualizePrototypeMethods = true;
        boolean boolean12 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.labelRenaming = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Scope scope2 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("STRING  [empty_block: 1]\n");
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node10 = compiler9.getRoot();
        com.google.javascript.jscomp.SourceFile.Generator generator12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator12);
        com.google.javascript.jscomp.SourceFile.Generator generator15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: hi! at DiagnosticGroup<tweakValidation>(WARNING) line 41 : 0", generator15);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile16 };
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter21 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler19, false);
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node23 = compiler22.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager24 = compiler22.getErrorManager();
        com.google.javascript.jscomp.MessageFormatter messageFormatter26 = errorFormat18.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler22, false);
        com.google.javascript.jscomp.JSError[] jSErrorArray27 = compiler22.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        java.lang.String str31 = jSSourceFile30.getName();
        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node33 = compiler32.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap34 = compiler32.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node38 = compiler32.parse(jSSourceFile37);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray39 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile30, jSSourceFile37 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray40 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph41 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray40);
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean43 = compilerOptions42.inlineGetters;
        java.lang.String str44 = compilerOptions42.locale;
        com.google.javascript.jscomp.Result result45 = compiler22.compile(jSSourceFileArray39, jSModuleArray40, compilerOptions42);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean47 = compilerOptions46.inlineGetters;
        java.lang.String str48 = compilerOptions46.renamePrefix;
        boolean boolean49 = compilerOptions46.collapseVariableDeclarations;
        compiler9.init(jSSourceFileArray17, jSModuleArray40, compilerOptions46);
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions46.checkGlobalThisLevel;
        com.google.javascript.jscomp.Result result52 = compiler0.compile(jSSourceFile5, jSSourceFile8, compilerOptions46);
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertNotNull(messageFormatter21);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNotNull(errorManager24);
        org.junit.Assert.assertNotNull(messageFormatter26);
        org.junit.Assert.assertNotNull(jSErrorArray27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "STRING " + "'", str31.equals("STRING "));
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNull(sourceMap34);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(jSSourceFileArray39);
        org.junit.Assert.assertNotNull(jSModuleArray40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(result45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result52);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test204");
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray1 = new com.google.javascript.jscomp.DiagnosticType[] {};
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray1);
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup2;
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        boolean boolean7 = defaultCodingConvention4.isExported("Named type with empty name component", true);
//        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 19, (java.lang.Object) diagnosticGroup2, (java.lang.Object) boolean7);
//        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean17 = node16.isUnscopedQualifiedName();
//        int int18 = node16.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType19 = node16.getJSType();
//        com.google.javascript.rhino.Node node20 = node16.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat23 = diagnosticType22.format;
//        java.lang.String[] strArray30 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("error reporter", node16, checkLevel21, diagnosticType22, strArray30);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat42 = diagnosticType41.format;
//        java.lang.String[] strArray48 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType41, strArray48);
//        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType37, strArray48);
//        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType22, strArray48);
//        com.google.javascript.jscomp.CheckLevel checkLevel52 = diagnosticType22.level;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard53 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel52);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup54 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup54;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup54;
//        com.google.javascript.jscomp.CheckLevel checkLevel57 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard58 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup54, checkLevel57);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup59 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup59;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType64 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat65 = diagnosticType64.format;
//        java.lang.String[] strArray71 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType64, strArray71);
//        boolean boolean73 = diagnosticGroup59.matches(jSError72);
//        boolean boolean74 = diagnosticGroupWarningsGuard58.disables(diagnosticGroup59);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup75 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup75;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup75;
//        com.google.javascript.jscomp.CheckLevel checkLevel78 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard79 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup75, checkLevel78);
//        java.lang.String str80 = diagnosticGroupWarningsGuard79.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup81 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        boolean boolean82 = diagnosticGroupWarningsGuard79.disables(diagnosticGroup81);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType86 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat87 = diagnosticType86.format;
//        java.lang.String[] strArray93 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError94 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType86, strArray93);
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy95 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
//        boolean boolean96 = jSError94.equals((java.lang.Object) propertyRenamingPolicy95);
//        com.google.javascript.jscomp.CheckLevel checkLevel97 = diagnosticGroupWarningsGuard79.level(jSError94);
//        boolean boolean98 = diagnosticGroup59.matches(jSError94);
//        boolean boolean99 = diagnosticGroupWarningsGuard53.enables(diagnosticGroup59);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(runtimeException8);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNull(jSType19);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType22);
//        org.junit.Assert.assertNotNull(messageFormat23);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(jSError31);
//        org.junit.Assert.assertNotNull(diagnosticType37);
//        org.junit.Assert.assertNotNull(diagnosticType41);
//        org.junit.Assert.assertNotNull(messageFormat42);
//        org.junit.Assert.assertNotNull(strArray48);
//        org.junit.Assert.assertNotNull(jSError49);
//        org.junit.Assert.assertNotNull(jSError50);
//        org.junit.Assert.assertNotNull(jSError51);
//        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticGroup54);
//        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticGroup59);
//        org.junit.Assert.assertNotNull(diagnosticType64);
//        org.junit.Assert.assertNotNull(messageFormat65);
//        org.junit.Assert.assertNotNull(strArray71);
//        org.junit.Assert.assertNotNull(jSError72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup75);
//        org.junit.Assert.assertTrue("'" + checkLevel78 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel78.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticGroup81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(diagnosticType86);
//        org.junit.Assert.assertNotNull(messageFormat87);
//        org.junit.Assert.assertNotNull(strArray93);
//        org.junit.Assert.assertNotNull(jSError94);
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy95 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy95.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//        org.junit.Assert.assertNull(checkLevel97);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
//        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
//    }
//}

