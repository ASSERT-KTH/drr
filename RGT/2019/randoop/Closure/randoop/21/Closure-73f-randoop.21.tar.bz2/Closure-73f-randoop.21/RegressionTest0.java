import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            java.lang.String str5 = com.google.javascript.rhino.ScriptRuntime.getMessage4("", (java.lang.Object) 0.0d, (java.lang.Object) 100.0f, (java.lang.Object) ' ', (java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("hi!", "hi!", 41, "hi!", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        try {
            node3.setSideEffectFlags(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("hi!", "hi!", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray1 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList2 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList2, jSSourceFileArray1);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, jSSourceFileArray4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList2, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray4 = new java.lang.String[] { "", "hi!", "" };
        try {
            com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = null;
        java.lang.String[] strArray5 = new java.lang.String[] { "Named type with empty name component" };
        try {
            com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make("", 150, 0, diagnosticType3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray5 = new java.lang.String[] {};
        try {
            com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make("language version", 1, 0, checkLevel3, diagnosticType4, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("language version", charset1);
        try {
            java.io.Reader reader3 = sourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: language version (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.getMessage2("Named type with empty name component", (java.lang.Object) ' ', (java.lang.Object) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Named type with empty name component");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "error reporter", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            com.google.javascript.rhino.Context.reportWarning("hi!", "language version", 26, "", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("language version", charset1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "language version" + "'", str3.equals("language version"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getName();
        try {
            com.google.javascript.jscomp.Region region5 = sourceFile2.getRegion(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("()", "()", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("()");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromCode("error reporter", "language version");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        try {
            java.lang.String str25 = com.google.javascript.rhino.ScriptRuntime.getMessage4("Named type with empty name component", (java.lang.Object) 23, (java.lang.Object) node5, (java.lang.Object) sourceFile19, (java.lang.Object) node24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Named type with empty name component");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertNotNull(node24);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        try {
            double double23 = node16.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING  is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = null;
        try {
            compiler0.init(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile1 };
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] { jSModule3 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = null;
        try {
            com.google.javascript.jscomp.Result result6 = compiler0.compile(jSSourceFileArray2, jSModuleArray4, compilerOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSModuleArray4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList3 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList3, jSSourceFileArray2);
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = null;
        try {
            com.google.javascript.jscomp.Result result9 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList3, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList6, compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.ERROR;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph3.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "()", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("language version", (java.lang.Object) propertyRenamingPolicy1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray1 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList2 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList2, jSSourceFileArray1);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, jSSourceFileArray4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            com.google.javascript.jscomp.Result result8 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList2, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(4095);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "language version", "", (int) (short) 10, "", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 2, (java.lang.Object) 38);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "language version", (-1), "hi!", 7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray14 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile7, jSSourceFile9, jSSourceFile11, jSSourceFile13 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = null;
        try {
            compiler0.init(jSSourceFileArray3, jSSourceFileArray14, compilerOptions15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFileArray14);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = null;
        try {
            com.google.javascript.rhino.Node node5 = compiler0.parse(jSSourceFile4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
        java.lang.String str4 = evaluatorException3.lineSource();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("");
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node61 = node10.getFirstChild();
        try {
            com.google.javascript.rhino.Node.AncestorIterable ancestorIterable62 = node61.getAncestors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNull(node61);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        java.lang.Appendable appendable29 = null;
        try {
            node28.appendStringTree(appendable29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat1 = diagnosticType0.format;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat3 = diagnosticType2.format;
        int int4 = diagnosticType0.compareTo(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(messageFormat1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(messageFormat3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList2 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList4 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList4, jSModuleArray3);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            compiler0.initModules(jSSourceFileList2, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList4, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSModuleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Object obj1 = null;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("language version", obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        java.util.Set<java.lang.String> strSet7 = node4.getDirectives();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        int int21 = node17.getIntProp((int) 'a');
        boolean boolean22 = node11.isEquivalentTo(node17);
        com.google.javascript.rhino.Node node23 = node4.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean28 = node27.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node27);
        int int30 = node4.getType();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node35.detachChildren();
        boolean boolean37 = node35.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node41.detachChildren();
        boolean boolean43 = node41.isOnlyModifiesThisCall();
        int int45 = node41.getIntProp((int) 'a');
        boolean boolean46 = node35.isEquivalentTo(node41);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean51 = node50.isUnscopedQualifiedName();
        int int52 = node50.getChildCount();
        java.util.Set<java.lang.String> strSet53 = node50.getDirectives();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node57.detachChildren();
        boolean boolean59 = node57.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node63.detachChildren();
        boolean boolean65 = node63.isOnlyModifiesThisCall();
        int int67 = node63.getIntProp((int) 'a');
        boolean boolean68 = node57.isEquivalentTo(node63);
        com.google.javascript.rhino.Node node69 = node50.copyInformationFromForTree(node63);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean74 = node73.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node75 = node50.copyInformationFromForTree(node73);
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean80 = node79.isUnscopedQualifiedName();
        int int81 = node79.getChildCount();
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean86 = node85.isUnscopedQualifiedName();
        int int87 = node85.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType88 = node85.getJSType();
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node(26, node41, node50, node79, node85, (int) (short) 0, (int) '4');
        try {
            com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node((int) (short) 10, node4, node79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 40 + "'", int30 == 40);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNull(strSet53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNull(jSType88);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node6.detachChildren();
        boolean boolean8 = node6.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        int int16 = node12.getIntProp((int) 'a');
        boolean boolean17 = node6.isEquivalentTo(node12);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean22 = node21.isUnscopedQualifiedName();
        int int23 = node21.getChildCount();
        java.util.Set<java.lang.String> strSet24 = node21.getDirectives();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node28.detachChildren();
        boolean boolean30 = node28.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node34.detachChildren();
        boolean boolean36 = node34.isOnlyModifiesThisCall();
        int int38 = node34.getIntProp((int) 'a');
        boolean boolean39 = node28.isEquivalentTo(node34);
        com.google.javascript.rhino.Node node40 = node21.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean45 = node44.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node46 = node21.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean51 = node50.isUnscopedQualifiedName();
        int int52 = node50.getChildCount();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean57 = node56.isUnscopedQualifiedName();
        int int58 = node56.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType59 = node56.getJSType();
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(26, node12, node21, node50, node56, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean67 = node66.isUnscopedQualifiedName();
        int int68 = node66.getChildCount();
        java.util.Set<java.lang.String> strSet69 = node66.getDirectives();
        node66.removeProp(29);
        try {
            com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) (byte) 1, node1, node50, node66, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(strSet24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNull(strSet69);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        com.google.javascript.rhino.Context context1 = null;
//        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context1);
//        context2.removeActivationName("Named type with empty name component");
//        try {
//            java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.getMessage3("language version", (java.lang.Object) "Named type with empty name component", (java.lang.Object) (byte) 10, (java.lang.Object) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(context2);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode2 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
//        context1.putThreadLocal((java.lang.Object) tracerMode2, (java.lang.Object) ' ');
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter6 = context1.setErrorReporter(errorReporter5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + tracerMode2 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode2.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        int int21 = node17.getIntProp((int) 'a');
        boolean boolean22 = node11.isEquivalentTo(node17);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        int int28 = node26.getChildCount();
        java.util.Set<java.lang.String> strSet29 = node26.getDirectives();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node33.detachChildren();
        boolean boolean35 = node33.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node39.detachChildren();
        boolean boolean41 = node39.isOnlyModifiesThisCall();
        int int43 = node39.getIntProp((int) 'a');
        boolean boolean44 = node33.isEquivalentTo(node39);
        com.google.javascript.rhino.Node node45 = node26.copyInformationFromForTree(node39);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean50 = node49.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node51 = node26.copyInformationFromForTree(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean56 = node55.isUnscopedQualifiedName();
        int int57 = node55.getChildCount();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean62 = node61.isUnscopedQualifiedName();
        int int63 = node61.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType64 = node61.getJSType();
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(26, node17, node26, node55, node61, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node71.detachChildren();
        boolean boolean73 = node71.isOnlyModifiesThisCall();
        int int75 = node71.getIntProp((int) 'a');
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean80 = node79.isUnscopedQualifiedName();
        int int81 = node79.getChildCount();
        node79.putProp((int) (byte) 10, (java.lang.Object) 150);
        node79.putBooleanProp(10, false);
        try {
            com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node(49, node4, node26, node71, node79, 9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(strSet29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.Context.checkOptimizationLevel(7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        try {
            java.lang.String[] strArray4 = compiler0.toSourceArray(jSModule3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        try {
//            com.google.javascript.rhino.Context.reportError("Named type with empty name component", "", 100, "", (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Named type with empty name component (#100)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean11 = node10.isUnscopedQualifiedName();
        int int12 = node10.getChildCount();
        java.util.Set<java.lang.String> strSet13 = node10.getDirectives();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node23.detachChildren();
        boolean boolean25 = node23.isOnlyModifiesThisCall();
        int int27 = node23.getIntProp((int) 'a');
        boolean boolean28 = node17.isEquivalentTo(node23);
        com.google.javascript.rhino.Node node29 = node10.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean34 = node33.isUnscopedQualifiedName();
        int int35 = node33.getChildCount();
        node33.putProp((int) (byte) 10, (java.lang.Object) 150);
        node33.putBooleanProp(10, false);
        boolean boolean42 = node33.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) ' ', node6, node23, node33);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean48 = node47.isUnscopedQualifiedName();
        int int49 = node47.getChildCount();
        java.util.Set<java.lang.String> strSet50 = node47.getDirectives();
        com.google.javascript.rhino.Node node51 = null;
        try {
            com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(150, node1, node43, node47, node51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(strSet13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNull(strSet50);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("language version", charset2);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        try {
            java.lang.String str8 = com.google.javascript.rhino.ScriptRuntime.getMessage2("Named type with empty name component", (java.lang.Object) charset2, (java.lang.Object) jSModuleGraph7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Named type with empty name component");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
        java.lang.String str6 = context1.getImplementationVersion();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = context1.getErrorReporter();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(errorReporter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertNull(errorReporter7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(12, nodeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        com.google.javascript.rhino.Node node34 = null;
        try {
            node3.addChildAfter(node32, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        int int13 = node9.getIntProp((int) 'a');
        boolean boolean14 = node3.isEquivalentTo(node9);
        node9.setOptionalArg(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup4;
        try {
            java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.getMessage2("", (java.lang.Object) generator2, (java.lang.Object) diagnosticGroup4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType22 = node19.getJSType();
        com.google.javascript.rhino.Node node23 = node19.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat26 = diagnosticType25.format;
        java.lang.String[] strArray33 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("error reporter", node19, checkLevel24, diagnosticType25, strArray33);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("error reporter", 100, (int) (byte) 1);
        try {
            java.lang.String str39 = defaultCodingConvention0.extractClassNameIfRequire(node19, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(messageFormat26);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean21 = node20.isUnscopedQualifiedName();
        int int22 = node20.getChildCount();
        java.util.Set<java.lang.String> strSet23 = node20.getDirectives();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node27.detachChildren();
        boolean boolean29 = node27.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node33.detachChildren();
        boolean boolean35 = node33.isOnlyModifiesThisCall();
        int int37 = node33.getIntProp((int) 'a');
        boolean boolean38 = node27.isEquivalentTo(node33);
        com.google.javascript.rhino.Node node39 = node20.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean44 = node43.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node45 = node20.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean50 = node49.isUnscopedQualifiedName();
        int int51 = node49.getChildCount();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean56 = node55.isUnscopedQualifiedName();
        int int57 = node55.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType58 = node55.getJSType();
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(26, node11, node20, node49, node55, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node[] nodeArray62 = new com.google.javascript.rhino.Node[] { node49 };
        try {
            com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(0, nodeArray62, 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(strSet23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(nodeArray62);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator7);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile8 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList10 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, jSSourceFileArray9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = null;
        try {
            com.google.javascript.jscomp.Result result13 = compiler0.compile(jSSourceFileList3, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, compilerOptions12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean10 = node9.isUnscopedQualifiedName();
        int int11 = node9.getChildCount();
        java.util.Set<java.lang.String> strSet12 = node9.getDirectives();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node22.detachChildren();
        boolean boolean24 = node22.isOnlyModifiesThisCall();
        int int26 = node22.getIntProp((int) 'a');
        boolean boolean27 = node16.isEquivalentTo(node22);
        com.google.javascript.rhino.Node node28 = node9.copyInformationFromForTree(node22);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean33 = node32.isUnscopedQualifiedName();
        int int34 = node32.getChildCount();
        node32.putProp((int) (byte) 10, (java.lang.Object) 150);
        node32.putBooleanProp(10, false);
        boolean boolean41 = node32.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) ' ', node5, node22, node32);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean47 = node46.isUnscopedQualifiedName();
        int int48 = node46.getChildCount();
        java.util.Set<java.lang.String> strSet49 = node46.getDirectives();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node53.detachChildren();
        boolean boolean55 = node53.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node59.detachChildren();
        boolean boolean61 = node59.isOnlyModifiesThisCall();
        int int63 = node59.getIntProp((int) 'a');
        boolean boolean64 = node53.isEquivalentTo(node59);
        com.google.javascript.rhino.Node node65 = node46.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean70 = node69.isUnscopedQualifiedName();
        int int71 = node69.getChildCount();
        node69.putProp((int) (byte) 10, (java.lang.Object) 150);
        node69.putBooleanProp(10, false);
        boolean boolean78 = node69.isUnscopedQualifiedName();
        try {
            com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(2, node32, node46, node69, 18, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(strSet12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(strSet49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            boolean boolean7 = jSModuleGraph3.dependsOn(jSModule5, jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList6);
        try {
            com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            com.google.javascript.rhino.Context.reportWarning("language version", "language version", (int) ' ', "language version", 140);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        try {
            node3.setSideEffectFlags((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "error reporter");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException5);
        int int7 = evaluatorException5.lineNumber();
        try {
            evaluatorException5.initSourceName("Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        compiler1.disableThreads();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        try {
//            com.google.javascript.rhino.Context.reportError("Named type with empty name component");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Named type with empty name component");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile9, jSSourceFile11, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule jSModule16 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray17 = new com.google.javascript.jscomp.JSModule[] { jSModule16 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = null;
        try {
            com.google.javascript.jscomp.Result result19 = compiler0.compile(jSSourceFileArray15, jSModuleArray17, compilerOptions18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule6);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            com.google.javascript.jscomp.Result result7 = compiler0.compile(jSSourceFile2, jSSourceFile5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        node3.putBooleanProp(36, false);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags8 = null;
        try {
            node3.setSideEffectFlags(sideEffectFlags8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("hi!", "DiagnosticGroup<tweakValidation>(WARNING)", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 26");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean6 = node5.isUnscopedQualifiedName();
//        int int7 = node5.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType8 = node5.getJSType();
//        com.google.javascript.rhino.Node node9 = node5.getLastSibling();
//        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.WARNING;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat12 = diagnosticType11.format;
//        java.lang.String[] strArray19 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
//        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("error reporter", node5, checkLevel10, diagnosticType11, strArray19);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray21 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList22 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList22, warningsGuardArray21);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard24 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList22);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray25 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList26 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList26, warningsGuardArray25);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard28 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList26);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray29 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList30 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList30, warningsGuardArray29);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard32 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList30);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray33 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList34 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList34, warningsGuardArray33);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard36 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList34);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray37 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard24, composeWarningsGuard28, composeWarningsGuard32, composeWarningsGuard36 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard38 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray37);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup39;
//        boolean boolean41 = composeWarningsGuard38.disables(diagnosticGroup39);
//        com.google.javascript.rhino.EcmaError ecmaError43 = com.google.javascript.rhino.ScriptRuntime.typeError("");
//        com.google.javascript.rhino.EvaluatorException evaluatorException47 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
//        ecmaError43.addSuppressed((java.lang.Throwable) evaluatorException47);
//        try {
//            java.lang.String str49 = com.google.javascript.rhino.ScriptRuntime.getMessage3("language version", (java.lang.Object) strArray19, (java.lang.Object) diagnosticGroup39, (java.lang.Object) ecmaError43);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(node5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
//        org.junit.Assert.assertNotNull(diagnosticType11);
//        org.junit.Assert.assertNotNull(messageFormat12);
//        org.junit.Assert.assertNotNull(strArray19);
//        org.junit.Assert.assertNotNull(jSError20);
//        org.junit.Assert.assertNotNull(warningsGuardArray21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray37);
//        org.junit.Assert.assertNotNull(diagnosticGroup39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(ecmaError43);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
//        java.lang.String str3 = compiler0.toSource();
//        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator5);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = null;
//        try {
//            com.google.javascript.jscomp.Result result17 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, compilerOptions16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNotNull(errorManager2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//        org.junit.Assert.assertNotNull(jSSourceFileArray7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertNotNull(jSSourceFileArray13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        java.lang.RuntimeException runtimeException3 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compiler0, (java.lang.Object) 7);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            com.google.javascript.jscomp.Result result7 = compiler0.compile(jSSourceFileArray4, jSSourceFileArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(runtimeException3);
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("@IMPLEMENTATION.VERSION@", "DiagnosticGroup<tweakValidation>(WARNING)", (int) (short) -1, "@IMPLEMENTATION.VERSION@", (-3));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -3");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        try {
            java.io.Reader reader3 = sourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = errorFormat4.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, false);
        try {
            com.google.javascript.rhino.Node node8 = compilerInput3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertNotNull(messageFormatter7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(JSC_OPTIMIZE_LOOP_ERROR)" + "'", str1.equals("(JSC_OPTIMIZE_LOOP_ERROR)"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = null;
        boolean boolean6 = composeWarningsGuard3.enables(diagnosticGroup5);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            com.google.javascript.rhino.Context.reportWarning("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eq" + "'", str1.equals("eq"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("language version", "", "JSC_OPTIMIZE_LOOP_ERROR", "JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("Not declared as a type name", "JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a type name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            com.google.javascript.jscomp.Result result8 = compiler0.compile(jSSourceFile3, jSSourceFile6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("language version");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "language version" + "'", str1.equals("language version"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "language version");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        node4.addChildToBack(node11);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean21 = node20.isUnscopedQualifiedName();
        int int22 = node20.getChildCount();
        node20.putProp((int) (byte) 10, (java.lang.Object) 150);
        node20.putBooleanProp(10, false);
        java.util.Set<java.lang.String> strSet29 = node20.getDirectives();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean34 = node33.isUnscopedQualifiedName();
        int int35 = node33.getChildCount();
        java.util.Set<java.lang.String> strSet36 = node33.getDirectives();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node40.detachChildren();
        boolean boolean42 = node40.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node46.detachChildren();
        boolean boolean48 = node46.isOnlyModifiesThisCall();
        int int50 = node46.getIntProp((int) 'a');
        boolean boolean51 = node40.isEquivalentTo(node46);
        com.google.javascript.rhino.Node node52 = node33.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean57 = node56.isUnscopedQualifiedName();
        int int58 = node56.getChildCount();
        java.util.Set<java.lang.String> strSet59 = node56.getDirectives();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node63.detachChildren();
        boolean boolean65 = node63.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node69.detachChildren();
        boolean boolean71 = node69.isOnlyModifiesThisCall();
        int int73 = node69.getIntProp((int) 'a');
        boolean boolean74 = node63.isEquivalentTo(node69);
        com.google.javascript.rhino.Node node75 = node56.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean80 = node79.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node81 = node56.copyInformationFromForTree(node79);
        try {
            com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(150, node11, node20, node33, node81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(strSet29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(strSet36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(strSet59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(node81);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        try {
            int int5 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
        java.lang.String str6 = context1.getImplementationVersion();
        boolean boolean8 = context1.isActivationNeeded("language version");
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(errorReporter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component");
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.level;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
        java.lang.String str6 = diagnosticGroupWarningsGuard5.toString();
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "null(ERROR)" + "'", str6.equals("null(ERROR)"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException5);
        int int7 = evaluatorException5.lineNumber();
        int int8 = evaluatorException5.lineNumber();
        java.lang.Throwable[] throwableArray9 = evaluatorException5.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 23 + "'", int7 == 23);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 23 + "'", int8 == 23);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat4 = diagnosticType3.format;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType3, strArray10);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        boolean boolean13 = jSError11.equals((java.lang.Object) propertyRenamingPolicy12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = errorFormat15.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler16, false);
        try {
            java.lang.String str19 = jSError11.format(checkLevel14, messageFormatter18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(messageFormat4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy12.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(errorFormat15);
        org.junit.Assert.assertNotNull(messageFormatter18);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            com.google.javascript.rhino.Context.reportWarning("eq", "", 0, "JSC_OPTIMIZE_LOOP_ERROR", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean9 = node8.isUnscopedQualifiedName();
        int int10 = node8.getChildCount();
        java.util.Set<java.lang.String> strSet11 = node8.getDirectives();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node15.detachChildren();
        boolean boolean17 = node15.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node21.detachChildren();
        boolean boolean23 = node21.isOnlyModifiesThisCall();
        int int25 = node21.getIntProp((int) 'a');
        boolean boolean26 = node15.isEquivalentTo(node21);
        com.google.javascript.rhino.Node node27 = node8.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        int int33 = node31.getChildCount();
        node31.putProp((int) (byte) 10, (java.lang.Object) 150);
        node31.putBooleanProp(10, false);
        boolean boolean40 = node31.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) ' ', node4, node21, node31);
        java.lang.String str45 = node31.toString(false, false, false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(strSet11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "STRING " + "'", str45.equals("STRING "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        int int13 = node9.getIntProp((int) 'a');
        boolean boolean14 = node3.isEquivalentTo(node9);
        node9.putIntProp(41, 4095);
        boolean boolean18 = node9.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Scope scope2 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile8 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.SourceFile.Generator generator19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray25 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile17, jSSourceFile20, jSSourceFile22, jSSourceFile24 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = null;
        try {
            compiler0.init(jSSourceFileArray9, jSSourceFileArray25, compilerOptions26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFileArray25);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.lang.String str5 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler0.getState();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = compiler0.tracker;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = null;
        try {
            com.google.javascript.rhino.Node node6 = compiler0.parse(jSSourceFile5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNull(performanceTracker4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        try {
            com.google.javascript.jscomp.Region region8 = compilerInput3.getRegion((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        try {
            com.google.javascript.jscomp.Region region10 = compilerInput3.getRegion(24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
//        com.google.javascript.jscomp.CodingConvention codingConvention3 = compiler0.getCodingConvention();
//        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator5);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile9, jSSourceFile12 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
//        try {
//            com.google.javascript.jscomp.Result result21 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNotNull(errorManager2);
//        org.junit.Assert.assertNotNull(codingConvention3);
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//        org.junit.Assert.assertNotNull(jSSourceFile9);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertNotNull(jSSourceFileArray13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("JSC_OPTIMIZE_LOOP_ERROR", "()", (int) (short) 1);
        try {
            evaluatorException3.initSourceName("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
//        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
//        com.google.javascript.jscomp.CodingConvention codingConvention7 = compiler4.getCodingConvention();
//        com.google.javascript.rhino.Node node8 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler4);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        try {
//            jsAst3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(sourceFile2);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(errorManager6);
//        org.junit.Assert.assertNotNull(codingConvention7);
//        org.junit.Assert.assertNull(node8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("Named type with empty name component");
//        int int4 = context1.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.jscomp.Scope scope2 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray3 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList4, objectTypeArray3);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, scope2, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList4);
        boolean boolean8 = defaultCodingConvention0.isPrivate("(JSC_OPTIMIZE_LOOP_ERROR)");
        org.junit.Assert.assertNotNull(objectTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
//        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
//        com.google.javascript.jscomp.CodingConvention codingConvention7 = compiler4.getCodingConvention();
//        com.google.javascript.rhino.Node node8 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler4);
//        com.google.javascript.jscomp.JSModule jSModule9 = null;
//        try {
//            java.lang.String[] strArray10 = compiler4.toSourceArray(jSModule9);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(sourceFile2);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(errorManager6);
//        org.junit.Assert.assertNotNull(codingConvention7);
//        org.junit.Assert.assertNull(node8);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        int int7 = node3.getIntProp((int) 'a');
        boolean boolean8 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node13.detachChildren();
        boolean boolean15 = node13.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node19.detachChildren();
        boolean boolean21 = node19.isOnlyModifiesThisCall();
        int int23 = node19.getIntProp((int) 'a');
        boolean boolean24 = node13.isEquivalentTo(node19);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean29 = node28.isUnscopedQualifiedName();
        int int30 = node28.getChildCount();
        java.util.Set<java.lang.String> strSet31 = node28.getDirectives();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node35.detachChildren();
        boolean boolean37 = node35.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node41.detachChildren();
        boolean boolean43 = node41.isOnlyModifiesThisCall();
        int int45 = node41.getIntProp((int) 'a');
        boolean boolean46 = node35.isEquivalentTo(node41);
        com.google.javascript.rhino.Node node47 = node28.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean52 = node51.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node53 = node28.copyInformationFromForTree(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean58 = node57.isUnscopedQualifiedName();
        int int59 = node57.getChildCount();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean64 = node63.isUnscopedQualifiedName();
        int int65 = node63.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType66 = node63.getJSType();
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(26, node19, node28, node57, node63, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node70 = node63.getFirstChild();
        try {
            boolean boolean71 = node3.isEquivalentTo(node70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(strSet31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertNull(node70);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node42 = node17.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node46.detachChildren();
        boolean boolean48 = node46.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable49 = node46.siblings();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node4, node40, node46 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, nodeArray50, 0, 18);
        boolean boolean54 = node53.isOptionalArg();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(nodeIterable49);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean65 = node64.isUnscopedQualifiedName();
        int int66 = node64.getChildCount();
        java.util.Set<java.lang.String> strSet67 = node64.getDirectives();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node71.detachChildren();
        boolean boolean73 = node71.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node77.detachChildren();
        boolean boolean79 = node77.isOnlyModifiesThisCall();
        int int81 = node77.getIntProp((int) 'a');
        boolean boolean82 = node71.isEquivalentTo(node77);
        com.google.javascript.rhino.Node node83 = node64.copyInformationFromForTree(node77);
        boolean boolean84 = node10.isEquivalentTo(node83);
        boolean boolean85 = node10.hasSideEffects();
        java.util.Set<java.lang.String> strSet86 = node10.getDirectives();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNull(strSet67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(strSet86);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "TypeError: ");
        int int3 = ecmaError2.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("(JSC_OPTIMIZE_LOOP_ERROR)", "Not declared as a constructor", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        node3.detachChildren();
        java.lang.Appendable appendable6 = null;
        try {
            node3.appendStringTree(appendable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
//        java.lang.String str6 = context1.getImplementationVersion();
//        context1.removeActivationName("Named type with empty name component");
//        java.util.Locale locale9 = context1.getLocale();
//        try {
//            context1.unseal((java.lang.Object) (-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(errorReporter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNotNull(locale9);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("hi!");
//        int int4 = context1.getLanguageVersion();
//        boolean boolean5 = context1.isGeneratingSource();
//        boolean boolean6 = context1.isGeneratingDebugChanged();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        node5.putProp((int) (byte) 10, (java.lang.Object) 150);
        node5.putBooleanProp(10, false);
        boolean boolean14 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean19 = node18.isUnscopedQualifiedName();
        int int20 = node18.getChildCount();
        java.util.Set<java.lang.String> strSet21 = node18.getDirectives();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node25.detachChildren();
        boolean boolean27 = node25.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node31.detachChildren();
        boolean boolean33 = node31.isOnlyModifiesThisCall();
        int int35 = node31.getIntProp((int) 'a');
        boolean boolean36 = node25.isEquivalentTo(node31);
        com.google.javascript.rhino.Node node37 = node18.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean42 = node41.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node43 = node18.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node47.detachChildren();
        boolean boolean49 = node47.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable50 = node47.siblings();
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node5, node41, node47 };
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, nodeArray51, 0, 18);
        try {
            com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(24, nodeArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(strSet21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(nodeIterable50);
        org.junit.Assert.assertNotNull(nodeArray51);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator1);
        try {
            java.lang.String str3 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean65 = node64.isUnscopedQualifiedName();
        boolean boolean66 = node64.isOnlyModifiesThisCall();
        boolean boolean67 = node48.isEquivalentToTyped(node64);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput3.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst10 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst10, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule14 = compilerInput13.getModule();
        boolean boolean15 = compilerInput13.isExtern();
        java.lang.String str16 = compilerInput13.getName();
        com.google.javascript.jscomp.JSModule jSModule17 = null;
        compilerInput13.setModule(jSModule17);
        com.google.javascript.jscomp.JSModule jSModule19 = compilerInput13.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst20 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(sourceAst20, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule24 = compilerInput23.getModule();
        boolean boolean25 = compilerInput23.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst26 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(sourceAst26, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule30 = compilerInput29.getModule();
        boolean boolean31 = compilerInput29.isExtern();
        java.lang.String str32 = compilerInput29.getName();
        com.google.javascript.jscomp.JSModule jSModule33 = null;
        compilerInput29.setModule(jSModule33);
        com.google.javascript.jscomp.JSModule jSModule35 = compilerInput29.getModule();
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray36 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3, compilerInput13, compilerInput23, jSModule35 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList37 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList37, dependencyInfoArray36);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies39 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNull(jSModule9);
        org.junit.Assert.assertNull(jSModule14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str16.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNull(jSModule19);
        org.junit.Assert.assertNull(jSModule24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(jSModule30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str32.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNull(jSModule35);
        org.junit.Assert.assertNotNull(dependencyInfoArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("eq", "Not declared as a type name", "Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property eq");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        try {
//            com.google.javascript.rhino.Context.reportError("JSC_OPTIMIZE_LOOP_ERROR", "Not declared as a constructor", 0, "", (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
//        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler0.getErrorManager();
//        boolean boolean4 = compiler0.hasErrors();
//        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator6);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "null(ERROR)");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile12 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator20);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile21, jSSourceFile23, jSSourceFile26 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList28 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList28, jSSourceFileArray27);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = null;
//        try {
//            com.google.javascript.jscomp.Result result31 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList28, compilerOptions30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNull(sourceMap2);
//        org.junit.Assert.assertNotNull(errorManager3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertNotNull(jSSourceFileArray13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(jSSourceFile18);
//        org.junit.Assert.assertNotNull(jSSourceFile21);
//        org.junit.Assert.assertNotNull(jSSourceFile23);
//        org.junit.Assert.assertNotNull(jSSourceFile26);
//        org.junit.Assert.assertNotNull(jSSourceFileArray27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (int) (short) -1, (int) (byte) 0);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection8 = defaultCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        defaultCodingConvention0.applySingletonGetter(functionType9, functionType10, objectType11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean22 = node21.isUnscopedQualifiedName();
        int int23 = node21.getChildCount();
        java.util.Set<java.lang.String> strSet24 = node21.getDirectives();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node28.detachChildren();
        boolean boolean30 = node28.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node34.detachChildren();
        boolean boolean36 = node34.isOnlyModifiesThisCall();
        int int38 = node34.getIntProp((int) 'a');
        boolean boolean39 = node28.isEquivalentTo(node34);
        com.google.javascript.rhino.Node node40 = node21.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean45 = node44.isUnscopedQualifiedName();
        int int46 = node44.getChildCount();
        node44.putProp((int) (byte) 10, (java.lang.Object) 150);
        node44.putBooleanProp(10, false);
        boolean boolean53 = node44.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) ' ', node17, node34, node44);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean59 = node58.isUnscopedQualifiedName();
        try {
            java.lang.String str60 = defaultCodingConvention0.extractClassNameIfProvide(node54, node58);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection8);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(strSet24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        node11.putIntProp(41, 4095);
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 100, node1, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("@IMPLEMENTATION.VERSION@", (java.lang.Object) "(JSC_OPTIMIZE_LOOP_ERROR)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property @IMPLEMENTATION.VERSION@");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
//        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
//        com.google.javascript.jscomp.CodingConvention codingConvention7 = compiler4.getCodingConvention();
//        com.google.javascript.rhino.Node node8 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler4);
//        try {
//            compiler4.rebuildInputsFromModules();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(sourceFile2);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(errorManager6);
//        org.junit.Assert.assertNotNull(codingConvention7);
//        org.junit.Assert.assertNull(node8);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Named type with empty name component", "TypeError: ");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context1.isActivationNeeded("error reporter");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, (long) (byte) 1);
        int int6 = context1.getLanguageVersion();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        java.util.Set<java.lang.String> strSet7 = node4.getDirectives();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        int int21 = node17.getIntProp((int) 'a');
        boolean boolean22 = node11.isEquivalentTo(node17);
        com.google.javascript.rhino.Node node23 = node4.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean28 = node27.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node27);
        int int30 = node4.getType();
        com.google.javascript.rhino.Node node31 = node4.getLastSibling();
        boolean boolean32 = node31.isLocalResultCall();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        java.lang.Object obj36 = null;
        com.google.javascript.rhino.Context context37 = null;
        com.google.javascript.rhino.Context context38 = com.google.javascript.rhino.Context.enter(context37);
        try {
            java.lang.String str39 = com.google.javascript.rhino.ScriptRuntime.getMessage4("TypeError: ", (java.lang.Object) boolean32, (java.lang.Object) jSSourceFile35, obj36, (java.lang.Object) context37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError: ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 40 + "'", int30 == 40);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(context38);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("DiagnosticGroup<tweakValidation>(WARNING)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<tweakValidation>(WARNING)");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.Context context5 = null;
//        com.google.javascript.rhino.Context context6 = com.google.javascript.rhino.Context.enter(context5);
//        java.util.logging.Logger logger7 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
//        java.lang.Object obj9 = context6.getThreadLocal((java.lang.Object) loggerErrorManager8);
//        java.util.Locale locale10 = context6.getLocale();
//        context1.seal((java.lang.Object) locale10);
//        boolean boolean12 = context1.isGeneratingDebugChanged();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNotNull(context6);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertNotNull(locale10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<checkTypes>(WARNING)", '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "null(ERROR)");
        java.lang.RuntimeException runtimeException3 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "()");
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(runtimeException3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node6.detachChildren();
        boolean boolean8 = node6.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        int int16 = node12.getIntProp((int) 'a');
        boolean boolean17 = node6.isEquivalentTo(node12);
        node12.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup21;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup21;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup21, checkLevel24);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat30 = diagnosticType29.format;
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType29, strArray36);
        java.lang.String[] strArray38 = null;
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node12, checkLevel24, diagnosticType29, strArray38);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean48 = node47.isUnscopedQualifiedName();
        int int49 = node47.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType50 = node47.getJSType();
        com.google.javascript.rhino.Node node51 = node47.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel52 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat54 = diagnosticType53.format;
        java.lang.String[] strArray61 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("error reporter", node47, checkLevel52, diagnosticType53, strArray61);
        com.google.javascript.jscomp.DiagnosticType diagnosticType68 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType72 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat73 = diagnosticType72.format;
        java.lang.String[] strArray79 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError80 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType72, strArray79);
        com.google.javascript.jscomp.JSError jSError81 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType68, strArray79);
        com.google.javascript.jscomp.JSError jSError82 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType53, strArray79);
        com.google.javascript.jscomp.CheckLevel checkLevel83 = diagnosticType53.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType87 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat88 = diagnosticType87.format;
        java.lang.String[] strArray94 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError95 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType87, strArray94);
        try {
            com.google.javascript.jscomp.JSError jSError96 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node1, checkLevel24, diagnosticType53, strArray94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(messageFormat30);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(messageFormat54);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNotNull(diagnosticType68);
        org.junit.Assert.assertNotNull(diagnosticType72);
        org.junit.Assert.assertNotNull(messageFormat73);
        org.junit.Assert.assertNotNull(strArray79);
        org.junit.Assert.assertNotNull(jSError80);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertNotNull(jSError82);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType87);
        org.junit.Assert.assertNotNull(messageFormat88);
        org.junit.Assert.assertNotNull(strArray94);
        org.junit.Assert.assertNotNull(jSError95);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        int int29 = node3.getType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean34 = node33.isUnscopedQualifiedName();
        int int35 = node33.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType36 = node33.getJSType();
        com.google.javascript.rhino.Node node37 = node3.copyInformationFromForTree(node33);
        int int39 = node37.getIntProp(7);
        boolean boolean40 = node37.isQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 40 + "'", int29 == 40);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
//        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler0.getErrorManager();
//        boolean boolean4 = compiler0.hasErrors();
//        java.lang.String str5 = compiler0.getAstDotGraph();
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNull(sourceMap2);
//        org.junit.Assert.assertNotNull(errorManager3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = null;
        try {
            compiler0.initOptions(compilerOptions3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node2);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("Named type with empty name component");
//        boolean boolean4 = context1.isSealed();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<tweakValidation>(WARNING)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str1.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("JSC_OPTIMIZE_LOOP_ERROR", "()");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            com.google.javascript.rhino.Context.reportWarning("@IMPLEMENTATION.VERSION@", "eq", 3, "STRING  [empty_block: 1]\n", (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(47, 16, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        node7.putProp((int) (byte) 10, (java.lang.Object) 150);
        node7.putBooleanProp(10, false);
        boolean boolean16 = node7.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship17 = defaultCodingConvention3.getDelegateRelationship(node7);
        try {
            compiler0.toSource(codeBuilder1, 41, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(delegateRelationship17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("JSC_OPTIMIZE_LOOP_ERROR", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "window", 22, "window", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        node3.putProp((int) (byte) 10, (java.lang.Object) 150);
        node3.putBooleanProp(10, false);
        boolean boolean12 = node3.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node13 = null;
        try {
            boolean boolean14 = node3.isEquivalentToTyped(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node42 = node17.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node46.detachChildren();
        boolean boolean48 = node46.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable49 = node46.siblings();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node4, node40, node46 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, nodeArray50, 0, 18);
        boolean boolean54 = node53.isQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(nodeIterable49);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        java.lang.RuntimeException runtimeException3 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) diagnosticGroup0, (java.lang.Object) diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup7;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard11 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup7, checkLevel10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat13 = diagnosticType12.format;
        java.lang.String[] strArray14 = null;
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel10, diagnosticType12, strArray14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = jSError15.getType();
        try {
            boolean boolean17 = diagnosticGroup0.matches(jSError15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(runtimeException3);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(messageFormat13);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(diagnosticType16);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule10 = null;
        compilerInput3.setModule(jSModule10);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNull(jSModule9);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("TypeError: ", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            com.google.javascript.rhino.Context.reportWarning("error reporter", "Named type with empty name component", 4, "", 150);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        node5.detachChildren();
        java.lang.String[] strArray10 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        node5.setDirectives((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(110, node5, 20, (int) (byte) -1);
        com.google.javascript.rhino.Node node17 = null;
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node22.detachChildren();
        boolean boolean24 = node22.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node28.detachChildren();
        boolean boolean30 = node28.isOnlyModifiesThisCall();
        int int32 = node28.getIntProp((int) 'a');
        boolean boolean33 = node22.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean38 = node37.isUnscopedQualifiedName();
        int int39 = node37.getChildCount();
        java.util.Set<java.lang.String> strSet40 = node37.getDirectives();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node44.detachChildren();
        boolean boolean46 = node44.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node50.detachChildren();
        boolean boolean52 = node50.isOnlyModifiesThisCall();
        int int54 = node50.getIntProp((int) 'a');
        boolean boolean55 = node44.isEquivalentTo(node50);
        com.google.javascript.rhino.Node node56 = node37.copyInformationFromForTree(node50);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean61 = node60.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node62 = node37.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean67 = node66.isUnscopedQualifiedName();
        int int68 = node66.getChildCount();
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean73 = node72.isUnscopedQualifiedName();
        int int74 = node72.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType75 = node72.getJSType();
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node(26, node28, node37, node66, node72, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node79 = node28.getFirstChild();
        node28.setWasEmptyNode(true);
        java.lang.String str82 = node28.toStringTree();
        try {
            com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(6, node16, node17, node28, (int) (byte) 100, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(strSet40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNull(node79);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "STRING  [empty_block: 1]\n" + "'", str82.equals("STRING  [empty_block: 1]\n"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("Not declared as a type name");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        org.junit.Assert.assertNotNull(format0);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
//        java.lang.String str6 = context1.getImplementationVersion();
//        context1.removeActivationName("Named type with empty name component");
//        java.util.Locale locale9 = context1.getLocale();
//        boolean boolean10 = context1.hasCompileFunctionsWithDynamicScope();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(errorReporter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNotNull(locale9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 110");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node42 = node17.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node46.detachChildren();
        boolean boolean48 = node46.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable49 = node46.siblings();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node4, node40, node46 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, nodeArray50, 0, 18);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        boolean boolean59 = node53.isEquivalentTo(node58);
        boolean boolean60 = node58.isLocalResultCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(nodeIterable49);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        boolean boolean29 = node3.isLocalResultCall();
        com.google.javascript.rhino.Node node30 = node3.cloneTree();
        int int31 = node30.getCharno();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("window", "Not declared as a type name", 0, "TypeError: ", 15);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: window");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("()");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        jSSourceFile23.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray25 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9, jSSourceFile12, jSSourceFile16, jSSourceFile18, jSSourceFile20, jSSourceFile23 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = null;
        try {
            com.google.javascript.jscomp.Result result27 = compiler0.compile(jSSourceFile5, jSSourceFileArray25, compilerOptions26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFileArray25);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
//        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = null;
//        compiler4.tracker = performanceTracker9;
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertNotNull(messageFormatter3);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(errorManager6);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, false);
        try {
            java.lang.String str6 = compilerInput5.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: () (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node15.detachChildren();
        boolean boolean17 = node15.isOnlyModifiesThisCall();
        int int19 = node15.getIntProp((int) 'a');
        boolean boolean20 = node9.isEquivalentTo(node15);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean25 = node24.isUnscopedQualifiedName();
        int int26 = node24.getChildCount();
        java.util.Set<java.lang.String> strSet27 = node24.getDirectives();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node31.detachChildren();
        boolean boolean33 = node31.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node37.detachChildren();
        boolean boolean39 = node37.isOnlyModifiesThisCall();
        int int41 = node37.getIntProp((int) 'a');
        boolean boolean42 = node31.isEquivalentTo(node37);
        com.google.javascript.rhino.Node node43 = node24.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean48 = node47.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node49 = node24.copyInformationFromForTree(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean54 = node53.isUnscopedQualifiedName();
        int int55 = node53.getChildCount();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean60 = node59.isUnscopedQualifiedName();
        int int61 = node59.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType62 = node59.getJSType();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(26, node15, node24, node53, node59, (int) (short) 0, (int) '4');
        try {
            com.google.javascript.rhino.Node node66 = node3.removeChildAfter(node53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(strSet27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNull(jSType62);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        node5.detachChildren();
        java.lang.String[] strArray10 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        node5.setDirectives((java.util.Set<java.lang.String>) strSet11);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(110, node5, 20, (int) (byte) -1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup17;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup22;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup22;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard26 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup22, checkLevel25);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat28 = diagnosticType27.format;
        java.lang.String[] strArray29 = null;
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel25, diagnosticType27, strArray29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = jSError30.getType();
        boolean boolean32 = diagnosticGroup17.matches(jSError30);
        java.lang.Object obj33 = null;
        try {
            java.lang.String str34 = com.google.javascript.rhino.ScriptRuntime.getMessage3("TypeError: ", (java.lang.Object) node5, (java.lang.Object) jSError30, obj33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError: ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(messageFormat28);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        node10.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup19;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup19;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard23 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup19, checkLevel22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat28 = diagnosticType27.format;
        java.lang.String[] strArray34 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType27, strArray34);
        java.lang.String[] strArray36 = null;
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node10, checkLevel22, diagnosticType27, strArray36);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component");
        com.google.javascript.jscomp.CheckLevel checkLevel41 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType40.level = checkLevel41;
        diagnosticType27.level = checkLevel41;
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(messageFormat28);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!");
        try {
            java.io.Reader reader2 = jSSourceFile1.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        try {
            java.lang.String str5 = compilerInput3.getLine(16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        node4.addChildToBack(node11);
        java.lang.Object obj18 = node11.getProp(2);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node11 };
        try {
            com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(4, nodeArray19, 4, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup6;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat12 = diagnosticType11.format;
        java.lang.String[] strArray13 = null;
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel9, diagnosticType11, strArray13);
        loggerErrorManager1.report(checkLevel2, jSError14);
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = loggerErrorManager1.getErrors();
        int int17 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(messageFormat12);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup3;
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(errorReporter5);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        node3.setVarArgs(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("()", "TypeError: ");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Scope scope2 = compiler0.getTopScope();
        compiler0.disableThreads();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = null;
        try {
            compiler0.initOptions(compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(scope2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean21 = node20.isUnscopedQualifiedName();
        int int22 = node20.getChildCount();
        java.util.Set<java.lang.String> strSet23 = node20.getDirectives();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node27.detachChildren();
        boolean boolean29 = node27.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node33.detachChildren();
        boolean boolean35 = node33.isOnlyModifiesThisCall();
        int int37 = node33.getIntProp((int) 'a');
        boolean boolean38 = node27.isEquivalentTo(node33);
        com.google.javascript.rhino.Node node39 = node20.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean44 = node43.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node45 = node20.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean50 = node49.isUnscopedQualifiedName();
        int int51 = node49.getChildCount();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean56 = node55.isUnscopedQualifiedName();
        int int57 = node55.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType58 = node55.getJSType();
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(26, node11, node20, node49, node55, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node62 = node55.getFirstChild();
        try {
            com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) 'a', node62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(strSet23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNull(node62);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat4 = diagnosticType3.format;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType3, strArray10);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        boolean boolean13 = jSError11.equals((java.lang.Object) propertyRenamingPolicy12);
        int int14 = jSError11.getCharno();
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(messageFormat4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy12.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3, composeWarningsGuard7, composeWarningsGuard11, composeWarningsGuard15 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray16);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup18;
//        boolean boolean20 = composeWarningsGuard17.disables(diagnosticGroup18);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
//        boolean boolean22 = composeWarningsGuard17.disables(diagnosticGroup21);
//        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup21;
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup21;
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray16);
//        org.junit.Assert.assertNotNull(diagnosticGroup18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        java.util.Locale locale5 = context1.getLocale();
//        context1.addActivationName("");
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNotNull(locale5);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("@IMPLEMENTATION.VERSION@");
        boolean boolean4 = closureCodingConvention0.isOptionalParameter(node3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType5, functionType6, objectType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(130);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode2 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
//        context1.putThreadLocal((java.lang.Object) tracerMode2, (java.lang.Object) ' ');
//        java.lang.Object obj5 = null;
//        try {
//            context1.unseal(obj5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + tracerMode2 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode2.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup2;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel5);
        java.lang.String str7 = diagnosticGroupWarningsGuard6.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean9 = diagnosticGroupWarningsGuard6.disables(diagnosticGroup8);
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray10 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup("JSC_OPTIMIZE_LOOP_ERROR", diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup("error reporter", diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray10);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(diagnosticGroupArray10);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
//        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4, false);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] {};
//        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = null;
//        try {
//            com.google.javascript.jscomp.Result result12 = compiler4.compile(jSSourceFileArray9, jSSourceFileArray10, compilerOptions11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertNotNull(messageFormatter3);
//        org.junit.Assert.assertNull(node5);
//        org.junit.Assert.assertNotNull(errorManager6);
//        org.junit.Assert.assertNotNull(messageFormatter8);
//        org.junit.Assert.assertNotNull(jSSourceFileArray9);
//        org.junit.Assert.assertNotNull(jSSourceFileArray10);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.rhino.Context context7 = null;
        com.google.javascript.rhino.Context context8 = com.google.javascript.rhino.Context.enter(context7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        java.lang.Object obj11 = context8.getThreadLocal((java.lang.Object) loggerErrorManager10);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNotNull(context8);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) 'a');
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Object obj2 = null;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray3 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray3);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat9 = diagnosticType8.format;
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType8, strArray15);
        int int17 = jSError16.getCharno();
        boolean boolean18 = diagnosticGroup4.matches(jSError16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean23 = node22.isUnscopedQualifiedName();
        int int24 = node22.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType25 = node22.getJSType();
        com.google.javascript.rhino.Node node26 = node22.getLastSibling();
        try {
            java.lang.String str27 = com.google.javascript.rhino.ScriptRuntime.getMessage4("null(ERROR)", (java.lang.Object) "hi!", obj2, (java.lang.Object) boolean18, (java.lang.Object) node26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property null(ERROR)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticTypeArray3);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(messageFormat9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        int int13 = node9.getIntProp((int) 'a');
        boolean boolean14 = node3.isEquivalentTo(node9);
        java.lang.String str18 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node19 = node3.cloneTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "STRING " + "'", str18.equals("STRING "));
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder5 = null;
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean11 = node10.isUnscopedQualifiedName();
        int int12 = node10.getChildCount();
        java.util.Set<java.lang.String> strSet13 = node10.getDirectives();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node23.detachChildren();
        boolean boolean25 = node23.isOnlyModifiesThisCall();
        int int27 = node23.getIntProp((int) 'a');
        boolean boolean28 = node17.isEquivalentTo(node23);
        com.google.javascript.rhino.Node node29 = node10.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean34 = node33.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node35 = node10.copyInformationFromForTree(node33);
        int int36 = node10.getType();
        com.google.javascript.rhino.Node node37 = node10.getLastSibling();
        try {
            compiler0.toSource(codeBuilder5, (int) 'a', node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(strSet13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 40 + "'", int36 == 40);
        org.junit.Assert.assertNotNull(node37);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.removeActivationName("hi!");
//        int int4 = context1.getLanguageVersion();
//        context1.setGeneratingSource(true);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("TypeError", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = null;
        defaultCodingConvention0.applySingletonGetter(functionType15, functionType16, objectType17);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        int int7 = node3.getIntProp((int) 'a');
        boolean boolean8 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags9 = null;
        try {
            node3.setSideEffectFlags(sideEffectFlags9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType10, strArray17);
        boolean boolean19 = diagnosticGroup5.matches(jSError18);
        boolean boolean20 = diagnosticGroupWarningsGuard4.disables(diagnosticGroup5);
        java.lang.String str21 = diagnosticGroupWarningsGuard4.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        int int29 = node3.getType();
        com.google.javascript.rhino.Node node30 = node3.cloneNode();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 40 + "'", int29 == 40);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 39, 14);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean10 = node9.isUnscopedQualifiedName();
        int int11 = node9.getChildCount();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node15.detachChildren();
        boolean boolean17 = node15.hasMoreThanOneChild();
        boolean boolean18 = node9.isEquivalentToTyped(node15);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node23.detachChildren();
        boolean boolean25 = node23.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node29.detachChildren();
        boolean boolean31 = node29.isOnlyModifiesThisCall();
        int int33 = node29.getIntProp((int) 'a');
        boolean boolean34 = node23.isEquivalentTo(node29);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean39 = node38.isUnscopedQualifiedName();
        int int40 = node38.getChildCount();
        java.util.Set<java.lang.String> strSet41 = node38.getDirectives();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node45.detachChildren();
        boolean boolean47 = node45.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node51.detachChildren();
        boolean boolean53 = node51.isOnlyModifiesThisCall();
        int int55 = node51.getIntProp((int) 'a');
        boolean boolean56 = node45.isEquivalentTo(node51);
        com.google.javascript.rhino.Node node57 = node38.copyInformationFromForTree(node51);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean62 = node61.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node63 = node38.copyInformationFromForTree(node61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean68 = node67.isUnscopedQualifiedName();
        int int69 = node67.getChildCount();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean74 = node73.isUnscopedQualifiedName();
        int int75 = node73.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType76 = node73.getJSType();
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(26, node29, node38, node67, node73, (int) (short) 0, (int) '4');
        boolean boolean80 = node79.wasEmptyNode();
        boolean boolean81 = node79.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node(0, node5, node15, node79, 5, (int) (byte) 10);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags85 = null;
        try {
            node5.setSideEffectFlags(sideEffectFlags85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(strSet41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        java.lang.String str6 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray5 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6, objectTypeArray5);
        defaultCodingConvention2.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList6);
        java.lang.String str9 = defaultCodingConvention2.getGlobalObject();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean13 = defaultCodingConvention10.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention10, "language version", (int) (short) -1, (int) (byte) 0);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection18 = defaultCodingConvention10.getAssertionFunctions();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean23 = node22.isUnscopedQualifiedName();
        int int24 = node22.getChildCount();
        node22.putProp((int) (byte) 10, (java.lang.Object) 150);
        node22.putBooleanProp(10, false);
        try {
            java.lang.String str31 = com.google.javascript.rhino.ScriptRuntime.getMessage4("Not declared as a type name", (java.lang.Object) 38, (java.lang.Object) str9, (java.lang.Object) defaultCodingConvention10, (java.lang.Object) node22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a type name");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "window" + "'", str9.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup3;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat9 = diagnosticType8.format;
        java.lang.String[] strArray10 = null;
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel6, diagnosticType8, strArray10);
        java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) diagnosticType8);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node23.detachChildren();
        boolean boolean25 = node23.isOnlyModifiesThisCall();
        int int27 = node23.getIntProp((int) 'a');
        boolean boolean28 = node17.isEquivalentTo(node23);
        node23.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup32 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup32;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup32;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup32, checkLevel35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat41 = diagnosticType40.format;
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType40, strArray47);
        java.lang.String[] strArray49 = null;
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node23, checkLevel35, diagnosticType40, strArray49);
        diagnosticType8.level = checkLevel35;
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(messageFormat9);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str12.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup32);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(messageFormat41);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError50);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component");
        com.google.javascript.jscomp.CheckLevel checkLevel14 = diagnosticType13.level;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard15 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node20.detachChildren();
        boolean boolean22 = node20.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        int int30 = node26.getIntProp((int) 'a');
        boolean boolean31 = node20.isEquivalentTo(node26);
        node26.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup35 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup35;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup35;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard39 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup35, checkLevel38);
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat44 = diagnosticType43.format;
        java.lang.String[] strArray50 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType43, strArray50);
        java.lang.String[] strArray52 = null;
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node26, checkLevel38, diagnosticType43, strArray52);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean62 = node61.isUnscopedQualifiedName();
        int int63 = node61.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType64 = node61.getJSType();
        com.google.javascript.rhino.Node node65 = node61.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel66 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat68 = diagnosticType67.format;
        java.lang.String[] strArray75 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("error reporter", node61, checkLevel66, diagnosticType67, strArray75);
        com.google.javascript.jscomp.DiagnosticType diagnosticType82 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType86 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat87 = diagnosticType86.format;
        java.lang.String[] strArray93 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError94 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType86, strArray93);
        com.google.javascript.jscomp.JSError jSError95 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType82, strArray93);
        com.google.javascript.jscomp.JSError jSError96 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType67, strArray93);
        com.google.javascript.jscomp.JSError jSError97 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 130, 0, checkLevel14, diagnosticType43, strArray93);
        try {
            com.google.javascript.jscomp.JSError jSError98 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType6, strArray93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup35);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(messageFormat44);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + checkLevel66 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel66.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(messageFormat68);
        org.junit.Assert.assertNotNull(strArray75);
        org.junit.Assert.assertNotNull(jSError76);
        org.junit.Assert.assertNotNull(diagnosticType82);
        org.junit.Assert.assertNotNull(diagnosticType86);
        org.junit.Assert.assertNotNull(messageFormat87);
        org.junit.Assert.assertNotNull(strArray93);
        org.junit.Assert.assertNotNull(jSError94);
        org.junit.Assert.assertNotNull(jSError95);
        org.junit.Assert.assertNotNull(jSError96);
        org.junit.Assert.assertNotNull(jSError97);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
//        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
//        int int3 = compiler0.getErrorCount();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
//        com.google.javascript.jscomp.Region region12 = jSSourceFile9.getRegion(31);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
//        com.google.javascript.jscomp.Region region18 = jSSourceFile15.getRegion(31);
//        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node20 = compiler19.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap21 = compiler19.getSourceMap();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.rhino.Node node25 = compiler19.parse(jSSourceFile24);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile9, jSSourceFile15, jSSourceFile24, jSSourceFile28 };
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
//        jSSourceFile34.clearCachedSource();
//        jSSourceFile34.clearCachedSource();
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
//        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
//        jSSourceFile43.clearCachedSource();
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31, jSSourceFile34, jSSourceFile39, jSSourceFile43 };
//        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = null;
//        try {
//            compiler0.init(jSSourceFileArray29, jSSourceFileArray45, compilerOptions46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(node1);
//        org.junit.Assert.assertNotNull(errorManager2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//        org.junit.Assert.assertNotNull(jSSourceFile9);
//        org.junit.Assert.assertNull(region12);
//        org.junit.Assert.assertNotNull(jSSourceFile15);
//        org.junit.Assert.assertNull(region18);
//        org.junit.Assert.assertNull(node20);
//        org.junit.Assert.assertNull(sourceMap21);
//        org.junit.Assert.assertNotNull(jSSourceFile24);
//        org.junit.Assert.assertNotNull(node25);
//        org.junit.Assert.assertNotNull(jSSourceFile28);
//        org.junit.Assert.assertNotNull(jSSourceFileArray29);
//        org.junit.Assert.assertNotNull(jSSourceFile31);
//        org.junit.Assert.assertNotNull(jSSourceFile34);
//        org.junit.Assert.assertNotNull(jSSourceFile39);
//        org.junit.Assert.assertNotNull(jSSourceFile43);
//        org.junit.Assert.assertNotNull(jSSourceFileArray45);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        java.util.logging.Logger logger7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.parsing.ParserRunner.parse("language version", "hi!", config5, errorReporter6, logger7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        node5.putProp((int) (byte) 10, (java.lang.Object) 150);
        node5.putBooleanProp(10, false);
        boolean boolean14 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean19 = node18.isUnscopedQualifiedName();
        int int20 = node18.getChildCount();
        java.util.Set<java.lang.String> strSet21 = node18.getDirectives();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node25.detachChildren();
        boolean boolean27 = node25.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node31.detachChildren();
        boolean boolean33 = node31.isOnlyModifiesThisCall();
        int int35 = node31.getIntProp((int) 'a');
        boolean boolean36 = node25.isEquivalentTo(node31);
        com.google.javascript.rhino.Node node37 = node18.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean42 = node41.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node43 = node18.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node47.detachChildren();
        boolean boolean49 = node47.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable50 = node47.siblings();
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node5, node41, node47 };
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, nodeArray51, 0, 18);
        try {
            com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(150, nodeArray51, (int) (short) 1, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(strSet21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(nodeIterable50);
        org.junit.Assert.assertNotNull(nodeArray51);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        boolean boolean17 = closureCodingConvention0.isVarArgsParameter(node5);
        com.google.javascript.rhino.Node node18 = node5.getParent();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean24 = node23.isUnscopedQualifiedName();
        node23.detachChildren();
        java.lang.String[] strArray28 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet29 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet29, strArray28);
        node23.setDirectives((java.util.Set<java.lang.String>) strSet29);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node23, 20, (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean39 = node38.isUnscopedQualifiedName();
        int int40 = node38.getChildCount();
        java.util.Set<java.lang.String> strSet41 = node38.getDirectives();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node45.detachChildren();
        boolean boolean47 = node45.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node51.detachChildren();
        boolean boolean53 = node51.isOnlyModifiesThisCall();
        int int55 = node51.getIntProp((int) 'a');
        boolean boolean56 = node45.isEquivalentTo(node51);
        com.google.javascript.rhino.Node node57 = node38.copyInformationFromForTree(node51);
        node51.setIsSyntheticBlock(true);
        node51.setOptionalArg(false);
        node23.addChildToFront(node51);
        java.lang.Class<?> wildcardClass63 = node51.getClass();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean68 = node67.isUnscopedQualifiedName();
        int int69 = node67.getChildCount();
        java.util.Set<java.lang.String> strSet70 = node67.getDirectives();
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node74.detachChildren();
        boolean boolean76 = node74.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node80.detachChildren();
        boolean boolean82 = node80.isOnlyModifiesThisCall();
        int int84 = node80.getIntProp((int) 'a');
        boolean boolean85 = node74.isEquivalentTo(node80);
        com.google.javascript.rhino.Node node86 = node67.copyInformationFromForTree(node80);
        try {
            node18.addChildAfter(node51, node80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(strSet41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNull(strSet70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(node86);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("language version", "hi!", 23);
        ecmaError1.addSuppressed((java.lang.Throwable) evaluatorException5);
        ecmaError1.initLineSource("null(ERROR)");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
//        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
//        boolean boolean5 = compilerInput3.isExtern();
//        java.lang.String str6 = compilerInput3.getName();
//        com.google.javascript.jscomp.JSModule jSModule7 = null;
//        compilerInput3.setModule(jSModule7);
//        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput3.getModule();
//        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
//        com.google.javascript.rhino.Node node11 = compiler10.getRoot();
//        com.google.javascript.jscomp.SourceMap sourceMap12 = compiler10.getSourceMap();
//        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler10.getErrorManager();
//        compilerInput3.setErrorManager(errorManager13);
//        org.junit.Assert.assertNull(jSModule4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
//        org.junit.Assert.assertNull(jSModule9);
//        org.junit.Assert.assertNull(node11);
//        org.junit.Assert.assertNull(sourceMap12);
//        org.junit.Assert.assertNotNull(errorManager13);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node2 = null;
        java.lang.String str3 = defaultCodingConvention0.getSingletonGetterClassName(node2);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("()");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(())" + "'", str1.equals("(())"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention8 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str9 = closureCodingConvention8.getAbstractMethodName();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node13.detachChildren();
        boolean boolean15 = node13.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node19.detachChildren();
        boolean boolean21 = node19.isOnlyModifiesThisCall();
        int int23 = node19.getIntProp((int) 'a');
        boolean boolean24 = node13.isEquivalentTo(node19);
        boolean boolean25 = closureCodingConvention8.isVarArgsParameter(node13);
        com.google.javascript.rhino.Node node26 = node13.getParent();
        node7.addChildToFront(node13);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.abstractMethod" + "'", str9.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(node26);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
//        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator2);
//        java.lang.String str4 = sourceFile3.getName();
//        sourceFile3.setOriginalPath("Named type with empty name component");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup10;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup10;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup10;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray14 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8, diagnosticGroup10 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup("Not declared as a constructor", diagnosticGroupArray14);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray14);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup17;
//        com.google.javascript.rhino.Context context19 = null;
//        com.google.javascript.rhino.Context context20 = com.google.javascript.rhino.Context.enter(context19);
//        context20.removeActivationName("hi!");
//        int int23 = context20.getLanguageVersion();
//        boolean boolean24 = context20.isGeneratingSource();
//        try {
//            java.lang.String str25 = com.google.javascript.rhino.ScriptRuntime.getMessage4("language version", (java.lang.Object) sourceFile3, (java.lang.Object) diagnosticGroup16, (java.lang.Object) diagnosticGroup17, (java.lang.Object) context20);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(sourceFile3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertNotNull(diagnosticGroup10);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray14);
//        org.junit.Assert.assertNotNull(diagnosticGroup17);
//        org.junit.Assert.assertNotNull(context20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("STRING  [empty_block: 1]\n", "", "", "language version");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property STRING  [empty_block: 1]\n");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean16 = node15.isUnscopedQualifiedName();
        int int17 = node15.getChildCount();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node21.detachChildren();
        boolean boolean23 = node21.hasMoreThanOneChild();
        boolean boolean24 = node15.isEquivalentToTyped(node21);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node29.detachChildren();
        boolean boolean31 = node29.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node35.detachChildren();
        boolean boolean37 = node35.isOnlyModifiesThisCall();
        int int39 = node35.getIntProp((int) 'a');
        boolean boolean40 = node29.isEquivalentTo(node35);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean45 = node44.isUnscopedQualifiedName();
        int int46 = node44.getChildCount();
        java.util.Set<java.lang.String> strSet47 = node44.getDirectives();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node51.detachChildren();
        boolean boolean53 = node51.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node57.detachChildren();
        boolean boolean59 = node57.isOnlyModifiesThisCall();
        int int61 = node57.getIntProp((int) 'a');
        boolean boolean62 = node51.isEquivalentTo(node57);
        com.google.javascript.rhino.Node node63 = node44.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean68 = node67.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node69 = node44.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean74 = node73.isUnscopedQualifiedName();
        int int75 = node73.getChildCount();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean80 = node79.isUnscopedQualifiedName();
        int int81 = node79.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType82 = node79.getJSType();
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(26, node35, node44, node73, node79, (int) (short) 0, (int) '4');
        boolean boolean86 = node85.wasEmptyNode();
        boolean boolean87 = node85.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node(0, node11, node21, node85, 5, (int) (byte) 10);
        try {
            node3.addChildrenToFront(node85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNull(strSet47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 49, 40);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 40.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        boolean boolean61 = node60.wasEmptyNode();
        node60.setWasEmptyNode(false);
        boolean boolean64 = node60.isNoSideEffectsCall();
        com.google.javascript.jscomp.Compiler compiler65 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node66 = compiler65.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap67 = compiler65.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile70 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node71 = compiler65.parse(jSSourceFile70);
        try {
            com.google.javascript.rhino.Node node72 = node60.getChildBefore(node71);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(node66);
        org.junit.Assert.assertNull(sourceMap67);
        org.junit.Assert.assertNotNull(jSSourceFile70);
        org.junit.Assert.assertNotNull(node71);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node3.getJsDocBuilderForNode();
        try {
            double double8 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING  is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node4 = null;
        java.lang.String str5 = defaultCodingConvention0.identifyTypeDefAssign(node4);
        java.lang.String str6 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean12 = node11.isUnscopedQualifiedName();
        int int13 = node11.getChildCount();
        node11.putProp((int) (byte) 10, (java.lang.Object) 150);
        node11.putBooleanProp(10, false);
        boolean boolean20 = node11.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = defaultCodingConvention7.getDelegateRelationship(node11);
        boolean boolean22 = defaultCodingConvention0.isPropertyTestFunction(node11);
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) defaultCodingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(runtimeException23);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray7 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup3 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup("Not declared as a constructor", diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray7);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroupArray7);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(17);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ge" + "'", str1.equals("ge"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        java.lang.String str61 = node19.getQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNull(str61);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("<No stack trace available>");
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "hi!", 9, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("error reporter", "language version");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        java.lang.String str9 = jSSourceFile7.getName();
        try {
            jsAst4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str9.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        int int33 = node31.getChildCount();
        java.util.Set<java.lang.String> strSet34 = node31.getDirectives();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node38.detachChildren();
        boolean boolean40 = node38.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node44.detachChildren();
        boolean boolean46 = node44.isOnlyModifiesThisCall();
        int int48 = node44.getIntProp((int) 'a');
        boolean boolean49 = node38.isEquivalentTo(node44);
        com.google.javascript.rhino.Node node50 = node31.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        node54.putProp((int) (byte) 10, (java.lang.Object) 150);
        node54.putBooleanProp(10, false);
        boolean boolean63 = node54.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) ' ', node27, node44, node54);
        boolean boolean65 = node3.hasChild(node44);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean71 = node70.isUnscopedQualifiedName();
        int int72 = node70.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType73 = node70.getJSType();
        com.google.javascript.rhino.Node node74 = node70.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel75 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat77 = diagnosticType76.format;
        java.lang.String[] strArray84 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError85 = com.google.javascript.jscomp.JSError.make("error reporter", node70, checkLevel75, diagnosticType76, strArray84);
        com.google.javascript.rhino.Node node87 = node70.getAncestor(45);
        try {
            com.google.javascript.rhino.Node node88 = node3.clonePropsFrom(node87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(strSet34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNull(jSType73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType76);
        org.junit.Assert.assertNotNull(messageFormat77);
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertNotNull(jSError85);
        org.junit.Assert.assertNull(node87);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, false);
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput5.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Object obj1 = null;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("DiagnosticGroup<checkTypes>(WARNING)", obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<checkTypes>(WARNING)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("TypeError");
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node5.detachChildren();
        boolean boolean7 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node11.detachChildren();
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        int int15 = node11.getIntProp((int) 'a');
        boolean boolean16 = node5.isEquivalentTo(node11);
        boolean boolean17 = closureCodingConvention0.isVarArgsParameter(node5);
        com.google.javascript.rhino.Node node18 = node5.getParent();
        try {
            java.lang.String str19 = node18.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(node18);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3, composeWarningsGuard7, composeWarningsGuard11, composeWarningsGuard15 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray16);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup18;
        boolean boolean20 = composeWarningsGuard17.disables(diagnosticGroup18);
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup18;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertNotNull(diagnosticGroup18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        java.lang.String str6 = compilerInput3.getName();
        com.google.javascript.rhino.Context context7 = null;
        com.google.javascript.rhino.Context context8 = com.google.javascript.rhino.Context.enter(context7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        java.lang.Object obj11 = context8.getThreadLocal((java.lang.Object) loggerErrorManager10);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.JSModule jSModule13 = compilerInput3.getModule();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<tweakValidation>(WARNING)" + "'", str6.equals("DiagnosticGroup<tweakValidation>(WARNING)"));
        org.junit.Assert.assertNotNull(context8);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(jSModule13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType10 = node7.getJSType();
        com.google.javascript.rhino.Node node11 = node7.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat14 = diagnosticType13.format;
        java.lang.String[] strArray21 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("error reporter", node7, checkLevel12, diagnosticType13, strArray21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat33 = diagnosticType32.format;
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType32, strArray39);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType28, strArray39);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType13, strArray39);
        java.text.MessageFormat messageFormat43 = diagnosticType13.format;
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(messageFormat14);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(messageFormat33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(messageFormat43);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        java.lang.RuntimeException runtimeException3 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compiler0, (java.lang.Object) 7);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        java.util.Set<java.lang.String> strSet10 = node7.getDirectives();
        node7.removeProp(29);
        com.google.javascript.rhino.Node node13 = node7.removeChildren();
        com.google.javascript.jscomp.NodeTraversal.Callback callback14 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node7, callback14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(runtimeException3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(strSet10);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray1 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray1);
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup2;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean7 = defaultCodingConvention4.isExported("Named type with empty name component", true);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 19, (java.lang.Object) diagnosticGroup2, (java.lang.Object) boolean7);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup2;
        org.junit.Assert.assertNotNull(diagnosticTypeArray1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType2, functionType3, objectType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup5;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard9 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel8);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat11 = diagnosticType10.format;
        java.lang.String[] strArray12 = null;
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel8, diagnosticType10, strArray12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = jSError13.getType();
        boolean boolean15 = diagnosticGroup0.matches(jSError13);
        java.lang.String str16 = jSError13.description;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Exceeded max number of optimization iterations: {0}" + "'", str16.equals("Exceeded max number of optimization iterations: {0}"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.jscomp.Scope scope2 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray3 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList4, objectTypeArray3);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, scope2, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList4);
        java.lang.String str7 = defaultCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType10 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType8, functionType9, subclassType10);
        boolean boolean13 = defaultCodingConvention0.isConstantKey("eq");
        org.junit.Assert.assertNotNull(objectTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "window" + "'", str7.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType10 = node7.getJSType();
        com.google.javascript.rhino.Node node11 = node7.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat14 = diagnosticType13.format;
        java.lang.String[] strArray21 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("error reporter", node7, checkLevel12, diagnosticType13, strArray21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat33 = diagnosticType32.format;
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType32, strArray39);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType28, strArray39);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType13, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = diagnosticType13.level;
        java.lang.String str44 = diagnosticType13.toString();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(messageFormat14);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(messageFormat33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        node3.putBooleanProp(36, false);
        com.google.javascript.rhino.Node node8 = node3.getLastChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node15 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean21 = node20.isUnscopedQualifiedName();
        node20.detachChildren();
        java.lang.String[] strArray25 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet26 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet26, strArray25);
        node20.setDirectives((java.util.Set<java.lang.String>) strSet26);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(110, node20, 20, (int) (byte) -1);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean36 = node35.isUnscopedQualifiedName();
        int int37 = node35.getChildCount();
        java.util.Set<java.lang.String> strSet38 = node35.getDirectives();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node42.detachChildren();
        boolean boolean44 = node42.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node48.detachChildren();
        boolean boolean50 = node48.isOnlyModifiesThisCall();
        int int52 = node48.getIntProp((int) 'a');
        boolean boolean53 = node42.isEquivalentTo(node48);
        com.google.javascript.rhino.Node node54 = node35.copyInformationFromForTree(node48);
        node48.setIsSyntheticBlock(true);
        node48.setOptionalArg(false);
        node20.addChildToFront(node48);
        try {
            java.lang.String str60 = defaultCodingConvention0.extractClassNameIfProvide(node15, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(node54);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup2;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel5);
        java.lang.String str7 = diagnosticGroupWarningsGuard6.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        boolean boolean9 = diagnosticGroupWarningsGuard6.disables(diagnosticGroup8);
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray10 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup("JSC_OPTIMIZE_LOOP_ERROR", diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup("error reporter", diagnosticGroupArray10);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup12;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup12;
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(diagnosticGroupArray10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node61 = node10.getFirstChild();
        try {
            node61.setLineno(8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNull(node61);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        boolean boolean61 = node60.wasEmptyNode();
        node60.setWasEmptyNode(false);
        boolean boolean64 = node60.isNoSideEffectsCall();
        boolean boolean66 = node60.getBooleanProp(33);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType10 = node7.getJSType();
        com.google.javascript.rhino.Node node11 = node7.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat14 = diagnosticType13.format;
        java.lang.String[] strArray21 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("error reporter", node7, checkLevel12, diagnosticType13, strArray21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat33 = diagnosticType32.format;
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType32, strArray39);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType28, strArray39);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType13, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = diagnosticType13.level;
        java.lang.String str44 = diagnosticType13.key;
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(messageFormat14);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(messageFormat33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("language version", "goog.abstractMethod");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        int int13 = node9.getIntProp((int) 'a');
        boolean boolean14 = node3.isEquivalentTo(node9);
        node9.putIntProp(41, 4095);
        node9.setOptionalArg(true);
        try {
            double double20 = node9.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("error reporter");
        evaluatorException1.initColumnNumber(19);
        try {
            evaluatorException1.initLineNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.hasMoreThanOneChild();
        boolean boolean12 = node3.isEquivalentToTyped(node9);
        boolean boolean13 = node3.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        node10.putIntProp(41, 4095);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup19;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup19;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard23 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup19, checkLevel22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat28 = diagnosticType27.format;
        java.lang.String[] strArray34 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType27, strArray34);
        java.lang.String[] strArray36 = null;
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", node10, checkLevel22, diagnosticType27, strArray36);
        int int38 = node10.getChildCount();
        com.google.javascript.rhino.Node node39 = node10.getParent();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(messageFormat28);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(node39);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean8 = node7.isUnscopedQualifiedName();
        int int9 = node7.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType10 = node7.getJSType();
        com.google.javascript.rhino.Node node11 = node7.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat14 = diagnosticType13.format;
        java.lang.String[] strArray21 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("error reporter", node7, checkLevel12, diagnosticType13, strArray21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat33 = diagnosticType32.format;
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType32, strArray39);
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType28, strArray39);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType13, strArray39);
        com.google.javascript.jscomp.CheckLevel checkLevel43 = diagnosticType13.level;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = diagnosticType13.defaultLevel;
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(messageFormat14);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(messageFormat33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean27 = node26.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFromForTree(node26);
        int int29 = node3.getType();
        com.google.javascript.rhino.Node node30 = node3.getLastSibling();
        boolean boolean32 = node30.getBooleanProp(47);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 40 + "'", int29 == 40);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean65 = node64.isUnscopedQualifiedName();
        int int66 = node64.getChildCount();
        java.util.Set<java.lang.String> strSet67 = node64.getDirectives();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node71.detachChildren();
        boolean boolean73 = node71.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node77.detachChildren();
        boolean boolean79 = node77.isOnlyModifiesThisCall();
        int int81 = node77.getIntProp((int) 'a');
        boolean boolean82 = node71.isEquivalentTo(node77);
        com.google.javascript.rhino.Node node83 = node64.copyInformationFromForTree(node77);
        boolean boolean84 = node10.isEquivalentTo(node83);
        com.google.javascript.rhino.Node node85 = node10.detachFromParent();
        com.google.javascript.rhino.Node node89 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean90 = node89.isUnscopedQualifiedName();
        node89.detachChildren();
        java.lang.String[] strArray94 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet95 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean96 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet95, strArray94);
        node89.setDirectives((java.util.Set<java.lang.String>) strSet95);
        node10.setDirectives((java.util.Set<java.lang.String>) strSet95);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNull(strSet67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(strArray94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node4 = null;
        java.lang.String str5 = defaultCodingConvention0.identifyTypeDefAssign(node4);
        java.lang.String str6 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean12 = node11.isUnscopedQualifiedName();
        int int13 = node11.getChildCount();
        node11.putProp((int) (byte) 10, (java.lang.Object) 150);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast17 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal7, node11);
        boolean boolean18 = node11.hasOneChild();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean23 = node22.isUnscopedQualifiedName();
        int int24 = node22.getChildCount();
        java.util.Set<java.lang.String> strSet25 = node22.getDirectives();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node29.detachChildren();
        boolean boolean31 = node29.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node35.detachChildren();
        boolean boolean37 = node35.isOnlyModifiesThisCall();
        int int39 = node35.getIntProp((int) 'a');
        boolean boolean40 = node29.isEquivalentTo(node35);
        com.google.javascript.rhino.Node node41 = node22.copyInformationFromForTree(node35);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean46 = node45.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node47 = node22.copyInformationFromForTree(node45);
        int int48 = node22.getType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean53 = node52.isUnscopedQualifiedName();
        int int54 = node52.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType55 = node52.getJSType();
        com.google.javascript.rhino.Node node56 = node22.copyInformationFromForTree(node52);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention57 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean60 = defaultCodingConvention57.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node61 = null;
        java.lang.String str62 = defaultCodingConvention57.identifyTypeDefAssign(node61);
        java.lang.String str63 = defaultCodingConvention57.getDelegateSuperclassName();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal64 = null;
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean69 = node68.isUnscopedQualifiedName();
        int int70 = node68.getChildCount();
        node68.putProp((int) (byte) 10, (java.lang.Object) 150);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast74 = defaultCodingConvention57.getObjectLiteralCast(nodeTraversal64, node68);
        try {
            node11.replaceChildAfter(node56, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(objectLiteralCast17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(strSet25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 40 + "'", int48 == 40);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNull(objectLiteralCast74);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node9.detachChildren();
        boolean boolean11 = node9.isOnlyModifiesThisCall();
        int int13 = node9.getIntProp((int) 'a');
        boolean boolean14 = node3.isEquivalentTo(node9);
        node3.putIntProp(0, (int) (byte) -1);
        java.lang.String str18 = node3.getQualifiedName();
        node3.setString("STRING ");
        java.util.Set<java.lang.String> strSet21 = null;
        node3.setDirectives(strSet21);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup6;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard10 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat12 = diagnosticType11.format;
        java.lang.String[] strArray13 = null;
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (byte) 100, 0, checkLevel9, diagnosticType11, strArray13);
        loggerErrorManager1.report(checkLevel2, jSError14);
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = loggerErrorManager1.getErrors();
        try {
            loggerErrorManager1.generateReport();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(messageFormat12);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSErrorArray16);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        node4.detachChildren();
        java.lang.String[] strArray9 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType20 = node17.getJSType();
        com.google.javascript.rhino.Node node21 = node17.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat24 = diagnosticType23.format;
        java.lang.String[] strArray31 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("error reporter", node17, checkLevel22, diagnosticType23, strArray31);
        com.google.javascript.rhino.Node node33 = null;
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node38.detachChildren();
        boolean boolean40 = node38.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node44.detachChildren();
        boolean boolean46 = node44.isOnlyModifiesThisCall();
        int int48 = node44.getIntProp((int) 'a');
        boolean boolean49 = node38.isEquivalentTo(node44);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean54 = node53.isUnscopedQualifiedName();
        int int55 = node53.getChildCount();
        java.util.Set<java.lang.String> strSet56 = node53.getDirectives();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node60.detachChildren();
        boolean boolean62 = node60.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node66.detachChildren();
        boolean boolean68 = node66.isOnlyModifiesThisCall();
        int int70 = node66.getIntProp((int) 'a');
        boolean boolean71 = node60.isEquivalentTo(node66);
        com.google.javascript.rhino.Node node72 = node53.copyInformationFromForTree(node66);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean77 = node76.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node78 = node53.copyInformationFromForTree(node76);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean83 = node82.isUnscopedQualifiedName();
        int int84 = node82.getChildCount();
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean89 = node88.isUnscopedQualifiedName();
        int int90 = node88.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType91 = node88.getJSType();
        com.google.javascript.rhino.Node node94 = new com.google.javascript.rhino.Node(26, node44, node53, node82, node88, (int) (short) 0, (int) '4');
        boolean boolean95 = node82.isOnlyModifiesThisCall();
        try {
            com.google.javascript.rhino.Node node98 = new com.google.javascript.rhino.Node(3, node4, node17, node33, node82, 100, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(messageFormat24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNull(strSet56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat6 = diagnosticType5.format;
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType5, strArray12);
        boolean boolean14 = diagnosticGroup0.matches(jSError13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType22 = node19.getJSType();
        com.google.javascript.rhino.Node node23 = node19.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat26 = diagnosticType25.format;
        java.lang.String[] strArray33 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("error reporter", node19, checkLevel24, diagnosticType25, strArray33);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = diagnosticType25.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard36 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel35);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(messageFormat6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(messageFormat26);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        node5.putProp((int) (byte) 10, (java.lang.Object) 150);
        node5.putBooleanProp(10, false);
        boolean boolean14 = node5.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean19 = node18.isUnscopedQualifiedName();
        int int20 = node18.getChildCount();
        java.util.Set<java.lang.String> strSet21 = node18.getDirectives();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node25.detachChildren();
        boolean boolean27 = node25.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node31.detachChildren();
        boolean boolean33 = node31.isOnlyModifiesThisCall();
        int int35 = node31.getIntProp((int) 'a');
        boolean boolean36 = node25.isEquivalentTo(node31);
        com.google.javascript.rhino.Node node37 = node18.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean42 = node41.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node43 = node18.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node47.detachChildren();
        boolean boolean49 = node47.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable50 = node47.siblings();
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node5, node41, node47 };
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, nodeArray51, 0, 18);
        try {
            com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(7, nodeArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(strSet21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(nodeIterable50);
        org.junit.Assert.assertNotNull(nodeArray51);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
//        boolean boolean6 = context1.isGeneratingSource();
//        long long7 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNull(errorReporter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        try {
//            com.google.javascript.rhino.Context.reportError("ge");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ge");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("eq");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eq" + "'", str1.equals("eq"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (int) (short) -1, (int) (byte) 0);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection8 = defaultCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        defaultCodingConvention0.applySingletonGetter(functionType9, functionType10, objectType11);
        boolean boolean14 = defaultCodingConvention0.isConstant("goog.abstractMethod");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        node3.setCharno(18);
        com.google.javascript.rhino.Node node7 = node3.getParent();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        int int62 = node54.getIntProp(8);
        java.lang.Object obj63 = null;
        java.lang.RuntimeException runtimeException64 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) int62, obj63);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(runtimeException64);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        java.util.Set<java.lang.String> strSet6 = node3.getDirectives();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node16.detachChildren();
        boolean boolean18 = node16.isOnlyModifiesThisCall();
        int int20 = node16.getIntProp((int) 'a');
        boolean boolean21 = node10.isEquivalentTo(node16);
        com.google.javascript.rhino.Node node22 = node3.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean32 = node31.isUnscopedQualifiedName();
        int int33 = node31.getChildCount();
        java.util.Set<java.lang.String> strSet34 = node31.getDirectives();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node38.detachChildren();
        boolean boolean40 = node38.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node44.detachChildren();
        boolean boolean46 = node44.isOnlyModifiesThisCall();
        int int48 = node44.getIntProp((int) 'a');
        boolean boolean49 = node38.isEquivalentTo(node44);
        com.google.javascript.rhino.Node node50 = node31.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        node54.putProp((int) (byte) 10, (java.lang.Object) 150);
        node54.putBooleanProp(10, false);
        boolean boolean63 = node54.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) ' ', node27, node44, node54);
        boolean boolean65 = node3.hasChild(node44);
        int int66 = node44.getChildCount();
        java.lang.String str70 = node44.toString(true, true, true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(strSet6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(strSet34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "STRING " + "'", str70.equals("STRING "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(4095);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 4095");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        java.text.MessageFormat messageFormat4 = diagnosticType3.format;
//        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
//        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType3, strArray10);
//        int int12 = jSError11.getCharno();
//        com.google.javascript.rhino.Context context13 = null;
//        com.google.javascript.rhino.Context context14 = com.google.javascript.rhino.Context.enter(context13);
//        context14.removeActivationName("Named type with empty name component");
//        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        node21.detachChildren();
//        boolean boolean23 = node21.isOnlyModifiesThisCall();
//        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        node27.detachChildren();
//        boolean boolean29 = node27.isOnlyModifiesThisCall();
//        int int31 = node27.getIntProp((int) 'a');
//        boolean boolean32 = node21.isEquivalentTo(node27);
//        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean37 = node36.isUnscopedQualifiedName();
//        int int38 = node36.getChildCount();
//        java.util.Set<java.lang.String> strSet39 = node36.getDirectives();
//        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        node43.detachChildren();
//        boolean boolean45 = node43.isOnlyModifiesThisCall();
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        node49.detachChildren();
//        boolean boolean51 = node49.isOnlyModifiesThisCall();
//        int int53 = node49.getIntProp((int) 'a');
//        boolean boolean54 = node43.isEquivalentTo(node49);
//        com.google.javascript.rhino.Node node55 = node36.copyInformationFromForTree(node49);
//        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean60 = node59.isUnscopedQualifiedName();
//        com.google.javascript.rhino.Node node61 = node36.copyInformationFromForTree(node59);
//        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean66 = node65.isUnscopedQualifiedName();
//        int int67 = node65.getChildCount();
//        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean72 = node71.isUnscopedQualifiedName();
//        int int73 = node71.getChildCount();
//        com.google.javascript.rhino.jstype.JSType jSType74 = node71.getJSType();
//        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node(26, node27, node36, node65, node71, (int) (short) 0, (int) '4');
//        com.google.javascript.rhino.Node node78 = node27.getFirstChild();
//        java.lang.RuntimeException runtimeException79 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) int12, (java.lang.Object) context14, (java.lang.Object) node78);
//        com.google.javascript.rhino.Context context80 = null;
//        com.google.javascript.rhino.Context context81 = com.google.javascript.rhino.Context.enter(context80);
//        java.util.logging.Logger logger82 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager83 = new com.google.javascript.jscomp.LoggerErrorManager(logger82);
//        java.lang.Object obj84 = context81.getThreadLocal((java.lang.Object) loggerErrorManager83);
//        java.util.Locale locale85 = context81.getLocale();
//        java.util.Locale locale86 = context14.setLocale(locale85);
//        org.junit.Assert.assertNotNull(diagnosticType3);
//        org.junit.Assert.assertNotNull(messageFormat4);
//        org.junit.Assert.assertNotNull(strArray10);
//        org.junit.Assert.assertNotNull(jSError11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(context14);
//        org.junit.Assert.assertNotNull(node21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(node27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(node36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNull(strSet39);
//        org.junit.Assert.assertNotNull(node43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(node55);
//        org.junit.Assert.assertNotNull(node59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(node61);
//        org.junit.Assert.assertNotNull(node65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertNotNull(node71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//        org.junit.Assert.assertNull(jSType74);
//        org.junit.Assert.assertNull(node78);
//        org.junit.Assert.assertNotNull(runtimeException79);
//        org.junit.Assert.assertNotNull(context81);
//        org.junit.Assert.assertNull(obj84);
//        org.junit.Assert.assertNotNull(locale85);
//        org.junit.Assert.assertNull(locale86);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        node3.putProp((int) (byte) 10, (java.lang.Object) 150);
        node3.putBooleanProp(10, false);
        int int12 = node3.getSourcePosition();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node2 = compiler1.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler1.getErrorManager();
        java.lang.String str4 = compiler1.toSource();
        boolean boolean5 = compiler1.acceptConstKeyword();
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) 19, (java.lang.Object) compiler1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(errorManager3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(runtimeException6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        node4.detachChildren();
        java.lang.String[] strArray9 = new java.lang.String[] { "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(110, node4, 20, (int) (byte) -1);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(nodeCollection16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        java.lang.String str3 = compiler0.toSource();
        boolean boolean4 = compiler0.acceptConstKeyword();
        try {
            compiler0.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean65 = node64.isUnscopedQualifiedName();
        int int66 = node64.getChildCount();
        java.util.Set<java.lang.String> strSet67 = node64.getDirectives();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node71.detachChildren();
        boolean boolean73 = node71.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node77.detachChildren();
        boolean boolean79 = node77.isOnlyModifiesThisCall();
        int int81 = node77.getIntProp((int) 'a');
        boolean boolean82 = node71.isEquivalentTo(node77);
        com.google.javascript.rhino.Node node83 = node64.copyInformationFromForTree(node77);
        boolean boolean84 = node10.isEquivalentTo(node83);
        com.google.javascript.rhino.Node node85 = null;
        try {
            com.google.javascript.rhino.Node node86 = node10.copyInformationFromForTree(node85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNull(strSet67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "DiagnosticGroup<tweakValidation>(WARNING)", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        boolean boolean5 = compilerInput3.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput3.getSourceAst();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(sourceAst6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Named type with empty name component", "STRING Named type with empty name component\n", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention0.getDelegateRelationship(node4);
        boolean boolean17 = defaultCodingConvention0.isExported("language version", false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean6 = node5.isUnscopedQualifiedName();
        int int7 = node5.getChildCount();
        java.util.Set<java.lang.String> strSet8 = node5.getDirectives();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node18.detachChildren();
        boolean boolean20 = node18.isOnlyModifiesThisCall();
        int int22 = node18.getIntProp((int) 'a');
        boolean boolean23 = node12.isEquivalentTo(node18);
        com.google.javascript.rhino.Node node24 = node5.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean29 = node28.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node28);
        int int31 = node5.getType();
        com.google.javascript.rhino.Node node32 = node5.getLastSibling();
        boolean boolean33 = node32.isLocalResultCall();
        boolean boolean34 = closureCodingConvention0.isVarArgsParameter(node32);
        java.lang.String str35 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 40 + "'", int31 == 40);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "goog.exportProperty" + "'", str35.equals("goog.exportProperty"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.Throwable[] throwableArray2 = ecmaError1.getSuppressed();
        java.lang.String str3 = ecmaError1.getLineSource();
        ecmaError1.initLineSource("DiagnosticGroup<checkTypes>(WARNING)");
        java.lang.String str6 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError: " + "'", str6.equals("TypeError: "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "null(ERROR)", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "language version", (-1), (int) (short) 1);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray2 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray2);
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup3;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean8 = defaultCodingConvention5.isExported("Named type with empty name component", true);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 19, (java.lang.Object) diagnosticGroup3, (java.lang.Object) boolean8);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType20 = node17.getJSType();
        com.google.javascript.rhino.Node node21 = node17.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat24 = diagnosticType23.format;
        java.lang.String[] strArray31 = new java.lang.String[] { "language version", "DiagnosticGroup<tweakValidation>(WARNING)", "()", "DiagnosticGroup<tweakValidation>(WARNING)", "Named type with empty name component", "JSC_OPTIMIZE_LOOP_ERROR" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("error reporter", node17, checkLevel22, diagnosticType23, strArray31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("()", "JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat43 = diagnosticType42.format;
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType42, strArray49);
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR", 15, (int) (short) 0, diagnosticType38, strArray49);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", 31, 140, diagnosticType23, strArray49);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = diagnosticType23.level;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard54 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel53);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.make("null(ERROR)", checkLevel53, "error reporter");
        org.junit.Assert.assertNotNull(diagnosticTypeArray2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(messageFormat24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(messageFormat43);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType56);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("window", "Named type with empty name component");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
//        boolean boolean5 = node4.isUnscopedQualifiedName();
//        int int6 = node4.getChildCount();
//        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
//        node4.putBooleanProp(41, true);
//        com.google.javascript.rhino.Node node14 = node4.getAncestor(16);
//        com.google.javascript.rhino.Context context16 = null;
//        com.google.javascript.rhino.Context context17 = com.google.javascript.rhino.Context.enter(context16);
//        java.util.logging.Logger logger18 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager19 = new com.google.javascript.jscomp.LoggerErrorManager(logger18);
//        java.lang.Object obj20 = context17.getThreadLocal((java.lang.Object) loggerErrorManager19);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = context17.getErrorReporter();
//        java.lang.String str22 = context17.getImplementationVersion();
//        com.google.javascript.rhino.EcmaError ecmaError24 = com.google.javascript.rhino.ScriptRuntime.typeError("");
//        int int25 = ecmaError24.lineNumber();
//        int int26 = ecmaError24.lineNumber();
//        java.lang.String str27 = ecmaError24.getName();
//        java.lang.String str28 = ecmaError24.lineSource();
//        context17.removeThreadLocal((java.lang.Object) str28);
//        boolean boolean30 = context17.isGeneratingSource();
//        try {
//            java.lang.String str31 = com.google.javascript.rhino.ScriptRuntime.getMessage3("TypeError", (java.lang.Object) 16, (java.lang.Object) (-2), (java.lang.Object) context17);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertNotNull(node4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNull(node14);
//        org.junit.Assert.assertNotNull(context17);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertNull(errorReporter21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str22.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNotNull(ecmaError24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TypeError" + "'", str27.equals("TypeError"));
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean10 = node9.isUnscopedQualifiedName();
        int int11 = node9.getChildCount();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node15.detachChildren();
        boolean boolean17 = node15.hasMoreThanOneChild();
        boolean boolean18 = node9.isEquivalentToTyped(node15);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node23.detachChildren();
        boolean boolean25 = node23.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node29.detachChildren();
        boolean boolean31 = node29.isOnlyModifiesThisCall();
        int int33 = node29.getIntProp((int) 'a');
        boolean boolean34 = node23.isEquivalentTo(node29);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean39 = node38.isUnscopedQualifiedName();
        int int40 = node38.getChildCount();
        java.util.Set<java.lang.String> strSet41 = node38.getDirectives();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node45.detachChildren();
        boolean boolean47 = node45.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node51.detachChildren();
        boolean boolean53 = node51.isOnlyModifiesThisCall();
        int int55 = node51.getIntProp((int) 'a');
        boolean boolean56 = node45.isEquivalentTo(node51);
        com.google.javascript.rhino.Node node57 = node38.copyInformationFromForTree(node51);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean62 = node61.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node63 = node38.copyInformationFromForTree(node61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean68 = node67.isUnscopedQualifiedName();
        int int69 = node67.getChildCount();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean74 = node73.isUnscopedQualifiedName();
        int int75 = node73.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType76 = node73.getJSType();
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(26, node29, node38, node67, node73, (int) (short) 0, (int) '4');
        boolean boolean80 = node79.wasEmptyNode();
        boolean boolean81 = node79.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node(0, node5, node15, node79, 5, (int) (byte) 10);
        java.lang.String str85 = node79.toStringTree();
        node79.detachChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(strSet41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "NOT 0\n    STRING \n    STRING \n    STRING \n    STRING \n" + "'", str85.equals("NOT 0\n    STRING \n    STRING \n    STRING \n    STRING \n"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
        java.lang.String str6 = context1.getImplementationVersion();
        try {
            context1.unseal((java.lang.Object) "TypeError");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(errorReporter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
        boolean boolean7 = context1.isActivationNeeded("STRING ");
        com.google.javascript.rhino.ErrorReporter errorReporter8 = context1.getErrorReporter();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(errorReporter5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(errorReporter8);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("TypeError: ");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", (int) (short) -1, (int) (byte) 0);
        com.google.javascript.rhino.Node node8 = null;
        java.lang.String str9 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean11 = defaultCodingConvention0.isPrivate("");
        java.lang.String str12 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compiler0.getCodingConvention();
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat8 = diagnosticType7.format;
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "language version", "Named type with empty name component", "hi!", "error reporter" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<tweakValidation>(WARNING)", 41, 0, diagnosticType7, strArray14);
        int int16 = jSError15.getCharno();
        compiler0.report(jSError15);
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(codingConvention3);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(messageFormat8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        java.lang.RuntimeException runtimeException3 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compiler0, (java.lang.Object) 7);
        java.lang.String str4 = runtimeException3.toString();
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(runtimeException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 7 is not a function, it is com.google.javascript.jscomp.Compiler." + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 7 is not a function, it is com.google.javascript.jscomp.Compiler."));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        com.google.javascript.rhino.Node node4 = null;
        java.lang.String str5 = defaultCodingConvention0.identifyTypeDefAssign(node4);
        java.lang.String str6 = defaultCodingConvention0.getDelegateSuperclassName();
        boolean boolean8 = defaultCodingConvention0.isConstant("");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String[] strArray0 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        boolean boolean61 = node60.wasEmptyNode();
        node60.setWasEmptyNode(false);
        boolean boolean64 = node60.isNoSideEffectsCall();
        boolean boolean65 = node60.hasChildren();
        boolean boolean66 = node60.hasChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node4.detachChildren();
        boolean boolean6 = node4.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node10.detachChildren();
        boolean boolean12 = node10.isOnlyModifiesThisCall();
        int int14 = node10.getIntProp((int) 'a');
        boolean boolean15 = node4.isEquivalentTo(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean20 = node19.isUnscopedQualifiedName();
        int int21 = node19.getChildCount();
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node32.detachChildren();
        boolean boolean34 = node32.isOnlyModifiesThisCall();
        int int36 = node32.getIntProp((int) 'a');
        boolean boolean37 = node26.isEquivalentTo(node32);
        com.google.javascript.rhino.Node node38 = node19.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean43 = node42.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean49 = node48.isUnscopedQualifiedName();
        int int50 = node48.getChildCount();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType57 = node54.getJSType();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(26, node10, node19, node48, node54, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node61 = node10.getFirstChild();
        node10.setOptionalArg(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(strSet22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNull(node61);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            com.google.javascript.rhino.Context.reportWarning("TypeError: ", "goog.abstractMethod", 34, "@IMPLEMENTATION.VERSION@", 40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = null;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node12.detachChildren();
        boolean boolean14 = node12.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node18.detachChildren();
        boolean boolean20 = node18.isOnlyModifiesThisCall();
        int int22 = node18.getIntProp((int) 'a');
        boolean boolean23 = node12.isEquivalentTo(node18);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean28 = node27.isUnscopedQualifiedName();
        int int29 = node27.getChildCount();
        java.util.Set<java.lang.String> strSet30 = node27.getDirectives();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node34.detachChildren();
        boolean boolean36 = node34.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node40.detachChildren();
        boolean boolean42 = node40.isOnlyModifiesThisCall();
        int int44 = node40.getIntProp((int) 'a');
        boolean boolean45 = node34.isEquivalentTo(node40);
        com.google.javascript.rhino.Node node46 = node27.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean51 = node50.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node52 = node27.copyInformationFromForTree(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean57 = node56.isUnscopedQualifiedName();
        int int58 = node56.getChildCount();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean63 = node62.isUnscopedQualifiedName();
        int int64 = node62.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType65 = node62.getJSType();
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(26, node18, node27, node56, node62, (int) (short) 0, (int) '4');
        boolean boolean69 = node68.wasEmptyNode();
        node68.setWasEmptyNode(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder72 = node68.getJsDocBuilderForNode();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast73 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal7, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(strSet30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNull(jSType65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder72);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.ObjectType objectType1 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType1, objectType2, objectType3, functionType4, functionType5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean11 = node10.isUnscopedQualifiedName();
        int int12 = node10.getChildCount();
        java.util.Set<java.lang.String> strSet13 = node10.getDirectives();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node17.detachChildren();
        boolean boolean19 = node17.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node23.detachChildren();
        boolean boolean25 = node23.isOnlyModifiesThisCall();
        int int27 = node23.getIntProp((int) 'a');
        boolean boolean28 = node17.isEquivalentTo(node23);
        com.google.javascript.rhino.Node node29 = node10.copyInformationFromForTree(node23);
        node23.setIsSyntheticBlock(true);
        node23.setOptionalArg(false);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node39.detachChildren();
        boolean boolean41 = node39.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node45.detachChildren();
        boolean boolean47 = node45.isOnlyModifiesThisCall();
        int int49 = node45.getIntProp((int) 'a');
        boolean boolean50 = node39.isEquivalentTo(node45);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean55 = node54.isUnscopedQualifiedName();
        int int56 = node54.getChildCount();
        java.util.Set<java.lang.String> strSet57 = node54.getDirectives();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node61.detachChildren();
        boolean boolean63 = node61.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node67.detachChildren();
        boolean boolean69 = node67.isOnlyModifiesThisCall();
        int int71 = node67.getIntProp((int) 'a');
        boolean boolean72 = node61.isEquivalentTo(node67);
        com.google.javascript.rhino.Node node73 = node54.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean78 = node77.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node79 = node54.copyInformationFromForTree(node77);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean84 = node83.isUnscopedQualifiedName();
        int int85 = node83.getChildCount();
        com.google.javascript.rhino.Node node89 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean90 = node89.isUnscopedQualifiedName();
        int int91 = node89.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType92 = node89.getJSType();
        com.google.javascript.rhino.Node node95 = new com.google.javascript.rhino.Node(26, node45, node54, node83, node89, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node96 = node89.getParent();
        node23.putProp(9, (java.lang.Object) node96);
        java.util.List<java.lang.String> strList98 = closureCodingConvention0.identifyTypeDeclarationCall(node96);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(strSet13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(strSet57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertNull(jSType92);
        org.junit.Assert.assertNotNull(node96);
        org.junit.Assert.assertNull(strList98);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.logging.Logger logger2 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(logger2);
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) loggerErrorManager3);
//        com.google.javascript.rhino.Context context5 = null;
//        com.google.javascript.rhino.Context context6 = com.google.javascript.rhino.Context.enter(context5);
//        java.util.logging.Logger logger7 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
//        java.lang.Object obj9 = context6.getThreadLocal((java.lang.Object) loggerErrorManager8);
//        java.util.Locale locale10 = context6.getLocale();
//        context1.seal((java.lang.Object) locale10);
//        boolean boolean12 = context1.isSealed();
//        java.lang.Object obj13 = null;
//        java.lang.Object obj14 = context1.getThreadLocal(obj13);
//        boolean boolean15 = context1.isSealed();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj4);
//        org.junit.Assert.assertNotNull(context6);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertNotNull(locale10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(obj14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        try {
            boolean boolean5 = jSModuleGraph2.dependsOn(jSModule3, jSModule4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        try {
            node7.setDouble((double) 38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING  is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Scope scope2 = compiler0.getTopScope();
        compiler0.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.Region region9 = jSSourceFile6.getRegion(31);
        java.lang.String str10 = jSSourceFile6.getName();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node12 = compiler11.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap13 = compiler11.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        com.google.javascript.rhino.Node node17 = compiler11.parse(jSSourceFile16);
        com.google.javascript.jscomp.SourceFile.Generator generator19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("STRING ", "window");
        jSSourceFile23.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromCode("()", "error reporter");
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset31);
        com.google.javascript.jscomp.SourceFile.Generator generator34 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("()", generator34);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR", "error reporter");
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray40 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile16, jSSourceFile20, jSSourceFile23, jSSourceFile26, jSSourceFile29, jSSourceFile32, jSSourceFile35, jSSourceFile38 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList41 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList41, jSSourceFileArray40);
        com.google.javascript.jscomp.JSModule[] jSModuleArray43 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList44 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList44, jSModuleArray43);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph46 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList44);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph47 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = null;
        try {
            com.google.javascript.jscomp.Result result49 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList41, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList44, compilerOptions48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(region9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str10.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(sourceMap13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFileArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(jSModuleArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("language version");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        jsAst2.clearAst();
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean3 = context1.isActivationNeeded("error reporter");
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context1, (long) (byte) 1);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        java.lang.Object obj8 = null;
//        java.lang.Object obj9 = context1.getThreadLocal(obj8);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNull(obj9);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph5 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph10 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph11 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        try {
            com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph5.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        try {
//            com.google.javascript.rhino.Context.reportError("language version", "(JSC_OPTIMIZE_LOOP_ERROR)", 0, "com.google.javascript.rhino.EcmaError: TypeError: 7 is not a function, it is com.google.javascript.jscomp.Compiler.", 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: language version");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean4 = node3.isUnscopedQualifiedName();
        int int5 = node3.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType6 = node3.getJSType();
        node3.setCharno(7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        int int42 = node40.getChildCount();
        node40.putProp((int) (byte) 10, (java.lang.Object) 150);
        node40.putBooleanProp(10, false);
        boolean boolean49 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) ' ', node13, node30, node40);
        boolean boolean51 = node3.hasChild(node30);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean56 = node55.isUnscopedQualifiedName();
        int int57 = node55.getChildCount();
        node55.putProp((int) (byte) 10, (java.lang.Object) 150);
        node55.putBooleanProp(41, true);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable64 = node55.children();
        try {
            com.google.javascript.rhino.Node node65 = node3.removeChildAfter(node55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(nodeIterable64);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray2 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray2);
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup3;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean8 = defaultCodingConvention5.isExported("Named type with empty name component", true);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 19, (java.lang.Object) diagnosticGroup3, (java.lang.Object) boolean8);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.level;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState13 = compiler12.getState();
        try {
            java.lang.String str14 = com.google.javascript.rhino.ScriptRuntime.getMessage3("@IMPLEMENTATION.VERSION@", (java.lang.Object) diagnosticGroup3, (java.lang.Object) diagnosticType10, (java.lang.Object) intermediateState13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property @IMPLEMENTATION.VERSION@");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticTypeArray2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(intermediateState13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager6 = compiler4.getErrorManager();
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compiler4.getCodingConvention();
        com.google.javascript.rhino.Node node8 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler4);
        jsAst3.clearAst();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(errorManager6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("<No stack trace available>", "Not declared as a constructor");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node3.detachChildren();
        boolean boolean5 = node3.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node3.siblings();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean11 = node10.isUnscopedQualifiedName();
        int int12 = node10.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        com.google.javascript.rhino.Node node14 = node10.getLastSibling();
        node3.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node20.detachChildren();
        boolean boolean22 = node20.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node26.detachChildren();
        boolean boolean28 = node26.isOnlyModifiesThisCall();
        int int30 = node26.getIntProp((int) 'a');
        boolean boolean31 = node20.isEquivalentTo(node26);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean36 = node35.isUnscopedQualifiedName();
        int int37 = node35.getChildCount();
        java.util.Set<java.lang.String> strSet38 = node35.getDirectives();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node42.detachChildren();
        boolean boolean44 = node42.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node48.detachChildren();
        boolean boolean50 = node48.isOnlyModifiesThisCall();
        int int52 = node48.getIntProp((int) 'a');
        boolean boolean53 = node42.isEquivalentTo(node48);
        com.google.javascript.rhino.Node node54 = node35.copyInformationFromForTree(node48);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean59 = node58.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node60 = node35.copyInformationFromForTree(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean65 = node64.isUnscopedQualifiedName();
        int int66 = node64.getChildCount();
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean71 = node70.isUnscopedQualifiedName();
        int int72 = node70.getChildCount();
        com.google.javascript.rhino.jstype.JSType jSType73 = node70.getJSType();
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(26, node26, node35, node64, node70, (int) (short) 0, (int) '4');
        com.google.javascript.rhino.Node node77 = node70.getFirstChild();
        try {
            node3.addChildrenToFront(node77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNull(jSType73);
        org.junit.Assert.assertNull(node77);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("(())");
        sourceFile1.setOriginalPath("language version");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            com.google.javascript.rhino.Context.reportWarning("window", "", 16, "JSC_OPTIMIZE_LOOP_ERROR", (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean5 = node4.isUnscopedQualifiedName();
        int int6 = node4.getChildCount();
        node4.putProp((int) (byte) 10, (java.lang.Object) 150);
        node4.putBooleanProp(10, false);
        boolean boolean13 = node4.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean18 = node17.isUnscopedQualifiedName();
        int int19 = node17.getChildCount();
        java.util.Set<java.lang.String> strSet20 = node17.getDirectives();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node24.detachChildren();
        boolean boolean26 = node24.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node30.detachChildren();
        boolean boolean32 = node30.isOnlyModifiesThisCall();
        int int34 = node30.getIntProp((int) 'a');
        boolean boolean35 = node24.isEquivalentTo(node30);
        com.google.javascript.rhino.Node node36 = node17.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        boolean boolean41 = node40.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node42 = node17.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("", (-1), (int) (byte) 10);
        node46.detachChildren();
        boolean boolean48 = node46.hasMoreThanOneChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable49 = node46.siblings();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node4, node40, node46 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, nodeArray50, 0, 18);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) '4', "language version", 26, (int) (byte) 10);
        boolean boolean59 = node53.isEquivalentTo(node58);
        java.lang.Appendable appendable60 = null;
        try {
            node53.appendStringTree(appendable60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(strSet20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(nodeIterable49);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }
}

