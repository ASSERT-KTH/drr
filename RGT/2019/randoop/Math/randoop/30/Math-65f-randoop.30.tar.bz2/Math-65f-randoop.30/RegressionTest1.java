import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.lang.IllegalArgumentException illegalArgumentException6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException7 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException8 = new org.apache.commons.math.linear.MatrixIndexException("", objArray4);
        java.lang.String str9 = matrixIndexException8.toString();
        java.lang.Object[] objArray10 = matrixIndexException8.getArguments();
        java.lang.Class<?> wildcardClass11 = objArray10.getClass();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(illegalArgumentException6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.linear.MatrixIndexException: " + "'", str9.equals("org.apache.commons.math.linear.MatrixIndexException: "));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray2 = array2DRowRealMatrix1.getData();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MathRuntimeException$4: hi!", (java.lang.Object[]) doubleArray2);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2, false);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        double double3 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix33.scalarAdd((double) (short) -1);
        double[] doubleArray42 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray49 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray56 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray63 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray64 = new double[][] { doubleArray42, doubleArray49, doubleArray56, doubleArray63 };
        org.apache.commons.math.linear.RealMatrix realMatrix65 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray64);
        org.apache.commons.math.linear.RealMatrix realMatrix66 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray64);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray64);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix67.transpose();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix33, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix68);
        try {
            double double72 = blockRealMatrix33.getEntry((int) '#', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (35, 1) in a 4x6 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix65);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable1, objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        int int5 = maxIterationsExceededException3.getMaxIterations();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException11 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray10);
        java.lang.ArithmeticException arithmeticException13 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray10);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException19 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray18);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray18);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray18);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException13, "", objArray18);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(throwable5, localizable6, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable3, localizable4, objArray18);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException25 = new org.apache.commons.math.linear.InvalidMatrixException(throwable3);
        org.apache.commons.math.exception.Localizable localizable26 = invalidMatrixException25.getLocalizablePattern();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray28 = array2DRowRealMatrix27.getData();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException29 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable26, (java.lang.Object[]) doubleArray28);
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Throwable throwable34 = null;
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException40 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray39);
        java.lang.IllegalArgumentException illegalArgumentException41 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray39);
        java.lang.ArithmeticException arithmeticException42 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray39);
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException48 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray47);
        java.lang.IllegalArgumentException illegalArgumentException49 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray47);
        java.lang.ArithmeticException arithmeticException50 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray47);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException42, "", objArray47);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(throwable34, localizable35, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable32, localizable33, objArray47);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException(2147483647, "BlockRealMatrix{{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0}}", objArray47);
        java.lang.IllegalArgumentException illegalArgumentException55 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable26, objArray47);
        java.lang.Object[] objArray58 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException59 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray58);
        java.lang.IllegalArgumentException illegalArgumentException60 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray58);
        org.apache.commons.math.exception.Localizable localizable61 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException65 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray64);
        java.lang.IllegalArgumentException illegalArgumentException66 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray64);
        org.apache.commons.math.MathRuntimeException mathRuntimeException67 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException60, localizable61, objArray64);
        org.apache.commons.math.exception.Localizable localizable68 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException74 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray73);
        java.lang.Class<?> wildcardClass75 = objArray73.getClass();
        java.text.ParseException parseException76 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray73);
        org.apache.commons.math.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.MathRuntimeException("", objArray73);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException60, localizable68, objArray73);
        org.apache.commons.math.exception.Localizable localizable81 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException86 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray85);
        java.lang.Class<?> wildcardClass87 = objArray85.getClass();
        java.text.ParseException parseException88 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray85);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(localizable81, objArray85);
        org.apache.commons.math.optimization.OptimizationException optimizationException90 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.linear.MatrixIndexException: ", objArray85);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException60, "org.apache.commons.math.MathRuntimeException$4: hi!", objArray85);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable26, objArray85);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, localizable2, objArray85);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
        org.junit.Assert.assertNotNull(arithmeticException13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException19);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException29);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException40);
        org.junit.Assert.assertNotNull(illegalArgumentException41);
        org.junit.Assert.assertNotNull(arithmeticException42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException48);
        org.junit.Assert.assertNotNull(illegalArgumentException49);
        org.junit.Assert.assertNotNull(arithmeticException50);
        org.junit.Assert.assertNotNull(illegalArgumentException55);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException59);
        org.junit.Assert.assertNotNull(illegalArgumentException60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException65);
        org.junit.Assert.assertNotNull(illegalArgumentException66);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(parseException76);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException86);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertNotNull(parseException88);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException10 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray9);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray9);
        java.lang.ArithmeticException arithmeticException12 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray9);
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException18 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray17);
        java.lang.IllegalArgumentException illegalArgumentException19 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray17);
        java.lang.ArithmeticException arithmeticException20 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException12, "", objArray17);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(throwable4, localizable5, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable2, localizable3, objArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException24 = new org.apache.commons.math.MaxEvaluationsExceededException(2147483647, "BlockRealMatrix{{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0}}", objArray17);
        java.lang.Object[] objArray25 = maxEvaluationsExceededException24.getArguments();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException10);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertNotNull(arithmeticException12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException18);
        org.junit.Assert.assertNotNull(illegalArgumentException19);
        org.junit.Assert.assertNotNull(arithmeticException20);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double[] doubleArray8 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray15 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray22 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray29 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray36 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray43 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(1, "", (java.lang.Object[]) doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getChiSquare();
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double4 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException2 = new org.apache.commons.math.linear.MatrixIndexException("BlockRealMatrix{{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0},{9.0,0.0,31.0,99.0,9.0,9.0}}", objArray1);
        org.apache.commons.math.exception.Localizable localizable3 = matrixIndexException2.getLocalizablePattern();
        org.junit.Assert.assertNotNull(localizable3);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getEvaluations();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker5 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, 0.0d);
        double[] doubleArray8 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix12 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray11);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray11);
        double[] doubleArray15 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix16 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray15);
        double[] doubleArray18 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix19 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray18);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray18);
        double[] doubleArray21 = vectorialPointValuePair20.getPointRef();
        boolean boolean22 = simpleVectorialValueChecker5.converged((int) (short) 10, vectorialPointValuePair13, vectorialPointValuePair20);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker5);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(bigMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(bigMatrix12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(bigMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(bigMatrix19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double[] doubleArray7 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray14 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray21 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray28 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray29 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28 };
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray29);
        java.lang.NullPointerException nullPointerException33 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(nullPointerException33);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        double[] doubleArray34 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix35 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray34);
        try {
            double[] doubleArray36 = array2DRowRealMatrix32.preMultiply(doubleArray34);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(bigMatrix35);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        array2DRowRealMatrix0.luDecompose();
        org.apache.commons.math.linear.RealVector realVector7 = null;
        try {
            array2DRowRealMatrix0.setRowVector((int) (short) 1, realVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException10 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray9);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray9);
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException16 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray15);
        java.lang.IllegalArgumentException illegalArgumentException17 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException11, localizable12, objArray15);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException25 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray24);
        java.lang.Class<?> wildcardClass26 = objArray24.getClass();
        java.text.ParseException parseException27 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException11, localizable19, objArray24);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException5, localizable6, objArray24);
        double[] doubleArray37 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray44 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray51 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray58 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray59 = new double[][] { doubleArray37, doubleArray44, doubleArray51, doubleArray58 };
        org.apache.commons.math.linear.RealMatrix realMatrix60 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.linear.RealMatrix realMatrix61 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray59);
        double[] doubleArray66 = blockRealMatrix64.getRow((int) (short) 0);
        java.lang.Object[] objArray72 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException73 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray72);
        java.lang.Class<?> wildcardClass74 = objArray72.getClass();
        java.text.ParseException parseException75 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray72);
        org.apache.commons.math.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.MathRuntimeException("", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException30, doubleArray66, "", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(644.7480127925949d, "hi!", objArray72);
        java.lang.IllegalStateException illegalStateException79 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.MathRuntimeException$3: ", objArray72);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException10);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException16);
        org.junit.Assert.assertNotNull(illegalArgumentException17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(parseException27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(parseException75);
        org.junit.Assert.assertNotNull(illegalStateException79);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealVector realVector35 = blockRealMatrix33.getColumnVector(0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix33.scalarAdd((double) (short) -1);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(0.0d);
        double[] doubleArray41 = new double[] { (byte) 0, (-1.0d), 1.0d };
        org.apache.commons.math.linear.RealVector realVector42 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException37, doubleArray41);
        boolean boolean45 = blockRealMatrix35.equals((java.lang.Object) functionEvaluationException44);
        int int46 = blockRealMatrix35.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix48 = blockRealMatrix35.getRowMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "org.apache.commons.math.MathRuntimeException$4: hi!", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        int int5 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix67.scalarAdd(0.0d);
        int int71 = blockRealMatrix70.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 6 + "'", int71 == 6);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix69 = blockRealMatrix33.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 4x6 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double[] doubleArray6 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray13 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray20 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray27 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray34 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray41 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix43, (int) (short) 0);
        int int46 = array2DRowRealMatrix43.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealVector realVector48 = array2DRowRealMatrix43.getRowVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.lang.Class<?> wildcardClass6 = objArray4.getClass();
        java.text.ParseException parseException7 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray4);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable9 = mathRuntimeException8.getLocalizablePattern();
        java.lang.Object[] objArray10 = null;
        java.io.EOFException eOFException11 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable9, objArray10);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        double[] doubleArray21 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray28 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray35 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray42 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray43 = new double[][] { doubleArray21, doubleArray28, doubleArray35, doubleArray42 };
        org.apache.commons.math.linear.RealMatrix realMatrix44 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43, true);
        org.apache.commons.math.linear.RealMatrix realMatrix48 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("org.apache.commons.math.linear.MatrixIndexException: ", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        try {
            array2DRowRealMatrix51.addToEntry(2147483647, 0, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (2,147,483,647, 0) in a 4x6 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(parseException7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(eOFException11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix48);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException4 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray3);
        java.lang.Class<?> wildcardClass5 = objArray3.getClass();
        java.text.ParseException parseException6 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray3);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray11);
        java.lang.Class<?> wildcardClass13 = objArray11.getClass();
        java.text.ParseException parseException14 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable16 = mathRuntimeException15.getLocalizablePattern();
        java.lang.Object[] objArray17 = null;
        java.io.EOFException eOFException18 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable16, objArray17);
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException25 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray24);
        java.lang.Class<?> wildcardClass26 = objArray24.getClass();
        java.text.ParseException parseException27 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException6, localizable16, objArray24);
        double[] doubleArray37 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray44 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray51 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray58 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray59 = new double[][] { doubleArray37, doubleArray44, doubleArray51, doubleArray58 };
        org.apache.commons.math.linear.RealMatrix realMatrix60 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.linear.RealMatrix realMatrix61 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, true);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.MathRuntimeException(localizable16, (java.lang.Object[]) doubleArray59);
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException70 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray69);
        java.lang.IllegalArgumentException illegalArgumentException71 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray69);
        java.lang.ArithmeticException arithmeticException72 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray69);
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException78 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray77);
        java.lang.IllegalArgumentException illegalArgumentException79 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray77);
        java.lang.ArithmeticException arithmeticException80 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray77);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException72, "", objArray77);
        java.io.EOFException eOFException82 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable16, objArray77);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(parseException6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(parseException14);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(eOFException18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(parseException27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException70);
        org.junit.Assert.assertNotNull(illegalArgumentException71);
        org.junit.Assert.assertNotNull(arithmeticException72);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException78);
        org.junit.Assert.assertNotNull(illegalArgumentException79);
        org.junit.Assert.assertNotNull(arithmeticException80);
        org.junit.Assert.assertNotNull(eOFException82);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable3, objArray4);
        java.lang.Object[] objArray6 = maxIterationsExceededException5.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((double) 10, "", objArray6);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray12);
        java.lang.Class<?> wildcardClass14 = objArray12.getClass();
        java.text.ParseException parseException15 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException("", objArray12);
        org.apache.commons.math.exception.Localizable localizable17 = mathRuntimeException16.getLocalizablePattern();
        java.lang.Object[] objArray18 = null;
        java.io.EOFException eOFException19 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable17, objArray18);
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray34 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray41 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray48 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray49 = new double[][] { doubleArray27, doubleArray34, doubleArray41, doubleArray48 };
        org.apache.commons.math.linear.RealMatrix realMatrix50 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathRuntimeException$4: hi!", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException7, localizable17, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(parseException15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(eOFException19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor71 = null;
        try {
            double double76 = blockRealMatrix67.walkInRowOrder(realMatrixPreservingVisitor71, 6, (int) (byte) 100, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 6 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException8 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray7);
        java.lang.IllegalArgumentException illegalArgumentException9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray7);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException10 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray7);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException16 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray15);
        java.lang.IllegalArgumentException illegalArgumentException17 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray15);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException10, localizable11, objArray15);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException(localizable3, objArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable0, 0.0d, localizable2, objArray15);
        double[] doubleArray22 = functionEvaluationException21.getArgument();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException8);
        org.junit.Assert.assertNotNull(illegalArgumentException9);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException16);
        org.junit.Assert.assertNotNull(illegalArgumentException17);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        double[] doubleArray7 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray14 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray21 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray28 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray29 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28 };
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, true);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("org.apache.commons.math.linear.MatrixIndexException: ", (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        double[] doubleArray41 = new double[] { (byte) 0, (-1.0d), 1.0d };
        org.apache.commons.math.linear.RealVector realVector42 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray41);
        java.lang.Class<?> wildcardClass43 = realVector42.getClass();
        try {
            org.apache.commons.math.linear.RealVector realVector44 = array2DRowRealMatrix37.preMultiply(realVector42);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl6 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 0L);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver7 = lUDecompositionImpl6.getSolver();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver8 = lUDecompositionImpl6.getSolver();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = lUDecompositionImpl6.getP();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(decompositionSolver7);
        org.junit.Assert.assertNotNull(decompositionSolver8);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException4 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray3);
        java.lang.Class<?> wildcardClass5 = objArray3.getClass();
        java.text.ParseException parseException6 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray3);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray11);
        java.lang.Class<?> wildcardClass13 = objArray11.getClass();
        java.text.ParseException parseException14 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable16 = mathRuntimeException15.getLocalizablePattern();
        java.lang.Object[] objArray17 = null;
        java.io.EOFException eOFException18 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable16, objArray17);
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException25 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray24);
        java.lang.Class<?> wildcardClass26 = objArray24.getClass();
        java.text.ParseException parseException27 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException6, localizable16, objArray24);
        double[] doubleArray37 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray44 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray51 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray58 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray59 = new double[][] { doubleArray37, doubleArray44, doubleArray51, doubleArray58 };
        org.apache.commons.math.linear.RealMatrix realMatrix60 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.linear.RealMatrix realMatrix61 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, true);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.MathRuntimeException(localizable16, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.linear.RealMatrix realMatrix66 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray59);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(parseException6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(parseException14);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(eOFException18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(parseException27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(realMatrix66);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix67.scalarAdd(0.0d);
        int int71 = blockRealMatrix67.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix73 = blockRealMatrix67.scalarAdd((double) 100L);
        try {
            boolean boolean74 = blockRealMatrix67.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 4x6 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        double double3 = array2DRowRealMatrix0.getTrace();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix4, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5);
        int int7 = array2DRowRealMatrix4.getColumnDimension();
        double double8 = array2DRowRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix4);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix4.walkInColumnOrder(realMatrixPreservingVisitor10, (int) (short) -1, 0, 2147483647, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        double[][] doubleArray5 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix7);
        boolean boolean9 = array2DRowRealMatrix7.isSingular();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 100, (int) ' ');
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        double[] doubleArray6 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray13 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray20 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray27 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray34 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray41 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix43, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix47 = array2DRowRealMatrix43.scalarAdd((double) ' ');
        boolean boolean48 = array2DRowRealMatrix43.isSingular();
        int int49 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix52 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (byte) 1, (int) (short) 10);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix43.subtract(realMatrix52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(realMatrix52);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix3 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray2);
        double[] doubleArray5 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray5);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray5);
        double[] doubleArray8 = vectorialPointValuePair7.getValue();
        double[] doubleArray10 = new double[] { 10L };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10, true);
        org.apache.commons.math.exception.Localizable localizable13 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException20 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray19);
        java.io.IOException iOException21 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) arrayIndexOutOfBoundsException20);
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException26 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray25);
        java.lang.IllegalArgumentException illegalArgumentException27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray25);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray25);
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1.0f), (byte) 1, (byte) 0, arrayIndexOutOfBoundsException20, "hi!" };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable14, objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable13, objArray29);
        org.apache.commons.math.optimization.OptimizationException optimizationException32 = new org.apache.commons.math.optimization.OptimizationException(localizable0, objArray29);
        java.lang.String str33 = optimizationException32.toString();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(bigMatrix3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(bigMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException20);
        org.junit.Assert.assertNotNull(iOException21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException26);
        org.junit.Assert.assertNotNull(illegalArgumentException27);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.optimization.OptimizationException: " + "'", str33.equals("org.apache.commons.math.optimization.OptimizationException: "));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        double double71 = blockRealMatrix67.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix72 = blockRealMatrix67.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix74 = blockRealMatrix67.scalarMultiply((double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 212.83796653792763d + "'", double71 == 212.83796653792763d);
        org.junit.Assert.assertNotNull(realMatrix72);
        org.junit.Assert.assertNotNull(realMatrix74);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException6 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray5);
        java.lang.Class<?> wildcardClass7 = objArray5.getClass();
        java.text.ParseException parseException8 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray5);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException("", objArray5);
        org.apache.commons.math.exception.Localizable localizable10 = mathRuntimeException9.getLocalizablePattern();
        java.lang.Object[] objArray11 = null;
        java.io.EOFException eOFException12 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable10, objArray11);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable10, objArray13);
        double[] doubleArray22 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray29 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray36 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray43 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray44 = new double[][] { doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray44);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44, true);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray44);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("org.apache.commons.math.linear.MatrixIndexException: ", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable10, (java.lang.Object[]) doubleArray44);
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException56 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray55);
        java.lang.IllegalArgumentException illegalArgumentException57 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray55);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException58 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray55);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException64 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray63);
        java.lang.IllegalArgumentException illegalArgumentException65 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray63);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException66 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray63);
        org.apache.commons.math.MathRuntimeException mathRuntimeException67 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException58, localizable59, objArray63);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException68 = new org.apache.commons.math.MaxEvaluationsExceededException(1000, localizable10, objArray63);
        double[] doubleArray72 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix73 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray72);
        double[] doubleArray75 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix76 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray75);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair77 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray72, doubleArray75);
        java.lang.Object[] objArray82 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException83 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray82);
        java.lang.IllegalArgumentException illegalArgumentException84 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray82);
        java.lang.ArithmeticException arithmeticException85 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray82);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException(doubleArray72, "", objArray82);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray82);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(localizable10, objArray82);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(parseException8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(eOFException12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException56);
        org.junit.Assert.assertNotNull(illegalArgumentException57);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException64);
        org.junit.Assert.assertNotNull(illegalArgumentException65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(bigMatrix73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(bigMatrix76);
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException83);
        org.junit.Assert.assertNotNull(illegalArgumentException84);
        org.junit.Assert.assertNotNull(arithmeticException85);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException2 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray1);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException7 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray6);
        java.lang.IllegalArgumentException illegalArgumentException8 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray6);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray12);
        java.lang.IllegalArgumentException illegalArgumentException14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException8, localizable9, objArray12);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException22 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray21);
        java.lang.Class<?> wildcardClass23 = objArray21.getClass();
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException("", objArray21);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException8, localizable16, objArray21);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException2, localizable3, objArray21);
        double[] doubleArray35 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray42 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray49 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray56 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray57 = new double[][] { doubleArray35, doubleArray42, doubleArray49, doubleArray56 };
        org.apache.commons.math.linear.RealMatrix realMatrix58 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException2, "", (java.lang.Object[]) doubleArray57);
        java.io.IOException iOException60 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) arrayIndexOutOfBoundsException2);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException2);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException7);
        org.junit.Assert.assertNotNull(illegalArgumentException8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException13);
        org.junit.Assert.assertNotNull(illegalArgumentException14);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(parseException24);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(iOException60);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.lang.Class<?> wildcardClass6 = objArray4.getClass();
        java.text.ParseException parseException7 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray4);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException("", objArray4);
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray10);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException19 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray18);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray18);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray18);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException27 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray26);
        java.lang.IllegalArgumentException illegalArgumentException28 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray26);
        java.lang.ArithmeticException arithmeticException29 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray26);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException21, "", objArray26);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(throwable13, localizable14, objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException8, doubleArray10, "", objArray26);
        double[] doubleArray39 = new double[] { (byte) 0, '4', 36, (-1L), 0L, 100.0f };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray39, true);
        double[] doubleArray42 = vectorialPointValuePair41.getPointRef();
        double[] doubleArray43 = vectorialPointValuePair41.getPointRef();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(parseException7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(bigMatrix11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException19);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException27);
        org.junit.Assert.assertNotNull(illegalArgumentException28);
        org.junit.Assert.assertNotNull(arithmeticException29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertNull(doubleArray1);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        blockRealMatrix67.multiplyEntry((int) (short) 1, (int) (byte) -1, (double) (-1));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix67.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix77 = blockRealMatrix67.scalarAdd(0.0d);
        java.lang.Object[] objArray80 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "org.apache.commons.math.MathRuntimeException$4: hi!", objArray80);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException81);
        boolean boolean83 = blockRealMatrix67.equals((java.lang.Object) maxIterationsExceededException81);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor84 = null;
        try {
            double double85 = blockRealMatrix67.walkInRowOrder(realMatrixChangingVisitor84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        double double3 = array2DRowRealMatrix0.getTrace();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix4, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5);
        int int7 = array2DRowRealMatrix4.getColumnDimension();
        double double8 = array2DRowRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix4);
        try {
            double[] doubleArray11 = array2DRowRealMatrix4.getRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException8 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray7);
        java.lang.IllegalArgumentException illegalArgumentException9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray7);
        java.lang.ArithmeticException arithmeticException10 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray7);
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException16 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray15);
        java.lang.IllegalArgumentException illegalArgumentException17 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray15);
        java.lang.ArithmeticException arithmeticException18 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray15);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException10, "", objArray15);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable2, localizable3, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable0, localizable1, objArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException(throwable0);
        org.apache.commons.math.exception.Localizable localizable23 = invalidMatrixException22.getLocalizablePattern();
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException26 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray25);
        java.lang.UnsupportedOperationException unsupportedOperationException27 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable23, objArray25);
        java.io.ObjectInputStream objectInputStream29 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) localizable23, "org.apache.commons.math.MathRuntimeException$8: ", objectInputStream29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException8);
        org.junit.Assert.assertNotNull(illegalArgumentException9);
        org.junit.Assert.assertNotNull(arithmeticException10);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException16);
        org.junit.Assert.assertNotNull(illegalArgumentException17);
        org.junit.Assert.assertNotNull(arithmeticException18);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable23.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException26);
        org.junit.Assert.assertNotNull(unsupportedOperationException27);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException(6);
        int int2 = maxEvaluationsExceededException1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix67.scalarAdd((double) (byte) 100);
        double[] doubleArray74 = blockRealMatrix72.getColumn((int) (short) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix72.copy();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix72.getRowMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        array2DRowRealMatrix0.luDecompose();
        double[] doubleArray12 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray19 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray26 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray33 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray34 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33 };
        org.apache.commons.math.linear.RealMatrix realMatrix35 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray34);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix0.subtract(realMatrix40);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray1);
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix12 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray11);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray11);
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException19 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray18);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray18);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray8, false);
        double[] doubleArray30 = new double[] { (byte) 0, '#', (short) 0, (-1.0d) };
        double[] doubleArray35 = new double[] { (byte) 0, '#', (short) 0, (-1.0d) };
        double[][] doubleArray36 = new double[][] { doubleArray30, doubleArray35 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36, false);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, "org.apache.commons.math.MathRuntimeException$4: hi!", (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(bigMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(bigMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(bigMatrix12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException19);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix67.scalarAdd(0.0d);
        int int71 = blockRealMatrix67.getRowDimension();
        blockRealMatrix67.setEntry((int) (byte) 1, (int) (short) 0, (double) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        org.apache.commons.math.linear.RealMatrix realMatrix69 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix67.add(realMatrix69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix67.scalarAdd((double) (byte) 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix67.scalarAdd(212.83796653792763d);
        double[] doubleArray76 = blockRealMatrix74.getRow(0);
        int int77 = blockRealMatrix74.getRowDimension();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix82 = blockRealMatrix74.getSubMatrix((int) (short) 10, 0, (int) '4', 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 4 + "'", int77 == 4);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.lang.Class<?> wildcardClass6 = objArray4.getClass();
        java.text.ParseException parseException7 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray4);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable9 = mathRuntimeException8.getLocalizablePattern();
        java.lang.Object[] objArray10 = null;
        java.io.EOFException eOFException11 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable9, objArray10);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        double[] doubleArray21 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray28 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray35 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray42 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray43 = new double[][] { doubleArray21, doubleArray28, doubleArray35, doubleArray42 };
        org.apache.commons.math.linear.RealMatrix realMatrix44 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43, true);
        org.apache.commons.math.linear.RealMatrix realMatrix48 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray43);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("org.apache.commons.math.linear.MatrixIndexException: ", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43);
        try {
            boolean boolean52 = array2DRowRealMatrix51.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 4x6 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(parseException7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(eOFException11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(realMatrix48);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.createMatrix(52, (int) (byte) 10);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException39 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray38);
        java.lang.IllegalArgumentException illegalArgumentException40 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray38);
        org.apache.commons.math.exception.Localizable localizable41 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException45 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray44);
        java.lang.IllegalArgumentException illegalArgumentException46 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray44);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException40, localizable41, objArray44);
        double[] doubleArray48 = null;
        double[] doubleArray50 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix51 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray50);
        double[] doubleArray53 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix54 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray53);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair55 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray50, doubleArray53);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException47, doubleArray53);
        try {
            double[] doubleArray58 = array2DRowRealMatrix32.solve(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 4x6 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException39);
        org.junit.Assert.assertNotNull(illegalArgumentException40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException45);
        org.junit.Assert.assertNotNull(illegalArgumentException46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(bigMatrix51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(bigMatrix54);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray1);
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValue();
        double[] doubleArray8 = vectorialPointValuePair6.getPoint();
        double[] doubleArray9 = vectorialPointValuePair6.getPoint();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(bigMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BigMatrix bigMatrix34 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(bigMatrix34);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray1);
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValue();
        double[] doubleArray8 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(bigMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double double69 = blockRealMatrix33.getNorm();
        try {
            double[] doubleArray71 = blockRealMatrix33.getColumn(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 400.0d + "'", double69 == 400.0d);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray1);
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray11);
        java.lang.IllegalArgumentException illegalArgumentException13 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray11);
        java.lang.ArithmeticException arithmeticException14 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, "", objArray11);
        org.apache.commons.math.linear.BigMatrix bigMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray1);
        org.apache.commons.math.linear.RealVector realVector17 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(bigMatrix5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
        org.junit.Assert.assertNotNull(illegalArgumentException13);
        org.junit.Assert.assertNotNull(arithmeticException14);
        org.junit.Assert.assertNotNull(bigMatrix16);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException(throwable0, 0.0d);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException2);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException3 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray2);
        java.lang.IllegalArgumentException illegalArgumentException4 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray2);
        org.apache.commons.math.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException4);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException3);
        org.junit.Assert.assertNotNull(illegalArgumentException4);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        blockRealMatrix67.multiplyEntry((int) (short) 1, (int) (byte) -1, (double) (-1));
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix75, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix76);
        int int78 = array2DRowRealMatrix75.getColumnDimension();
        double[][] doubleArray79 = array2DRowRealMatrix75.getDataRef();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix80 = blockRealMatrix67.solve((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 4x6 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNull(doubleArray79);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) ' ', (int) ' ');
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor3, 10, (int) 'a', 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 31]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        double[] doubleArray7 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray14 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray21 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray28 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray29 = new double[][] { doubleArray7, doubleArray14, doubleArray21, doubleArray28 };
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, true);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("org.apache.commons.math.linear.MatrixIndexException: ", (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix34);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getChiSquare();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        int int3 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 0);
        int int6 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1000 + "'", int3 == 1000);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray1);
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray11);
        java.lang.IllegalArgumentException illegalArgumentException13 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray11);
        java.lang.ArithmeticException arithmeticException14 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, "", objArray11);
        org.apache.commons.math.linear.BigMatrix bigMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray1);
        org.apache.commons.math.linear.RealVector realVector17 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray1);
        try {
            array2DRowRealMatrix19.multiplyEntry((int) (byte) 10, 10, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (10, 10) in a 1x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(bigMatrix5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
        org.junit.Assert.assertNotNull(illegalArgumentException13);
        org.junit.Assert.assertNotNull(arithmeticException14);
        org.junit.Assert.assertNotNull(bigMatrix16);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getIterations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        int int3 = array2DRowRealMatrix0.getColumnDimension();
        double double4 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl6 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 0L);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver7 = lUDecompositionImpl6.getSolver();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver8 = lUDecompositionImpl6.getSolver();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = lUDecompositionImpl6.getU();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(decompositionSolver7);
        org.junit.Assert.assertNotNull(decompositionSolver8);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        blockRealMatrix67.multiplyEntry((int) (short) 1, (int) (byte) -1, (double) (-1));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix67.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor76 = null;
        try {
            double double77 = blockRealMatrix67.walkInOptimizedOrder(realMatrixChangingVisitor76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        java.lang.String str33 = array2DRowRealMatrix32.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Array2DRowRealMatrix{{10.0,1.0,32.0,100.0,10.0,10.0},{10.0,1.0,32.0,100.0,10.0,10.0},{10.0,1.0,32.0,100.0,10.0,10.0},{10.0,1.0,32.0,100.0,10.0,10.0}}" + "'", str33.equals("Array2DRowRealMatrix{{10.0,1.0,32.0,100.0,10.0,10.0},{10.0,1.0,32.0,100.0,10.0,10.0},{10.0,1.0,32.0,100.0,10.0,10.0},{10.0,1.0,32.0,100.0,10.0,10.0}}"));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        java.lang.String[] strArray1 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: " };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix33.scalarAdd((double) (short) -1);
        org.apache.commons.math.linear.RealVector realVector37 = blockRealMatrix35.getRowVector(0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        blockRealMatrix67.multiplyEntry((int) (short) 1, (int) (byte) -1, (double) (-1));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix67.copy();
        int[] intArray79 = new int[] { (byte) 1, '#', (byte) -1 };
        int[] intArray84 = new int[] { 100, '#', (short) 1, (short) 10 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix85 = blockRealMatrix67.getSubMatrix(intArray79, intArray84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker3 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker4 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker3);
        org.junit.Assert.assertNull(vectorialConvergenceChecker4);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.lang.Class<?> wildcardClass6 = objArray4.getClass();
        java.text.ParseException parseException7 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray4);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException("", objArray4);
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray10);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException19 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray18);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray18);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray18);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException27 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray26);
        java.lang.IllegalArgumentException illegalArgumentException28 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray26);
        java.lang.ArithmeticException arithmeticException29 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray26);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException21, "", objArray26);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(throwable13, localizable14, objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException8, doubleArray10, "", objArray26);
        double[] doubleArray34 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix35 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray34);
        double[] doubleArray37 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix38 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray37);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray34, doubleArray37);
        double[] doubleArray40 = vectorialPointValuePair39.getPointRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException32, doubleArray40);
        java.lang.String str42 = functionEvaluationException41.getPattern();
        java.lang.RuntimeException runtimeException43 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) functionEvaluationException41);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException41);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(parseException7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(bigMatrix11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException19);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException27);
        org.junit.Assert.assertNotNull(illegalArgumentException28);
        org.junit.Assert.assertNotNull(arithmeticException29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(bigMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(bigMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{0}" + "'", str42.equals("{0}"));
        org.junit.Assert.assertNotNull(runtimeException43);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException3 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray2);
        java.lang.IllegalArgumentException illegalArgumentException4 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray2);
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException9 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray8);
        java.lang.IllegalArgumentException illegalArgumentException10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException4, localizable5, objArray8);
        try {
            java.lang.String str12 = mathRuntimeException11.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException3);
        org.junit.Assert.assertNotNull(illegalArgumentException4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException9);
        org.junit.Assert.assertNotNull(illegalArgumentException10);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix67.scalarAdd(0.0d);
        int int71 = blockRealMatrix67.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor72 = null;
        try {
            double double77 = blockRealMatrix67.walkInRowOrder(realMatrixChangingVisitor72, 1000, (int) (short) 0, (int) (short) 1, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1,000 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        double[] doubleArray6 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray13 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray20 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray27 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray34 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray41 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[][] doubleArray42 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34, doubleArray41 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix43, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix47 = array2DRowRealMatrix43.scalarAdd((double) ' ');
        int int48 = array2DRowRealMatrix43.getRowDimension();
        double[] doubleArray55 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray62 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray69 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray76 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray83 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[] doubleArray90 = new double[] { (short) 1, 10.0d, (-1.0d), 1L, (byte) 0, '#' };
        double[][] doubleArray91 = new double[][] { doubleArray55, doubleArray62, doubleArray69, doubleArray76, doubleArray83, doubleArray90 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix92 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray91);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix92, (int) (short) 0);
        int int95 = array2DRowRealMatrix92.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix96 = array2DRowRealMatrix43.add(array2DRowRealMatrix92);
        org.apache.commons.math.linear.RealMatrix realMatrix97 = array2DRowRealMatrix96.transpose();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor98 = null;
        try {
            double double99 = array2DRowRealMatrix96.walkInColumnOrder(realMatrixChangingVisitor98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 6 + "'", int95 == 6);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix96);
        org.junit.Assert.assertNotNull(realMatrix97);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
        double double3 = array2DRowRealMatrix0.getTrace();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix4, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5);
        int int7 = array2DRowRealMatrix4.getColumnDimension();
        double double8 = array2DRowRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix4);
        double[] doubleArray11 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix12 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray11);
        double[] doubleArray14 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray14);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray14);
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException22 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray21);
        java.lang.IllegalArgumentException illegalArgumentException23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray21);
        java.lang.ArithmeticException arithmeticException24 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray21);
        org.apache.commons.math.linear.BigMatrix bigMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray11);
        org.apache.commons.math.linear.RealVector realVector27 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray11);
        try {
            org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix0.preMultiply(realVector27);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(bigMatrix12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(bigMatrix15);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException22);
        org.junit.Assert.assertNotNull(illegalArgumentException23);
        org.junit.Assert.assertNotNull(arithmeticException24);
        org.junit.Assert.assertNotNull(bigMatrix26);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test82");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) 10, (int) (byte) 1);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test83");
        double[] doubleArray2 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix3 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray2);
        double[] doubleArray5 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray5);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray5);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray12);
        java.lang.IllegalArgumentException illegalArgumentException14 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray12);
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, "", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.optimization.OptimizationException: ", objArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(bigMatrix3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(bigMatrix6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException13);
        org.junit.Assert.assertNotNull(illegalArgumentException14);
        org.junit.Assert.assertNotNull(arithmeticException15);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test84");
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray4);
        java.lang.Class<?> wildcardClass6 = objArray4.getClass();
        java.text.ParseException parseException7 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray4);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray12);
        java.lang.Class<?> wildcardClass14 = objArray12.getClass();
        java.text.ParseException parseException15 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException("", objArray12);
        org.apache.commons.math.exception.Localizable localizable17 = mathRuntimeException16.getLocalizablePattern();
        java.lang.Object[] objArray18 = null;
        java.io.EOFException eOFException19 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable17, objArray18);
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException26 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray25);
        java.lang.Class<?> wildcardClass27 = objArray25.getClass();
        java.text.ParseException parseException28 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException7, localizable17, objArray25);
        double[] doubleArray38 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray45 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray52 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray59 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray60 = new double[][] { doubleArray38, doubleArray45, doubleArray52, doubleArray59 };
        org.apache.commons.math.linear.RealMatrix realMatrix61 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray60);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray60);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60, true);
        org.apache.commons.math.linear.RealMatrix realMatrix65 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray60);
        org.apache.commons.math.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.MathRuntimeException(localizable17, (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.exception.Localizable localizable68 = null;
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable68, objArray69);
        java.lang.Object[] objArray71 = maxIterationsExceededException70.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(1000, localizable17, objArray71);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(parseException7);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(parseException15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(eOFException19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(parseException28);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(realMatrix65);
        org.junit.Assert.assertNotNull(objArray71);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test85");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray1);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) bigMatrix2, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test86");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        boolean boolean69 = blockRealMatrix67.isSquare();
        double[] doubleArray70 = null;
        try {
            double[] doubleArray71 = blockRealMatrix67.preMultiply(doubleArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test87");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException9 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray8);
        java.lang.IllegalArgumentException illegalArgumentException10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray8);
        java.lang.ArithmeticException arithmeticException11 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray8);
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException17 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray16);
        java.lang.IllegalArgumentException illegalArgumentException18 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray16);
        java.lang.ArithmeticException arithmeticException19 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray16);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException11, "", objArray16);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable3, localizable4, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable1, localizable2, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.linear.MatrixIndexException: ", objArray16);
        java.lang.Object[] objArray24 = convergenceException23.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException9);
        org.junit.Assert.assertNotNull(illegalArgumentException10);
        org.junit.Assert.assertNotNull(arithmeticException11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException17);
        org.junit.Assert.assertNotNull(illegalArgumentException18);
        org.junit.Assert.assertNotNull(arithmeticException19);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test88");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = null;
        try {
            array2DRowRealMatrix32.setRowMatrix((int) (byte) 1, realMatrix34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test89");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, 0.0d);
        double[] doubleArray5 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray5);
        double[] doubleArray8 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray8);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray8);
        double[] doubleArray12 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray12);
        double[] doubleArray15 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix16 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray15);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray15);
        double[] doubleArray18 = vectorialPointValuePair17.getPointRef();
        boolean boolean19 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair10, vectorialPointValuePair17);
        double[] doubleArray20 = vectorialPointValuePair17.getPoint();
        double[] doubleArray21 = vectorialPointValuePair17.getPoint();
        double[] doubleArray22 = vectorialPointValuePair17.getValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(bigMatrix6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(bigMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(bigMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(bigMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test90");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        int int33 = blockRealMatrix31.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test91");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        double[] doubleArray40 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray47 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray54 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray61 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray62 = new double[][] { doubleArray40, doubleArray47, doubleArray54, doubleArray61 };
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix33.subtract(blockRealMatrix67);
        double[] doubleArray70 = blockRealMatrix67.getRow((int) (short) 0);
        blockRealMatrix67.multiplyEntry((int) (short) 1, (int) (byte) -1, (double) (-1));
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix67.copy();
        boolean boolean76 = blockRealMatrix75.isSquare();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test92");
        double[] doubleArray6 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray13 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray20 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[] doubleArray27 = new double[] { 10L, 1.0d, ' ', 100.0f, 10, 10L };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix33.scalarAdd((double) (short) -1);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(0.0d);
        double[] doubleArray41 = new double[] { (byte) 0, (-1.0d), 1.0d };
        org.apache.commons.math.linear.RealVector realVector42 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException37, doubleArray41);
        boolean boolean45 = blockRealMatrix35.equals((java.lang.Object) functionEvaluationException44);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix35, (int) (short) 0);
        double[] doubleArray49 = blockRealMatrix35.getRow(0);
        org.apache.commons.math.linear.RealVector realVector50 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test93");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '4');
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException7 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray6);
        java.lang.Class<?> wildcardClass8 = objArray6.getClass();
        java.text.ParseException parseException9 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray6);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException("", objArray6);
        double[] doubleArray12 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray12);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException21 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray20);
        java.lang.IllegalArgumentException illegalArgumentException22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray20);
        java.lang.ArithmeticException arithmeticException23 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray20);
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException29 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray28);
        java.lang.IllegalArgumentException illegalArgumentException30 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray28);
        java.lang.ArithmeticException arithmeticException31 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray28);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException23, "", objArray28);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(throwable15, localizable16, objArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException10, doubleArray12, "", objArray28);
        double[] doubleArray36 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix37 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray36);
        double[] doubleArray39 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix40 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray39);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray39);
        double[] doubleArray42 = vectorialPointValuePair41.getPointRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException34, doubleArray42);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException49 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray48);
        java.lang.Class<?> wildcardClass50 = objArray48.getClass();
        java.text.ParseException parseException51 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray48);
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException("", objArray48);
        org.apache.commons.math.exception.Localizable localizable53 = mathRuntimeException52.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException60 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray59);
        java.io.IOException iOException61 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) arrayIndexOutOfBoundsException60);
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException66 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray65);
        java.lang.IllegalArgumentException illegalArgumentException67 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray65);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException68 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray65);
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1.0f), (byte) 1, (byte) 0, arrayIndexOutOfBoundsException60, "hi!" };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable54, objArray69);
        java.lang.Object[] objArray71 = convergenceException70.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, localizable53, objArray71);
        org.apache.commons.math.exception.Localizable localizable73 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException78 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray77);
        java.lang.IllegalArgumentException illegalArgumentException79 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray77);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException80 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable73, objArray77);
        org.apache.commons.math.MathRuntimeException mathRuntimeException82 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException1, localizable53, objArray77);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(parseException9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(bigMatrix13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException21);
        org.junit.Assert.assertNotNull(illegalArgumentException22);
        org.junit.Assert.assertNotNull(arithmeticException23);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException29);
        org.junit.Assert.assertNotNull(illegalArgumentException30);
        org.junit.Assert.assertNotNull(arithmeticException31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(bigMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(bigMatrix40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(parseException51);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException60);
        org.junit.Assert.assertNotNull(iOException61);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException66);
        org.junit.Assert.assertNotNull(illegalArgumentException67);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException78);
        org.junit.Assert.assertNotNull(illegalArgumentException79);
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test94");
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException8 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray7);
        java.lang.Class<?> wildcardClass9 = objArray7.getClass();
        java.text.ParseException parseException10 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException("", objArray7);
        double[] doubleArray13 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray13);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException22 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray21);
        java.lang.IllegalArgumentException illegalArgumentException23 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray21);
        java.lang.ArithmeticException arithmeticException24 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray21);
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException30 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray29);
        java.lang.IllegalArgumentException illegalArgumentException31 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray29);
        java.lang.ArithmeticException arithmeticException32 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) arithmeticException24, "", objArray29);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(throwable16, localizable17, objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException11, doubleArray13, "", objArray29);
        double[] doubleArray37 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix38 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray37);
        double[] doubleArray40 = new double[] { 10 };
        org.apache.commons.math.linear.BigMatrix bigMatrix41 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray40);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray40);
        double[] doubleArray43 = vectorialPointValuePair42.getPointRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException35, doubleArray43);
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException50 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray49);
        java.lang.Class<?> wildcardClass51 = objArray49.getClass();
        java.text.ParseException parseException52 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.MathRuntimeException("", objArray49);
        org.apache.commons.math.exception.Localizable localizable54 = mathRuntimeException53.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException61 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray60);
        java.io.IOException iOException62 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) arrayIndexOutOfBoundsException61);
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException67 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray66);
        java.lang.IllegalArgumentException illegalArgumentException68 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray66);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException69 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray66);
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1.0f), (byte) 1, (byte) 0, arrayIndexOutOfBoundsException61, "hi!" };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable55, objArray70);
        java.lang.Object[] objArray72 = convergenceException71.getArguments();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, localizable54, objArray72);
        java.lang.Object[] objArray79 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException80 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray79);
        java.lang.Class<?> wildcardClass81 = objArray79.getClass();
        java.text.ParseException parseException82 = org.apache.commons.math.MathRuntimeException.createParseException(0, "", objArray79);
        org.apache.commons.math.MathRuntimeException mathRuntimeException83 = new org.apache.commons.math.MathRuntimeException("", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException("", objArray79);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException85 = new org.apache.commons.math.linear.MatrixIndexException(localizable54, objArray79);
        java.lang.Object[] objArray87 = new java.lang.Object[] {};
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException88 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray87);
        java.lang.NullPointerException nullPointerException89 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable54, objArray87);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException90 = new org.apache.commons.math.FunctionEvaluationException((double) '#', "org.apache.commons.math.MathRuntimeException$8: ", objArray87);
        java.lang.IllegalArgumentException illegalArgumentException91 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.linear.MatrixIndexException: ", objArray87);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(parseException10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(bigMatrix14);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException22);
        org.junit.Assert.assertNotNull(illegalArgumentException23);
        org.junit.Assert.assertNotNull(arithmeticException24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException30);
        org.junit.Assert.assertNotNull(illegalArgumentException31);
        org.junit.Assert.assertNotNull(arithmeticException32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(bigMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(bigMatrix41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(parseException52);
        org.junit.Assert.assertNotNull(localizable54);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException61);
        org.junit.Assert.assertNotNull(iOException62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException67);
        org.junit.Assert.assertNotNull(illegalArgumentException68);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException80);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(parseException82);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException88);
        org.junit.Assert.assertNotNull(nullPointerException89);
        org.junit.Assert.assertNotNull(illegalArgumentException91);
    }
}

