import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException28.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { "", convergenceException41, 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34, "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable29, objArray44);
        java.lang.String str48 = maxIterationsExceededException47.toString();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable15, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 10.0f, true);
        java.lang.Number number55 = numberIsTooLargeException54.getArgument();
        java.lang.Object[] objArray56 = numberIsTooLargeException54.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable15, objArray56);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.13309280691923742d, (java.lang.Number) 0.0021347737482555044d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str48.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 0.0f + "'", number55.equals(0.0f));
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable36 = outOfRangeException35.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException41);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] { "", convergenceException48, 1 };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException41, "hi!", objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable36, objArray51);
        java.lang.String str55 = maxIterationsExceededException54.toString();
        java.lang.Throwable[] throwableArray56 = maxIterationsExceededException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable22, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable6, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(97, "9aec7bbe61", (java.lang.Object[]) throwableArray56);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str55.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray56);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-1.065917938003058d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double6 = randomDataImpl1.nextBeta((double) 26, 1.6002109203213934d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int[] intArray10 = randomDataImpl1.nextPermutation(730414245, 2147483647);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than the maximum (730,414,245): permutation size (2,147,483,647) exceeds permuation domain (730,414,245)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9067170842947643d + "'", double6 == 0.9067170842947643d);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.cumulativeProbability(0.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator(32L);
//        try {
//            double double8 = normalDistributionImpl0.inverseCumulativeProbability(1.4299077186505331d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.43 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.31157991010473834d) + "'", double4 == (-0.31157991010473834d));
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 6.2618158542110685E28d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5230570971461214d, (java.lang.Number) (-0.7062759960992602d), true);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextF(0.13643148660018825d, 9.786480471548866E10d);
//        try {
//            int int10 = randomDataImpl0.nextHypergeometric((int) (short) -1, 0, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.546742589091753E-4d + "'", double6 == 1.546742589091753E-4d);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.004809337296120825d, number2, false);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure();
//        double double12 = randomDataImpl0.nextF((double) 1.0f, 0.1751505484133071d);
//        try {
//            long long15 = randomDataImpl0.nextLong((long) 27, 23L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 27 is larger than, or equal to, the maximum (23): lower bound (27) must be strictly less than upper bound (23)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 15.327263349792572d + "'", double6 == 15.327263349792572d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "09b7ddfec394522058927313a803ae07de6f25b5aec681c70f1b9fabe0910bff2e39a98da03fc4f2adeba713e07e453b64b7" + "'", str8.equals("09b7ddfec394522058927313a803ae07de6f25b5aec681c70f1b9fabe0910bff2e39a98da03fc4f2adeba713e07e453b64b7"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.146039594207097d + "'", double12 == 5.146039594207097d);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1853863619, 5.870685127143877d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(2147483647);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 90L, (java.lang.Number) (-1.0d), false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 90 is larger than, or equal to, the maximum (-1)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 90 is larger than, or equal to, the maximum (-1)"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.cos(17.986548194746224d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.650155137110211d + "'", double1 == 0.650155137110211d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1218447478451852d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6980958750986321d + "'", double1 == 1.6980958750986321d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, 26L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 26L + "'", long2 == 26L);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextF(0.13643148660018825d, 9.786480471548866E10d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43L + "'", long3 == 43L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.802725602251779E-9d + "'", double6 == 8.802725602251779E-9d);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.9999999954373608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6336266500948113E-9d + "'", double1 == 2.6336266500948113E-9d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.max(9.786480471231227E10d, 1.746366256758777E-223d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.786480471231227E10d + "'", double2 == 9.786480471231227E10d);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) '#');
//        java.lang.String str7 = randomDataImpl1.nextHexString(5);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "367935eec4a583d0607576524327866dd68" + "'", str5.equals("367935eec4a583d0607576524327866dd68"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ed789" + "'", str7.equals("ed789"));
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextF((double) 1.0f, 10.0d);
//        double double9 = randomDataImpl0.nextGaussian(0.0d, (double) 26.0f);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 42L + "'", long3 == 42L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.35080670894622346d + "'", double6 == 0.35080670894622346d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.187093273162083d + "'", double9 == 6.187093273162083d);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextUniform(1.5707963267948966d, (double) 6);
//        int int12 = randomDataImpl0.nextInt(29, 2147483647);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(100);
//        double double17 = randomDataImpl0.nextUniform(0.5058623118433196d, 0.9998878083470994d);
//        double double20 = randomDataImpl0.nextBeta((double) 35, 50.498986710526204d);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 13.031649665863478d + "'", double6 == 13.031649665863478d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.988348979682566d + "'", double9 == 3.988348979682566d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 975580464 + "'", int12 == 975580464);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "316fe0c07aac8394cdfcd517e5ec00af2f5a21b851b9bacde610706ba0033a345bd908732f953e1cdcdb8b2ce18b96b5d254" + "'", str14.equals("316fe0c07aac8394cdfcd517e5ec00af2f5a21b851b9bacde610706ba0033a345bd908732f953e1cdcdb8b2ce18b96b5d254"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9018499561574387d + "'", double17 == 0.9018499561574387d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.39000409689567717d + "'", double20 == 0.39000409689567717d);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric((int) 'a', (int) '4', (int) '4');
//        double double7 = randomDataImpl0.nextUniform(2.718281828459045d, 3.1570758432947725d);
//        int int10 = randomDataImpl0.nextInt((int) (short) 1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure(26L);
//        double double15 = randomDataImpl0.nextBeta((double) 2147483647, 8.81869321993664d);
//        java.lang.String str17 = randomDataImpl0.nextHexString(10);
//        double double20 = randomDataImpl0.nextGaussian((-14.386147739632968d), (double) 14L);
//        int int23 = randomDataImpl0.nextZipf((int) (short) 100, 2.774646749383381d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 28 + "'", int4 == 28);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.1412271856036407d + "'", double7 == 3.1412271856036407d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9999999953901828d + "'", double15 == 0.9999999953901828d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "b2c1a4a9e0" + "'", str17.equals("b2c1a4a9e0"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-45.30737554348216d) + "'", double20 == (-45.30737554348216d));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.786480471231227E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 312833.5095738822d + "'", double1 == 312833.5095738822d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        java.lang.Object[] objArray20 = new java.lang.Object[] { "", convergenceException17, 1 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10, "hi!", objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, "", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable30 = outOfRangeException29.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException42.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { "", convergenceException42, 1 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35, "hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable30, objArray45);
        java.lang.String str49 = maxIterationsExceededException48.toString();
        java.lang.Throwable[] throwableArray50 = maxIterationsExceededException48.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(40, localizable24, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = maxIterationsExceededException51.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str49.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(localizable52);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.5574077246549023d), (double) 3L);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double16 = randomDataImpl0.nextBeta(5.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.962");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 38L + "'", long3 == 38L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-5.64022627330037d) + "'", double6 == (-5.64022627330037d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8242197320272328d + "'", double9 == 0.8242197320272328d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-2.5042364827510752d) + "'", double13 == (-2.5042364827510752d));
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException4.getGeneralPattern();
        java.lang.Class<?> wildcardClass6 = localizable5.getClass();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.6665207205746262d, (java.lang.Number) 1.1189396031849521d, true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.760472270277511d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37196069675515364d + "'", double1 == 0.37196069675515364d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 4, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.012255014605283644d, (java.lang.Number) (byte) 10, (java.lang.Number) 57679.89170767657d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5788569702133275d + "'", double1 == 4.5788569702133275d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { "", convergenceException9, 1 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, "hi!", objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException2.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 10L, number17, (java.lang.Number) 3.289152467414951d);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable15);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.0f, (java.lang.Number) 100, (java.lang.Number) 24L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 24L, (java.lang.Number) 1, true);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] { "", convergenceException54, 1 };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47, "hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable42, objArray57);
        java.lang.String str61 = maxIterationsExceededException60.toString();
        java.lang.Throwable[] throwableArray62 = maxIterationsExceededException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable28, (java.lang.Object[]) throwableArray62);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, localizable28, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = mathException65.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65);
        java.lang.Class<?> wildcardClass68 = mathException65.getClass();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str61.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        int int6 = randomDataImpl0.nextPascal(1, 0.0d);
//        long long9 = randomDataImpl0.nextLong(0L, (long) (byte) 1);
//        randomDataImpl0.reSeedSecure(10L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 36L + "'", long3 == 36L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { "", convergenceException16, 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, "hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", objArray19);
        java.lang.String str23 = mathException22.getPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) (short) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable40 = outOfRangeException39.getGeneralPattern();
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51);
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException52.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "", convergenceException52, 1 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45, "hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable40, objArray55);
        java.lang.String str59 = maxIterationsExceededException58.toString();
        java.lang.Throwable[] throwableArray60 = maxIterationsExceededException58.getSuppressed();
        java.lang.Throwable[] throwableArray61 = maxIterationsExceededException58.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22, localizable28, (java.lang.Object[]) throwableArray61);
        java.lang.Object[] objArray63 = mathException22.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable64 = mathException22.getGeneralPattern();
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) 23L, (java.lang.Number) 2.7312629036686165d, number67);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str59.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(localizable64);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 20, (float) 77L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.0263532332847123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.334438934814619d, 0.017740155652700977d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.030145732037903d + "'", double2 == 1.030145732037903d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        java.lang.Throwable[] throwableArray4 = mathException3.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("e7d72934428306d7d2a1468c8775fac3b7a7da777c2ac5a92eeeedc54afd920e13dca09cd90c7d264212eec01b10dc3a6cc5", (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.log(50.498986710526204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9219532709419114d + "'", double1 == 3.9219532709419114d);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextUniform(1.5707963267948966d, (double) 6);
//        int int12 = randomDataImpl0.nextInt(29, 2147483647);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(100);
//        try {
//            int int17 = randomDataImpl0.nextSecureInt((int) (short) 100, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 59L + "'", long3 == 59L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 15.535261176772092d + "'", double6 == 15.535261176772092d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.5729541456585525d + "'", double9 == 3.5729541456585525d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1001674648 + "'", int12 == 1001674648);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "90ed7a3cc79c3d1c0cb596545a00684c80d18883a008022233c60988181a4dfb2b56842b202de0e5c161ceb6b117e3683563" + "'", str14.equals("90ed7a3cc79c3d1c0cb596545a00684c80d18883a008022233c60988181a4dfb2b56842b202de0e5c161ceb6b117e3683563"));
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure(100L);
//        double double13 = randomDataImpl0.nextGamma((double) 30, 0.9998878083470994d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 59L + "'", long3 == 59L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.24461610757801d + "'", double6 == 3.24461610757801d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4c8bcbc81060d341f494d927ab154eb5c5b8004cec238d80704c1f716d8ee0068e0c9d4bfdbdc7361a445ce785f4265df6d6" + "'", str8.equals("4c8bcbc81060d341f494d927ab154eb5c5b8004cec238d80704c1f716d8ee0068e0c9d4bfdbdc7361a445ce785f4265df6d6"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 36.964851376216764d + "'", double13 == 36.964851376216764d);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.6523739067759445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.578042238027644d + "'", double1 == 0.578042238027644d);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextF((double) 1.0f, 10.0d);
//        randomDataImpl0.reSeed(66L);
//        try {
//            int int11 = randomDataImpl0.nextBinomial((-1), 0.012255014605283644d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.50801851189572d + "'", double6 == 0.50801851189572d);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        int int4 = randomDataImpl0.nextPascal(4, 0.0d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl5.cumulativeProbability(0.0d);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5640429512205467d) + "'", double8 == (-0.5640429512205467d));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException8.getGeneralPattern();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] { "", convergenceException21, 1 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "hi!", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable9, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(8, localizable3, objArray24);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("4b477da7ff", objArray24);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray24);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.5574077246549023d), (double) 3L);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double15 = normalDistributionImpl12.density((double) 39L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 62L + "'", long3 == 62L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 24.39430938676046d + "'", double6 == 24.39430938676046d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.8177901541576311d + "'", double9 == 1.8177901541576311d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-3.870894398007564d) + "'", double13 == (-3.870894398007564d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.7316891071729E-41d + "'", double15 == 2.7316891071729E-41d);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) '4', 1287.8755425951492d, 1.6673845734742283d, 24);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        int int4 = randomDataImpl0.nextPascal(4, 0.0d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl5.cumulativeProbability(0.0d);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double9 = normalDistributionImpl5.getMean();
//        double double10 = normalDistributionImpl5.getStandardDeviation();
//        try {
//            double double13 = normalDistributionImpl5.cumulativeProbability((double) 100, 0.3995411154147387d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.3214764691858589d) + "'", double8 == (-0.3214764691858589d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.7453292519943295d, number1, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.745 is larger than, or equal to, the maximum (null)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.745 is larger than, or equal to, the maximum (null)"));
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double11 = randomDataImpl0.nextF((double) (short) 1, 2.718281828459045d);
//        long long14 = randomDataImpl0.nextSecureLong((long) 9, 67L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 51L + "'", long3 == 51L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.528283699614885d + "'", double6 == 11.528283699614885d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "577c826a443aff16db37520d165a921ceee6594cf42531dd74deb9a74061f7dd3ba1b9cb1639d4340028531f306d2161aaf9" + "'", str8.equals("577c826a443aff16db37520d165a921ceee6594cf42531dd74deb9a74061f7dd3ba1b9cb1639d4340028531f306d2161aaf9"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08128410296435647d + "'", double11 == 0.08128410296435647d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 33L + "'", long14 == 33L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double8 = randomDataImpl0.nextExponential((double) (byte) 100);
//        randomDataImpl0.reSeed((long) 448458535);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 51L + "'", long3 == 51L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.75970632256191d + "'", double6 == 10.75970632256191d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 49.79286123106466d + "'", double8 == 49.79286123106466d);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double2 = org.apache.commons.math.util.FastMath.max(1.6980958750986321d, 382.8226229560662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 382.8226229560662d + "'", double2 == 382.8226229560662d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.sin(1287.8755425951492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1765156419227821d) + "'", double1 == (-0.1765156419227821d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException28.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { "", convergenceException41, 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34, "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable29, objArray44);
        java.lang.String str48 = maxIterationsExceededException47.toString();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable15, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 4, (java.lang.Number) 97L, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str48.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.543080634815244d, 28.0d);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextUniform(1.5707963267948966d, (double) 6);
//        try {
//            long long12 = randomDataImpl0.nextLong(52L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 47L + "'", long3 == 47L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-4.635152887010425d) + "'", double6 == (-4.635152887010425d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.076996102572268d + "'", double9 == 5.076996102572268d);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4L, (java.lang.Number) 52L, false);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException32.getGeneralPattern();
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { "", convergenceException45, 1 };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, "hi!", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable33, objArray48);
        java.lang.String str52 = maxIterationsExceededException51.toString();
        java.lang.Throwable[] throwableArray53 = maxIterationsExceededException51.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable19, (java.lang.Object[]) throwableArray53);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException57);
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64);
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException70);
        org.apache.commons.math.exception.util.Localizable localizable72 = convergenceException71.getGeneralPattern();
        java.lang.Object[] objArray74 = new java.lang.Object[] { "", convergenceException71, 1 };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64, "hi!", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58, "", objArray74);
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException58.getGeneralPattern();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58);
        java.lang.Throwable[] throwableArray80 = convergenceException58.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, (java.lang.Object[]) throwableArray80);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException81);
        org.apache.commons.math.exception.util.Localizable localizable83 = mathIllegalArgumentException81.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str52.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNull(localizable83);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextWeibull(2.7312629036686165d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException28.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { "", convergenceException41, 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34, "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable29, objArray44);
        java.lang.String str48 = maxIterationsExceededException47.toString();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable15, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException50);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray54 = null;
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException55);
        org.apache.commons.math.exception.util.Localizable localizable57 = convergenceException56.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable57, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        java.lang.Throwable[] throwableArray62 = numberIsTooLargeException61.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException51, localizable52, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.exception.util.Localizable localizable64 = mathException63.getSpecificPattern();
        java.lang.Object[] objArray65 = mathException63.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable66 = mathException63.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str48.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNull(localizable64);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNull(localizable66);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) 28, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 65);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable40 = outOfRangeException39.getGeneralPattern();
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51);
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException52.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "", convergenceException52, 1 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45, "hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable40, objArray55);
        java.lang.String str59 = maxIterationsExceededException58.toString();
        java.lang.Throwable[] throwableArray60 = maxIterationsExceededException58.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable26, (java.lang.Object[]) throwableArray60);
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64);
        java.lang.Object[] objArray70 = null;
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException71);
        java.lang.Object[] objArray76 = null;
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException77);
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException78.getGeneralPattern();
        java.lang.Object[] objArray81 = new java.lang.Object[] { "", convergenceException78, 1 };
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException71, "hi!", objArray81);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray81);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException65, "", objArray81);
        org.apache.commons.math.exception.util.Localizable localizable85 = convergenceException65.getGeneralPattern();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException65);
        java.lang.Throwable[] throwableArray87 = convergenceException65.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) throwableArray87);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException89);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str59.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertTrue("'" + localizable85 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable85.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray87);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 40L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2291.831180523293d + "'", double1 == 2291.831180523293d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.414213562373095d, (java.lang.Number) (-0.9111302618846769d), (java.lang.Number) 10.078024923980033d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.9111302618846769d) + "'", number4.equals((-0.9111302618846769d)));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.020725758589058d + "'", double1 == 4.020725758589058d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException28.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { "", convergenceException41, 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34, "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable29, objArray44);
        java.lang.String str48 = maxIterationsExceededException47.toString();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable15, (java.lang.Object[]) throwableArray49);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException66);
        org.apache.commons.math.exception.util.Localizable localizable68 = convergenceException67.getGeneralPattern();
        java.lang.Object[] objArray70 = new java.lang.Object[] { "", convergenceException67, 1 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60, "hi!", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException54, "", objArray70);
        org.apache.commons.math.exception.util.Localizable localizable74 = convergenceException54.getGeneralPattern();
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException54);
        java.lang.Throwable[] throwableArray76 = convergenceException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = mathIllegalArgumentException77.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable78, (java.lang.Number) 64L, (java.lang.Number) 69L, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str48.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5923570746083866d, 1.6449340767586613d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5923570746083868d + "'", double2 == 1.5923570746083868d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.5440211108893698d), (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { "", convergenceException18, 1 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, "hi!", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5);
        java.lang.Throwable[] throwableArray27 = convergenceException5.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(26, "", (java.lang.Object[]) throwableArray27);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31);
        java.lang.String str33 = mathException31.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException31.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable40 = outOfRangeException39.getGeneralPattern();
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51);
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException52.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "", convergenceException52, 1 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45, "hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable40, objArray55);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable34, objArray55);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException28, localizable34, objArray60);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0.0f);
        double double4 = normalDistributionImpl0.getStandardDeviation();
        double double6 = normalDistributionImpl0.inverseCumulativeProbability(0.004809337296120825d);
        normalDistributionImpl0.reseedRandomGenerator((long) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.589244594966013d) + "'", double6 == (-2.589244594966013d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.9708907034521393d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5095203350864208d + "'", double1 == 1.5095203350864208d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.signum(57.3532111788295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.0f, (java.lang.Number) 100, (java.lang.Number) 24L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 24L, (java.lang.Number) 1, true);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] { "", convergenceException54, 1 };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47, "hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable42, objArray57);
        java.lang.String str61 = maxIterationsExceededException60.toString();
        java.lang.Throwable[] throwableArray62 = maxIterationsExceededException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable28, (java.lang.Object[]) throwableArray62);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, localizable28, objArray64);
        java.lang.Number number66 = numberIsTooLargeException12.getMax();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str61.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 1 + "'", number66.equals(1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.0f, (java.lang.Number) 100, (java.lang.Number) 24L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.890375927529153d, (java.lang.Number) (short) 100, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.3776488876755815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8804237038140085d + "'", double1 == 0.8804237038140085d);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextF(0.13643148660018825d, 9.786480471548866E10d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double10 = randomDataImpl0.nextUniform(2.8547881217850706d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2.855 is larger than, or equal to, the maximum (0): lower bound (2.855) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 36L + "'", long3 == 36L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.037482874722921444d + "'", double6 == 0.037482874722921444d);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.997783552913881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.441894297259541d + "'", double1 == 1.441894297259541d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { "", convergenceException18, 1 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, "hi!", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException30.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException42);
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "", convergenceException43, 1 };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36, "hi!", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable31, objArray46);
        java.lang.String str50 = maxIterationsExceededException49.toString();
        java.lang.Throwable[] throwableArray51 = maxIterationsExceededException49.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(40, localizable25, (java.lang.Object[]) throwableArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray51);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str50.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray51);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.0d, (-0.9708907034521393d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.971 is smaller than, or equal to, the minimum (0): standard deviation (-0.971)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 42L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.73927494152050099E18d + "'", double1 == 1.73927494152050099E18d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1693705988362009d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.cumulativeProbability(0.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) 0);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3341881268968549d + "'", double4 == 0.3341881268968549d);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure(100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability((double) 1L, 3.1570758432947725d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        int int18 = randomDataImpl0.nextBinomial(65, 0.5291908692275725d);
//        int int22 = randomDataImpl0.nextHypergeometric(97, 28, 52);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.417339921209184d + "'", double6 == 12.417339921209184d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "c8d9cbc86442c417bdf21f71392ab79e04df5abca39db5d7c79ec75afb2984249760f88da50eed2a46539beeae36e5729d8c" + "'", str8.equals("c8d9cbc86442c417bdf21f71392ab79e04df5abca39db5d7c79ec75afb2984249760f88da50eed2a46539beeae36e5729d8c"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.15785845447387603d + "'", double14 == 0.15785845447387603d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.7438961137930775d + "'", double15 == 1.7438961137930775d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 37 + "'", int18 == 37);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 14 + "'", int22 == 14);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.sin(13.031649665863478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44867220623557635d + "'", double1 == 0.44867220623557635d);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric((int) 'a', (int) '4', (int) '4');
//        randomDataImpl0.reSeedSecure(51L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2561176655412654d + "'", double1 == 1.2561176655412654d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-6.25414637562537d), (java.lang.Number) 1.2130532941206642d, true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException28.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { "", convergenceException41, 1 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34, "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable29, objArray44);
        java.lang.String str48 = maxIterationsExceededException47.toString();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable15, (java.lang.Object[]) throwableArray49);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60);
        java.lang.Object[] objArray65 = null;
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException66);
        org.apache.commons.math.exception.util.Localizable localizable68 = convergenceException67.getGeneralPattern();
        java.lang.Object[] objArray70 = new java.lang.Object[] { "", convergenceException67, 1 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60, "hi!", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException54, "", objArray70);
        org.apache.commons.math.exception.util.Localizable localizable74 = convergenceException54.getGeneralPattern();
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException54);
        java.lang.Throwable[] throwableArray76 = convergenceException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 0.9342923864031678d, (java.lang.Number) 0.0f, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str48.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray76);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double6 = randomDataImpl1.nextGamma((double) 34L, (double) 21L);
//        try {
//            int int10 = randomDataImpl1.nextHypergeometric(0, 10, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 738.7096667636274d + "'", double6 == 738.7096667636274d);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (byte) 1, 3.8104773809653514d);
//        double double7 = randomDataImpl1.nextGaussian(7.360986402388584d, 7.573951125153773d);
//        double double10 = randomDataImpl1.nextGamma((double) 67L, (double) 21L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.783949690791832d + "'", double7 == 10.783949690791832d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1486.5722004217325d + "'", double10 == 1486.5722004217325d);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16);
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { "", convergenceException23, 1 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, "hi!", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable11, objArray26);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable5, objArray26);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 42L, (java.lang.Number) 9.786480471231227E10d, true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2147483647L + "'", long1 == 2147483647L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 72L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 72.0d + "'", double1 == 72.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, (double) (byte) 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2147483647, (java.lang.Number) 2.8639917032921d, false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 1);
//        long long12 = randomDataImpl0.nextLong((long) 52, (long) 2147483647);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6311855384874216d + "'", double6 == 0.6311855384874216d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.35385606653526d + "'", double9 == 0.35385606653526d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 265899492L + "'", long12 == 265899492L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1189396031849523d + "'", double1 == 1.1189396031849523d);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure(100L);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong(94L, 40L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 94 is larger than, or equal to, the maximum (40): lower bound (94) must be strictly less than upper bound (40)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60L + "'", long3 == 60L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 19.319896774978215d + "'", double6 == 19.319896774978215d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0e800d170fa5258f24eb9f70ef3a43cae73c803b08eb0a6c8d9b1a059fc4d39a1b9b3c72353deff1337b79fb4401bf36f8d7" + "'", str8.equals("0e800d170fa5258f24eb9f70ef3a43cae73c803b08eb0a6c8d9b1a059fc4d39a1b9b3c72353deff1337b79fb4401bf36f8d7"));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9999999979999601d, 3.238742509961439d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.238742509961439d + "'", double2 == 3.238742509961439d);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        double double4 = randomDataImpl0.nextCauchy(1.1693705988362009d, 0.21793298745270903d);
//        int int7 = randomDataImpl0.nextZipf((int) 'a', (double) 24L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2574757293357253d + "'", double4 == 1.2574757293357253d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.3776488876755815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.12492169606779d + "'", double1 == 1.12492169606779d);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        int int6 = randomDataImpl0.nextPascal(1, 0.0d);
//        long long9 = randomDataImpl0.nextLong(0L, (long) (byte) 1);
//        int int12 = randomDataImpl0.nextInt((int) (short) -1, 25);
//        int int15 = randomDataImpl0.nextBinomial(7, 0.9999999953901828d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60L + "'", long3 == 60L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 21 + "'", int12 == 21);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) (byte) 1, 3.8104773809653514d);
//        double double7 = randomDataImpl1.nextGaussian(7.360986402388584d, 7.573951125153773d);
//        double double10 = randomDataImpl1.nextBeta(44.227385249772276d, 57679.89170767657d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 11.747208434940198d + "'", double7 == 11.747208434940198d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 7.6980526179671E-4d + "'", double10 == 7.6980526179671E-4d);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1474836470000002E9d + "'", double1 == 2.1474836470000002E9d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long1 = org.apache.commons.math.util.FastMath.round((-3.5095321525104364d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-4L) + "'", long1 == (-4L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((-1));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric((int) 'a', (int) '4', (int) '4');
//        double double7 = randomDataImpl0.nextUniform(2.718281828459045d, 3.1570758432947725d);
//        int int10 = randomDataImpl0.nextInt((int) (short) 1, (int) (byte) 10);
//        double double12 = randomDataImpl0.nextT((double) 4);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.876709894981086d + "'", double7 == 2.876709894981086d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6678693242088992d + "'", double12 == 0.6678693242088992d);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.0d, 64.77736516132902d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextF((double) 1.0f, 10.0d);
//        double double8 = randomDataImpl0.nextChiSquare(10.0d);
//        double double10 = randomDataImpl0.nextExponential(8.525161361065413d);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong((long) (byte) 0, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8437424493338389d + "'", double6 == 0.8437424493338389d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.92772867210578d + "'", double8 == 7.92772867210578d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 17.083159525158628d + "'", double10 == 17.083159525158628d);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 65);
        java.lang.Number number7 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4L, (java.lang.Number) 52L, false);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException32.getGeneralPattern();
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { "", convergenceException45, 1 };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, "hi!", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable33, objArray48);
        java.lang.String str52 = maxIterationsExceededException51.toString();
        java.lang.Throwable[] throwableArray53 = maxIterationsExceededException51.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable19, (java.lang.Object[]) throwableArray53);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException57);
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64);
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException70);
        org.apache.commons.math.exception.util.Localizable localizable72 = convergenceException71.getGeneralPattern();
        java.lang.Object[] objArray74 = new java.lang.Object[] { "", convergenceException71, 1 };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64, "hi!", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58, "", objArray74);
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException58.getGeneralPattern();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException58);
        java.lang.Throwable[] throwableArray80 = convergenceException58.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, (java.lang.Object[]) throwableArray80);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException81);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException81);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str52.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray80);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 61L);
        double double5 = normalDistributionImpl0.cumulativeProbability(0.057827785337894747d);
        normalDistributionImpl0.reseedRandomGenerator((-1L));
        double double9 = normalDistributionImpl0.density(2.876709894981086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5230570971461214d + "'", double5 == 0.5230570971461214d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.006366735359881294d + "'", double9 == 0.006366735359881294d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        java.lang.Object[] objArray20 = new java.lang.Object[] { "", convergenceException17, 1 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10, "hi!", objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, "", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable30 = outOfRangeException29.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException42.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { "", convergenceException42, 1 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35, "hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable30, objArray45);
        java.lang.String str49 = maxIterationsExceededException48.toString();
        java.lang.Throwable[] throwableArray50 = maxIterationsExceededException48.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(40, localizable24, (java.lang.Object[]) throwableArray50);
        java.lang.String str52 = maxIterationsExceededException51.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = maxIterationsExceededException51.getGeneralPattern();
        java.lang.Number number55 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) 7L, number55, true);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str49.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(localizable53);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.5607966601494503d, true);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double6 = randomDataImpl1.nextBeta((double) 26, 1.6002109203213934d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextWeibull(1.7438961137930775d, 0.9262879360252497d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9828822985255968d + "'", double6 == 0.9828822985255968d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.41562130099433503d + "'", double11 == 0.41562130099433503d);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 57.3532111788295d, (java.lang.Number) 2L, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        long long4 = randomDataImpl0.nextLong((long) (byte) 0, 26L);
//        int int7 = randomDataImpl0.nextZipf((int) 'a', 5.0d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 23L + "'", long4 == 23L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double6 = randomDataImpl1.nextBeta((double) 26, 1.6002109203213934d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9841621792253238d + "'", double6 == 0.9841621792253238d);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] { "", convergenceException21, 1 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, "hi!", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable5, objArray24);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        java.lang.Object[] objArray47 = new java.lang.Object[] { "", convergenceException44, 1 };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, "hi!", objArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, "", objArray47);
        java.lang.String str51 = mathException50.getPattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray53);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54);
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException55.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) (short) 0);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable68 = outOfRangeException67.getGeneralPattern();
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException73);
        java.lang.Object[] objArray78 = null;
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException("", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException79);
        org.apache.commons.math.exception.util.Localizable localizable81 = convergenceException80.getGeneralPattern();
        java.lang.Object[] objArray83 = new java.lang.Object[] { "", convergenceException80, 1 };
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException73, "hi!", objArray83);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray83);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable68, objArray83);
        java.lang.String str87 = maxIterationsExceededException86.toString();
        java.lang.Throwable[] throwableArray88 = maxIterationsExceededException86.getSuppressed();
        java.lang.Throwable[] throwableArray89 = maxIterationsExceededException86.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException50, localizable56, (java.lang.Object[]) throwableArray89);
        java.lang.Object[] objArray91 = mathException50.getArguments();
        java.lang.Object[] objArray92 = mathException50.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException(30, localizable5, objArray92);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str87.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray88);
        org.junit.Assert.assertNotNull(throwableArray89);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(objArray92);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        int int6 = randomDataImpl0.nextPascal(1, 0.0d);
//        double double9 = randomDataImpl0.nextCauchy(0.12808828690271637d, (double) 10);
//        randomDataImpl0.reSeedSecure(66L);
//        try {
//            long long14 = randomDataImpl0.nextLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-8.941293733610019d) + "'", double9 == (-8.941293733610019d));
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) '#');
//        int int8 = randomDataImpl1.nextInt(26, 448458535);
//        double double11 = randomDataImpl1.nextWeibull(3.7319094399955625E14d, 0.9999043909854876d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "bb11112091bd0c59b44e15fb67faf915c19" + "'", str5.equals("bb11112091bd0c59b44e15fb67faf915c19"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83338681 + "'", int8 == 83338681);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999043909854856d + "'", double11 == 0.9999043909854856d);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.078024923980033d, (double) 44L);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(7.6980526179671E-4d);
        double[] doubleArray6 = normalDistributionImpl2.sample(3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-129.27489953231017d) + "'", double4 == (-129.27489953231017d));
        org.junit.Assert.assertNotNull(doubleArray6);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure(100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability((double) 1L, 3.1570758432947725d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        int int18 = randomDataImpl0.nextInt((int) (short) -1, 0);
//        int int21 = randomDataImpl0.nextZipf(1, 9.349131989282897E-5d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-12.263591118903719d) + "'", double6 == (-12.263591118903719d));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "475af9feca4db2cb001b3582bed3466e4b8fcb171f684d9d9b891f6c1258ba13238172dea25a009c3a6567a873ddb62422a4" + "'", str8.equals("475af9feca4db2cb001b3582bed3466e4b8fcb171f684d9d9b891f6c1258ba13238172dea25a009c3a6567a873ddb62422a4"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.15785845447387603d + "'", double14 == 0.15785845447387603d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.12121381596034901d + "'", double15 == 0.12121381596034901d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { "", convergenceException16, 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, "hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", objArray19);
        java.lang.String str23 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException22.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNull(localizable24);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 0);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) Double.NaN, (java.lang.Number) 1, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 2.76047227027751d, (java.lang.Number) 4.0f, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number8 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0f + "'", number8.equals(100.0f));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math.util.FastMath.min(4.0f, 4.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.7299794548101768d, 0.15785845447387603d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3578251824529282d + "'", double2 == 1.3578251824529282d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 65);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { "", convergenceException16, 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, "hi!", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable4, objArray19);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 448458535);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.48458535E8d + "'", double1 == 4.48458535E8d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9999043909854856d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403827556101428d + "'", double1 == 0.5403827556101428d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(24);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        java.lang.Throwable[] throwableArray15 = mathException14.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("da82a36e08ce52ad78ea5b4749a6e96d685d3242e000af54639b0ddda1d0fb9bea1dad20e9333cf139030b6ebcc3f1331", (java.lang.Object[]) throwableArray15);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (-2.969250483613804d), (java.lang.Number) 25);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.20727069149606714d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(objArray3);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.cumulativeProbability(0.0d);
//        double double3 = normalDistributionImpl0.sample();
//        double double4 = normalDistributionImpl0.getStandardDeviation();
//        try {
//            double double6 = normalDistributionImpl0.inverseCumulativeProbability((-1.6479095657450595d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.648 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.017139401027895334d) + "'", double3 == (-0.017139401027895334d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) '#');
//        int int8 = randomDataImpl1.nextInt(26, 448458535);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString(9);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1e95aff8e9f4131da1e7698c2d323acfbe6" + "'", str5.equals("1e95aff8e9f4131da1e7698c2d323acfbe6"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 340062848 + "'", int8 == 340062848);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "bdad0f309" + "'", str10.equals("bdad0f309"));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.acos((-12.495074277658304d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4L, (java.lang.Number) 52L, false);
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable34 = outOfRangeException33.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException39);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException45);
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        java.lang.Object[] objArray49 = new java.lang.Object[] { "", convergenceException46, 1 };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException39, "hi!", objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable34, objArray49);
        java.lang.String str53 = maxIterationsExceededException52.toString();
        java.lang.Throwable[] throwableArray54 = maxIterationsExceededException52.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable20, (java.lang.Object[]) throwableArray54);
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException58);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65);
        java.lang.Object[] objArray70 = null;
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException71);
        org.apache.commons.math.exception.util.Localizable localizable73 = convergenceException72.getGeneralPattern();
        java.lang.Object[] objArray75 = new java.lang.Object[] { "", convergenceException72, 1 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65, "hi!", objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray75);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException59, "", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException59.getGeneralPattern();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException59);
        java.lang.Throwable[] throwableArray81 = convergenceException59.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, (java.lang.Object[]) throwableArray81);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException82);
        mathException0.addSuppressed((java.lang.Throwable) mathIllegalArgumentException82);
        org.apache.commons.math.exception.util.Localizable localizable85 = mathException0.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str53.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray81);
        org.junit.Assert.assertNull(localizable85);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample((int) ' ');
        double double3 = normalDistributionImpl0.getStandardDeviation();
        try {
            double[] doubleArray5 = normalDistributionImpl0.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        randomDataImpl0.reSeed();
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(28);
//        int int9 = randomDataImpl0.nextZipf(1, 8.653397151028901d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 76L + "'", long3 == 76L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "afe1d4fe0cdfb7f0b7c29b7e4cea" + "'", str6.equals("afe1d4fe0cdfb7f0b7c29b7e4cea"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 1.891382897E9d, 7.38905609893065d, (int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double3 = normalDistributionImpl0.cumulativeProbability((double) 0.0f);
        double double4 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.reseedRandomGenerator((long) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.0365889718756627d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double8 = randomDataImpl0.nextT((double) (byte) 10);
//        double double10 = randomDataImpl0.nextChiSquare(3.24461610757801d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 76L + "'", long3 == 76L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-14.357022993464614d) + "'", double6 == (-14.357022993464614d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.3459811075068178d) + "'", double8 == (-2.3459811075068178d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5166350453910181d + "'", double10 == 0.5166350453910181d);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10, (java.lang.Number) 12.11232718110484d, (java.lang.Number) 3.1570758432947725d);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.String str6 = outOfRangeException4.toString();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable46 = outOfRangeException45.getGeneralPattern();
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException57);
        org.apache.commons.math.exception.util.Localizable localizable59 = convergenceException58.getGeneralPattern();
        java.lang.Object[] objArray61 = new java.lang.Object[] { "", convergenceException58, 1 };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51, "hi!", objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable46, objArray61);
        java.lang.String str65 = maxIterationsExceededException64.toString();
        java.lang.Throwable[] throwableArray66 = maxIterationsExceededException64.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable32, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException67);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("", objArray71);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException72);
        org.apache.commons.math.exception.util.Localizable localizable74 = convergenceException73.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable74, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        java.lang.Throwable[] throwableArray79 = numberIsTooLargeException78.getSuppressed();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException68, localizable69, (java.lang.Object[]) throwableArray79);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(1891382897, "da82a36e08ce52ad78ea5b4749a6e96d685d3242e000af54639b0ddda1d0fb9bea1dad20e9333cf139030b6ebcc3f1331", (java.lang.Object[]) throwableArray79);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable14, (java.lang.Object[]) throwableArray79);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable8, (java.lang.Object[]) throwableArray79);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.1570758432947725d + "'", number5.equals(3.1570758432947725d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [12.112, 3.157] range" + "'", str6.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [12.112, 3.157] range"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 12.11232718110484d + "'", number7.equals(12.11232718110484d));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str65.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray79);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure();
//        double double12 = randomDataImpl0.nextF(0.9673574250257546d, (double) 40);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.05138741296164d + "'", double6 == 6.05138741296164d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "df782904ce3a3386c0676067b2640f77cddb28823dd3d3251d8f9f37443e545d769328edb54713bd0b0331ab5dda598ec180" + "'", str8.equals("df782904ce3a3386c0676067b2640f77cddb28823dd3d3251d8f9f37443e545d769328edb54713bd0b0331ab5dda598ec180"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.564143392413331d + "'", double12 == 2.564143392413331d);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric((int) 'a', (int) '4', (int) '4');
//        double double7 = randomDataImpl0.nextUniform(2.718281828459045d, 3.1570758432947725d);
//        int int10 = randomDataImpl0.nextInt((int) (short) 1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure(26L);
//        double double15 = randomDataImpl0.nextBeta((double) 2147483647, 8.81869321993664d);
//        double double18 = randomDataImpl0.nextWeibull(1.2348673387385076d, 1.2348673387385076d);
//        try {
//            long long21 = randomDataImpl0.nextLong(4L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than, or equal to, the maximum (0): lower bound (4) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.005335627372182d + "'", double7 == 3.005335627372182d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9999999964303876d + "'", double15 == 0.9999999964303876d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.7572279317026797d + "'", double18 == 0.7572279317026797d);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 7L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9459101490553132d + "'", double1 == 1.9459101490553132d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable39 = outOfRangeException38.getGeneralPattern();
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException44);
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException50);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException51.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { "", convergenceException51, 1 };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException44, "hi!", objArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable39, objArray54);
        java.lang.String str58 = maxIterationsExceededException57.toString();
        java.lang.Throwable[] throwableArray59 = maxIterationsExceededException57.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable25, (java.lang.Object[]) throwableArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException60);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65);
        org.apache.commons.math.exception.util.Localizable localizable67 = convergenceException66.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException71 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable67, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        java.lang.Throwable[] throwableArray72 = numberIsTooLargeException71.getSuppressed();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException61, localizable62, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(1891382897, "da82a36e08ce52ad78ea5b4749a6e96d685d3242e000af54639b0ddda1d0fb9bea1dad20e9333cf139030b6ebcc3f1331", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable7, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException(36, "4c8bcbc81060d341f494d927ab154eb5c5b8004cec238d80704c1f716d8ee0068e0c9d4bfdbdc7361a445ce785f4265df6d6", (java.lang.Object[]) throwableArray72);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str58.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray72);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { "", convergenceException16, 1 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, "hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, "", objArray19);
        java.lang.String str23 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable30 = outOfRangeException29.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException42.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { "", convergenceException42, 1 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35, "hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable30, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        java.lang.Throwable[] throwableArray54 = mathException53.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException49, localizable50, (java.lang.Object[]) throwableArray54);
        mathException22.addSuppressed((java.lang.Throwable) convergenceException55);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.tan(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.58721391515691d) + "'", double1 == (-0.58721391515691d));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure(100L);
//        try {
//            double double12 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 95L + "'", long3 == 95L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.18268118382812d + "'", double6 == 9.18268118382812d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e03647c5f1e69071d4074ea995096cafde669d63e0a9f74b984616aee0c89d056da92c56c913ffecc114f70b02cad1a3d74b" + "'", str8.equals("e03647c5f1e69071d4074ea995096cafde669d63e0a9f74b984616aee0c89d056da92c56c913ffecc114f70b02cad1a3d74b"));
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double6 = randomDataImpl1.nextGamma((double) 34L, (double) 21L);
//        int int10 = randomDataImpl1.nextHypergeometric(14, 0, 0);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 980.9329940228059d + "'", double6 == 980.9329940228059d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric((int) 'a', (int) '4', (int) '4');
//        double double7 = randomDataImpl0.nextUniform(2.718281828459045d, 3.1570758432947725d);
//        int int10 = randomDataImpl0.nextInt((int) (short) 1, (int) (byte) 10);
//        randomDataImpl0.reSeedSecure(26L);
//        double double15 = randomDataImpl0.nextBeta((double) 2147483647, 8.81869321993664d);
//        double double18 = randomDataImpl0.nextUniform((double) (short) 10, 8.474446222051669E27d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.131878344037471d + "'", double7 == 3.131878344037471d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9999999972042467d + "'", double15 == 0.9999999972042467d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.1941735675304523E27d + "'", double18 == 3.1941735675304523E27d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 65);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 29L, (java.lang.Number) 3.941597514286071d, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.12164184119930521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12164184119930521d + "'", double1 == 0.12164184119930521d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.349131989282897E-5d, 28.999999999999996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.223838616982934E-6d + "'", double2 == 3.223838616982934E-6d);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) 'a');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl1.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "397d5b7db603beedd24d31467eb7ab3b74843a613fd8fd7f0a857c77dbecf195fe5fe059857278fb5cadd9efcda428c7d" + "'", str3.equals("397d5b7db603beedd24d31467eb7ab3b74843a613fd8fd7f0a857c77dbecf195fe5fe059857278fb5cadd9efcda428c7d"));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.248699261236361d, (java.lang.Number) (-33.27106466687737d), false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        java.lang.Number number9 = numberIsTooLargeException8.getMax();
        java.lang.Object[] objArray10 = numberIsTooLargeException8.getArguments();
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable46 = outOfRangeException45.getGeneralPattern();
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51);
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException57);
        org.apache.commons.math.exception.util.Localizable localizable59 = convergenceException58.getGeneralPattern();
        java.lang.Object[] objArray61 = new java.lang.Object[] { "", convergenceException58, 1 };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51, "hi!", objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable46, objArray61);
        java.lang.String str65 = maxIterationsExceededException64.toString();
        java.lang.Throwable[] throwableArray66 = maxIterationsExceededException64.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable32, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(localizable16, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException8, "org.apache.commons.math.exception.OutOfRangeException: 100 out of [100, 100] range", (java.lang.Object[]) throwableArray66);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0f) + "'", number9.equals((-1.0f)));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str65.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray66);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        double double6 = randomDataImpl0.nextGaussian((double) 1, (double) 10L);
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.5574077246549023d), (double) 3L);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double16 = randomDataImpl0.nextGamma(1.9618754749065739d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 87L + "'", long3 == 87L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.671718884236839d + "'", double6 == 11.671718884236839d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.5392949808973233d + "'", double9 == 2.5392949808973233d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-2.552273052106918d) + "'", double13 == (-2.552273052106918d));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10, (java.lang.Number) 12.11232718110484d, (java.lang.Number) 3.1570758432947725d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) '#');
//        double double7 = randomDataImpl1.nextT(2.8531355713679543d);
//        int int10 = randomDataImpl1.nextZipf(28, (double) 5);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0d0bbf6205afeed72d36d868cf3b3ebfd8b" + "'", str5.equals("0d0bbf6205afeed72d36d868cf3b3ebfd8b"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0780281332071695d + "'", double7 == 0.0780281332071695d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException30.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException42);
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "", convergenceException43, 1 };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36, "hi!", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable31, objArray46);
        java.lang.String str50 = maxIterationsExceededException49.toString();
        java.lang.Throwable[] throwableArray51 = maxIterationsExceededException49.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable17, (java.lang.Object[]) throwableArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", (java.lang.Object[]) throwableArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("80bc5602a1865c491ea282d80361759ecd49f72ca21ba50434d562b0ce2ea21b0fdf0514db49a2678f360744179a2ee1616b", (java.lang.Object[]) throwableArray51);
        java.lang.String str55 = mathException54.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str50.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.MathException: 80bc5602a1865c491ea282d80361759ecd49f72ca21ba50434d562b0ce2ea21b0fdf0514db49a2678f360744179a2ee1616b" + "'", str55.equals("org.apache.commons.math.MathException: 80bc5602a1865c491ea282d80361759ecd49f72ca21ba50434d562b0ce2ea21b0fdf0514db49a2678f360744179a2ee1616b"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 0.0f, (java.lang.Number) 100, (java.lang.Number) 24L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 24L, (java.lang.Number) 1, true);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (short) 0);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) (byte) 0, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] { "", convergenceException54, 1 };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException47, "hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable42, objArray57);
        java.lang.String str61 = maxIterationsExceededException60.toString();
        java.lang.Throwable[] throwableArray62 = maxIterationsExceededException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable28, (java.lang.Object[]) throwableArray62);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, localizable28, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = mathException65.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65);
        java.lang.String str68 = mathException65.toString();
        org.apache.commons.math.exception.util.Localizable localizable69 = mathException65.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str61.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math.MathException: {0}" + "'", str68.equals("org.apache.commons.math.MathException: {0}"));
        org.junit.Assert.assertNull(localizable69);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) '#');
//        int int8 = randomDataImpl1.nextInt(26, 448458535);
//        try {
//            int int11 = randomDataImpl1.nextInt(340062848, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 340,062,848 is larger than, or equal to, the maximum (10): lower bound (340,062,848) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2db7dd83dac54e905b42273542d5d596179" + "'", str5.equals("2db7dd83dac54e905b42273542d5d596179"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16924872 + "'", int8 == 16924872);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong((long) 0, (long) 'a');
//        int int6 = randomDataImpl0.nextPascal(1, 0.0d);
//        long long9 = randomDataImpl0.nextLong(0L, (long) (byte) 1);
//        double double11 = randomDataImpl0.nextExponential(3.301085896855878E7d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.091908016553615E7d + "'", double11 == 4.091908016553615E7d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.min(13.031649665863478d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        long long1 = org.apache.commons.math.util.FastMath.abs(74L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 74L + "'", long1 == 74L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 65);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getSpecificPattern();
        java.lang.Number number8 = notStrictlyPositiveException6.getArgument();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 65 + "'", number8.equals(65));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.reseedRandomGenerator((long) 4);
        double double4 = normalDistributionImpl0.getStandardDeviation();
        double double6 = normalDistributionImpl0.cumulativeProbability((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str3 = randomDataImpl0.nextSecureHexString(1);
//        long long5 = randomDataImpl0.nextPoisson(0.650155137110211d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9" + "'", str3.equals("9"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { "", convergenceException18, 1 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, "hi!", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 100.0f, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException30.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException42);
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] { "", convergenceException43, 1 };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36, "hi!", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable31, objArray46);
        java.lang.String str50 = maxIterationsExceededException49.toString();
        java.lang.Throwable[] throwableArray51 = maxIterationsExceededException49.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(40, localizable25, (java.lang.Object[]) throwableArray51);
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException58);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65);
        java.lang.Object[] objArray70 = null;
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException71);
        org.apache.commons.math.exception.util.Localizable localizable73 = convergenceException72.getGeneralPattern();
        java.lang.Object[] objArray75 = new java.lang.Object[] { "", convergenceException72, 1 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65, "hi!", objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "hi!", objArray75);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException59, "", objArray75);
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException59.getGeneralPattern();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException59);
        java.lang.Throwable[] throwableArray81 = convergenceException59.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(26, "", (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable25, (java.lang.Object[]) throwableArray81);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range" + "'", str50.equals("org.apache.commons.math.MaxIterationsExceededException:  out of [org.apache.commons.math.ConvergenceException: , 1] range"));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray81);
    }
}

