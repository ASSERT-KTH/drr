import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(100.0d, 0.0039134618669983915d, 10);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        double[] doubleArray11 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray11, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray22 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds28 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray22);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double36 = noBracketingException35.getLo();
        java.lang.Throwable[] throwableArray37 = noBracketingException35.getSuppressed();
        boolean boolean38 = pointValuePair30.equals((java.lang.Object) throwableArray37);
        double[] doubleArray41 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, false);
        double[] doubleArray46 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        double[] doubleArray51 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double[] doubleArray54 = diagonalMatrix48.operate(doubleArray51);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight55 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector56.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, arrayRealVector56);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray51, (int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds63 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray41, doubleArray61);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray41);
        org.apache.commons.math3.optim.PointValuePair pointValuePair67 = new org.apache.commons.math3.optim.PointValuePair(doubleArray41, 0.0d, true);
        boolean boolean68 = simpleValueChecker3.converged(0, pointValuePair30, pointValuePair67);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }
}

