import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math3.util.FastMath.sin(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 100.0d, (double) 100L, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 100]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double[] doubleArray1 = new double[] { 0.0f };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray1, (double) (-1.0f), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (short) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("hi!", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector11 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = diagonalMatrix4.operate(realVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.RealVector realVector6 = null;
        try {
            diagonalMatrix4.setColumnVector((-1), realVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 10, (float) 100L, (float) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) (short) 100, (double) (byte) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 100, (double) 0L, (double) 0, (double) (short) 10, (double) 1, (double) (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        long long1 = org.apache.commons.math3.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (byte) 10, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math3.util.FastMath.asin(10.000000000000002d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) '#', (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [35, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) ' ', 0.0d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.5434049467914646d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((-0.5440211108893698d), (double) (byte) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.45597888911063d + "'", double3 == 99.45597888911063d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-1.0f), (float) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix32, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "hi!", "", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(0.0f, 50, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        try {
            array2DRowRealMatrix32.setEntry((int) (byte) 0, (int) '#', (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition36 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32, 10.000000000000002d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        int[] intArray4 = null;
        int[] intArray9 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray9, (int) (byte) 100);
        int[] intArray12 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix3, intArray4, intArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray34, (double) 100, 0.0d, (double) '4', 1.1102230246251565E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector12.add((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        try {
            org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector16.getSubVector(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor17 = null;
        try {
            double double18 = arrayRealVector14.walkInDefaultOrder(realVectorPreservingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { (byte) -1 };
        double[] doubleArray5 = new double[] { (byte) -1 };
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[][] doubleArray14 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (byte) 100, (java.lang.Object[]) doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 0, (float) 36, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (-1), (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 50, 100.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 0 out of [50, 100] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.278369388163781d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2887003518651174d + "'", double1 == 1.2887003518651174d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        double[][] doubleArray3 = new double[][] {};
        try {
            openMapRealMatrix2.setSubMatrix(doubleArray3, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 50, (int) (byte) 1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException3.getContext();
        int int5 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        try {
            openMapRealMatrix2.setEntry((int) (byte) 1, (int) (byte) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double39 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixChangingVisitor34, (int) (short) 0, 100, (int) (short) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103343d + "'", double1 == 11013.232920103343d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) false, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair0 = null;
        try {
            org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair1 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>(bitsStreamGeneratorPair0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 100, (double) (-1), (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        try {
            double double14 = arrayRealVector11.getEntry((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) -1, (double) (byte) 10, pointValuePairConvergenceChecker2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0f), (double) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((-1.0d));
        double double2 = bracketingStep1.getBracketingStep();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor33 = null;
        try {
            double double38 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixChangingVisitor33, 10, 0, 50, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector12.add((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        try {
            double double19 = arrayRealVector12.getEntry((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        int[] intArray8 = new int[] { (short) -1, (-1), '4', 4, (short) 1 };
        int[] intArray13 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13, (int) (byte) 100);
        double[] doubleArray17 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray19 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray21 = new double[] { (-0.5440211108893698d) };
        double[] doubleArray23 = new double[] { (-0.5440211108893698d) };
        double[][] doubleArray24 = new double[][] { doubleArray17, doubleArray19, doubleArray21, doubleArray23 };
        try {
            openMapRealMatrix2.copySubMatrix(intArray8, intArray15, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) (short) 10, (double) (-0.99999994f), (-0.5440211108893698d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, -0.544]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(pointValuePairConvergenceChecker0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.5434049467914646d, (java.lang.Number) 11013.232920103343d, true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 100, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double double6 = lUDecomposition5.getDeterminant();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) lUDecomposition5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = eigenDecomposition7.getEigenvector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(10, (double) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        int[] intArray9 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray9, (int) (byte) 100);
        int[] intArray12 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11);
        int[] intArray17 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray19 = org.apache.commons.math3.util.MathArrays.copyOf(intArray17, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, intArray12, intArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        double[] doubleArray25 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        try {
            double double28 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray16, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor35 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double40 = array2DRowRealMatrix32.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35, 0, (int) (short) -1, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        try {
            double[] doubleArray7 = diagonalMatrix4.getColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix38 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj39 = null;
        boolean boolean40 = openMapRealMatrix38.equals(obj39);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix32, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = openMapRealMatrix2.walkInRowOrder(realMatrixChangingVisitor6, (int) '4', (int) (byte) -1, (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver2, preconditioner3);
        int int5 = nonLinearConjugateGradientOptimizer4.getIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        double[] doubleArray21 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray21, doubleArray22);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray21, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17, arrayRealVector29);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector12.combineToSelf(0.003913481845644553d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray9, doubleArray11, doubleArray13, doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = diagonalMatrix4.multiply(realMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray13 = new double[] { '#' };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = diagonalMatrix4.multiply(realMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (byte) -1 };
        double[] doubleArray4 = new double[] { (byte) -1 };
        double[] doubleArray6 = new double[] { (byte) -1 };
        double[] doubleArray8 = new double[] { (byte) -1 };
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (byte) -1 };
        double[][] doubleArray13 = new double[][] { doubleArray2, doubleArray4, doubleArray6, doubleArray8, doubleArray10, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray13);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = openMapRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor5, 36, (int) (byte) 10, (int) (short) 0, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (int) (short) -1, orderDirection3, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 10L, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7168146928204138d + "'", double2 == 3.7168146928204138d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double3 = sinc1.value((double) 'a');
        try {
            double[] doubleArray8 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) (-1L), (double) 10, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: bad value for maximum iterations number: 0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.003913481845644553d + "'", double3 == 0.003913481845644553d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix2 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor15 = null;
        try {
            double double16 = arrayRealVector2.walkInDefaultOrder(realVectorPreservingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        try {
            incrementor0.incrementCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix36 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = openMapRealMatrix36.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor38 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double39 = openMapRealMatrix36.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor38);
        try {
            double double44 = array2DRowRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor38, (int) (byte) 10, 36, (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        double[] doubleArray38 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38, true);
        double[] doubleArray43 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        double[] doubleArray46 = diagonalMatrix40.operate(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight47 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray55 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        double[] doubleArray58 = diagonalMatrix52.operate(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight59 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = diagonalMatrix40.multiply(diagonalMatrix52);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix61 = array2DRowRealMatrix32.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(diagonalMatrix60);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor15 = null;
        try {
            double double18 = arrayRealVector14.walkInDefaultOrder(realVectorChangingVisitor15, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 0, 7.930067261567154E14d, (double) (byte) -1, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        mersenneTwister1.clear();
        try {
            int int4 = mersenneTwister1.nextInt((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double[] doubleArray12 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray17 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray22 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray27 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray32 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray37 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray38 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32, doubleArray37 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38, false);
        int int41 = array2DRowRealMatrix40.getColumnDimension();
        boolean boolean42 = array2DRowRealMatrix40.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix40.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix44 = diagonalMatrix4.multiply(realMatrix43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval(100.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int[] intArray0 = null;
        double[] doubleArray3 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix5);
        int[] intArray7 = lUDecomposition6.getPivot();
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition13 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
        int[] intArray14 = lUDecomposition13.getPivot();
        double double15 = org.apache.commons.math3.util.MathArrays.distance(intArray7, intArray14);
        try {
            int int16 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray0, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) '#');
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) (-1), (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.5d + "'", double2 == 4.5d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 50, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.177183820135558d + "'", double2 == 1.177183820135558d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 4, (float) 36, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor17 = null;
        try {
            double double18 = arrayRealVector16.walkInOptimizedOrder(realVectorPreservingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        try {
            diagonalMatrix4.setEntry(0, (int) ' ', (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) 'a', 100);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray5 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        double[] doubleArray13 = diagonalMatrix7.operate(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector15.add((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector2.append(arrayRealVector19);
        try {
            arrayRealVector2.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1), (double) '#', 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        double[] doubleArray25 = pointVectorValuePair23.getKey();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math3.util.FastMath.asin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math3.util.FastMath.pow(2.2250738585072014E-308d, 0.278369388163781d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.28516993925936E-86d + "'", double2 == 2.28516993925936E-86d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        double[] doubleArray11 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition14 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix13, 10.0d);
        org.apache.commons.math3.linear.RealVector realVector18 = eigenDecomposition16.getEigenvector(1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix8, realVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: denominator must be different from 0");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        double double52 = arrayRealVector48.getMaxValue();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (byte) -1 };
        double[] doubleArray5 = new double[] { (byte) -1 };
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[][] doubleArray12 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray12);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray12, (double) 0, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[] doubleArray13 = new double[] { (byte) -1 };
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) -1 };
        double[][] doubleArray20 = new double[][] { doubleArray9, doubleArray11, doubleArray13, doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix7.preMultiply(realMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1.0f), (double) 100, (double) 2147483647, (double) (-1L), (double) 10, (double) 0.9670298f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.147483737329702E9d) + "'", double6 == (-2.147483737329702E9d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math3.util.FastMath.sin(11013.232920103343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9287117556321675d) + "'", double1 == (-0.9287117556321675d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector16.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double[] doubleArray22 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector30);
        double[] doubleArray35 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray40 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        double[] doubleArray43 = diagonalMatrix37.operate(doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector45);
        double double49 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector18.mapSubtractToSelf(0.5434049467914646d);
        try {
            org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector15.projection(realVector51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector12 = null;
        try {
            diagonalMatrix4.setRowVector((int) (byte) -1, realVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        boolean boolean6 = openMapRealMatrix2.isSquare();
        int int7 = openMapRealMatrix2.getColumnDimension();
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        double[] doubleArray15 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        double[] doubleArray18 = diagonalMatrix12.operate(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector20.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector24.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double[] doubleArray30 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray31 = new double[] {};
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray30, doubleArray31);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex37 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray30, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector26, arrayRealVector38);
        double[] doubleArray43 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        double[] doubleArray48 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48, true);
        double[] doubleArray51 = diagonalMatrix45.operate(doubleArray48);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight52 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector53.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, arrayRealVector53);
        double double57 = arrayRealVector26.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector26.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector23.append((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realVector60);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 1, (float) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor69 = null;
        try {
            double double70 = array2DRowRealMatrix68.walkInRowOrder(realMatrixChangingVisitor69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        incrementor0.setMaximalCount((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        double[] doubleArray7 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray8 = new double[] {};
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray8);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector15);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.add((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        try {
            double double7 = openMapRealMatrix2.getEntry((int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector16.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double[] doubleArray22 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector30);
        double[] doubleArray35 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray40 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        double[] doubleArray43 = diagonalMatrix37.operate(doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector45);
        double double49 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector18.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector15.append((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        arrayRealVector18.set((double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition16 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix15);
        int[] intArray17 = lUDecomposition16.getPivot();
        int[] intArray22 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray24 = org.apache.commons.math3.util.MathArrays.copyOf(intArray22, (int) (byte) 100);
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray24);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix4, intArray17, intArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor8, (int) '#', (int) (byte) 1, 3, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        double[] doubleArray25 = pointVectorValuePair23.getSecond();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.177183820135558d, 1.2887003518651174d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) -1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(36, (int) (byte) 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix35.createMatrix((int) (byte) 0, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(3.2710663101885897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.900849165587834d + "'", double1 == 1.900849165587834d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        int[] intArray40 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray42 = org.apache.commons.math3.util.MathArrays.copyOf(intArray40, (int) (byte) 100);
        int[] intArray47 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray49 = org.apache.commons.math3.util.MathArrays.copyOf(intArray47, (int) (byte) 100);
        int[] intArray50 = org.apache.commons.math3.util.MathArrays.copyOf(intArray49);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix35, intArray40, intArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 1L, (double) 0.0f, 0.0d, 99.45597888911063d, Double.NaN, 2.2250738585072014E-308d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        array2DRowRealMatrix32.setEntry((int) (short) 1, 0, (double) (-1.0f));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double40 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixChangingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        float float2 = org.apache.commons.math3.util.Precision.round(0.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray12 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray23 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray23, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds29 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray23);
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray12, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException36 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double37 = noBracketingException36.getLo();
        java.lang.Throwable[] throwableArray38 = noBracketingException36.getSuppressed();
        boolean boolean39 = pointValuePair31.equals((java.lang.Object) throwableArray38);
        double[] doubleArray45 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex50 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray45, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray56 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex61 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray56, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds62 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray45, doubleArray56);
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException69 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double70 = noBracketingException69.getLo();
        java.lang.Throwable[] throwableArray71 = noBracketingException69.getSuppressed();
        boolean boolean72 = pointValuePair64.equals((java.lang.Object) throwableArray71);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat73 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str74 = realMatrixFormat73.getColumnSeparator();
        boolean boolean75 = pointValuePair64.equals((java.lang.Object) str74);
        boolean boolean76 = simpleValueChecker5.converged((int) (byte) 100, pointValuePair31, pointValuePair64);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer77 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer78 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer79 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10, 0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "," + "'", str74.equals(","));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 1L, objArray2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double41 = blockRealMatrix35.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36, (int) (byte) 10, 10, (int) (short) 100, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double[] doubleArray1 = new double[] { (byte) -1 };
        double[] doubleArray3 = new double[] { (byte) -1 };
        double[] doubleArray5 = new double[] { (byte) -1 };
        double[] doubleArray7 = new double[] { (byte) -1 };
        double[] doubleArray9 = new double[] { (byte) -1 };
        double[] doubleArray11 = new double[] { (byte) -1 };
        double[][] doubleArray12 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray12);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, 0.0d, 0.0d, (double) '4', (double) 0.9670298f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 2147483647, 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.330679416656494d) + "'", double2 == (-2.330679416656494d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (-1), 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(2.28516993925936E-86d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.28516993925936E-86d) + "'", double2 == (-2.28516993925936E-86d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long[] longArray5 = new long[] { 3, '#', (short) 0, 0L, 10L };
        long[] longArray11 = new long[] { 3, '#', (short) 0, 0L, 10L };
        long[][] longArray12 = new long[][] { longArray5, longArray11 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray12);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = openMapRealMatrix2.getRowVector((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray59 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray64 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray65 = new double[][] { doubleArray39, doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix67.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix32.add(array2DRowRealMatrix67);
        try {
            array2DRowRealMatrix69.addToEntry((int) (short) 0, (-1), (double) 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 4, (double) (byte) 10, 1.900849165587834d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.random.BitsStreamGenerator bitsStreamGenerator7 = bitsStreamGeneratorPair4.getFirst();
        double double8 = bitsStreamGenerator7.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(bitsStreamGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.2321040789270661d) + "'", double8 == (-0.2321040789270661d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray41 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray46 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray51 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray56 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray61 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray66 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray67 = new double[][] { doubleArray41, doubleArray46, doubleArray51, doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67, false);
        int int70 = array2DRowRealMatrix69.getColumnDimension();
        double[][] doubleArray71 = array2DRowRealMatrix69.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray71);
        try {
            blockRealMatrix35.setRowMatrix((int) (short) 100, blockRealMatrix72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 4 + "'", int70 == 4);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        java.lang.Double double74 = pointValuePair61.getValue();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 11013.232920103343d + "'", double74.equals(11013.232920103343d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        double[] doubleArray73 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray74 = new double[] {};
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray73, doubleArray74);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex80 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray73, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73, arrayRealVector81);
        try {
            array2DRowRealMatrix68.setColumn((-1), doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray10 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray10, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray21 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray21, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds27 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair29 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException34 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double35 = noBracketingException34.getLo();
        java.lang.Throwable[] throwableArray36 = noBracketingException34.getSuppressed();
        boolean boolean37 = pointValuePair29.equals((java.lang.Object) throwableArray36);
        double[] doubleArray43 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray43, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray54 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex59 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray54, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds60 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray54);
        org.apache.commons.math3.optim.PointValuePair pointValuePair62 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException67 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double68 = noBracketingException67.getLo();
        java.lang.Throwable[] throwableArray69 = noBracketingException67.getSuppressed();
        boolean boolean70 = pointValuePair62.equals((java.lang.Object) throwableArray69);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat71 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str72 = realMatrixFormat71.getColumnSeparator();
        boolean boolean73 = pointValuePair62.equals((java.lang.Object) str72);
        boolean boolean74 = simpleValueChecker3.converged((int) (byte) 100, pointValuePair29, pointValuePair62);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer75 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "," + "'", str72.equals(","));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = diagonalMatrix4.walkInRowOrder(realMatrixChangingVisitor8, (int) (byte) 100, (int) (short) 1, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double6 = noBracketingException5.getLo();
        java.lang.Throwable[] throwableArray7 = noBracketingException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        double[] doubleArray37 = new double[] { '#' };
        double[][] doubleArray38 = new double[][] { doubleArray37 };
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray38);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix35, (org.apache.commons.math3.linear.AnyMatrix) realMatrix39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x4 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double37 = array2DRowRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double39 = array2DRowRealMatrix32.walkInOptimizedOrder(realMatrixChangingVisitor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        float float2 = org.apache.commons.math3.util.Precision.round(0.0f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        double[] doubleArray72 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray73 = new double[] {};
        boolean boolean74 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray73);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex75 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray72);
        try {
            double[] doubleArray76 = array2DRowRealMatrix32.preMultiply(doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection25 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.blockInverse((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix2, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x10) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[] doubleArray12 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray17 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray22 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray27 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray32 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray37 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray38 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27, doubleArray32, doubleArray37 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38, false);
        int int41 = array2DRowRealMatrix40.getColumnDimension();
        double[] doubleArray46 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray51 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray56 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray61 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray66 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray71 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray72 = new double[][] { doubleArray46, doubleArray51, doubleArray56, doubleArray61, doubleArray66, doubleArray71 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = array2DRowRealMatrix74.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix40.subtract(array2DRowRealMatrix74);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        try {
            openMapRealMatrix2.multiplyEntry((-1), (int) ' ', (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double[] doubleArray7 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray8 = new double[] {};
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray8);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector15);
        double[] doubleArray20 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        double[] doubleArray25 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        double[] doubleArray28 = diagonalMatrix22.operate(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight29 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector30.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, arrayRealVector30);
        double double34 = arrayRealVector3.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring(",", "{{-1,0},{0,0}}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector2.mapSubtractToSelf(0.5434049467914646d);
        boolean boolean36 = arrayRealVector2.isInfinite();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray2 = new long[] { (-1) };
        long[][] longArray3 = new long[][] { longArray2 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray3);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) longArray3);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix2.subtract(openMapRealMatrix16);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix30 = openMapRealMatrix2.getRowMatrix(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            org.apache.commons.math3.linear.RealVector realVector37 = blockRealMatrix35.getColumnVector((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        java.lang.String str27 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        try {
            double double30 = diagonalMatrix6.getEntry(36, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{{-1,0},{0,0}}" + "'", str27.equals("{{-1,0},{0,0}}"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        long[] longArray6 = new long[] { 10L, (-1L), 0, (short) -1, ' ', 10L };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getLo();
        double double3 = bracketFinder0.getFLo();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix4.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = diagonalMatrix4.getRowMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, arrayRealVector14);
        java.lang.StringBuffer stringBuffer18 = null;
        java.text.FieldPosition fieldPosition19 = null;
        try {
            java.lang.StringBuffer stringBuffer20 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector17, stringBuffer18, fieldPosition19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector16);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 1, (float) 0, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(pointVectorValuePairConvergenceChecker0);
        double[] doubleArray2 = null;
        try {
            double[][] doubleArray4 = gaussNewtonOptimizer1.computeCovariances(doubleArray2, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray59 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray64 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray65 = new double[][] { doubleArray39, doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix67.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix32.add(array2DRowRealMatrix67);
        double[] doubleArray73 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix75 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray73, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition76 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix75);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix75, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = eigenDecomposition78.getD();
        try {
            array2DRowRealMatrix67.setColumnMatrix(1, realMatrix79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x2 but expected 6x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix79);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 100.0f, 49.72798944455531d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getRowMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.append((double) (-1L));
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor15 = null;
        try {
            double double16 = arrayRealVector12.walkInDefaultOrder(realVectorChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        double[] doubleArray25 = diagonalMatrix16.getDataRef();
        double[] doubleArray29 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray30);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex36 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray29, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector37);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.append((double) (-1L));
        try {
            org.apache.commons.math3.linear.RealVector realVector41 = diagonalMatrix16.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.00000000000001d + "'", double1 == 36.00000000000001d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int2 = org.apache.commons.math3.util.FastMath.max(4, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 0.003913481845644553d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double5 = arrayRealVector3.walkInDefaultOrder(realVectorPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix2.subtract(openMapRealMatrix16);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.blockInverse((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix16, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x10) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = openMapRealMatrix13.createMatrix((int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getAbsoluteAccuracy();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        try {
            double double6 = brentSolver0.solve((int) (byte) 0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc3, (double) 50, (double) 0.9670298f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [50, 25.484]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-6d + "'", double1 == 1.0E-6d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", ",", "{", ",", "hi!", "");
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver9 = eigenDecomposition7.getSolver();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(decompositionSolver9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 3 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double37 = array2DRowRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        defaultRealMatrixPreservingVisitor36.start((int) (short) 1, (int) (short) 10, (int) (short) 0, (int) '4', (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (short) 10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray11 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray16 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray21 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray26 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray31 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32, false);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException35 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 10, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException37 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2.2250738585072014E-308d);
        maxCountExceededException35.addSuppressed((java.lang.Throwable) tooManyIterationsException37);
        java.lang.Number number39 = maxCountExceededException35.getMax();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 10 + "'", number39.equals(10));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = diagonalMatrix4.multiply(diagonalMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = openMapRealMatrix2.multiply(realMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (-1.0f));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 100);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException4 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        double[] doubleArray25 = diagonalMatrix16.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor26 = null;
        try {
            double double31 = diagonalMatrix16.walkInColumnOrder(realMatrixChangingVisitor26, 0, (int) ' ', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.append((double) (-1L));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        double[] doubleArray21 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray22 = new double[] {};
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray21, doubleArray22);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray21, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17, arrayRealVector29);
        double[] doubleArray34 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        double[] doubleArray39 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        double[] doubleArray42 = diagonalMatrix36.operate(doubleArray39);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight43 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector44.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, arrayRealVector44);
        double double48 = arrayRealVector17.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.analysis.function.Sinc sinc50 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector44.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc50);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector12.add((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector51);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            double[] doubleArray37 = blockRealMatrix35.getColumn(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray41 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray46 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray51 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray56 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray61 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray66 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray67 = new double[][] { doubleArray41, doubleArray46, doubleArray51, doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67, false);
        int int70 = array2DRowRealMatrix69.getColumnDimension();
        double[][] doubleArray71 = array2DRowRealMatrix69.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray71);
        try {
            blockRealMatrix35.setRowMatrix((int) '4', blockRealMatrix72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 4 + "'", int70 == 4);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            blockRealMatrix35.addToEntry(2147483647, (-1), (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 1, 0.0f, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.subtract(realMatrix34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        boolean boolean6 = openMapRealMatrix2.isSquare();
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray7, doubleArray8 };
        try {
            openMapRealMatrix2.setSubMatrix(doubleArray9, 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0, (double) 4, (-2.28516993925936E-86d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (byte) -1 };
        double[] doubleArray4 = new double[] { (byte) -1 };
        double[] doubleArray6 = new double[] { (byte) -1 };
        double[] doubleArray8 = new double[] { (byte) -1 };
        double[] doubleArray10 = new double[] { (byte) -1 };
        double[] doubleArray12 = new double[] { (byte) -1 };
        double[][] doubleArray13 = new double[][] { doubleArray2, doubleArray4, doubleArray6, doubleArray8, doubleArray10, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray13);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (-0.2321040789270661d), (double) 100.0f, 0.0d, 2.99822295029797d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((double) 10L, (double) 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        int int14 = openMapRealMatrix8.getRowDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.003913481845644553d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector2.mapSubtractToSelf(0.5434049467914646d);
        double double36 = arrayRealVector2.getNorm();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        double[] doubleArray23 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray16, doubleArray23, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(4);
        float float2 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((long) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.9670298f + "'", float2 == 0.9670298f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.exception.ConvergenceException convergenceException0 = new org.apache.commons.math3.exception.ConvergenceException();
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) convergenceException0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        double[] doubleArray37 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray42 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray47 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray52 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray57 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray62 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray63 = new double[][] { doubleArray37, doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63, false);
        int int66 = array2DRowRealMatrix65.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix32, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        double double11 = mersenneTwister6.nextDouble();
        long long12 = mersenneTwister6.nextLong();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.278369388163781d + "'", double11 == 0.278369388163781d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7830967380036616271L + "'", long12 == 7830967380036616271L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1578212823495775d + "'", double1 == 1.1578212823495775d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = openMapRealMatrix11.transpose();
        org.apache.commons.math3.linear.RealVector realVector14 = openMapRealMatrix11.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = openMapRealMatrix17.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor19 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double20 = openMapRealMatrix17.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor19);
        boolean boolean21 = openMapRealMatrix17.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix11.subtract(openMapRealMatrix17);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix25 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = openMapRealMatrix25.transpose();
        org.apache.commons.math3.linear.RealVector realVector28 = openMapRealMatrix25.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix31 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = openMapRealMatrix31.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor33 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double34 = openMapRealMatrix31.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33);
        boolean boolean35 = openMapRealMatrix31.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix25.subtract(openMapRealMatrix31);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix37 = openMapRealMatrix11.subtract(openMapRealMatrix25);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix4, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix37);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        boolean boolean36 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor37 = null;
        try {
            double double38 = array2DRowRealMatrix32.walkInRowOrder(realMatrixChangingVisitor37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = diagonalMatrix24.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix24.scalarAdd(6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 6.283 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix4.getRowMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 7830967380036616271L, 4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 7830967380036616271L, 1.900849165587834d, (double) 36);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        double double11 = mersenneTwister6.nextDouble();
        boolean boolean12 = mersenneTwister6.nextBoolean();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.278369388163781d + "'", double11 == 0.278369388163781d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray39 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray40 = new double[] {};
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray40);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex42 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = array2DRowRealMatrix43.scalarMultiply(9.42477794844185d);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix35.add(realMatrix45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x4 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        double double11 = mersenneTwister6.nextDouble();
        double double12 = mersenneTwister6.nextGaussian();
        boolean boolean13 = mersenneTwister6.nextBoolean();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.278369388163781d + "'", double11 == 0.278369388163781d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.5167245664147402d) + "'", double12 == (-0.5167245664147402d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double35 = array2DRowRealMatrix32.walkInOptimizedOrder(realMatrixChangingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        boolean boolean6 = openMapRealMatrix2.isSquare();
        int int7 = openMapRealMatrix2.getColumnDimension();
        try {
            double[] doubleArray9 = openMapRealMatrix2.getRow((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.multiply(blockRealMatrix36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, number1);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        array2DRowRealMatrix32.setEntry((int) (short) 1, 0, (double) (-1.0f));
        try {
            double double39 = array2DRowRealMatrix32.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector37.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double[] doubleArray43 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray44 = new double[] {};
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray43, doubleArray44);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex50 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray43, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43, arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector39, arrayRealVector51);
        double[] doubleArray56 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray56, true);
        double[] doubleArray61 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix63 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray61, true);
        double[] doubleArray64 = diagonalMatrix58.operate(doubleArray61);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight65 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector66.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61, arrayRealVector66);
        double double70 = arrayRealVector39.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector71.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        double[] doubleArray77 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray78 = new double[] {};
        boolean boolean79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray77, doubleArray78);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex84 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray77, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77, arrayRealVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector73, arrayRealVector85);
        double double88 = arrayRealVector66.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector85);
        org.apache.commons.math3.analysis.function.Sinc sinc90 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double94 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc90, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector85.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc90);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector96 = arrayRealVector85.copy();
        org.apache.commons.math3.linear.RealVector realVector98 = arrayRealVector96.mapSubtract((double) 100L);
        try {
            blockRealMatrix35.setRowVector(3, realVector98);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 49.72798944455531d + "'", double94 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector95);
        org.junit.Assert.assertNotNull(arrayRealVector96);
        org.junit.Assert.assertNotNull(realVector98);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, (int) (short) 0);
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        double[] doubleArray20 = new double[] { (byte) -1 };
        double[] doubleArray22 = new double[] { (byte) -1 };
        double[] doubleArray24 = new double[] { (byte) -1 };
        double[] doubleArray26 = new double[] { (byte) -1 };
        double[] doubleArray28 = new double[] { (byte) -1 };
        double[] doubleArray30 = new double[] { (byte) -1 };
        double[][] doubleArray31 = new double[][] { doubleArray20, doubleArray22, doubleArray24, doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException33 = new org.apache.commons.math3.exception.MathArithmeticException(localizable18, (java.lang.Object[]) doubleArray31);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray17, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        double double11 = mersenneTwister6.nextDouble();
        mersenneTwister6.setSeed((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.278369388163781d + "'", double11 == 0.278369388163781d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        try {
            double double14 = diagonalMatrix4.getEntry(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix4.copy();
        double[] doubleArray10 = diagonalMatrix4.getRow((int) (short) 1);
        double double11 = diagonalMatrix4.getNorm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(Double.NaN, (double) 100.0f, (-0.0d), (double) 0.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(99.45597888911063d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2595063905404449d + "'", double2 == 1.2595063905404449d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector16.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double[] doubleArray22 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector30);
        double[] doubleArray35 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray40 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        double[] doubleArray43 = diagonalMatrix37.operate(doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector45);
        double double49 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector18.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector15.append((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        double double53 = arrayRealVector18.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(100);
        try {
            double double4 = diagonalMatrix1.getEntry(52, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        double[] doubleArray20 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray20);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray20);
        double double23 = org.apache.commons.math3.util.MathArrays.distance(doubleArray8, doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 139.56534896654014d + "'", double23 == 139.56534896654014d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        double[] doubleArray52 = arrayRealVector29.toArray();
        double[] doubleArray58 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex63 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray58, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray66 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix68 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66, true);
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray66);
        try {
            double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray52, doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        int int5 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1195587395 + "'", int5 == 1195587395);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
        int int2 = levenbergMarquardtOptimizer1.getMaxEvaluations();
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray21, true);
        double[] doubleArray27 = pointVectorValuePair26.getPoint();
        try {
            double[][] doubleArray29 = levenbergMarquardtOptimizer1.computeCovariances(doubleArray27, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        int int11 = nelderMeadSimplex10.getDimension();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 1L, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.analysis.function.Sinc sinc35 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc35);
        double double38 = sinc35.value(4.5d);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-0.21722891503668823d) + "'", double38 == (-0.21722891503668823d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.power(4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((-2.28516993925936E-86d), 1.1102230246251565E-16d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray12 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector2.append(arrayRealVector6);
        try {
            arrayRealVector19.setEntry((-1), 1.1102230246251565E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector19);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        double double11 = eigenDecomposition7.getDeterminant();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = eigenDecomposition7.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.0d) + "'", double11 == (-0.0d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) (-1.0d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100.0d, (java.lang.Number) (-1), 0);
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 0, 36.00000000000001d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray5);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, arrayRealVector12);
        try {
            double double14 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        int[] intArray7 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7, (int) (byte) 100);
        int[] intArray14 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14, (int) (byte) 100);
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray16);
        int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray17);
        int[] intArray19 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = openMapRealMatrix2.getSubMatrix(intArray7, intArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray59 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray64 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray65 = new double[][] { doubleArray39, doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix67.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix32.add(array2DRowRealMatrix67);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix72 = array2DRowRealMatrix32.createMatrix(1195587395, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.900849165587834d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 7830967380036616271L, 52);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 100.0d, 1.1102230246251565E-16d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, (int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 9 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        java.lang.String str27 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition35 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix32.copy();
        double[] doubleArray38 = diagonalMatrix32.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix6.add(diagonalMatrix32);
        try {
            double double42 = diagonalMatrix32.getEntry((int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{{-1,0},{0,0}}" + "'", str27.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        int int12 = cMAESOptimizer10.getIterations();
        java.util.List<java.lang.Double> doubleList13 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList14 = cMAESOptimizer10.getStatisticsFitnessHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((-1.0d));
        double double17 = bracketingStep16.getBracketingStep();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep19 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((-1.0d));
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) '#');
        double[] doubleArray27 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray27, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray38 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex43 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray38, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds44 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray27, doubleArray38);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray38, (double) (byte) 10, (-0.9287117556321675d));
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray59 = new org.apache.commons.math3.optim.OptimizationData[] { bracketingStep16, bracketingStep19, simpleBounds21, multiDirectionalSimplex47, nelderMeadSimplex58 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair60 = cMAESOptimizer10.optimize(optimizationDataArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(doubleList13);
        org.junit.Assert.assertNotNull(doubleList14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertNotNull(simpleBounds21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(optimizationDataArray59);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(4);
        mersenneTwister1.setSeed(50);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        java.lang.CharSequence charSequence7 = bitsStreamGeneratorPair4.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence7 + "' != '" + "hi!" + "'", charSequence7.equals("hi!"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.003913481845644553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0039134618669983915d + "'", double1 == 0.0039134618669983915d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 1195587395, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        long[] longArray1 = new long[] { '4' };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 0.0f, (double) (-1L), (double) 1041236929);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.1578212823495775d, 0.003913481845644553d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        double[] doubleArray27 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        double[] doubleArray32 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        double[] doubleArray35 = diagonalMatrix29.operate(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector37.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, arrayRealVector37);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) (short) 0);
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 4, (double) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0000005f + "'", float2 == 4.0000005f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        double double52 = arrayRealVector29.getNorm();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, number1, false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector12.add((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector16.mapDivideToSelf((double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix2.subtract(openMapRealMatrix16);
        double[] doubleArray31 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition34 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix33);
        int[] intArray35 = lUDecomposition34.getPivot();
        double[] doubleArray38 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition41 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
        int[] intArray42 = lUDecomposition41.getPivot();
        double double43 = org.apache.commons.math3.util.MathArrays.distance(intArray35, intArray42);
        int[] intArray50 = new int[] { 0, 2147483647, 4, 100, 4, 2147483647 };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix2, intArray42, intArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) (short) 100, 1.2887003518651174d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        double[] doubleArray14 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray25 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray25, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray14, doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = diagonalMatrix33.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = diagonalMatrix4.subtract(diagonalMatrix33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x2 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (int) (short) -1, orderDirection3, true);
        int int6 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        try {
            openMapRealMatrix2.addToEntry(36, (int) '#', 10.000000000000002d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(2147483647, (int) (short) 100);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (-0.99999994f), 0.003913481845644553d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, (int) (short) 0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, (int) (short) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-0.0d));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double double5 = simpleVectorValueChecker3.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.177183820135558d + "'", double5 == 1.177183820135558d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 0.0d, 99.45597888911063d, (double) '4');
        try {
            double[] doubleArray10 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, (double) 10.0f, 1.2887003518651174d, 100.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: bad value for maximum iterations number: 0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 49.72798944455531d + "'", double5 == 49.72798944455531d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(36.00000000000001d, 1.0E-6d, (double) (short) 1, 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.000036d + "'", double4 == 10.000036d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval(0.0d, Double.NaN);
        double double3 = searchInterval2.getMax();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int[] intArray0 = null;
        double[] doubleArray3 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix5);
        int[] intArray7 = lUDecomposition6.getPivot();
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition13 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
        int[] intArray14 = lUDecomposition13.getPivot();
        double double15 = org.apache.commons.math3.util.MathArrays.distance(intArray7, intArray14);
        try {
            double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray0, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver2, preconditioner3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector6.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double[] doubleArray12 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray13 = new double[] {};
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray12, doubleArray13);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector8, arrayRealVector20);
        double[] doubleArray25 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        double[] doubleArray33 = diagonalMatrix27.operate(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector35.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector35);
        double double39 = arrayRealVector8.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector40.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        double[] doubleArray46 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray47 = new double[] {};
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray46, doubleArray47);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex53 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray46, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46, arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector42, arrayRealVector54);
        double double57 = arrayRealVector35.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.analysis.function.Sinc sinc59 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double63 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc59, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector54.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc59);
        try {
            double double68 = brentSolver2.solve(35, (org.apache.commons.math3.analysis.UnivariateFunction) sinc59, 3.7168146928204138d, (double) (-1L), (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [3.717, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 49.72798944455531d + "'", double63 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector64);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray3 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition6 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix5);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix5, 10.0d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray3, 0.003913481845644553d, 0.003913481845644553d);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) '#');
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix12, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        double[] doubleArray28 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray29 = new double[] {};
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray5, doubleArray28);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction33 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator34 = null;
        try {
            nelderMeadSimplex32.evaluate(multivariateFunction33, pointValuePairComparator34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray37 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray38);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex44 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray37, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector46.append((double) (-1L));
        try {
            double double49 = arrayRealVector2.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor13 = null;
        try {
            double double16 = arrayRealVector11.walkInOptimizedOrder(realVectorPreservingVisitor13, 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (double) 1.0f);
        diagonalMatrix4.multiplyEntry((int) (byte) -1, (int) '#', 3.2710663101885897d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix15 = diagonalMatrix4.scalarAdd(10.000000000000002d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) 10, 1041236929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1041236929 + "'", int2 == 1041236929);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((-2.28516993925936E-86d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.28516993925936E-86d) + "'", double1 == (-2.28516993925936E-86d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray1 = new double[] { '#' };
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray2);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj7 = null;
        boolean boolean8 = openMapRealMatrix6.equals(obj7);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix3, (org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 1x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.multiply(blockRealMatrix71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 4.0000005f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition35 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray10 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray10, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray21 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray21, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds27 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair29 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException34 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double35 = noBracketingException34.getLo();
        java.lang.Throwable[] throwableArray36 = noBracketingException34.getSuppressed();
        boolean boolean37 = pointValuePair29.equals((java.lang.Object) throwableArray36);
        double[] doubleArray43 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray43, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray54 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex59 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray54, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds60 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray54);
        org.apache.commons.math3.optim.PointValuePair pointValuePair62 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException67 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double68 = noBracketingException67.getLo();
        java.lang.Throwable[] throwableArray69 = noBracketingException67.getSuppressed();
        boolean boolean70 = pointValuePair62.equals((java.lang.Object) throwableArray69);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat71 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str72 = realMatrixFormat71.getColumnSeparator();
        boolean boolean73 = pointValuePair62.equals((java.lang.Object) str72);
        boolean boolean74 = simpleValueChecker3.converged((int) (byte) 100, pointValuePair29, pointValuePair62);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer75 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer76 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer77 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        double[] doubleArray78 = nonLinearConjugateGradientOptimizer77.getLowerBound();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "," + "'", str72.equals(","));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNull(doubleArray78);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor35 = null;
        try {
            double double40 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixChangingVisitor35, (int) (byte) 100, (int) ' ', (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        double[] doubleArray3 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3, true);
        double[] doubleArray8 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8, true);
        double[] doubleArray11 = diagonalMatrix5.operate(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector13.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        double[] doubleArray23 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray24 = new double[] {};
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray23, doubleArray24);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray23, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector31);
        double[] doubleArray36 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        double[] doubleArray41 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, true);
        double[] doubleArray44 = diagonalMatrix38.operate(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight45 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector46.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, arrayRealVector46);
        double double50 = arrayRealVector19.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector19.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector16.append((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        java.lang.StringBuffer stringBuffer54 = null;
        java.text.FieldPosition fieldPosition55 = null;
        try {
            java.lang.StringBuffer stringBuffer56 = realVectorFormat0.format(realVector53, stringBuffer54, fieldPosition55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-0.99999994f), 1.5707963267948966d, 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        mersenneTwister1.clear();
        double double3 = mersenneTwister1.nextGaussian();
        mersenneTwister1.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5401476965874874d) + "'", double3 == (-1.5401476965874874d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval(10.000036d, 1.1102230246251565E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = levenbergMarquardtOptimizer1.getWeight();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray13);
        double[] doubleArray20 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray21 = new double[] {};
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray20, doubleArray21);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        try {
            double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray5, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 100L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037347d + "'", double2 == 1.4711276743037347d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 100);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray2, 2.2250738585072014E-308d, 0.0d, 0.278369388163781d, 2.28516993925936E-86d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: simplex must contain at least one point");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray8 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray13 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray18 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray23 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray28 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray33 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray34 = new double[][] { doubleArray8, doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, false);
        int int37 = array2DRowRealMatrix36.getColumnDimension();
        double[][] doubleArray38 = array2DRowRealMatrix36.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable2, (java.lang.Number) 1, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException40 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 100.0d, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException41 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-1.0f), (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector16.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double[] doubleArray22 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector30);
        double[] doubleArray33 = arrayRealVector30.getDataRef();
        try {
            openMapRealMatrix14.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        double double3 = simpleVectorValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.177183820135558d + "'", double3 == 1.177183820135558d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        try {
            boolean boolean4 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection1.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] {};
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.2887003518651174d, (java.lang.Number) 35.0d, (int) '#', orderDirection4, false);
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray0, orderDirection4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(formulaArray0);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (byte) -1, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor36 = null;
        try {
            double double37 = array2DRowRealMatrix32.walkInRowOrder(realMatrixChangingVisitor36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-1), 0.0d, (-2.28516993925936E-86d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 49.72798944455531d, number1, (int) '4');
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector1.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor3 = null;
        try {
            double double6 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor3, (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = blockRealMatrix35.getColumnMatrix((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double43 = blockRealMatrix35.walkInOptimizedOrder(realMatrixChangingVisitor38, 36, (int) (byte) 100, (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[][] doubleArray10 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 100);
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray10, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        mersenneTwister1.clear();
        mersenneTwister1.setSeed((int) (short) 1);
        try {
            long long6 = mersenneTwister1.nextLong((long) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = lUDecomposition5.getU();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNull(realMatrix6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2.2250738585072014E-308d);
        java.lang.Number number2 = tooManyIterationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 2.2250738585072014E-308d + "'", number2.equals(2.2250738585072014E-308d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1041236929, 36, 52, (-1) };
        java.lang.Integer[] intArray5 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException6 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double12 = mersenneTwister11.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker14 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, true, pointValuePairConvergenceChecker14);
        double double16 = mersenneTwister11.nextGaussian();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker20 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray27 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray27, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray38 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex43 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray38, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds44 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray27, doubleArray38);
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException51 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double52 = noBracketingException51.getLo();
        java.lang.Throwable[] throwableArray53 = noBracketingException51.getSuppressed();
        boolean boolean54 = pointValuePair46.equals((java.lang.Object) throwableArray53);
        double[] doubleArray60 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex65 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray60, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray71 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex76 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray71, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds77 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray60, doubleArray71);
        org.apache.commons.math3.optim.PointValuePair pointValuePair79 = new org.apache.commons.math3.optim.PointValuePair(doubleArray60, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException84 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double85 = noBracketingException84.getLo();
        java.lang.Throwable[] throwableArray86 = noBracketingException84.getSuppressed();
        boolean boolean87 = pointValuePair79.equals((java.lang.Object) throwableArray86);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat88 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str89 = realMatrixFormat88.getColumnSeparator();
        boolean boolean90 = pointValuePair79.equals((java.lang.Object) str89);
        boolean boolean91 = simpleValueChecker20.converged((int) (byte) 100, pointValuePair46, pointValuePair79);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer92 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker20);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer93 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', 11013.232920103343d, false, 10, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker20);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5434049467914646d + "'", double12 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.2321040789270661d) + "'", double16 == (-0.2321040789270661d));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "," + "'", str89.equals(","));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NaN, 7.930067261567154E14d, 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        boolean boolean36 = array2DRowRealMatrix32.isSquare();
        array2DRowRealMatrix32.multiplyEntry((int) (byte) 0, (int) (short) 0, 0.0d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix32.multiply(array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-2.147483737329702E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.147483737E9d) + "'", double1 == (-2.147483737E9d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = diagonalMatrix24.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        double double27 = defaultRealMatrixPreservingVisitor25.end();
        double double28 = defaultRealMatrixPreservingVisitor25.end();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[] doubleArray77 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray78 = new double[] {};
        boolean boolean79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray77, doubleArray78);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex84 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray77, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray87 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray87, true);
        double[] doubleArray92 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix94 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray92, true);
        double[] doubleArray95 = diagonalMatrix89.operate(doubleArray92);
        double[] doubleArray96 = diagonalMatrix89.getDataRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds97 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray77, doubleArray96);
        try {
            blockRealMatrix71.setRow(1041236929, doubleArray77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,041,236,929)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        java.lang.Double double74 = pointValuePair28.getValue();
        java.lang.Double double75 = pointValuePair28.getSecond();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 11013.232920103343d + "'", double74.equals(11013.232920103343d));
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 11013.232920103343d + "'", double75.equals(11013.232920103343d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int[] intArray4 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, (int) (byte) 100);
        int[] intArray11 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11, (int) (byte) 100);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13);
        int int15 = org.apache.commons.math3.util.MathArrays.distance1(intArray4, intArray14);
        int[] intArray16 = null;
        try {
            int int17 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double19 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor14, (int) (byte) -1, 2147483647, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        double[][] doubleArray38 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, 100);
        try {
            array2DRowRealMatrix32.setSubMatrix(doubleArray38, 1041236929, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        int[] intArray6 = lUDecomposition5.getPivot();
        int[] intArray7 = null;
        try {
            double double8 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair2 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 0.0039134618669983915d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix4.power((int) 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.19036012811898584d + "'", double0 == 0.19036012811898584d);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        double[] doubleArray13 = cMAESOptimizer10.getUpperBound();
        int int14 = cMAESOptimizer10.getMaxEvaluations();
        int int15 = cMAESOptimizer10.getIterations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double57 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc53, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector48.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector48.copy();
        double[] doubleArray62 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix64 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray62, false);
        double[] doubleArray67 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray67, true);
        double[] doubleArray72 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray72, true);
        double[] doubleArray75 = diagonalMatrix69.operate(doubleArray72);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight76 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector77.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray72, arrayRealVector77);
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72, (int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray82);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds84 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray62, doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, doubleArray82);
        double double86 = arrayRealVector48.getL1Norm();
        boolean boolean87 = arrayRealVector48.isInfinite();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 49.72798944455531d + "'", double57 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(arrayRealVector79);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.003913481845644553d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver2, preconditioner3);
        double[] doubleArray8 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray9 = new double[] {};
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray26 = diagonalMatrix20.operate(doubleArray23);
        double[] doubleArray27 = diagonalMatrix20.getDataRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds28 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray8, doubleArray27);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray29 = new org.apache.commons.math3.optim.OptimizationData[] { simpleBounds28 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair30 = nonLinearConjugateGradientOptimizer4.optimize(optimizationDataArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: constraint");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(optimizationDataArray29);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double double6 = lUDecomposition5.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = lUDecomposition5.getU();
        double double8 = lUDecomposition5.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = lUDecomposition5.getL();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(realMatrix9);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray16, (double) (byte) 10, (-0.9287117556321675d));
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray16);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("{{-1,0},{0,0}}", "", "hi!", ",", "{", "", numberFormat7);
        java.lang.String str9 = realMatrixFormat8.getColumnSeparator();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str11 = realMatrixFormat10.getColumnSeparator();
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        double[] doubleArray26 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        double[] doubleArray31 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, true);
        double[] doubleArray34 = diagonalMatrix28.operate(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix28);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = diagonalMatrix16.multiply(diagonalMatrix28);
        java.lang.String str37 = realMatrixFormat10.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        double[] doubleArray40 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition43 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix42);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition45 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix42, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = diagonalMatrix42.copy();
        double[] doubleArray48 = diagonalMatrix42.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = diagonalMatrix16.add(diagonalMatrix42);
        java.lang.StringBuffer stringBuffer50 = null;
        java.text.FieldPosition fieldPosition51 = null;
        try {
            java.lang.StringBuffer stringBuffer52 = realMatrixFormat8.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix42, stringBuffer50, fieldPosition51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(realMatrixFormat10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "," + "'", str11.equals(","));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{{-1,0},{0,0}}" + "'", str37.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(diagonalMatrix49);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) '#');
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(4.0000005f, 0.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 'a', 1.2595063905404449d);
        double double3 = brentOptimizer2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix2.subtract(openMapRealMatrix16);
        try {
            double double31 = openMapRealMatrix16.getEntry((int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        try {
            blockRealMatrix35.setEntry(50, (int) '#', 1.5707963267948966d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 'a', 1.2595063905404449d);
        int int3 = brentOptimizer2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        int int2 = mersenneTwister0.nextInt(100);
//        mersenneTwister0.clear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2.2250738585072014E-308d);
        java.io.ObjectInputStream objectInputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 2.2250738585072014E-308d, "hi!", objectInputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray1 = zeroException0.getSuppressed();
        java.lang.String str2 = zeroException0.toString();
        org.junit.Assert.assertNotNull(throwableArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.ZeroException: zero not allowed here" + "'", str2.equals("org.apache.commons.math3.exception.ZeroException: zero not allowed here"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        double[] doubleArray13 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray18 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray23 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray28 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray33 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray39 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33, doubleArray38 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39, false);
        try {
            array2DRowRealMatrix7.setColumnMatrix((int) (short) -1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) -1, 80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math3.util.FastMath.cos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-14d + "'", double1 == 1.0E-14d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray5 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        double[] doubleArray13 = diagonalMatrix7.operate(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector15.add((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector2.append(arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor22 = null;
        try {
            double double25 = arrayRealVector21.walkInDefaultOrder(realVectorChangingVisitor22, 35, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, 1.0E-6d);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.0d, 10.000036d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000036d + "'", double2 == 10.000036d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double5 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        double double11 = eigenDecomposition7.getDeterminant();
        double double12 = eigenDecomposition7.getDeterminant();
        try {
            double double14 = eigenDecomposition7.getRealEigenvalue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.0d) + "'", double11 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.0d) + "'", double12 == (-0.0d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double30 = noBracketingException29.getLo();
        java.lang.Throwable[] throwableArray31 = noBracketingException29.getSuppressed();
        boolean boolean32 = pointValuePair24.equals((java.lang.Object) throwableArray31);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat33 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str34 = realMatrixFormat33.getColumnSeparator();
        boolean boolean35 = pointValuePair24.equals((java.lang.Object) str34);
        double[] doubleArray36 = pointValuePair24.getFirst();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "," + "'", str34.equals(","));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray11 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray16 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray21 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray26 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray31 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32, false);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException35 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 10, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException37 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2.2250738585072014E-308d);
        maxCountExceededException35.addSuppressed((java.lang.Throwable) tooManyIterationsException37);
        org.apache.commons.math3.exception.MathInternalError mathInternalError39 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) tooManyIterationsException37);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math3.util.FastMath.max(9.42477794844185d, (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.42477794844185d + "'", double2 == 9.42477794844185d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        double double11 = eigenDecomposition7.getDeterminant();
        try {
            double double13 = eigenDecomposition7.getRealEigenvalue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.0d) + "'", double11 == (-0.0d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix72.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = blockRealMatrix74.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(realMatrix75);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray3 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3, false);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("{{-1,0},{0,0}}", "", "hi!", ",", "{", "", numberFormat7);
        java.io.ObjectInputStream objectInputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) ",", ",", objectInputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        double[] doubleArray74 = pointValuePair28.getPointRef();
        boolean boolean76 = pointValuePair28.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(12, 35);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray59 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray64 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray65 = new double[][] { doubleArray39, doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65, false);
        int int68 = array2DRowRealMatrix67.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix67.scalarMultiply((double) ' ');
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix71 = array2DRowRealMatrix32.preMultiply(realMatrix70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(realMatrix70);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 'a', 1.2595063905404449d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker3 = brentOptimizer2.getConvergenceChecker();
        org.junit.Assert.assertNull(univariatePointValuePairConvergenceChecker3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray11 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray16 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray21 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray26 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray31 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32, false);
        int int35 = array2DRowRealMatrix34.getColumnDimension();
        double[][] doubleArray36 = array2DRowRealMatrix34.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        double[] doubleArray25 = pointValuePair24.getKey();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix9, 2147483647, (int) '#', (int) (byte) 10, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj13 = null;
        boolean boolean14 = openMapRealMatrix12.equals(obj13);
        try {
            diagonalMatrix4.setColumnMatrix(12, (org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (12)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix15 = openMapRealMatrix13.subtract(realMatrix14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        int int35 = array2DRowRealMatrix32.getColumnDimension();
        try {
            array2DRowRealMatrix32.setEntry(1195587395, 80, (double) 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,195,587,395)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.apache.commons.math3.exception.MathInternalError mathInternalError7 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) matrixDimensionMismatchException4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 36 + "'", int5 == 36);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix36.transpose();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition38 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        long[] longArray4 = new long[] { 4, (-608192130026889042L), 1195587395, (short) 0 };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -608,192,130,026,889,042 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(47.123889803847106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8224670334241169d + "'", double1 == 0.8224670334241169d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair3 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 36.00000000000001d, false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint(7.930067261567154E14d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.965033630783837E14d + "'", double2 == 3.965033630783837E14d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        long[] longArray0 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector14.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector2.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, false);
        double double38 = arrayRealVector2.getMinValue();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("]", "org.apache.commons.math3.exception.ZeroException: zero not allowed here", "");
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.900849165587834d, 1.2595063905404449d, (double) 80);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(pointVectorValuePairConvergenceChecker0);
        try {
            int int2 = gaussNewtonOptimizer1.getTargetSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        java.lang.Double[] doubleArray58 = new java.lang.Double[] { 9.42477794844185d, 3.7168146928204138d, 1.1578212823495775d, (-0.0d), (-1.0d), 3.1622776601683795d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector29.append((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector60);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray16, (double) (byte) 10, (-0.9287117556321675d));
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction26 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator27 = null;
        try {
            multiDirectionalSimplex25.iterate(multivariateFunction26, pointValuePairComparator27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (byte) 100, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition35 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray16, (double) (byte) 10, (-0.9287117556321675d));
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker30 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer31 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker30);
        double[] doubleArray35 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray40 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        double[] doubleArray43 = diagonalMatrix37.operate(doubleArray40);
        double[] doubleArray46 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        double[] doubleArray51 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double[] doubleArray54 = diagonalMatrix48.operate(doubleArray51);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight55 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector56.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, arrayRealVector56);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray51, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair63 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray40, doubleArray61, false);
        double[] doubleArray64 = pointVectorValuePair63.getPointRef();
        double[] doubleArray68 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray69 = new double[] {};
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray68, doubleArray69);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex75 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray68, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray78 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray78, true);
        double[] doubleArray83 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix85 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray83, true);
        double[] doubleArray86 = diagonalMatrix80.operate(doubleArray83);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair88 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray68, doubleArray83, true);
        boolean boolean89 = simpleVectorValueChecker30.converged(100, pointVectorValuePair63, pointVectorValuePair88);
        double[] doubleArray90 = pointVectorValuePair63.getPoint();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair92 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray90, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix32.getColumnMatrix(0);
        boolean boolean37 = array2DRowRealMatrix32.isSquare();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1L, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix36.transpose();
        try {
            double double40 = array2DRowRealMatrix36.getEntry(6, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        boolean boolean11 = eigenDecomposition7.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math3.util.FastMath.abs((-1.5401476965874874d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5401476965874874d + "'", double1 == 1.5401476965874874d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair4 = null;
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray12 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12, true);
        double[] doubleArray15 = diagonalMatrix9.operate(doubleArray12);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray26 = diagonalMatrix20.operate(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector28.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23, arrayRealVector28);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray33, false);
        double[] doubleArray36 = pointVectorValuePair35.getPointRef();
        try {
            boolean boolean37 = simpleVectorValueChecker2.converged((int) '#', pointVectorValuePair4, pointVectorValuePair35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = openMapRealMatrix2.transpose();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix4.copy();
        java.io.ObjectInputStream objectInputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) diagonalMatrix4, "", objectInputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.45597888911063d, objArray25);
        java.lang.Throwable[] throwableArray27 = notFiniteNumberException26.getSuppressed();
        boolean boolean28 = pointVectorValuePair23.equals((java.lang.Object) throwableArray27);
        double[] doubleArray29 = pointVectorValuePair23.getValue();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        double double15 = arrayRealVector2.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector2.mapAddToSelf((double) 0.9670298f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector2.append((double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector30.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double[] doubleArray38 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex43 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray38, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray38);
        double double45 = arrayRealVector32.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector32.mapAddToSelf((double) 0.9670298f);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector27.combine(10.0d, 0.0d, realVector47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector47);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math3.util.FastMath.log10(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (double) 1.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = eigenDecomposition9.getD();
        boolean boolean11 = eigenDecomposition9.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.5401476965874874d, 2.2250738585072014E-308d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction11 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator12 = null;
        try {
            nelderMeadSimplex10.iterate(multivariateFunction11, pointValuePairComparator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        double[] doubleArray44 = new double[] { 7830967380036616271L, 3, 1.4E-45f, 7.930067261567154E14d };
        double[] doubleArray49 = new double[] { 7830967380036616271L, 3, 1.4E-45f, 7.930067261567154E14d };
        double[] doubleArray54 = new double[] { 7830967380036616271L, 3, 1.4E-45f, 7.930067261567154E14d };
        double[][] doubleArray55 = new double[][] { doubleArray44, doubleArray49, doubleArray54 };
        try {
            array2DRowRealMatrix32.copySubMatrix(36, 1041236929, (int) (short) 1, 1195587395, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 1, 4.0000005f, (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 6, (java.lang.Number) 0.0f, false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.ConvergenceException convergenceException2 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, objArray1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        int int11 = cMAESOptimizer10.getMaxEvaluations();
        int int12 = cMAESOptimizer10.getEvaluations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray10 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray10, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray21 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray21, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds27 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray21);
        org.apache.commons.math3.optim.PointValuePair pointValuePair29 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException34 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double35 = noBracketingException34.getLo();
        java.lang.Throwable[] throwableArray36 = noBracketingException34.getSuppressed();
        boolean boolean37 = pointValuePair29.equals((java.lang.Object) throwableArray36);
        double[] doubleArray43 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray43, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray54 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex59 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray54, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds60 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray54);
        org.apache.commons.math3.optim.PointValuePair pointValuePair62 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException67 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double68 = noBracketingException67.getLo();
        java.lang.Throwable[] throwableArray69 = noBracketingException67.getSuppressed();
        boolean boolean70 = pointValuePair62.equals((java.lang.Object) throwableArray69);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat71 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str72 = realMatrixFormat71.getColumnSeparator();
        boolean boolean73 = pointValuePair62.equals((java.lang.Object) str72);
        boolean boolean74 = simpleValueChecker3.converged((int) (byte) 100, pointValuePair29, pointValuePair62);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver75 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double76 = brentSolver75.getAbsoluteAccuracy();
        double double77 = brentSolver75.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer78 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver75);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "," + "'", str72.equals(","));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0E-6d + "'", double76 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0E-14d + "'", double77 == 1.0E-14d);
    }
}

