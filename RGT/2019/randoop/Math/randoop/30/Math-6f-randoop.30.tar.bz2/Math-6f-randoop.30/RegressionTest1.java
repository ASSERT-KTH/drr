import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 10.0f, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(4);
        double double2 = mersenneTwister1.nextDouble();
        int int3 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9670298382732487d + "'", double2 == 0.9670298382732487d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1944622665) + "'", int3 == (-1944622665));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix71 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = openMapRealMatrix71.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor73 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double74 = openMapRealMatrix71.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        double double75 = array2DRowRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        int int76 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor77 = null;
        try {
            double double82 = array2DRowRealMatrix32.walkInRowOrder(realMatrixChangingVisitor77, 0, 1195587395, (int) (byte) 100, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,195,587,395)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(realMatrix72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 4 + "'", int76 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getPoint();
        double[] doubleArray25 = pointVectorValuePair23.getFirst();
        org.apache.commons.math3.optim.PointValuePair pointValuePair27 = new org.apache.commons.math3.optim.PointValuePair(doubleArray25, (double) (short) 100);
        double[] doubleArray31 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray32 = new double[] {};
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray32);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray41 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, true);
        double[] doubleArray46 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        double[] doubleArray49 = diagonalMatrix43.operate(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair51 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray31, doubleArray46, true);
        double[] doubleArray52 = pointVectorValuePair51.getValue();
        int int53 = org.apache.commons.math3.util.MathUtils.hash(doubleArray52);
        double[] doubleArray56 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray56, false);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray52, doubleArray56);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition60 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray25, doubleArray52);
        double double61 = eigenDecomposition60.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1041236929 + "'", int53 == 1041236929);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-999.0d) + "'", double61 == (-999.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getFirst();
        double[] doubleArray25 = pointVectorValuePair23.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        int int11 = cMAESOptimizer10.getMaxEvaluations();
        double[] doubleArray17 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        double[] doubleArray24 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray24);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray26 = new org.apache.commons.math3.optim.OptimizationData[] { sigma18, sigma25 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair27 = cMAESOptimizer10.optimize(optimizationDataArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(optimizationDataArray26);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.analysis.function.Sinc sinc35 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc35);
        double double40 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc35, 0.278369388163781d, (double) 50, 2.28516993925936E-86d);
        try {
            double[] doubleArray45 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc35, 0.7853981633974483d, 0.0d, (double) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.785, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 47.123889803847106d + "'", double40 == 47.123889803847106d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer74 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker2);
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval78 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-1), 0.0d, (-2.28516993925936E-86d));
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval81 = new org.apache.commons.math3.optim.univariate.SearchInterval(0.0d, Double.NaN);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds83 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) '4');
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray84 = new org.apache.commons.math3.optim.OptimizationData[] { searchInterval78, searchInterval81, simpleBounds83 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair85 = simplexOptimizer74.optimize(optimizationDataArray84);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(simpleBounds83);
        org.junit.Assert.assertNotNull(optimizationDataArray84);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 139.56534896654014d, objArray2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) openMapRealMatrix13, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(50);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double double73 = blockRealMatrix71.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.add(realMatrix74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 24.65302686521849d + "'", double73 == 24.65302686521849d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        double[] doubleArray3 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3, true);
        double[] doubleArray8 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8, true);
        double[] doubleArray11 = diagonalMatrix5.operate(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector13.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        double[] doubleArray23 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray24 = new double[] {};
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray23, doubleArray24);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray23, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, arrayRealVector31);
        double[] doubleArray36 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        double[] doubleArray41 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, true);
        double[] doubleArray44 = diagonalMatrix38.operate(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight45 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector46.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, arrayRealVector46);
        double double50 = arrayRealVector19.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector19.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector16.append((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        java.lang.StringBuffer stringBuffer54 = null;
        java.text.FieldPosition fieldPosition55 = null;
        try {
            java.lang.StringBuffer stringBuffer56 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector16, stringBuffer54, fieldPosition55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector25.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        double[] doubleArray35 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray38 = diagonalMatrix32.operate(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector40.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35, arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.add((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector27.append(arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector27);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(arrayRealVector46);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(1.0d, 47.123889803847106d, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction7 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator8 = null;
        try {
            nelderMeadSimplex6.evaluate(multivariateFunction7, pointValuePairComparator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(100.0d, 0.0039134618669983915d, 10);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix36.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric(realMatrix37, Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(Double.NaN, (double) 0.9670298f);
        int int3 = brentOptimizer2.getMaxIterations();
        int int4 = brentOptimizer2.getEvaluations();
        double double5 = brentOptimizer2.getStartValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        boolean boolean6 = openMapRealMatrix2.isSquare();
        int int7 = openMapRealMatrix2.getColumnDimension();
        int int8 = openMapRealMatrix2.getColumnDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        double double25 = diagonalMatrix24.getTrace();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 200.54340494679147d + "'", double25 == 200.54340494679147d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        int int25 = org.apache.commons.math3.util.MathUtils.hash(doubleArray24);
        double[] doubleArray28 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, false);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray24, doubleArray28);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1041236929 + "'", int25 == 1041236929);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = eigenDecomposition7.getEigenvector(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector21);
        double[] doubleArray26 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        double[] doubleArray31 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, true);
        double[] doubleArray34 = diagonalMatrix28.operate(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector36);
        double double40 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector41.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        double[] doubleArray47 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray47, doubleArray48);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray47, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector43, arrayRealVector55);
        double double58 = arrayRealVector36.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.analysis.function.Sinc sinc60 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double64 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc60, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector55.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc60);
        boolean boolean66 = bitsStreamGeneratorPair4.equals((java.lang.Object) arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector55.mapDivideToSelf(0.9670298382732487d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 49.72798944455531d + "'", double64 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(realVector68);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.93006726156716E14d + "'", double1 == 7.93006726156716E14d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector23.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, arrayRealVector23);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair30 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray28, false);
        double[] doubleArray31 = pointVectorValuePair30.getPointRef();
        double[] doubleArray32 = pointVectorValuePair30.getKey();
        double[] doubleArray33 = pointVectorValuePair30.getFirst();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double30 = noBracketingException29.getLo();
        java.lang.Throwable[] throwableArray31 = noBracketingException29.getSuppressed();
        boolean boolean32 = pointValuePair24.equals((java.lang.Object) throwableArray31);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat33 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str34 = realMatrixFormat33.getColumnSeparator();
        boolean boolean35 = pointValuePair24.equals((java.lang.Object) str34);
        java.lang.Object obj36 = null;
        boolean boolean37 = pointValuePair24.equals(obj36);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "," + "'", str34.equals(","));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1L), (float) (-1944622665), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, (-1.5401476965874874d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        array2DRowRealMatrix66.multiplyEntry(1, 0, (double) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix74 = array2DRowRealMatrix66.getRowMatrix((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray12 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector2.append(arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector20.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector22.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        arrayRealVector26.set((double) 3);
        double double29 = arrayRealVector6.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector26.mapDivide(47.123889803847106d);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray34 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray45 = new double[][] { doubleArray19, doubleArray24, doubleArray29, doubleArray34, doubleArray39, doubleArray44 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45, false);
        int int48 = array2DRowRealMatrix47.getColumnDimension();
        double[][] doubleArray49 = array2DRowRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix51.transpose();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix53 = openMapRealMatrix14.subtract(realMatrix52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x10 but expected 4x6");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix52);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double57 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc53, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector48.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector59.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        double[] doubleArray67 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex72 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray67, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector61, doubleArray67);
        double double74 = arrayRealVector61.getMaxValue();
        int int75 = arrayRealVector61.getDimension();
        double double76 = arrayRealVector48.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 49.72798944455531d + "'", double57 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double74, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        double double5 = openMapRealMatrix2.getNorm();
        double[] doubleArray10 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray15 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray20 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray25 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray30 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray35 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray36 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36, false);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        double[][] doubleArray40 = array2DRowRealMatrix38.getData();
        int int41 = array2DRowRealMatrix38.getRowDimension();
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix42 = openMapRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x10 but expected 6x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getVT();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double12 = mersenneTwister11.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker14 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, true, pointValuePairConvergenceChecker14);
        double double16 = mersenneTwister11.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker18 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '4', (-2.330679416656494d), true, (int) 'a', (int) '4', (org.apache.commons.math3.random.RandomGenerator) mersenneTwister11, false, pointValuePairConvergenceChecker18);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5434049467914646d + "'", double12 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.278369388163781d + "'", double16 == 0.278369388163781d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 1.900849165587834d, "org.apache.commons.math3.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [0, 100], values: [35, 100]", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray3, 0.003913481845644553d, 0.003913481845644553d);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) '#');
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray11);
        org.apache.commons.math3.optim.PointValuePair pointValuePair15 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) 4.0000005f, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector2.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        try {
            arrayRealVector36.addToEntry(80, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (80)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 0.9670298f, 36.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9670298099517822d + "'", double2 == 0.9670298099517822d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 100, (double) 0, (-999.0d), (double) (short) 10, (double) 1.4E-45f, (-0.9287117556321675d), 2.2250738585072014E-308d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-9990.0d) + "'", double8 == (-9990.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition13 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = diagonalMatrix12.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = diagonalMatrix4.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(200.54340494679147d, (-0.0d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 0.0d, 99.45597888911063d, (double) '4');
        double double11 = brentSolver0.solve((int) (byte) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc3, (double) (-1L), (double) 10.0f, 1.5707963267948966d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction12 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = univariateObjectiveFunction12.getObjectiveFunction();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 49.72798944455531d + "'", double7 == 49.72798944455531d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.42477794844185d + "'", double11 == 9.42477794844185d);
        org.junit.Assert.assertNotNull(univariateFunction13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) '4', 1.2887003518651174d, univariatePointValuePairConvergenceChecker2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 7830967380036616271L, (double) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(3, 10, Double.NaN);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix36.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric(realMatrix37, (double) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getWrongDimensions();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getWrongDimensions();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 36 + "'", int5 == 36);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(2, 10.000000000000002d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.2321040789270661d), 0.0d, 7.930067261567154E14d, 7.93006726156716E14d, (double) (byte) 10, (double) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.288596677297923E29d + "'", double6 == 6.288596677297923E29d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str2 = realVectorFormat1.getSuffix();
        java.text.NumberFormat numberFormat3 = realVectorFormat1.getFormat();
        java.lang.StringBuffer stringBuffer4 = null;
        java.text.FieldPosition fieldPosition5 = null;
        try {
            java.lang.StringBuffer stringBuffer6 = org.apache.commons.math3.util.CompositeFormat.formatDouble((-2.147483737329702E9d), numberFormat3, stringBuffer4, fieldPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        int[] intArray6 = lUDecomposition5.getPivot();
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition12 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix11);
        int[] intArray13 = lUDecomposition12.getPivot();
        double double14 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray13);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double17 = mersenneTwister16.nextDouble();
        int[] intArray22 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray24 = org.apache.commons.math3.util.MathArrays.copyOf(intArray22, (int) (byte) 100);
        int[] intArray29 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray31 = org.apache.commons.math3.util.MathArrays.copyOf(intArray29, (int) (byte) 100);
        int[] intArray32 = org.apache.commons.math3.util.MathArrays.copyOf(intArray31);
        int int33 = org.apache.commons.math3.util.MathArrays.distance1(intArray22, intArray32);
        mersenneTwister16.setSeed(intArray32);
        double double35 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5434049467914646d + "'", double17 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 99.50376877284599d + "'", double35 == 99.50376877284599d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.8224670334241169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2761081516257424d + "'", double1 == 1.2761081516257424d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.2595063905404449d, (double) (-608192130026889042L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 0.9670298382732487d, 1.4711276743037347d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 100, 1.1578212823495775d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator4 = null;
        try {
            nelderMeadSimplex2.iterate(multivariateFunction3, pointValuePairComparator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double[] doubleArray7 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray8 = new double[] {};
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray8);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray7, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector3, arrayRealVector15);
        double[] doubleArray20 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        double[] doubleArray25 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        double[] doubleArray28 = diagonalMatrix22.operate(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight29 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector30.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25, arrayRealVector30);
        double double34 = arrayRealVector3.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector35.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        double[] doubleArray41 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray42 = new double[] {};
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray42);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray41, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector37, arrayRealVector49);
        double double52 = arrayRealVector30.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.analysis.function.Sinc sinc54 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double58 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc54, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector49.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector49.copy();
        double[] doubleArray63 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray63, false);
        double[] doubleArray68 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix70 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68, true);
        double[] doubleArray73 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix75 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray73, true);
        double[] doubleArray76 = diagonalMatrix70.operate(doubleArray73);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight77 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = arrayRealVector78.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector79);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73, arrayRealVector78);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73, (int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray83);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds85 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray63, doubleArray83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray83);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray83, (-0.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 49.72798944455531d + "'", double58 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(arrayRealVector80);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) ' ');
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            nelderMeadSimplex1.iterate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor69 = null;
        try {
            double double70 = array2DRowRealMatrix68.walkInOptimizedOrder(realMatrixChangingVisitor69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        int int4 = levenbergMarquardtOptimizer3.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 3, (double) (short) 0, 1.5707963267948966d, 0.0d, 0.8224670334241169d, 50.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 41.123351671205846d + "'", double6 == 41.123351671205846d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (short) 100, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver2, preconditioner3);
        double double5 = brentSolver2.getMax();
        org.apache.commons.math3.analysis.function.Sinc sinc8 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double10 = sinc8.value((double) 'a');
        try {
            double double12 = brentSolver2.solve((int) (byte) 1, (org.apache.commons.math3.analysis.UnivariateFunction) sinc8, (-0.2321040789270661d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.003913481845644553d + "'", double10 == 0.003913481845644553d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double double17 = arrayRealVector16.getL1Norm();
        double double18 = arrayRealVector16.getLInfNorm();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector0.copy();
        boolean boolean4 = arrayRealVector3.isNaN();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction11 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator12 = null;
        try {
            nelderMeadSimplex10.evaluate(multivariateFunction11, pointValuePairComparator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double double73 = blockRealMatrix71.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix71.createMatrix(6, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 24.65302686521849d + "'", double73 == 24.65302686521849d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.random.BitsStreamGenerator bitsStreamGenerator7 = bitsStreamGeneratorPair4.getFirst();
        double double8 = bitsStreamGenerator7.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(bitsStreamGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.278369388163781d + "'", double8 == 0.278369388163781d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = diagonalMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix24.add(realMatrix27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 41.123351671205846d, (java.lang.Number) 50, false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int6 = matrixDimensionMismatchException5.getWrongColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException5.getWrongDimensions();
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 36 + "'", int6 == 36);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 2.2250738585072014E-308d);
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) tooManyIterationsException1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("org.apache.commons.math3.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [0, 100], values: [35, 100]", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker4 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (byte) 0, (-0.21722891503668823d), (double) ' ', 35.0d, pointValuePairConvergenceChecker4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        double[] doubleArray13 = cMAESOptimizer10.getUpperBound();
        int int14 = cMAESOptimizer10.getMaxEvaluations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker15 = cMAESOptimizer10.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int[] intArray4 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, (int) (byte) 100);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition12 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix11);
        int[] intArray13 = lUDecomposition12.getPivot();
        try {
            int int14 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray3, 0.003913481845644553d, 0.003913481845644553d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction10 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator11 = null;
        try {
            multiDirectionalSimplex9.evaluate(multivariateFunction10, pointValuePairComparator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 10);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("{", "}", "", "}", "]", ",");
        java.lang.String str7 = realMatrixFormat6.getRowPrefix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.analysis.function.Sinc sinc35 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc35);
        double double40 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc35, 0.278369388163781d, (double) 50, 2.28516993925936E-86d);
        double double42 = sinc35.value((double) 0);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc35, 7.93006726156716E14d, 1.1102230246251565E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [793,006,726,156,716, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 47.123889803847106d + "'", double40 == 47.123889803847106d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        double[] doubleArray13 = cMAESOptimizer10.getUpperBound();
        int int14 = cMAESOptimizer10.getMaxEvaluations();
        double[] doubleArray15 = cMAESOptimizer10.getLowerBound();
        int int16 = cMAESOptimizer10.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str10 = realMatrixFormat9.getColumnSeparator();
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix15);
        double[] doubleArray25 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        double[] doubleArray33 = diagonalMatrix27.operate(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = diagonalMatrix15.multiply(diagonalMatrix27);
        java.lang.String str36 = realMatrixFormat9.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix15);
        double[] doubleArray39 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition42 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition44 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix41, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = diagonalMatrix41.copy();
        double[] doubleArray47 = diagonalMatrix41.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = diagonalMatrix15.add(diagonalMatrix41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = diagonalMatrix4.multiply(diagonalMatrix48);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrixFormat9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "," + "'", str10.equals(","));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{{-1,0},{0,0}}" + "'", str36.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(diagonalMatrix48);
        org.junit.Assert.assertNotNull(diagonalMatrix49);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer74 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker2);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer75 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker2);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer76 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 1.0E-6d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, (int) (byte) 0, 1041236929);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,041,236,929 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix2.subtract(openMapRealMatrix16);
        double[] doubleArray33 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray59 = new double[][] { doubleArray33, doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59, false);
        int int62 = array2DRowRealMatrix61.getColumnDimension();
        boolean boolean63 = array2DRowRealMatrix61.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = array2DRowRealMatrix61.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor65 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double66 = array2DRowRealMatrix61.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65);
        try {
            double double71 = openMapRealMatrix16.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65, 6, (int) 'a', 80, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(47.123889803847106d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-558340673) + "'", int1 == (-558340673));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapDivide((double) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector25.mapSubtract(0.0d);
        int int30 = arrayRealVector25.getDimension();
        try {
            org.apache.commons.math3.linear.RealVector realVector31 = diagonalMatrix4.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math3.util.FastMath.signum((-2.28516993925936E-86d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray5 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray5);
        double[] doubleArray7 = null;
        try {
            double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray5, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        try {
            blockRealMatrix71.multiplyEntry((int) ' ', 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math3.util.FastMath.acos(139.56534896654014d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 3.7168146928204138d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.7168146928204138d + "'", number5.equals(3.7168146928204138d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        double[] doubleArray26 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray27 = new double[] {};
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray27);
        try {
            double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray5, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, 0.9670298099517822d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix75 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = openMapRealMatrix75.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor77 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double78 = openMapRealMatrix75.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor77);
        try {
            double double83 = blockRealMatrix71.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor77, 80, 1041236929, 12, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (80)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) 10, (int) (short) -1, orderDirection3, true);
        java.lang.Number number6 = nonMonotonicSequenceException5.getArgument();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (byte) 0, 0.0f, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("]", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        double double5 = openMapRealMatrix2.getNorm();
        int int6 = openMapRealMatrix2.getRowDimension();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.scalarMultiply(9.42477794844185d);
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix7.getRowVector((int) (byte) 0);
        org.apache.commons.math3.linear.RealVector realVector13 = realVector11.mapDivide((double) 100L);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        int int12 = cMAESOptimizer10.getIterations();
        int int13 = cMAESOptimizer10.getEvaluations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix71.createMatrix((-558340673), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -558,340,673 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 0.0d, 99.45597888911063d, (double) '4');
        double double11 = brentSolver0.solve((int) (byte) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc3, (double) (-1L), (double) 10.0f, 1.5707963267948966d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction12 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc3);
        try {
            double double15 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 1.2761081516257424d, (-0.9287117556321675d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.276, 0.174]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 49.72798944455531d + "'", double7 == 49.72798944455531d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.42477794844185d + "'", double11 == 9.42477794844185d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math3.util.FastMath.rint(1.1578212823495775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6888366918779438d) + "'", double1 == (-0.6888366918779438d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double[] doubleArray2 = levenbergMarquardtOptimizer0.getStartPoint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(doubleArray2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector21);
        double[] doubleArray26 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        double[] doubleArray31 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, true);
        double[] doubleArray34 = diagonalMatrix28.operate(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector36);
        double double40 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector41.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        double[] doubleArray47 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray47, doubleArray48);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray47, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector43, arrayRealVector55);
        double double58 = arrayRealVector36.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.analysis.function.Sinc sinc60 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double64 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc60, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector55.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc60);
        boolean boolean66 = bitsStreamGeneratorPair4.equals((java.lang.Object) arrayRealVector55);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor67 = null;
        try {
            double double68 = arrayRealVector55.walkInDefaultOrder(realVectorPreservingVisitor67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 49.72798944455531d + "'", double64 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix26.scalarMultiply((double) (byte) 1);
        java.lang.StringBuffer stringBuffer29 = null;
        java.text.FieldPosition fieldPosition30 = null;
        try {
            java.lang.StringBuffer stringBuffer31 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, stringBuffer29, fieldPosition30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        double double15 = arrayRealVector2.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector2.mapAddToSelf((double) 0.9670298f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector2.append((double) (byte) 1);
        java.lang.Double[] doubleArray26 = new java.lang.Double[] { 9.42477794844185d, 3.7168146928204138d, 1.1578212823495775d, (-0.0d), (-1.0d), 3.1622776601683795d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getLo();
        double double3 = bracketFinder0.getFMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector23.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, arrayRealVector23);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair30 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray28, false);
        double[] doubleArray31 = pointVectorValuePair30.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray39 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        double[] doubleArray44 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44, true);
        double[] doubleArray47 = diagonalMatrix41.operate(doubleArray44);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight48 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector49.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44, arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector49.add((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector36.append(arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double57 = arrayRealVector36.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector33.add((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3, 1.900849165587834d, (-2.330679416656494d), (double) 1.0f, (double) ' ');
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray17 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray17, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray6, doubleArray17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, false);
        double[] doubleArray29 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray30 = new double[] {};
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray30);
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray29);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex33 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray55 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        double[] doubleArray58 = diagonalMatrix52.operate(doubleArray55);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair60 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray40, doubleArray55, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        double[] doubleArray65 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray65, doubleArray66);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex72 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray65, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray75 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix77 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray75, true);
        double[] doubleArray80 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix82 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray80, true);
        double[] doubleArray83 = diagonalMatrix77.operate(doubleArray80);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair85 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray80, true);
        double[] doubleArray86 = pointVectorValuePair85.getFirst();
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray40, doubleArray86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray40);
        boolean boolean89 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        double double74 = simpleValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        double[] doubleArray15 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        double[] doubleArray20 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        double[] doubleArray23 = diagonalMatrix17.operate(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector25.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector25.add((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector31.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double[] doubleArray37 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray38);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex44 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray37, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector45);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray55 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        double[] doubleArray58 = diagonalMatrix52.operate(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight59 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector60.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, arrayRealVector60);
        double double64 = arrayRealVector33.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector33.mapSubtractToSelf(0.5434049467914646d);
        double double67 = arrayRealVector30.getDistance(realVector66);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector11.append(realVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector11.copy();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(arrayRealVector69);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((-1944622665), (-0.5440211108893698d), (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray5 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray10 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray15 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray20 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray25 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray30 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray31 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31, false);
        int int34 = array2DRowRealMatrix33.getColumnDimension();
        double[][] doubleArray35 = array2DRowRealMatrix33.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException36 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight38 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("{", "{{-1,0},{0,0}}", "{{-1,0},{0,0}}", "", "org.apache.commons.math3.exception.ZeroException: zero not allowed here", "org.apache.commons.math3.exception.ZeroException: zero not allowed here", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10, (java.lang.Number) 3.7168146928204138d, (java.lang.Number) (-2.147483737329702E9d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getRowMatrix(0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double39 = blockRealMatrix35.walkInRowOrder(realMatrixChangingVisitor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 1, 2.28516993925936E-86d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int[] intArray4 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, (int) (byte) 100);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) 52, 47.123889803847106d, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math3.util.FastMath.atan(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-2.147483737E9d), 0.0d, pointValuePairConvergenceChecker2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -2,147,483,737 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.2676506E31f + "'", float2 == 1.2676506E31f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(100.0d, 0.0039134618669983915d, 10);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        double[] doubleArray5 = simplexOptimizer4.getLowerBound();
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 9.42477794844185d, 3.7168146928204138d, 1.1578212823495775d, (-0.0d), (-1.0d), 3.1622776601683795d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.exception.ConvergenceException convergenceException10 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.2595063905404449d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5236817353846415d + "'", double1 == 3.5236817353846415d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int[] intArray4 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, (int) (byte) 100);
        int[] intArray11 = new int[] { (byte) 10, 100, (byte) 100, (short) -1 };
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11, (int) (byte) 100);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13);
        double double15 = org.apache.commons.math3.util.MathArrays.distance(intArray6, intArray13);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int[] intArray3 = new int[] { (short) -1, (-1944622665), (short) 1 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector2.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector37 = realVector35.mapDivide(2.28516993925936E-86d);
        double double38 = realVector37.getMaxValue();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 1, 12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        int int2 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.ZeroException zeroException3 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray4 = zeroException3.getSuppressed();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable1, (java.lang.Number) 2147483647, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException6 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = mathUnsupportedOperationException6.getContext();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = eigenDecomposition7.getV();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (short) 100, (float) 7830967380036616271L, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 1, 0.0d, (double) 4.0000005f, (double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(3, 10, Double.NaN);
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapSubtractToSelf((double) (-1));
        java.io.ObjectInputStream objectInputStream16 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) realVector14, ",", objectInputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray3, 0.003913481845644553d, 0.003913481845644553d);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) '#');
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray3, orderDirection12, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double double17 = arrayRealVector16.getLInfNorm();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        int[] intArray6 = lUDecomposition5.getPivot();
        double double7 = lUDecomposition5.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = lUDecomposition5.getU();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(realMatrix8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector18.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        double[] doubleArray24 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray25 = new double[] {};
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray24, doubleArray25);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20, arrayRealVector32);
        double[] doubleArray37 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        double[] doubleArray42 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42, true);
        double[] doubleArray45 = diagonalMatrix39.operate(doubleArray42);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight46 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector47.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42, arrayRealVector47);
        double double51 = arrayRealVector20.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector47.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector15.combineToSelf((double) 4.0000005f, 3.1622776601683795d, (org.apache.commons.math3.linear.RealVector) arrayRealVector54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector54);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = blockRealMatrix35.getColumnMatrix((int) (byte) 0);
        double double38 = blockRealMatrix35.getNorm();
        try {
            double[] doubleArray40 = blockRealMatrix35.getRow((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 60.0d + "'", double38 == 60.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray12 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector2.append(arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector20.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector22.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector24.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getWrongDimensions();
        int int7 = matrixDimensionMismatchException4.getExpectedRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 36 + "'", int5 == 36);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor73 = null;
        try {
            double double78 = blockRealMatrix72.walkInRowOrder(realMatrixChangingVisitor73, 35, 0, (int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double double6 = lUDecomposition5.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = lUDecomposition5.getU();
        int[] intArray8 = lUDecomposition5.getPivot();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(realMatrix7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray29 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector31.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double[] doubleArray37 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray38);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex44 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray37, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector45);
        double[] doubleArray48 = arrayRealVector45.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, doubleArray48);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair51 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray18, doubleArray48, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        double[] doubleArray75 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex80 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray75, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray86 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex91 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray86, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds92 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray75, doubleArray86);
        double[] doubleArray93 = simpleBounds92.getUpper();
        try {
            array2DRowRealMatrix66.setRow(6, doubleArray93);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix73.getSubMatrix((int) '#', (-1), (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        java.lang.String str27 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition35 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix32.copy();
        double[] doubleArray38 = diagonalMatrix32.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix6.add(diagonalMatrix32);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix39.getColumnMatrix(1041236929);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,041,236,929)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{{-1,0},{0,0}}" + "'", str27.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        arrayRealVector1.set((double) 3);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double7 = arrayRealVector1.walkInDefaultOrder(realVectorPreservingVisitor4, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (-1L), (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        int int36 = array2DRowRealMatrix32.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition74 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix72, (-9990.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix71 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = openMapRealMatrix71.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor73 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double74 = openMapRealMatrix71.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        double double75 = array2DRowRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        defaultRealMatrixPreservingVisitor73.start(1041236929, 80, 10, 1, 2, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(realMatrix72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double[] doubleArray8 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray9 = new double[] {};
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray26 = diagonalMatrix20.operate(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray23, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector2);
        boolean boolean31 = arrayRealVector2.isNaN();
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String[] strArray2 = new java.lang.String[] { "{", "]" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray2, orderDirection3, false);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getMid();
        double double3 = bracketFinder0.getHi();
        int int4 = bracketFinder0.getEvaluations();
        org.apache.commons.math3.analysis.function.Sinc sinc5 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType6 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc5, goalType6, 4.5d, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + goalType6 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType6.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 3, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        java.text.NumberFormat numberFormat2 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat3 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat2);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat4 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = blockRealMatrix35.getColumnMatrix((int) (byte) 0);
        double double38 = blockRealMatrix35.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector39.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        double[] doubleArray45 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray46 = new double[] {};
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray45, doubleArray46);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray45, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45, arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector41, arrayRealVector53);
        double[] doubleArray58 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58, true);
        double[] doubleArray63 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray63, true);
        double[] doubleArray66 = diagonalMatrix60.operate(doubleArray63);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight67 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector68.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63, arrayRealVector68);
        double double72 = arrayRealVector41.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector41.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, false);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix35, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 60.0d + "'", double38 == 60.0d);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(realVector74);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        double[] doubleArray15 = openMapRealMatrix8.getRow(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix8);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = openMapRealMatrix10.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = openMapRealMatrix10.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        try {
            array2DRowRealMatrix7.addToEntry(1041236929, 2, 49.72798944455531d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,041,236,929)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(22025.465794806718d, 2.2250738585072014E-308d, (-1.5401476965874874d), 0.0d, (double) 0.9670298f, 2.718281828459045d, 0.9670298382732487d, (double) 36);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 37.44173373780709d + "'", double8 == 37.44173373780709d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(36, 0.19036012811898584d, 0.0d, 1.0E-14d, (double) ' ');
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double[] doubleArray8 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8, true);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray16 = diagonalMatrix10.operate(doubleArray13);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray34, false);
        double[] doubleArray37 = pointVectorValuePair36.getPointRef();
        double[] doubleArray41 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray42 = new double[] {};
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray42);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray41, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray51 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double[] doubleArray56 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray56, true);
        double[] doubleArray59 = diagonalMatrix53.operate(doubleArray56);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair61 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray41, doubleArray56, true);
        boolean boolean62 = simpleVectorValueChecker3.converged(100, pointVectorValuePair36, pointVectorValuePair61);
        double double63 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer64 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 10.0d + "'", double63 == 10.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (-558340673));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray12 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector2.append(arrayRealVector6);
        double double20 = arrayRealVector19.getNorm();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector19.mapDivideToSelf((-0.2321040789270661d));
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.ZeroException zeroException5 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Throwable[] throwableArray6 = zeroException5.getSuppressed();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable3, (java.lang.Number) 2147483647, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException8 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable2, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 0L, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), (float) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getRowMatrix(0);
        double[] doubleArray41 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix43 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition44 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix43);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition46 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix43, 10.0d);
        double double47 = diagonalMatrix43.getNorm();
        double[][] doubleArray48 = diagonalMatrix43.getData();
        try {
            blockRealMatrix35.setRowMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x2 but expected 1x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 36, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 36.0f + "'", float2 == 36.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector2.mapSubtractToSelf(0.5434049467914646d);
        double[] doubleArray38 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38, true);
        double[] doubleArray43 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        double[] doubleArray46 = diagonalMatrix40.operate(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight47 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector48.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector2.append(arrayRealVector48);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(arrayRealVector52);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        double[] doubleArray72 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray72, true);
        double[] doubleArray77 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray77, true);
        double[] doubleArray80 = diagonalMatrix74.operate(doubleArray77);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight81 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = arrayRealVector82.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77, arrayRealVector82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = arrayRealVector82.add((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        try {
            array2DRowRealMatrix68.setColumnVector(3, (org.apache.commons.math3.linear.RealVector) arrayRealVector82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 6x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(arrayRealVector84);
        org.junit.Assert.assertNotNull(arrayRealVector87);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.0d, (double) 10L, 49.72798944455531d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        int int2 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        double[] doubleArray40 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray51 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex56 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray51, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds57 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray40, doubleArray51);
        double[] doubleArray58 = simpleBounds57.getUpper();
        double[] doubleArray59 = simpleBounds57.getUpper();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight60 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray59);
        try {
            double[] doubleArray61 = array2DRowRealMatrix32.preMultiply(doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 'a', (float) 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        int int3 = openMapRealMatrix2.getRowDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getLo();
        int int3 = bracketFinder0.getEvaluations();
        double double4 = bracketFinder0.getFHi();
        double double5 = bracketFinder0.getFHi();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector3);
        double[] doubleArray8 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray9 = new double[] {};
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray26 = diagonalMatrix20.operate(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray23, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, arrayRealVector2);
        double double31 = arrayRealVector2.getNorm();
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.random.BitsStreamGenerator bitsStreamGenerator7 = bitsStreamGeneratorPair4.getFirst();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder8 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double9 = bracketFinder8.getFMid();
        double double10 = bracketFinder8.getLo();
        int int11 = bracketFinder8.getEvaluations();
        boolean boolean12 = bitsStreamGeneratorPair4.equals((java.lang.Object) bracketFinder8);
        double double13 = bracketFinder8.getFMid();
        double double14 = bracketFinder8.getFLo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(bitsStreamGenerator7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (short) 10, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 80);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 80.0d + "'", double1 == 80.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair6 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>(bitsStreamGeneratorPair4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (double) 1.0f);
        double[] doubleArray10 = diagonalMatrix4.getDataRef();
        double[] doubleArray14 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray15 = new double[] {};
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray15);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray29 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix31 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29, true);
        double[] doubleArray32 = diagonalMatrix26.operate(doubleArray29);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair34 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray29, true);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException37 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.45597888911063d, objArray36);
        java.lang.Throwable[] throwableArray38 = notFiniteNumberException37.getSuppressed();
        boolean boolean39 = pointVectorValuePair34.equals((java.lang.Object) throwableArray38);
        double[] doubleArray40 = pointVectorValuePair34.getValueRef();
        double double41 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray10, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("org.apache.commons.math3.exception.ZeroException: zero not allowed here", "{", "", "hi!", "", "org.apache.commons.math3.exception.ZeroException: zero not allowed here");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        java.text.NumberFormat numberFormat2 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealVector realVector3 = null;
        try {
            java.lang.String str4 = realVectorFormat0.format(realVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = openMapRealMatrix10.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = openMapRealMatrix10.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        defaultRealMatrixPreservingVisitor12.visit((int) (short) -1, 100, (double) '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.177183820135558d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = openMapRealMatrix27.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor29 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double30 = openMapRealMatrix27.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor29);
        double double31 = diagonalMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor29);
        diagonalMatrix24.multiplyEntry(12, 0, (-0.5440211108893698d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 9.42477794844185d, 3.7168146928204138d, 1.1578212823495775d, (-0.0d), (-1.0d), 3.1622776601683795d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((-1944622665), (int) ' ');
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(Double.NaN, (double) 0.9670298f);
        double double3 = brentOptimizer2.getStartValue();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker4 = brentOptimizer2.getConvergenceChecker();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = brentOptimizer2.getGoalType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(univariatePointValuePairConvergenceChecker4);
        org.junit.Assert.assertNull(goalType5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(100);
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[] doubleArray8 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray13 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray18 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray23 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray28 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray33 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray34 = new double[][] { doubleArray8, doubleArray13, doubleArray18, doubleArray23, doubleArray28, doubleArray33 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, false);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 100, localizable3, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix41);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        java.lang.Class<?> wildcardClass11 = doubleArray7.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        boolean boolean9 = diagonalMatrix4.isSquare();
        double[] doubleArray10 = diagonalMatrix4.getDataRef();
        double[] doubleArray14 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray15 = new double[] {};
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray15);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray29 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix31 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29, true);
        double[] doubleArray32 = diagonalMatrix26.operate(doubleArray29);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair34 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray29, true);
        double[] doubleArray35 = pointVectorValuePair34.getPoint();
        double[] doubleArray36 = pointVectorValuePair34.getFirst();
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (short) 100);
        double[] doubleArray42 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray52 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray52, true);
        double[] doubleArray57 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57, true);
        double[] doubleArray60 = diagonalMatrix54.operate(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray42, doubleArray57, true);
        double[] doubleArray63 = pointVectorValuePair62.getValue();
        int int64 = org.apache.commons.math3.util.MathUtils.hash(doubleArray63);
        double[] doubleArray67 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray67, false);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds70 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray63, doubleArray67);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition71 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray36, doubleArray63);
        try {
            double[] doubleArray72 = diagonalMatrix4.operate(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1041236929 + "'", int64 == 1041236929);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        double[] doubleArray15 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        double[] doubleArray20 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        double[] doubleArray23 = diagonalMatrix17.operate(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector25.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector25.add((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector31.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double[] doubleArray37 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray38);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex44 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray37, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector45);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray55 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        double[] doubleArray58 = diagonalMatrix52.operate(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight59 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector60.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, arrayRealVector60);
        double double64 = arrayRealVector33.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector33.mapSubtractToSelf(0.5434049467914646d);
        double double67 = arrayRealVector30.getDistance(realVector66);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector11.append(realVector66);
        org.apache.commons.math3.linear.RealVector realVector70 = arrayRealVector11.mapAdd((double) 2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(realVector70);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        int int11 = nelderMeadSimplex10.getDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str3 = realMatrixFormat2.getColumnSeparator();
        double[] doubleArray6 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray11 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double[] doubleArray14 = diagonalMatrix8.operate(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray26 = diagonalMatrix20.operate(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = diagonalMatrix8.multiply(diagonalMatrix20);
        java.lang.String str29 = realMatrixFormat2.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8);
        double[] doubleArray32 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition35 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = diagonalMatrix34.copy();
        double[] doubleArray40 = diagonalMatrix34.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = diagonalMatrix8.add(diagonalMatrix34);
        java.lang.String str42 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition43 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(realMatrixFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(diagonalMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{{-1,0},{0,0}}" + "'", str29.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(diagonalMatrix41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{{-1,0},{0,0}}" + "'", str42.equals("{{-1,0},{0,0}}"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double double73 = blockRealMatrix71.getFrobeniusNorm();
        try {
            double double76 = blockRealMatrix71.getEntry((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 24.65302686521849d + "'", double73 == 24.65302686521849d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable5, intArray12, intArray14);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 2, 1.0d, 0.0d, (double) (short) 10, (java.lang.Object[]) intArray14);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f, (java.lang.Number) 60.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((-0.5440211108893698d), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -0.544 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.0E-6d);
        try {
            java.lang.String str3 = notStrictlyPositiveException2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(7.93006726156716E14d, (double) 'a', 1.4711276743037347d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 793,006,726,156,716 is larger than, or equal to, the maximum (97)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getAbsoluteAccuracy();
        double double2 = brentSolver0.getRelativeAccuracy();
        double double3 = brentSolver0.getRelativeAccuracy();
        double double4 = brentSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-6d + "'", double1 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(Double.NaN, (double) 0.9670298f);
        int int3 = brentOptimizer2.getMaxIterations();
        double double4 = brentOptimizer2.getMax();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = eigenDecomposition7.getEigenvector(1);
        try {
            org.apache.commons.math3.linear.RealVector realVector11 = eigenDecomposition7.getEigenvector(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        double double5 = openMapRealMatrix2.getNorm();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix2.subtract(openMapRealMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix2.subtract(openMapRealMatrix16);
        try {
            openMapRealMatrix28.setEntry(80, (-1), 1.2761081516257424d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (80)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        int int5 = gaussNewtonOptimizer4.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        double[] doubleArray25 = diagonalMatrix16.getDataRef();
        int int26 = diagonalMatrix16.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix36.transpose();
        double[] doubleArray42 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray47 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray52 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray57 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray62 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray67 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray68 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62, doubleArray67 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68, false);
        int int71 = array2DRowRealMatrix70.getColumnDimension();
        double[][] doubleArray72 = array2DRowRealMatrix70.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = array2DRowRealMatrix74.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix37, (org.apache.commons.math3.linear.AnyMatrix) realMatrix75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix75);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray2 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, false);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray12 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12, true);
        double[] doubleArray15 = diagonalMatrix9.operate(doubleArray12);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, arrayRealVector17);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds24 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray2, doubleArray22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector25.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray31 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray32 = new double[] {};
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray32);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector27, arrayRealVector39);
        double[] doubleArray44 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44, true);
        double[] doubleArray49 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        double[] doubleArray52 = diagonalMatrix46.operate(doubleArray49);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight53 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector54.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49, arrayRealVector54);
        double double58 = arrayRealVector27.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector59.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        double[] doubleArray65 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray66 = new double[] {};
        boolean boolean67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray65, doubleArray66);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex72 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray65, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, arrayRealVector73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector61, arrayRealVector73);
        double double76 = arrayRealVector54.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        double[] doubleArray77 = arrayRealVector54.toArray();
        try {
            double[] doubleArray78 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray2, doubleArray77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0d);
        java.lang.Number number2 = notPositiveException1.getMin();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        java.lang.Number number4 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[] doubleArray78 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma79 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector80.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        double[] doubleArray86 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray87 = new double[] {};
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray86, doubleArray87);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex93 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray86, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray86, arrayRealVector94);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector96 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector82, arrayRealVector94);
        double[] doubleArray97 = arrayRealVector94.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector98 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78, doubleArray97);
        try {
            double[] doubleArray99 = blockRealMatrix71.preMultiply(doubleArray78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(doubleArray97);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (double) 1.0f);
        diagonalMatrix4.multiplyEntry((int) (byte) -1, (int) '#', 3.2710663101885897d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double19 = diagonalMatrix4.walkInColumnOrder(realMatrixChangingVisitor14, (int) (byte) 100, (int) '#', 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray11 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray16 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray21 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray26 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray31 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32, false);
        int int35 = array2DRowRealMatrix34.getColumnDimension();
        double[][] doubleArray36 = array2DRowRealMatrix34.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1, (java.lang.Object[]) doubleArray36);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex38 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 2, 52, 2, 6, (-1944622665), 35 };
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable7, intArray14, intArray16);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray14);
        java.lang.Integer[] intArray19 = multiDimensionMismatchException18.getWrongDimensions();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, number1);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        double[] doubleArray15 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        double[] doubleArray20 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20, true);
        double[] doubleArray23 = diagonalMatrix17.operate(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector25.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector25.add((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector31.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double[] doubleArray37 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray38 = new double[] {};
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray37, doubleArray38);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex44 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray37, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33, arrayRealVector45);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray55 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        double[] doubleArray58 = diagonalMatrix52.operate(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight59 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector60.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, arrayRealVector60);
        double double64 = arrayRealVector33.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector33.mapSubtractToSelf(0.5434049467914646d);
        double double67 = arrayRealVector30.getDistance(realVector66);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector11.append(realVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector69.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        double[] doubleArray74 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix76 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray74, true);
        double[] doubleArray79 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray79, true);
        double[] doubleArray82 = diagonalMatrix76.operate(doubleArray79);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight83 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray79);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = arrayRealVector84.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray79, arrayRealVector84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector84.add((org.apache.commons.math3.linear.RealVector) arrayRealVector88);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = arrayRealVector71.append(arrayRealVector88);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double92 = arrayRealVector71.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector91);
        try {
            double double93 = realVector66.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector91);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(arrayRealVector86);
        org.junit.Assert.assertNotNull(arrayRealVector89);
        org.junit.Assert.assertNotNull(arrayRealVector90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double2 = org.apache.commons.math3.util.FastMath.log(99.50376877284599d, (double) (-608192130026889042L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 7830967380036616271L, false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix72.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix76 = blockRealMatrix72.power((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getHi();
        double double2 = bracketFinder0.getFLo();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("}", "hi!", "}", "", ",", "{{-1,0},{0,0}}", numberFormat6);
        java.text.ParsePosition parsePosition9 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat7.parse("}", parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        java.lang.String str27 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition35 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix32.copy();
        double[] doubleArray38 = diagonalMatrix32.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix6.add(diagonalMatrix32);
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray59 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray64 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray69 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray70 = new double[][] { doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64, doubleArray69 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70, false);
        int int73 = array2DRowRealMatrix72.getColumnDimension();
        boolean boolean74 = array2DRowRealMatrix72.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = array2DRowRealMatrix72.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor76 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double77 = array2DRowRealMatrix72.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor76);
        double double78 = diagonalMatrix39.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor76);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{{-1,0},{0,0}}" + "'", str27.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L);
        double double2 = brentSolver1.getStartValue();
        double double3 = brentSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.5434049467914646d, 0.0d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = objectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = objectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = objectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNull(multivariateFunction2);
        org.junit.Assert.assertNull(multivariateFunction3);
        org.junit.Assert.assertNull(multivariateFunction4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 10);
        incrementor1.setMaximalCount((int) '#');
        boolean boolean4 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor69 = null;
        try {
            double double74 = array2DRowRealMatrix66.walkInRowOrder(realMatrixChangingVisitor69, 3, (int) (byte) 10, (-558340673), 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.233403117511217d + "'", double1 == 1.233403117511217d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister(100);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray10 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray15 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray20 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray25 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray30 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray35 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray36 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36, false);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 100, localizable5, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36, true);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException43 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable1, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 10);
        int int2 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math3.util.FastMath.abs(3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7168146928204138d + "'", double1 == 3.7168146928204138d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.scalarMultiply(9.42477794844185d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric(realMatrix9, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (3x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat11 = realMatrixFormat10.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("{{-1,0},{0,0}}", "", "hi!", ",", "{", "", numberFormat11);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat("{", "{{-1,0},{0,0}}", "{", numberFormat11);
        java.lang.StringBuffer stringBuffer14 = null;
        java.text.FieldPosition fieldPosition15 = null;
        try {
            java.lang.StringBuffer stringBuffer16 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 1041236929, numberFormat11, stringBuffer14, fieldPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat10);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.177183820135558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector16.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        double[] doubleArray22 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector30);
        double[] doubleArray35 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray40 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray40, true);
        double[] doubleArray43 = diagonalMatrix37.operate(doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector45);
        double double49 = arrayRealVector18.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector18.mapSubtractToSelf(0.5434049467914646d);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector15.append((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        int int53 = arrayRealVector18.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray11);
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        java.lang.Integer[] intArray20 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException23 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable13, intArray20, intArray22);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray9, intArray22);
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 2, 52, 2, 6, (-1944622665), 35 };
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        java.lang.Integer[] intArray39 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray41 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException42 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable32, intArray39, intArray41);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException43 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray39);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException44 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray22, intArray31);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (-1944622665));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1141867144998254E11d) + "'", double1 == (-1.1141867144998254E11d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        boolean boolean6 = openMapRealMatrix2.isSquare();
        try {
            openMapRealMatrix2.addToEntry((int) 'a', 1195587395, 50.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(4);
        long long7 = mersenneTwister6.nextLong();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula9 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray19 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray19, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray30 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray30, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds36 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray19, doubleArray30);
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double44 = noBracketingException43.getLo();
        java.lang.Throwable[] throwableArray45 = noBracketingException43.getSuppressed();
        boolean boolean46 = pointValuePair38.equals((java.lang.Object) throwableArray45);
        double[] doubleArray52 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex57 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray52, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray63 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex68 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray63, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds69 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray52, doubleArray63);
        org.apache.commons.math3.optim.PointValuePair pointValuePair71 = new org.apache.commons.math3.optim.PointValuePair(doubleArray52, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException76 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double77 = noBracketingException76.getLo();
        java.lang.Throwable[] throwableArray78 = noBracketingException76.getSuppressed();
        boolean boolean79 = pointValuePair71.equals((java.lang.Object) throwableArray78);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat80 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str81 = realMatrixFormat80.getColumnSeparator();
        boolean boolean82 = pointValuePair71.equals((java.lang.Object) str81);
        boolean boolean83 = simpleValueChecker12.converged((int) (byte) 100, pointValuePair38, pointValuePair71);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer84 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer85 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer86 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula9, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double87 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer88 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(12, 49.72798944455531d, true, 52, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        int int89 = cMAESOptimizer88.getIterations();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-608192130026889042L) + "'", long7 == (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + formula9 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula9.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "," + "'", str81.equals(","));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-0.5440211108893698d) + "'", double87 == (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        double[] doubleArray13 = cMAESOptimizer10.getUpperBound();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer10.getStatisticsMeanHistory();
        java.util.List<java.lang.Double> doubleList15 = cMAESOptimizer10.getStatisticsFitnessHistory();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNotNull(doubleList15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray5 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, true);
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        double[] doubleArray13 = diagonalMatrix7.operate(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector15.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector15.add((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector2.append(arrayRealVector19);
        double double22 = arrayRealVector19.getMinValue();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getHi();
        java.lang.String str8 = noBracketingException4.toString();
        double double9 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math3.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [0, 100], values: [35, 100]" + "'", str8.equals("org.apache.commons.math3.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [0, 100], values: [35, 100]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray2 = new long[] { (-1) };
        long[][] longArray3 = new long[][] { longArray2 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray3);
        org.apache.commons.math3.exception.ConvergenceException convergenceException5 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) longArray3);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray3);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix32.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        float[] floatArray6 = new float[] { 3, 'a', (-0.99999994f), 1.4E-45f, (-558340673), 10L };
        float[] floatArray13 = new float[] { (-1L), 'a', 10, (byte) -1, 100L, 7830967380036616271L };
        float[] floatArray14 = new float[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray13, floatArray14);
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray14);
        float[] floatArray23 = new float[] { 6, 36, 80, 10, (byte) -1, 36 };
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray23);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.19036012811898584d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray11 = null;
        try {
            double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray7, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        double double15 = arrayRealVector2.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector2.mapAddToSelf((double) 0.9670298f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector2.append((double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector23.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector2.combineToSelf((-1.5401476965874874d), (-1.0d), (org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector26 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector24.ebeMultiply(realVector26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double[] doubleArray4 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray5 = new double[] {};
        boolean boolean6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray5);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray4, doubleArray19, true);
        double[] doubleArray25 = pointVectorValuePair24.getPoint();
        double[] doubleArray26 = pointVectorValuePair24.getFirst();
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray26);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) (-1.0f), doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        double[] doubleArray28 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray29 = new double[] {};
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray5, doubleArray28);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.getDataRef();
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = diagonalMatrix4.getColumnVector(1195587395);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,195,587,395)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(3.965033630783837E14d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.965033630783837E14d + "'", double2 == 3.965033630783837E14d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor74 = null;
        try {
            double double75 = blockRealMatrix72.walkInRowOrder(realMatrixPreservingVisitor74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister(100);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray34 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray35 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35, false);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 100, localizable4, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35, true);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException42 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 1.0d, (java.lang.Object[]) doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.45597888911063d, objArray25);
        java.lang.Throwable[] throwableArray27 = notFiniteNumberException26.getSuppressed();
        boolean boolean28 = pointVectorValuePair23.equals((java.lang.Object) throwableArray27);
        double[] doubleArray29 = pointVectorValuePair23.getValueRef();
        double[] doubleArray32 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        double[] doubleArray37 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        double[] doubleArray40 = diagonalMatrix34.operate(doubleArray37);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector42);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) (short) 0);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray47, 47.123889803847106d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        double double11 = eigenDecomposition7.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = eigenDecomposition7.getV();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.0d) + "'", double11 == (-0.0d));
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("}", "hi!", "}", "", ",", "{{-1,0},{0,0}}", numberFormat6);
        double[] doubleArray10 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        double[] doubleArray15 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        double[] doubleArray18 = diagonalMatrix12.operate(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
        double[] doubleArray22 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22, true);
        double[] doubleArray27 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        double[] doubleArray30 = diagonalMatrix24.operate(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = diagonalMatrix12.multiply(diagonalMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.scalarMultiply((double) (byte) 1);
        java.lang.String str35 = realMatrixFormat7.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(diagonalMatrix32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "}}1{{-1,0},{0,0}}0,}0{{-1,0},{0,0}}0hi!" + "'", str35.equals("}}1{{-1,0},{0,0}}0,}0{{-1,0},{0,0}}0hi!"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(120.0d, (double) (-1944622665));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.21722891503668823d), (java.lang.Number) 1, (java.lang.Number) 3.965033630783837E14d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) 10.0f, (double) (byte) 1, 120.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double37 = array2DRowRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix32.copy();
        try {
            double double41 = array2DRowRealMatrix32.getEntry((int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        int int12 = cMAESOptimizer10.getIterations();
        java.util.List<java.lang.Double> doubleList13 = cMAESOptimizer10.getStatisticsFitnessHistory();
        double[] doubleArray14 = cMAESOptimizer10.getStartPoint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(doubleList13);
        org.junit.Assert.assertNull(doubleArray14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) '4');
        double[] doubleArray2 = simpleBounds1.getUpper();
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotFiniteNumberException; message: value ∞ at index 0");
        } catch (org.apache.commons.math3.exception.NotFiniteNumberException e) {
        }
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        double[] doubleArray12 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray12, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector2.append(arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector20.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector22.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector26.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double[] doubleArray32 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray33 = new double[] {};
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray32, doubleArray33);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray32, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28, arrayRealVector40);
        double[] doubleArray45 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray45, true);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray53 = diagonalMatrix47.operate(doubleArray50);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight54 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector55.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, arrayRealVector55);
        double double59 = arrayRealVector28.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector60.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        double[] doubleArray66 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray67 = new double[] {};
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray66, doubleArray67);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex73 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray66, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66, arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector62, arrayRealVector74);
        double double77 = arrayRealVector55.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        try {
            arrayRealVector24.setSubVector((int) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 1041236929, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.45597888911063d, objArray25);
        java.lang.Throwable[] throwableArray27 = notFiniteNumberException26.getSuppressed();
        boolean boolean28 = pointVectorValuePair23.equals((java.lang.Object) throwableArray27);
        double[] doubleArray29 = pointVectorValuePair23.getPoint();
        double[] doubleArray33 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray34 = new double[] {};
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray33, doubleArray34);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex40 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray33, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray43 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        double[] doubleArray48 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48, true);
        double[] doubleArray51 = diagonalMatrix45.operate(doubleArray48);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair53 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray48, true);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray48, (int) (byte) 10);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition56 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        double[] doubleArray52 = arrayRealVector29.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector53.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        double[] doubleArray59 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray60 = new double[] {};
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray59, doubleArray60);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex66 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray59, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59, arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector55, arrayRealVector67);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector69.mapMultiply((double) 0.0f);
        org.apache.commons.math3.linear.RealVector realVector72 = arrayRealVector29.append((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertNotNull(realVector72);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        double[] doubleArray13 = cMAESOptimizer10.getUpperBound();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType14 = cMAESOptimizer10.getGoalType();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(doubleArray13);
        org.junit.Assert.assertNull(goalType14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        float float2 = org.apache.commons.math3.util.Precision.round(0.0f, 1195587395);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix72.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = blockRealMatrix74.scalarAdd(35.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = blockRealMatrix74.scalarMultiply((double) (-558340673));
        try {
            blockRealMatrix74.addToEntry((int) (byte) -1, 3, 3.2710663101885897d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor74 = null;
        try {
            double double79 = blockRealMatrix72.walkInOptimizedOrder(realMatrixChangingVisitor74, (-558340673), (int) (short) 10, 50, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-558,340,673)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math3.util.FastMath.asin(80.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector21);
        double[] doubleArray26 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        double[] doubleArray31 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, true);
        double[] doubleArray34 = diagonalMatrix28.operate(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector36);
        double double40 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector41.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        double[] doubleArray47 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray47, doubleArray48);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray47, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector43, arrayRealVector55);
        double double58 = arrayRealVector36.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.analysis.function.Sinc sinc60 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double64 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc60, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector55.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc60);
        boolean boolean66 = bitsStreamGeneratorPair4.equals((java.lang.Object) arrayRealVector55);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor67 = null;
        try {
            double double68 = arrayRealVector55.walkInOptimizedOrder(realVectorChangingVisitor67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 49.72798944455531d + "'", double64 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(0.0d, (double) 2147483647);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        double[][] doubleArray69 = null;
        try {
            array2DRowRealMatrix32.setSubMatrix(doubleArray69, (int) (byte) 0, (-1944622665));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(1.177183820135558d, (double) 10L);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        int int4 = levenbergMarquardtOptimizer3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        blockRealMatrix72.multiplyEntry(0, (int) (short) 0, 4.5d);
        boolean boolean77 = blockRealMatrix72.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(1.2761081516257424d, 0.278369388163781d, 4.5d, (double) ' ');
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 9.42477794844185d, 3.7168146928204138d, 1.1578212823495775d, (-0.0d), (-1.0d), 3.1622776601683795d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) (-0.2321040789270661d), (java.lang.Object[]) doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.getDataRef();
        double[] doubleArray15 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray16 = new double[] {};
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray15, 0.003913481845644553d, 0.003913481845644553d);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) '#');
        try {
            double[] doubleArray24 = diagonalMatrix4.operate(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.RealVector realVector74 = blockRealMatrix71.getRowVector(0);
        double[] doubleArray79 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray80 = new double[] {};
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray79, doubleArray80);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex86 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray79, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray79, arrayRealVector87);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector88.append((double) (-1L));
        try {
            blockRealMatrix71.setRowVector(5, (org.apache.commons.math3.linear.RealVector) arrayRealVector88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 1x4");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(realVector90);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector21);
        double[] doubleArray26 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        double[] doubleArray31 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, true);
        double[] doubleArray34 = diagonalMatrix28.operate(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, arrayRealVector36);
        double double40 = arrayRealVector9.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector41.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        double[] doubleArray47 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray48 = new double[] {};
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray47, doubleArray48);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray47, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector43, arrayRealVector55);
        double double58 = arrayRealVector36.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.analysis.function.Sinc sinc60 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double64 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc60, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = arrayRealVector55.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc60);
        boolean boolean66 = bitsStreamGeneratorPair4.equals((java.lang.Object) arrayRealVector55);
        java.lang.CharSequence charSequence67 = bitsStreamGeneratorPair4.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 49.72798944455531d + "'", double64 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + charSequence67 + "' != '" + "hi!" + "'", charSequence67.equals("hi!"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.0E-6d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        double[] doubleArray23 = simpleBounds22.getUpper();
        double[] doubleArray24 = simpleBounds22.getUpper();
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray34 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray55 = new double[][] { doubleArray29, doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55, false);
        int int58 = array2DRowRealMatrix57.getColumnDimension();
        double[][] doubleArray59 = array2DRowRealMatrix57.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray24, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        int[] intArray6 = lUDecomposition5.getPivot();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver7 = lUDecomposition5.getSolver();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = lUDecomposition5.getL();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(decompositionSolver7);
        org.junit.Assert.assertNull(realMatrix8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math3.util.FastMath.atan(49.72798944455531d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.55068963742572d + "'", double1 == 1.55068963742572d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 9.42477794844185d, 3.7168146928204138d, 1.1578212823495775d, (-0.0d), (-1.0d), 3.1622776601683795d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double double8 = arrayRealVector7.getL1Norm();
        double[] doubleArray9 = arrayRealVector7.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 18.46169158378022d + "'", double8 == 18.46169158378022d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double37 = array2DRowRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix40 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = openMapRealMatrix40.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor42 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double43 = openMapRealMatrix40.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        double double44 = array2DRowRealMatrix32.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor42);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        double[] doubleArray23 = simpleBounds22.getUpper();
        double[] doubleArray24 = simpleBounds22.getUpper();
        double[] doubleArray25 = simpleBounds22.getLower();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((-2.330679416656494d), 0.0d, 3.2710663101885897d, 10.000000000000002d, 3.965033630783837E14d, (double) (short) 10, 0.003913481845644553d, (double) 6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.9650336307838695E15d + "'", double8 == 3.9650336307838695E15d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double57 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc53, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector48.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector48.copy();
        boolean boolean60 = arrayRealVector59.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector59.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector62.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double[] doubleArray68 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray69 = new double[] {};
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray68, doubleArray69);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex75 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray68, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray68, arrayRealVector76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector64, arrayRealVector76);
        double[] doubleArray81 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix83 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray81, true);
        double[] doubleArray86 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix88 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray86, true);
        double[] doubleArray89 = diagonalMatrix83.operate(doubleArray86);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight90 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector91.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector92);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray86, arrayRealVector91);
        double double95 = arrayRealVector64.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector91);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix96 = arrayRealVector61.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 49.72798944455531d + "'", double57 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(arrayRealVector61);
        org.junit.Assert.assertNotNull(arrayRealVector64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(arrayRealVector93);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getRowMatrix(0);
        int int38 = blockRealMatrix37.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) 'a', (int) (byte) 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math3.util.FastMath.rint(3.965033630783837E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.96503363078384E14d + "'", double1 == 3.96503363078384E14d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        boolean boolean9 = diagonalMatrix4.isSquare();
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray13, 0.003913481845644553d, 0.003913481845644553d);
        try {
            double[] doubleArray20 = diagonalMatrix4.operate(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        try {
            double double35 = array2DRowRealMatrix32.getEntry((int) (short) 0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix32.scalarMultiply((double) ' ');
        boolean boolean36 = array2DRowRealMatrix32.isSquare();
        array2DRowRealMatrix32.multiplyEntry((int) (byte) 0, (int) (short) 0, 0.0d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor41 = null;
        try {
            double double46 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixChangingVisitor41, 35, (int) (byte) 100, 1195587395, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.278369388163781d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        java.lang.String str27 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray30 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition35 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix32.copy();
        double[] doubleArray38 = diagonalMatrix32.getRow((int) (short) 1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix6.add(diagonalMatrix32);
        try {
            double double42 = diagonalMatrix39.getEntry(2, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{{-1,0},{0,0}}" + "'", str27.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getFHi();
        int int3 = bracketFinder0.getEvaluations();
        double double4 = bracketFinder0.getLo();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix16);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = openMapRealMatrix2.subtract(openMapRealMatrix28);
        double[] doubleArray31 = openMapRealMatrix2.getRow(0);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        int int14 = openMapRealMatrix13.getColumnDimension();
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double[] doubleArray5 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector21);
        double[] doubleArray24 = arrayRealVector21.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray24);
        arrayRealVector25.unitize();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 4, (java.lang.Number) 2, false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double57 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc53, 0.0d, 99.45597888911063d, (double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector48.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector48.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector59);
        double double61 = arrayRealVector60.getMinValue();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 49.72798944455531d + "'", double57 == 49.72798944455531d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix36.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double39 = array2DRowRealMatrix36.walkInColumnOrder(realMatrixChangingVisitor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        mersenneTwister1.clear();
        double double3 = mersenneTwister1.nextGaussian();
        long long4 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5401476965874874d) + "'", double3 == (-1.5401476965874874d));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7830967380036616271L + "'", long4 == 7830967380036616271L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double double73 = blockRealMatrix71.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor74 = null;
        try {
            double double79 = blockRealMatrix71.walkInRowOrder(realMatrixChangingVisitor74, (int) (short) 100, (int) (short) 1, (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 24.65302686521849d + "'", double73 == 24.65302686521849d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getSuffix();
        java.lang.String str2 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "]" + "'", str1.equals("]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "]" + "'", str2.equals("]"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer2 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(true, pointVectorValuePairConvergenceChecker1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(52, (-1.1141867144998254E11d), 1.0d, 1.2761081516257424d, (double) 80, 60.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor74 = null;
        try {
            double double79 = blockRealMatrix72.walkInOptimizedOrder(realMatrixChangingVisitor74, 6, 1, 4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        double[] doubleArray28 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray29 = new double[] {};
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray29);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray5, doubleArray28);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5);
        double[] doubleArray36 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray37 = new double[] {};
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray36, doubleArray37);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex43 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray36, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray46 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        double[] doubleArray51 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51, true);
        double[] doubleArray54 = diagonalMatrix48.operate(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray51, true);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        try {
            nelderMeadSimplex32.build(doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(18.46169158378022d, 24.65302686521849d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix32.scalarAdd((double) '#');
        double[][] doubleArray71 = array2DRowRealMatrix32.getDataRef();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix73 = array2DRowRealMatrix32.getRowMatrix(12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (12)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        java.util.List<java.lang.Double> doubleList11 = cMAESOptimizer10.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        double[] doubleArray13 = cMAESOptimizer10.getUpperBound();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer10.getStatisticsMeanHistory();
        double[] doubleArray15 = cMAESOptimizer10.getLowerBound();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertNotNull(doubleList11);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNull(doubleArray15);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(4);
        long long7 = mersenneTwister6.nextLong();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula9 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray19 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray19, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray30 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray30, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds36 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray19, doubleArray30);
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double44 = noBracketingException43.getLo();
        java.lang.Throwable[] throwableArray45 = noBracketingException43.getSuppressed();
        boolean boolean46 = pointValuePair38.equals((java.lang.Object) throwableArray45);
        double[] doubleArray52 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex57 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray52, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray63 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex68 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray63, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds69 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray52, doubleArray63);
        org.apache.commons.math3.optim.PointValuePair pointValuePair71 = new org.apache.commons.math3.optim.PointValuePair(doubleArray52, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException76 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double77 = noBracketingException76.getLo();
        java.lang.Throwable[] throwableArray78 = noBracketingException76.getSuppressed();
        boolean boolean79 = pointValuePair71.equals((java.lang.Object) throwableArray78);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat80 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str81 = realMatrixFormat80.getColumnSeparator();
        boolean boolean82 = pointValuePair71.equals((java.lang.Object) str81);
        boolean boolean83 = simpleValueChecker12.converged((int) (byte) 100, pointValuePair38, pointValuePair71);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer84 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer85 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer86 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula9, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double87 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer88 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(12, 49.72798944455531d, true, 52, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        int int89 = mersenneTwister6.nextInt();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-608192130026889042L) + "'", long7 == (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + formula9 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula9.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "," + "'", str81.equals(","));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-0.5440211108893698d) + "'", double87 == (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1944622665) + "'", int89 == (-1944622665));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        boolean boolean9 = diagonalMatrix4.isSquare();
        double[] doubleArray10 = diagonalMatrix4.getDataRef();
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray31 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex36 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray31, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds48 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor51 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double52 = diagonalMatrix50.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51);
        double double53 = defaultRealMatrixPreservingVisitor51.end();
        double double54 = array2DRowRealMatrix25.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51);
        double double55 = diagonalMatrix16.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor51);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 0, (-0.5440211108893698d));
        double[] doubleArray9 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray9, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray20 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray20, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray9, doubleArray20);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double34 = noBracketingException33.getLo();
        java.lang.Throwable[] throwableArray35 = noBracketingException33.getSuppressed();
        boolean boolean36 = pointValuePair28.equals((java.lang.Object) throwableArray35);
        double[] doubleArray42 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray53 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray53, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds59 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray42, doubleArray53);
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double67 = noBracketingException66.getLo();
        java.lang.Throwable[] throwableArray68 = noBracketingException66.getSuppressed();
        boolean boolean69 = pointValuePair61.equals((java.lang.Object) throwableArray68);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat70 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str71 = realMatrixFormat70.getColumnSeparator();
        boolean boolean72 = pointValuePair61.equals((java.lang.Object) str71);
        boolean boolean73 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair28, pointValuePair61);
        double[] doubleArray74 = pointValuePair28.getPointRef();
        org.apache.commons.math3.optim.PointValuePair pointValuePair76 = new org.apache.commons.math3.optim.PointValuePair(doubleArray74, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "," + "'", str71.equals(","));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        double[] doubleArray25 = diagonalMatrix16.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.blockInverse((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16, 0);
        double double28 = diagonalMatrix16.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        double[][] doubleArray76 = blockRealMatrix75.getData();
        try {
            blockRealMatrix75.multiplyEntry(6, (int) (short) 100, 1.5707963267948966d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double[] doubleArray2 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, false);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray12 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12, true);
        double[] doubleArray15 = diagonalMatrix9.operate(doubleArray12);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, arrayRealVector17);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds24 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray2, doubleArray22);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray2);
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray2, 0.0d, true);
        double[] doubleArray29 = pointValuePair28.getPoint();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        double[] doubleArray39 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray44 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray49 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray54 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray59 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray64 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray65 = new double[][] { doubleArray39, doubleArray44, doubleArray49, doubleArray54, doubleArray59, doubleArray64 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix67.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix32.add(array2DRowRealMatrix67);
        double[][] doubleArray70 = array2DRowRealMatrix69.getData();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5202350444438292d) + "'", double1 == (-0.5202350444438292d));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = openMapRealMatrix2.equals(obj3);
        int int5 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix6 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver2, preconditioner3);
        int int5 = nonLinearConjugateGradientOptimizer4.getMaxIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 0, (int) (short) -1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner3 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver2, preconditioner3);
        int int5 = brentSolver2.getMaxEvaluations();
        double double6 = brentSolver2.getMax();
        int int7 = brentSolver2.getMaxEvaluations();
        double double8 = brentSolver2.getMin();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector1.copy();
        org.apache.commons.math3.linear.RealVector realVector5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.combineToSelf((double) 7830967380036616271L, 0.0039134618669983915d, realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "org.apache.commons.math3.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [0, 100], values: [35, 100]", ",");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("org.apache.commons.math3.exception.ZeroException: zero not allowed here");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.exception.ZeroException: zero not allowed here\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-1.1141867144998254E11d), 1.233403117511217d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267838265d) + "'", double2 == (-1.5707963267838265d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        int int17 = arrayRealVector16.getMinIndex();
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(Double.NaN, (double) 0.9670298f);
        int int3 = brentOptimizer2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray16, (double) (byte) 10, (-0.9287117556321675d));
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        double[] doubleArray27 = target26.getTarget();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 80, (java.lang.Number) 36.0f, true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0);
        mersenneTwister1.setSeed(100);
        mersenneTwister1.setSeed(10L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        double[] doubleArray11 = eigenDecomposition7.getImagEigenvalues();
        double[] doubleArray17 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray17, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray28 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex33 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray28, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds34 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray17, doubleArray28);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, false);
        try {
            double double37 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray11, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 52, 6.283185307179586d, (double) 1195587395, 1.0E-14d, 60.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int6 = matrixDimensionMismatchException5.getWrongColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException5.getWrongDimensions();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException8 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) intArray7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 36 + "'", int6 == 36);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver8 = eigenDecomposition7.getSolver();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver9 = eigenDecomposition7.getSolver();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(decompositionSolver8);
        org.junit.Assert.assertNotNull(decompositionSolver9);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getFHi();
        int int3 = bracketFinder0.getEvaluations();
        int int4 = bracketFinder0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int6 = matrixDimensionMismatchException5.getWrongColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException5.getWrongDimensions();
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 2, 52, 2, 6, (-1944622665), 35 };
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray24 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException25 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable15, intArray22, intArray24);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException26 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray14, intArray22);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException27 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 36 + "'", int6 == 36);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray18, true);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        int int25 = org.apache.commons.math3.util.MathUtils.hash(doubleArray24);
        double[] doubleArray28 = new double[] { 2.2250738585072014E-308d, 49.72798944455531d };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, false);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray24, doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1041236929 + "'", int25 == 1041236929);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        array2DRowRealMatrix32.setEntry((int) (short) 1, 0, (double) (-1.0f));
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray68 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray69 = new double[][] { doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63, doubleArray68 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69, false);
        int int72 = array2DRowRealMatrix71.getColumnDimension();
        double[][] doubleArray73 = array2DRowRealMatrix71.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73, true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix32.add(array2DRowRealMatrix75);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = null;
        try {
            array2DRowRealMatrix75.setRowMatrix(1195587395, realMatrix78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,195,587,395)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 4 + "'", int72 == 4);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray5 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray10 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray15 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray20 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray25 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray30 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray31 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31, false);
        int int34 = array2DRowRealMatrix33.getColumnDimension();
        double[][] doubleArray35 = array2DRowRealMatrix33.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray35);
        double[] doubleArray41 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray46 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray51 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray56 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray61 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray66 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray67 = new double[][] { doubleArray41, doubleArray46, doubleArray51, doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67, false);
        int int70 = array2DRowRealMatrix69.getColumnDimension();
        double[][] doubleArray71 = array2DRowRealMatrix69.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix36.add(blockRealMatrix72);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix72.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix72.getRowMatrix(0);
        double[][] doubleArray77 = blockRealMatrix76.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException78 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 4 + "'", int70 == 4);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        boolean boolean1 = incrementor0.canIncrement();
        boolean boolean2 = incrementor0.canIncrement();
        int int3 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 1, 36.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector23.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, arrayRealVector23);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair30 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray28, false);
        double[] doubleArray31 = pointVectorValuePair30.getPointRef();
        double[] doubleArray35 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray36 = new double[] {};
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray35, doubleArray36);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex42 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray35, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray45 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray45, true);
        double[] doubleArray50 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50, true);
        double[] doubleArray53 = diagonalMatrix47.operate(doubleArray50);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray50, true);
        double double56 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray31, doubleArray50);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray50, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(4.5d, 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector2.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector2.mapDivideToSelf(Double.NaN);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector54);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor56 = null;
        try {
            double double57 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double[][] doubleArray73 = blockRealMatrix72.getData();
        double double74 = blockRealMatrix72.getNorm();
        double double75 = blockRealMatrix72.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 120.0d + "'", double74 == 120.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 49.30605373043698d + "'", double75 == 49.30605373043698d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getSuffix();
        java.lang.String str2 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "]" + "'", str1.equals("]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[" + "'", str2.equals("["));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        int int5 = diagonalMatrix4.getColumnDimension();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition7 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (double) (byte) 10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            diagonalMatrix4.setRowMatrix((int) (short) -1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[] doubleArray38 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray64 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix66.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix66);
        double[][] doubleArray69 = array2DRowRealMatrix68.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix68);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray5 = new double[] { 10.0f, (byte) 10, 3.7168146928204138d, 0L, 3 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray5);
        double[] doubleArray7 = sigma6.getSigma();
        double[] doubleArray8 = sigma6.getSigma();
        int int9 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 244834360 + "'", int9 == 244834360);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = openMapRealMatrix8.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = openMapRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        boolean boolean12 = openMapRealMatrix8.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = openMapRealMatrix16.transpose();
        org.apache.commons.math3.linear.RealVector realVector19 = openMapRealMatrix16.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = openMapRealMatrix22.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = openMapRealMatrix22.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        boolean boolean26 = openMapRealMatrix22.isSquare();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix16.subtract(openMapRealMatrix22);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix28 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix16);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix29 = openMapRealMatrix2.subtract(openMapRealMatrix28);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor30 = null;
        try {
            double double31 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertNotNull(openMapRealMatrix29);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        double[] doubleArray25 = diagonalMatrix18.getDataRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds26 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray6, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray25);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.RealVector realVector74 = blockRealMatrix71.getRowVector(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector77 = blockRealMatrix71.getRowVector(80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (80)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 244834360);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.003913481845644553d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(100, 36, (int) (short) 10, 3);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray9, intArray11);
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        java.lang.Integer[] intArray20 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException23 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable13, intArray20, intArray22);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray9, intArray22);
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        java.lang.Integer[] intArray32 = new java.lang.Integer[] { 52, 0, 50, 52, 1041236929, 52 };
        java.lang.Integer[] intArray34 = new java.lang.Integer[] { 2147483647 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException35 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable25, intArray32, intArray34);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray9, intArray32);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(1.5707963267948966d, 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6611224163193898d + "'", double2 == 1.6611224163193898d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 36);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        double double2 = bracketFinder0.getLo();
        int int3 = bracketFinder0.getMaxEvaluations();
        double double4 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix4.copy();
        double[] doubleArray10 = diagonalMatrix4.getRow((int) (short) 1);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat(",", "", "}}1{{-1,0},{0,0}}0,}0{{-1,0},{0,0}}0hi!", "hi!", "org.apache.commons.math3.exception.ZeroException: zero not allowed here", "");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix80 = blockRealMatrix71.getSubMatrix((-1), 1041236929, 4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        double double73 = blockRealMatrix71.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = null;
        try {
            blockRealMatrix71.setRowMatrix(10, blockRealMatrix75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 24.65302686521849d + "'", double73 == 24.65302686521849d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(Double.NaN, (double) '4', (double) (-1), (double) 10.0f);
        int int5 = powellOptimizer4.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = lUDecomposition5.getP();
        double double7 = lUDecomposition5.getDeterminant();
        java.io.ObjectInputStream objectInputStream9 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) double7, "org.apache.commons.math3.exception.ZeroException: zero not allowed here", objectInputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        try {
            double[] doubleArray77 = blockRealMatrix75.getRow(244834360);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (244,834,360)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        double[] doubleArray4 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9, true);
        double[] doubleArray12 = diagonalMatrix6.operate(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = diagonalMatrix6.multiply(diagonalMatrix18);
        java.lang.String str27 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix6);
        java.text.NumberFormat numberFormat28 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(diagonalMatrix26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{{-1,0},{0,0}}" + "'", str27.equals("{{-1,0},{0,0}}"));
        org.junit.Assert.assertNotNull(numberFormat28);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 'a', 1.2595063905404449d);
        int int3 = brentOptimizer2.getMaxIterations();
        double[] doubleArray6 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray11 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double[] doubleArray14 = diagonalMatrix8.operate(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix8);
        double[] doubleArray19 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray20 = new double[] {};
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray20);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray19, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        int int27 = nelderMeadSimplex26.getDimension();
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval31 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-0.99999994f), 1.5707963267948966d, 0.0d);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray32 = new org.apache.commons.math3.optim.OptimizationData[] { weight15, nelderMeadSimplex26, searchInterval31 };
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair33 = brentOptimizer2.optimize(optimizationDataArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(optimizationDataArray32);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = diagonalMatrix4.walkInRowOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray6 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray17 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray17, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray6, doubleArray17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, false);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor26 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double27 = diagonalMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor26);
        double double28 = defaultRealMatrixPreservingVisitor26.end();
        double double29 = array2DRowRealMatrix0.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor26);
        double[] doubleArray32 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        double[] doubleArray37 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        double[] doubleArray40 = diagonalMatrix34.operate(doubleArray37);
        double[] doubleArray43 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43, true);
        double[] doubleArray48 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48, true);
        double[] doubleArray51 = diagonalMatrix45.operate(doubleArray48);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight52 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector53.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, arrayRealVector53);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray48, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair60 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray58, false);
        double[] doubleArray61 = pointVectorValuePair60.getPointRef();
        try {
            double[] doubleArray62 = array2DRowRealMatrix0.preMultiply(doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("{");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"{\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        double double8 = diagonalMatrix4.getNorm();
        double[][] doubleArray9 = diagonalMatrix4.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = diagonalMatrix4.copy();
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray27 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray27, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray16, doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, false);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix4.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector34.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray40 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray41 = new double[] {};
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray41);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36, arrayRealVector48);
        double double51 = arrayRealVector29.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.RealVector realVector54 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector48.combineToSelf((double) (byte) -1, (double) 0.9670298f, realVector54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector5 = openMapRealMatrix2.getRowVector(0);
        double[] doubleArray10 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray15 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray20 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray25 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray30 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray35 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray36 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36, false);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        double[][] doubleArray40 = array2DRowRealMatrix38.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray40);
        double[] doubleArray46 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray51 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray56 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray61 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray66 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray71 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray72 = new double[][] { doubleArray46, doubleArray51, doubleArray56, doubleArray61, doubleArray66, doubleArray71 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72, false);
        int int75 = array2DRowRealMatrix74.getColumnDimension();
        double[][] doubleArray76 = array2DRowRealMatrix74.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray76);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix41.add(blockRealMatrix77);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix79 = blockRealMatrix77.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix81 = blockRealMatrix77.getRowMatrix(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix82 = blockRealMatrix81.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix83 = openMapRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 4 + "'", int75 == 4);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(blockRealMatrix79);
        org.junit.Assert.assertNotNull(blockRealMatrix81);
        org.junit.Assert.assertNotNull(blockRealMatrix82);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        blockRealMatrix72.multiplyEntry(0, (int) (short) 0, 4.5d);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix81 = blockRealMatrix72.getSubMatrix(6, (int) (byte) 100, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence> bitsStreamGeneratorPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.random.BitsStreamGenerator, java.lang.CharSequence>((org.apache.commons.math3.random.BitsStreamGenerator) mersenneTwister1, (java.lang.CharSequence) "hi!");
        java.lang.CharSequence charSequence5 = bitsStreamGeneratorPair4.getSecond();
        java.lang.CharSequence charSequence6 = bitsStreamGeneratorPair4.getSecond();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5434049467914646d + "'", double2 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + charSequence5 + "' != '" + "hi!" + "'", charSequence5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + charSequence6 + "' != '" + "hi!" + "'", charSequence6.equals("hi!"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex33 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(100);
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((-1), 0.5434049467914646d, true, 0, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, pointValuePairConvergenceChecker9);
        int int11 = cMAESOptimizer10.getMaxEvaluations();
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer10.getStatisticsSigmaHistory();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5434049467914646d + "'", double7 == 0.5434049467914646d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(doubleList12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.9670298099517822d, 10.000000000000002d, 49.72798944455531d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("{{-1,0},{0,0}}", "", "hi!", ",", "{", "", numberFormat7);
        java.lang.String str9 = realMatrixFormat8.getColumnSeparator();
        java.lang.String str10 = realMatrixFormat8.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double[] doubleArray3 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray4 = new double[] {};
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.scalarAdd((double) (-0.99999994f));
        double[] doubleArray13 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray14 = new double[] {};
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray13, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray28 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28, true);
        double[] doubleArray31 = diagonalMatrix25.operate(doubleArray28);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray28, true);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException36 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.45597888911063d, objArray35);
        java.lang.Throwable[] throwableArray37 = notFiniteNumberException36.getSuppressed();
        boolean boolean38 = pointVectorValuePair33.equals((java.lang.Object) throwableArray37);
        double[] doubleArray39 = pointVectorValuePair33.getPoint();
        double[] doubleArray40 = pointVectorValuePair33.getFirst();
        double[] doubleArray41 = pointVectorValuePair33.getPoint();
        double[] doubleArray45 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray46 = new double[] {};
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray45, doubleArray46);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray45);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray41, doubleArray45);
        double[] doubleArray50 = array2DRowRealMatrix7.preMultiply(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray8 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray9 = new double[] {};
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray23 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23, true);
        double[] doubleArray26 = diagonalMatrix20.operate(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray23, true);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) (byte) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray2, doubleArray30);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 50, 0.0d);
        double double3 = univariatePointValuePair2.getPoint();
        double double4 = univariatePointValuePair2.getValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.0d + "'", double3 == 50.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix0, (double) 0L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math3.optim.MaxEval maxEval0 = org.apache.commons.math3.optim.MaxEval.unlimited();
        org.junit.Assert.assertNotNull(maxEval0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        double[] doubleArray14 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray22 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = diagonalMatrix4.multiply(diagonalMatrix16);
        try {
            diagonalMatrix4.setEntry((int) (short) 10, 2147483647, 3.7168146928204138d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 3.717 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(diagonalMatrix24);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        double[] doubleArray79 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray80 = new double[] {};
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray79, doubleArray80);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex82 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray79);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex85 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray79, 0.003913481845644553d, 0.003913481845644553d);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray79, (int) '#');
        org.apache.commons.math3.linear.RealMatrix realMatrix88 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray87);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray87);
        try {
            double[] doubleArray90 = blockRealMatrix71.preMultiply(doubleArray87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix88);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector14);
        double[] doubleArray19 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        double[] doubleArray24 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24, true);
        double[] doubleArray27 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, arrayRealVector29);
        double double33 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.analysis.function.Sinc sinc35 = new org.apache.commons.math3.analysis.function.Sinc(false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc35);
        try {
            double double39 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc35, 0.0d, 0.9999999999999999d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [1, 0.841]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix4.copy();
        double[] doubleArray10 = diagonalMatrix4.getRow((int) (short) 1);
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        org.apache.commons.math3.exception.util.Localizable localizable12 = null;
        double[] doubleArray15 = new double[] { (byte) -1 };
        double[] doubleArray17 = new double[] { (byte) -1 };
        double[] doubleArray19 = new double[] { (byte) -1 };
        double[] doubleArray21 = new double[] { (byte) -1 };
        double[] doubleArray23 = new double[] { (byte) -1 };
        double[] doubleArray25 = new double[] { (byte) -1 };
        double[][] doubleArray26 = new double[][] { doubleArray15, doubleArray17, doubleArray19, doubleArray21, doubleArray23, doubleArray25 };
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray26);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable12, (java.lang.Number) 52, (java.lang.Object[]) doubleArray26);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray10, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector12);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, (int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) '4');
        double[] doubleArray2 = simpleBounds1.getUpper();
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.RealVector realVector74 = blockRealMatrix71.getRowVector(0);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix77 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = openMapRealMatrix77.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor79 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double80 = openMapRealMatrix77.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor79);
        boolean boolean81 = openMapRealMatrix77.isSquare();
        int int82 = openMapRealMatrix77.getColumnDimension();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix83 = blockRealMatrix71.multiply((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 10 + "'", int82 == 10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(2147483647, 52, (double) (byte) 1);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray5 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray10 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray15 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray20 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray25 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray30 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray31 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31, false);
        int int34 = array2DRowRealMatrix33.getColumnDimension();
        double[][] doubleArray35 = array2DRowRealMatrix33.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35, true);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException38 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray8 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray8, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        double double15 = arrayRealVector2.getMaxValue();
        int int16 = arrayRealVector2.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2);
        double[] doubleArray22 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray23 = new double[] {};
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray22, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, arrayRealVector30);
        double[] doubleArray34 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        double[] doubleArray39 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39, true);
        double[] doubleArray42 = diagonalMatrix36.operate(doubleArray39);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight43 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector44.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector44.add((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector50.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        double[] doubleArray56 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray57 = new double[] {};
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray56, doubleArray57);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex63 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray56, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56, arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector52, arrayRealVector64);
        double[] doubleArray69 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix71 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray69, true);
        double[] doubleArray74 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix76 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray74, true);
        double[] doubleArray77 = diagonalMatrix71.operate(doubleArray74);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight78 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = arrayRealVector79.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray74, arrayRealVector79);
        double double83 = arrayRealVector52.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector79);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector52.mapSubtractToSelf(0.5434049467914646d);
        double double86 = arrayRealVector49.getDistance(realVector85);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector30.append(realVector85);
        arrayRealVector17.setSubVector(0, realVector85);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(arrayRealVector81);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(realVector87);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.RealMatrix realMatrix74 = null;
        try {
            blockRealMatrix72.setColumnMatrix(3, realMatrix74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix71.getColumnMatrix(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        defaultRealMatrixPreservingVisitor4.start((-1944622665), 3, 0, 0, 0, (int) (byte) 100);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix3 = openMapRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = openMapRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        boolean boolean6 = openMapRealMatrix2.isSquare();
        int int7 = openMapRealMatrix2.getColumnDimension();
        double[] doubleArray11 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray19 = diagonalMatrix13.operate(doubleArray16);
        double[] doubleArray22 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22, true);
        double[] doubleArray27 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        double[] doubleArray30 = diagonalMatrix24.operate(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector32.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, arrayRealVector32);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray37, false);
        double[] doubleArray40 = pointVectorValuePair39.getPointRef();
        double[] doubleArray41 = pointVectorValuePair39.getKey();
        try {
            openMapRealMatrix2.setColumn((-558340673), doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-558,340,673)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
        double double5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 0.0d, 99.45597888911063d, (double) '4');
        try {
            double double9 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 1.6611224163193898d, (-0.6888366918779438d), 1.0E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.661, 0.486]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 49.72798944455531d + "'", double5 == 49.72798944455531d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(24.65302686521849d, 11013.232920103343d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.65302686521849d + "'", double2 == 24.65302686521849d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapDivide((double) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector0.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector0.mapSubtractToSelf(0.19036012811898584d);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-0.21722891503668823d), 3.2710663101885897d, (double) (-1944622665), 1.5401476965874874d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -0.217 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 10);
        incrementor1.setMaximalCount((int) '#');
        int int4 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix37.createMatrix((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        int int35 = array2DRowRealMatrix32.getRowDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector37.copy();
        double[] doubleArray42 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray43 = new double[] {};
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray42, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray52 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray52, true);
        double[] doubleArray57 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57, true);
        double[] doubleArray60 = diagonalMatrix54.operate(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray42, doubleArray57, true);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException65 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 99.45597888911063d, objArray64);
        java.lang.Throwable[] throwableArray66 = notFiniteNumberException65.getSuppressed();
        boolean boolean67 = pointVectorValuePair62.equals((java.lang.Object) throwableArray66);
        double[] doubleArray68 = pointVectorValuePair62.getPoint();
        double[] doubleArray69 = pointVectorValuePair62.getFirst();
        double[] doubleArray70 = pointVectorValuePair62.getPoint();
        boolean boolean71 = arrayRealVector38.equals((java.lang.Object) pointVectorValuePair62);
        org.apache.commons.math3.linear.RealVector realVector73 = arrayRealVector38.mapSubtractToSelf(11013.232920103343d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32, realVector73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(realVector73);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, doubleArray16);
        double double23 = arrayRealVector10.getMaxValue();
        int int24 = arrayRealVector10.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        boolean boolean34 = array2DRowRealMatrix32.isSquare();
        array2DRowRealMatrix32.setEntry((int) (short) 1, 0, (double) (-1.0f));
        double[] doubleArray43 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray48 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray53 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray58 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray63 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray68 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray69 = new double[][] { doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63, doubleArray68 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69, false);
        int int72 = array2DRowRealMatrix71.getColumnDimension();
        double[][] doubleArray73 = array2DRowRealMatrix71.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73, true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix32.add(array2DRowRealMatrix75);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = array2DRowRealMatrix75.copy();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 4 + "'", int72 == 4);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (double) 1.0f);
        boolean boolean10 = diagonalMatrix4.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        double[] doubleArray7 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray10 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray13 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13, true);
        double[] doubleArray18 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18, true);
        double[] doubleArray21 = diagonalMatrix15.operate(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector23.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, arrayRealVector23);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) (short) 0);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair30 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray28, false);
        double[] doubleArray31 = pointVectorValuePair30.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 100.0f, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5309649148733797d) + "'", double2 == (-0.5309649148733797d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(3, 10);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 30 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        double[] doubleArray6 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray7 = new double[] {};
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray7);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        double[] doubleArray16 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16, true);
        double[] doubleArray21 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        double[] doubleArray24 = diagonalMatrix18.operate(doubleArray21);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapAddToSelf(1.0E-15d);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.RealVector realVector74 = blockRealMatrix71.getRowVector(0);
        int int75 = realVector74.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 100, (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat10 = realMatrixFormat9.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat11 = new org.apache.commons.math3.linear.RealMatrixFormat("{{-1,0},{0,0}}", "", "hi!", ",", "{", "", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("{", "{{-1,0},{0,0}}", "{", numberFormat10);
        java.text.NumberFormat numberFormat13 = realVectorFormat12.getFormat();
        java.lang.String str14 = realVectorFormat12.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat9);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{{-1,0},{0,0}}" + "'", str14.equals("{{-1,0},{0,0}}"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray5, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        double[] doubleArray16 = new double[] { 1.0f, (-1.0f), (byte) 100, 100.0d, 0.5434049467914646d };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100, (double) (-1L), (double) ' ', (double) 10);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray5, doubleArray16);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, 11013.232920103343d);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) 100.0f, (double) '#', (double) 100);
        double double30 = noBracketingException29.getLo();
        java.lang.Throwable[] throwableArray31 = noBracketingException29.getSuppressed();
        boolean boolean32 = pointValuePair24.equals((java.lang.Object) throwableArray31);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat33 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str34 = realMatrixFormat33.getColumnSeparator();
        boolean boolean35 = pointValuePair24.equals((java.lang.Object) str34);
        java.lang.Double double36 = pointValuePair24.getSecond();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realMatrixFormat33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "," + "'", str34.equals(","));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 11013.232920103343d + "'", double36.equals(11013.232920103343d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getLo();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) 7830967380036616271L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((-1.0d), 35.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("{{-1,0},{0,0}}", "", "hi!", ",", "{", "", numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        int int1 = maxIter0.getMaxIter();
        int int2 = maxIter0.getMaxIter();
        org.junit.Assert.assertNotNull(maxIter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(120.0d, (double) 10.0f, (double) 100L, (double) 1078591488);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0785915E11d + "'", double4 == 1.0785915E11d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.2761081516257424d, 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (byte) 1, 0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) 1195587395, 1.2761081516257424d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.977936981380541E8d + "'", double2 == 5.977936981380541E8d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, 0.0d, 0.0d, (double) (-1), (-2.147483737329702E9d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
        int int2 = levenbergMarquardtOptimizer1.getMaxEvaluations();
        int int3 = levenbergMarquardtOptimizer1.getIterations();
        double[] doubleArray4 = levenbergMarquardtOptimizer1.getUpperBound();
        int int5 = levenbergMarquardtOptimizer1.getMaxEvaluations();
        double double6 = levenbergMarquardtOptimizer1.getChiSquare();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(120.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 120.0d + "'", double1 == 120.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = array2DRowRealMatrix32.getColumnMatrix(0);
        try {
            double double37 = array2DRowRealMatrix32.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        int int35 = array2DRowRealMatrix32.getRowDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix38 = array2DRowRealMatrix32.createMatrix((int) ' ', (int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double[] doubleArray3 = new double[] { 35.0d, 1.1102230246251565E-16d, 1195587395 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray3);
        double[] doubleArray5 = sigma4.getSigma();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test494");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        int int2 = mersenneTwister0.nextInt(100);
//        float float3 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.54336524f + "'", float3 == 0.54336524f);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double[] doubleArray4 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray9 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray14 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray19 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray24 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray29 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30, false);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        double[][] doubleArray34 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray40 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray45 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray50 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray55 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray60 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[] doubleArray65 = new double[] { 10.0d, 0.5434049467914646d, (-1.0d), 0L };
        double[][] doubleArray66 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66, false);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix35.add(blockRealMatrix71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix71.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.getRowMatrix(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix75.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector78 = blockRealMatrix76.getColumnVector((-558340673));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-558,340,673)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = eigenDecomposition7.getD();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = eigenDecomposition7.getV();
        double double10 = eigenDecomposition7.getDeterminant();
        org.apache.commons.math3.linear.RealVector realVector12 = eigenDecomposition7.getEigenvector((int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.0d) + "'", double10 == (-0.0d));
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((-1.5401476965874874d), 0.0d, (double) (byte) 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(36);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double[] doubleArray2 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2, true);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition5 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, 10.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector8.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        double[] doubleArray14 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray15 = new double[] {};
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray15);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector10, arrayRealVector22);
        double[] doubleArray27 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        double[] doubleArray32 = new double[] { (-1.0f), 0 };
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        double[] doubleArray35 = diagonalMatrix29.operate(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector37.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, arrayRealVector37);
        double double41 = arrayRealVector10.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double[] doubleArray48 = new double[] { (byte) 10, (short) 100, (-1.0f) };
        double[] doubleArray49 = new double[] {};
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray48, doubleArray49);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex55 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray48, (double) (short) 10, 0.5434049467914646d, 0.5434049467914646d, 0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector44, arrayRealVector56);
        double double59 = arrayRealVector10.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector10.mapDivideToSelf(Double.NaN);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10, arrayRealVector62);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix4, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(realVector61);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(Double.NaN, (double) 0.9670298f);
        int int3 = brentOptimizer2.getMaxIterations();
        int int4 = brentOptimizer2.getEvaluations();
        int int5 = brentOptimizer2.getMaxIterations();
        double double6 = brentOptimizer2.getMax();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }
}

