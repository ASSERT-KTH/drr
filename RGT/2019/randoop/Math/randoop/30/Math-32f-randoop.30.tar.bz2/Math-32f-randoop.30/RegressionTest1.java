import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = orientedPoint9.getLocation();
        boolean boolean11 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint4.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList13 = intervalsSet12.asList();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector14 = intervalsSet12.getBarycenter();
        double double15 = intervalsSet12.getSup();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet12.applyTransform(euclidean1DTransform16);
        double double18 = euclidean1DAbstractRegion17.getSize();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertNotNull(intervalList13);
        org.junit.Assert.assertNotNull(euclidean1DVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(1.5607966593453682d, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray1, orderDirection3, true);
        double[] doubleArray7 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple8 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray7);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray7, orderDirection9, true);
        double[] doubleArray13 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple14 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray13);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean17 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray13, orderDirection15, true);
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray7, orderDirection15, false, false);
        double double21 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray1, doubleArray7);
        double[] doubleArray23 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple24 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray23);
        double[] doubleArray25 = orderedTuple24.getComponents();
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray25, 2.0d);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        double double4 = vector3D1.getDelta();
        java.lang.String str5 = vector3D1.toString();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{1; 0; 0}" + "'", str5.equals("{1; 0; 0}"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet6 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double11 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D7.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.partitioning.Region.Location location13 = polyhedronsSet6.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D16, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double23 = vector3D21.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D19.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane25 = plane18.translate(vector3D19);
        double double26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D9, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane30 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D27, vector3D28, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = plane30.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine34 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D32, vector2D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = plane30.getPointAt(vector2D33, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = vector3D36.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line39 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D19, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double43 = vector3D41.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        double double44 = vector3D41.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.28091705788171395d, vector3D2, 1.5607966601082315d, vector3D38, 0.0d, vector3D41);
        double double46 = vector3D45.getNorm1();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + location13 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location13.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(plane25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(subPlane31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.junit.Assert.assertNotNull(vector2D0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double39 = vector3D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D35.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.partitioning.Region.Location location41 = polyhedronsSet34.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43, vector3D44, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double51 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D47.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = plane46.translate(vector3D47);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D37, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane58 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D56, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane59 = plane58.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine62 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D60, vector2D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = plane58.getPointAt(vector2D61, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D64.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line67 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D47, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet68 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double73 = vector3D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D69.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.Region.Location location75 = polyhedronsSet68.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree76 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D71.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = line67.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D77);
        boolean boolean79 = line33.isSimilarTo(line67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = line67.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = line67.pointAt((-0.9999999999999999d));
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + location41 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location41.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(plane53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(subPlane59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + location75 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location75.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D82);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.0d, 0.9999877116507956d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999877116507956d + "'", double2 == 0.9999877116507956d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree21 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = intervalsSet18.buildNew(euclidean1DBSPTree21);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(intervalsSet22);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(2.4674011002723395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.46740110027234d + "'", double1 == 2.46740110027234d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line2 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane3 = polyhedronsSet0.firstIntersection(vector3D1, line2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.partitioning.Region.Location location5 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        double double6 = polyhedronsSet0.getSize();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform7 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion8 = polyhedronsSet0.applyTransform(euclidean3DTransform7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double11 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.partitioning.Region.Location location19 = polyhedronsSet12.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D15.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double29 = vector3D27.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D25.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = plane24.translate(vector3D25);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D15, vector3D25);
        double double33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D9, vector3D25);
        org.apache.commons.math3.geometry.partitioning.Region.Location location34 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + location5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location5.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + location19 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location19.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(plane31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + location34 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location34.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane4 = plane3.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane5 = subPlane4.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane10 = plane9.wholeHyperplane();
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>> euclidean3DSubHyperplaneList11 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>();
        boolean boolean12 = euclidean3DSubHyperplaneList11.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) euclidean3DAbstractSubHyperplane5);
        boolean boolean13 = euclidean3DSubHyperplaneList11.add((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane10);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet14 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>>) euclidean3DSubHyperplaneList11);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet15 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = polyhedronsSet15.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet18 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree20 = polyhedronsSet18.getTree(false);
        euclidean3DBSPTree17.insertInTree(euclidean3DBSPTree20, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree23 = euclidean3DBSPTree17.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet24 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree26 = polyhedronsSet24.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet27 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree29 = polyhedronsSet27.getTree(false);
        euclidean3DBSPTree26.insertInTree(euclidean3DBSPTree29, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree32 = euclidean3DBSPTree26.getParent();
        euclidean3DBSPTree23.insertInTree(euclidean3DBSPTree26, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree35 = euclidean3DBSPTree23.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree36 = euclidean3DBSPTree23.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet37 = polyhedronsSet14.buildNew(euclidean3DBSPTree36);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet38 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D39, vector3D40, vector3D41);
        org.apache.commons.math3.geometry.partitioning.Side side43 = polyhedronsSet38.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane42);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = plane44.getNormal();
        org.apache.commons.math3.geometry.partitioning.Side side46 = polyhedronsSet37.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane44);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(subPlane4);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(subPlane10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree20);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree23);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree26);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree29);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree32);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree35);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree36);
        org.junit.Assert.assertNotNull(polyhedronsSet37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + side43 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side43.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + side46 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side46.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str8 = vector2D7.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D6.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane5.getPointAt(vector2D9, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str20 = vector2D19.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D18.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = plane17.getPointAt(vector2D21, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = plane5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str27 = vector2D26.toString();
        double double28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D25, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Line line30 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D26, 4.9E-324d);
        double double31 = line30.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine34 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D32, vector2D33);
        double double35 = vector2D33.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine38 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D36, vector2D37);
        double double39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D33, vector2D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = line30.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double45 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double50 = vector1D48.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        double double51 = vector1D44.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D53, true);
        double double57 = vector1D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = line30.getPointAt(vector1D49, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine62 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D60, vector2D61);
        double double63 = vector2D61.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine66 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D64, vector2D65);
        double double67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D61, vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = vector2D61.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = line30.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        double double71 = vector2D61.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = vector2D24.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = vector2D61.negate();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0; 0}" + "'", str8.equals("{0; 0}"));
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{0; 0}" + "'", str20.equals("{0; 0}"));
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{0; 0}" + "'", str27.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.9E-324d + "'", double31 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertNotNull(vector2D73);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double14 = vector3D12.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D10.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = plane9.translate(vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, vector3D10);
        double double18 = vector3D3.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        double double19 = vector3D3.getX();
        try {
            double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D0, vector3D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(plane16);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 100, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double20 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        double double32 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D24, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine37 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D35, vector2D36);
        double double38 = vector2D36.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D39, vector2D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D36.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine49 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D47, vector2D48);
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getNorm1();
        double[] doubleArray52 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        line5.translateToPoint(vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str57 = vector2D56.toString();
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, 4.9E-324d);
        boolean boolean61 = line5.isParallelTo(line60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str64 = vector2D63.toString();
        double double65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D62, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line67 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, 4.9E-324d);
        double double68 = line67.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine71 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D69, vector2D70);
        double double72 = vector2D70.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine75 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D73, vector2D74);
        double double76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D70, vector2D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = line67.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = line5.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D77);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str81 = vector2D80.toString();
        double double82 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D79, vector2D80);
        org.apache.commons.math3.geometry.euclidean.twod.Line line84 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D80, 4.9E-324d);
        double double85 = line84.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D86 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine88 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D86, vector2D87);
        double double89 = vector2D87.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D91 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine92 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D90, vector2D91);
        double double93 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D87, vector2D91);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D94 = line84.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D95 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D97 = line84.getPointAt(vector1D95, 1.5607966601082315d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D98 = vector2D78.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D97);
        org.apache.commons.math3.geometry.Space space99 = vector2D78.getSpace();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0; 0}" + "'", str57.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "{0; 0}" + "'", str64.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.9E-324d + "'", double68 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "{0; 0}" + "'", str81.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 4.9E-324d + "'", double85 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D86);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D90);
        org.junit.Assert.assertNotNull(vector2D91);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D94);
        org.junit.Assert.assertNotNull(vector1D95);
        org.junit.Assert.assertNotNull(vector2D97);
        org.junit.Assert.assertNotNull(vector2D98);
        org.junit.Assert.assertNotNull(space99);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        double double3 = vector2D1.getNorm();
        double double4 = vector2D1.getNorm1();
        double[] doubleArray5 = vector2D1.toArray();
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple6 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray5);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = vector2D8.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D8, (double) (short) 1);
        double double19 = line5.getOffset(line18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D20, vector2D21);
        double double23 = vector2D21.getNorm();
        double double24 = vector2D21.getX();
        line18.reset(vector2D21, (double) 10L);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D27, vector2D28);
        double double30 = vector2D28.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D32);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D28.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D28, (double) (short) 1);
        boolean boolean39 = line18.isParallelTo(line38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str42 = vector2D41.toString();
        double double43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D40, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, 4.9E-324d);
        double double46 = line45.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine49 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D47, vector2D48);
        double double50 = vector2D48.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine53 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D51, vector2D52);
        double double54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D48, vector2D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = line45.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = line45.getPointAt(vector1D56, 1.5607966601082315d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = line38.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = line38.getPointAt(vector1D60, (double) 127);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{0; 0}" + "'", str42.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.9E-324d + "'", double46 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector1D59);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math3.util.FastMath.log(97.00000762939453d, (double) (-127));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane5 = plane4.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine8 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D6, vector2D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = plane4.getPointAt(vector2D7, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet13 = polyhedronsSet0.translate(vector3D12);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector14 = polyhedronsSet0.getBarycenter();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(subPlane5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(polyhedronsSet13);
        org.junit.Assert.assertNotNull(euclidean3DVector14);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = plane3.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D7, vector3D8);
        org.apache.commons.math3.geometry.partitioning.Side side10 = polyhedronsSet5.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane9);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = plane11.getNormal();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine15 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D13, vector2D14);
        double double16 = vector2D14.getNorm();
        double double17 = vector2D14.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine20 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D18, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = vector2D14.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = plane11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D23, vector3D24, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double29 = vector3D27.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D27.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane4, plane11, plane31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D33, vector3D34, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = plane36.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet38 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D39, vector3D40, vector3D41);
        org.apache.commons.math3.geometry.partitioning.Side side43 = polyhedronsSet38.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane42);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane44 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = plane44.getNormal();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine48 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D46, vector2D47);
        double double49 = vector2D47.getNorm();
        double double50 = vector2D47.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine53 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D51, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = vector2D47.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = plane44.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane59 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D56, vector3D57, vector3D58);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double62 = vector3D60.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D60.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane64 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D57, vector3D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Plane.intersection(plane37, plane44, plane64);
        org.apache.commons.math3.geometry.euclidean.threed.Line line66 = plane4.intersection(plane37);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(plane4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + side10 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side10.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(plane37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + side43 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side43.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(line66);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree5 = polyhedronsSet3.getTree(false);
        euclidean3DBSPTree2.insertInTree(euclidean3DBSPTree5, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree8 = euclidean3DBSPTree2.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree11 = polyhedronsSet9.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = polyhedronsSet12.getTree(false);
        euclidean3DBSPTree11.insertInTree(euclidean3DBSPTree14, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree11.getParent();
        euclidean3DBSPTree8.insertInTree(euclidean3DBSPTree11, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D20, vector3D21, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = plane23.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane25 = plane23.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = plane23.getU();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane27 = plane23.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree28 = euclidean3DBSPTree8.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane32 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D29, vector3D30, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = plane32.copySelf();
        org.apache.commons.math3.geometry.partitioning.Side side34 = subPlane27.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane33);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree8);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(plane24);
        org.junit.Assert.assertNotNull(plane25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(subPlane27);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(plane33);
        org.junit.Assert.assertTrue("'" + side34 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side34.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet6 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(0.0d, (double) (short) 100, (double) 0, (double) (byte) 100, 4.9E-324d, (double) 52.000004f);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double12 = vector3D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D8.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.partitioning.Region.Location location14 = polyhedronsSet7.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet15 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = polyhedronsSet15.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet18 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree20 = polyhedronsSet18.getTree(false);
        euclidean3DBSPTree17.insertInTree(euclidean3DBSPTree20, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = polyhedronsSet7.buildNew(euclidean3DBSPTree20);
        boolean boolean24 = polyhedronsSet6.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D26, vector3D27, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double34 = vector3D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D30.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane36 = plane29.translate(vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38, vector3D39, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane42 = plane41.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine45 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D43, vector2D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = plane41.getPointAt(vector2D44, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.scalarMultiply((double) (byte) -1);
        double double50 = vector3D37.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.partitioning.Region.Location location51 = polyhedronsSet6.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + location14 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location14.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree20);
        org.junit.Assert.assertNotNull(polyhedronsSet23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(plane36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(subPlane42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + location51 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location51.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint36 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D33, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = orientedPoint36.getLocation();
        boolean boolean38 = orientedPoint31.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint36);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet39 = orientedPoint31.wholeSpace();
        boolean boolean40 = orientedPoint25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane42 = subOrientedPoint20.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint43 = orientedPoint25.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D45);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint48 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D45, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = orientedPoint48.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint54 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D51, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint59 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D56, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = orientedPoint59.getLocation();
        boolean boolean61 = orientedPoint54.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint59);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet62 = orientedPoint54.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList63 = intervalsSet62.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint64 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint48, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet62);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint69 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D66, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D71);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint74 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D71, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = orientedPoint74.getLocation();
        boolean boolean76 = orientedPoint69.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint74);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet77 = orientedPoint69.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Side side78 = intervalsSet62.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint69);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane79 = subOrientedPoint43.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint69);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane80 = null;
        try {
            boolean boolean81 = orientedPoint69.sameOrientationAs(euclidean1DHyperplane80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(intervalsSet39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane42);
        org.junit.Assert.assertNotNull(subOrientedPoint43);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(intervalsSet62);
        org.junit.Assert.assertNotNull(intervalList63);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(intervalsSet77);
        org.junit.Assert.assertTrue("'" + side78 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side78.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane79);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D5);
        double double7 = vector1D5.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D12, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D5.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double18 = vector1D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D17.scalarMultiply(94.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Line line34 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line33);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        double[] doubleArray3 = orderedTuple2.getComponents();
        double[] doubleArray4 = orderedTuple2.getComponents();
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple5 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray4);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.9999877116507956d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(7.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.283185307179587d + "'", double1 == 7.283185307179587d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane4 = plane3.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D7, vector3D8);
        org.apache.commons.math3.geometry.partitioning.Side side10 = polyhedronsSet5.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane9);
        plane3.reset(plane9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane16 = plane15.wholeHyperplane();
        double double17 = plane3.getOffset(plane15);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree18 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet19 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree18);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree20 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet21 = polygonsSet19.buildNew(euclidean2DBSPTree20);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane22 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane3, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet23 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double28 = vector3D26.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D24.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.partitioning.Region.Location location30 = polyhedronsSet23.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D26.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet32 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree34 = polyhedronsSet32.getTree(false);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector35 = polyhedronsSet32.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D26.subtract(euclidean3DVector35);
        double double37 = plane3.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D36);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(subPlane4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + side10 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side10.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(subPlane16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(polygonsSet21);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + location30 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location30.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree34);
        org.junit.Assert.assertNotNull(euclidean3DVector35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str1 = vector2D0.toString();
        double double2 = vector2D0.getY();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0; 0}" + "'", str1.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double20 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        double double32 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D24, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine37 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D35, vector2D36);
        double double38 = vector2D36.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D39, vector2D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D36.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine49 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D47, vector2D48);
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getNorm1();
        double[] doubleArray52 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        line5.translateToPoint(vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str57 = vector2D56.toString();
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, 4.9E-324d);
        boolean boolean61 = line5.isParallelTo(line60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine64 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D62, vector2D63);
        double double65 = vector2D63.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine68 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D66, vector2D67);
        double double69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D63, vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = vector2D63.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.twod.Line line73 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, (double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine76 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D74, vector2D75);
        double double77 = vector2D75.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine80 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D78, vector2D79);
        double double81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D75, vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = vector2D75.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.twod.Line line85 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D75, (double) (short) 1);
        boolean boolean86 = line73.isParallelTo(line85);
        org.apache.commons.math3.geometry.euclidean.twod.Line line87 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line73);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = line60.intersection(line87);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0; 0}" + "'", str57.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(vector2D88);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D1.normalize();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (-127), 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 127L + "'", long2 == 127L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D6, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double11 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D12);
        boolean boolean14 = plane4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane13);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector15 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = plane4.toSubSpace(euclidean3DVector15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree3 = polyhedronsSet1.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet4 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree6 = polyhedronsSet4.getTree(false);
        euclidean3DBSPTree3.insertInTree(euclidean3DBSPTree6, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = polyhedronsSet0.buildNew(euclidean3DBSPTree6);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet10 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11, vector3D12, vector3D13);
        org.apache.commons.math3.geometry.partitioning.Side side15 = polyhedronsSet10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane14);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane14);
        org.apache.commons.math3.geometry.partitioning.Side side17 = polyhedronsSet9.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane14);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet18 = plane14.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane14);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet20 = plane19.wholeSpace();
        org.junit.Assert.assertNotNull(euclidean3DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree6);
        org.junit.Assert.assertNotNull(polyhedronsSet9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + side15 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side15.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertTrue("'" + side17 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side17.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(polyhedronsSet18);
        org.junit.Assert.assertNotNull(polyhedronsSet20);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray1, orderDirection3, true);
        double[] doubleArray7 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple8 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray7);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray7, orderDirection9, true);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection9, false, false);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) (byte) 100);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint36 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D33, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = orientedPoint36.getLocation();
        boolean boolean38 = orientedPoint31.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint36);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet39 = orientedPoint31.wholeSpace();
        boolean boolean40 = orientedPoint25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane42 = subOrientedPoint20.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint47 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D44, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D49);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint52 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D49, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = orientedPoint52.getLocation();
        boolean boolean54 = orientedPoint47.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint52);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet55 = orientedPoint47.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint56 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet55);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(intervalsSet39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(intervalsSet55);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        double double10 = vector1D3.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        double double16 = vector1D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        java.lang.Object obj17 = null;
        boolean boolean18 = vector1D12.equals(obj17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        java.lang.String str22 = vector1D21.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double28 = vector1D26.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D27, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double36 = vector1D34.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D35, vector1D37);
        double double39 = vector1D37.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double45 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D44, vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = vector1D37.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double50 = vector1D48.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        boolean boolean51 = vector1D48.isInfinite();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        java.lang.String str55 = vector1D54.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D21, 2.6991118430775187d, vector1D27, 4.9E-324d, vector1D48, 8.0d, vector1D54);
        double double57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D12, vector1D27);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{-1}" + "'", str22.equals("{-1}"));
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{-1}" + "'", str55.equals("{-1}"));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double39 = vector3D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D35.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.partitioning.Region.Location location41 = polyhedronsSet34.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43, vector3D44, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double51 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D47.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = plane46.translate(vector3D47);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D37, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane58 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D56, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane59 = plane58.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine62 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D60, vector2D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = plane58.getPointAt(vector2D61, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D64.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line67 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D47, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet68 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double73 = vector3D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D69.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.Region.Location location75 = polyhedronsSet68.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree76 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D71.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = line67.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D77);
        boolean boolean79 = line33.isSimilarTo(line67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = line33.pointAt((double) (short) 0);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = line33.getOrigin();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = line33.getDirection();
        double double84 = vector3D83.getNorm1();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + location41 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location41.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(plane53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(subPlane59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + location75 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location75.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertEquals((double) double84, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long1 = org.apache.commons.math3.util.FastMath.round(1.0E52d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        java.lang.String str5 = vector1D1.toString();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math3.util.FastMath.abs(299.99999999999994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 299.99999999999994d + "'", double1 == 299.99999999999994d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double39 = vector3D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D35.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.partitioning.Region.Location location41 = polyhedronsSet34.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree42 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D37.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = line33.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Line line45 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet47 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double52 = vector3D50.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = vector3D48.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.partitioning.Region.Location location54 = polyhedronsSet47.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D50.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D46.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        double double57 = line45.distance(vector3D46);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + location41 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location41.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + location54 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location54.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint38 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D35, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint43 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D40, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = orientedPoint43.getLocation();
        boolean boolean45 = orientedPoint38.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint43);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet46 = orientedPoint38.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList47 = intervalsSet46.asList();
        boolean boolean48 = vector3D13.equals((java.lang.Object) intervalsSet46);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(intervalsSet46);
        org.junit.Assert.assertNotNull(intervalList47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D5);
        double double7 = vector1D5.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D12, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D5.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D18.normalize();
        double double20 = vector1D18.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D16.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(vector1D21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = plane4.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane10 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D8, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double15 = vector3D13.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D11.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = plane10.translate(vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet19 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double24 = vector3D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D20.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.partitioning.Region.Location location26 = polyhedronsSet19.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Line line27 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = plane5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(plane5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(plane17);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + location26 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location26.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector2D28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line2 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane3 = polyhedronsSet0.firstIntersection(vector3D1, line2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet4 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double9 = vector3D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D5.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.partitioning.Region.Location location11 = polyhedronsSet4.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree13 = euclidean3DBSPTree12.copySelf();
        try {
            boolean boolean14 = polyhedronsSet0.isEmpty(euclidean3DBSPTree12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.math3.geometry.euclidean.threed.Vector3D cannot be cast to java.lang.Boolean");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(euclidean3DSubHyperplane3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + location11 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location11.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean3DBSPTree13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(5.551115123125783E-17d, 2.0d, 300.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8, vector3D9, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = plane12.getV();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D17, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double24 = vector3D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D20.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = plane19.translate(vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D13.add((double) (byte) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D27);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 35, vector3D1, 7.490821521341943d, vector3D6, 2.758547353515625E15d, vector3D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(plane26);
        org.junit.Assert.assertNotNull(vector3D28);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = orientedPoint9.getLocation();
        boolean boolean11 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint4.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList13 = intervalsSet12.asList();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector14 = intervalsSet12.getBarycenter();
        double double15 = intervalsSet12.getSup();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet12.applyTransform(euclidean1DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree18 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet19 = intervalsSet12.buildNew(euclidean1DBSPTree18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D21, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = orientedPoint24.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint30 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D27, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint35 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D32, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = orientedPoint35.getLocation();
        boolean boolean37 = orientedPoint30.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint35);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet38 = orientedPoint30.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList39 = intervalsSet38.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint40 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D42, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = orientedPoint45.getLocation();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane47 = subOrientedPoint40.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint45);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion48 = subOrientedPoint40.getRemainingRegion();
        try {
            boolean boolean49 = intervalsSet19.contains(euclidean1DRegion48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertNotNull(intervalList13);
        org.junit.Assert.assertNotNull(euclidean1DVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertNotNull(intervalsSet19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(intervalsSet38);
        org.junit.Assert.assertNotNull(intervalList39);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane47);
        org.junit.Assert.assertNotNull(euclidean1DRegion48);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane27 = subOrientedPoint20.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet28 = orientedPoint25.wholeSpace();
        double double29 = intervalsSet28.getSup();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane27);
        org.junit.Assert.assertNotNull(intervalsSet28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 52.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7325112480890414d + "'", double1 == 3.7325112480890414d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree3 = polyhedronsSet1.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet4 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree6 = polyhedronsSet4.getTree(false);
        euclidean3DBSPTree3.insertInTree(euclidean3DBSPTree6, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = polyhedronsSet0.buildNew(euclidean3DBSPTree6);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector10 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree11 = euclidean3DBSPTree6.getCell(euclidean3DVector10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane15 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D12, vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane17 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18, vector3D19, vector3D20);
        boolean boolean22 = plane17.isSimilarTo(plane21);
        boolean boolean23 = euclidean3DBSPTree6.insertCut((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation25 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = plane17.rotate(vector3D24, rotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean3DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree6);
        org.junit.Assert.assertNotNull(polyhedronsSet9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space> spaceBoundaryAttribute2 = new org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceSubHyperplane1);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane3 = spaceBoundaryAttribute2.getPlusOutside();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane4 = spaceBoundaryAttribute2.getPlusOutside();
        org.junit.Assert.assertNull(spaceSubHyperplane3);
        org.junit.Assert.assertNull(spaceSubHyperplane4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D5);
        double double7 = vector1D5.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D12, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D5.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double18 = vector1D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D17.scalarMultiply(1.1102230246251565E-16d);
        java.text.NumberFormat numberFormat21 = null;
        java.lang.String str22 = vector1D20.toString(numberFormat21);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{(NaN)}" + "'", str22.equals("{(NaN)}"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D8, vector1D10);
        double double12 = vector1D1.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint17 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D14, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D20.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D21, vector1D23);
        double double25 = vector1D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D23.scalarMultiply(0.6610060414837631d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D1.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D28);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint30 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D27, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = orientedPoint30.getLocation();
        boolean boolean32 = orientedPoint25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint30);
        org.apache.commons.math3.geometry.partitioning.Side side33 = subOrientedPoint20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint30);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane34 = subOrientedPoint20.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane35 = subOrientedPoint20.getHyperplane();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + side33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side33.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(euclidean1DHyperplane34);
        org.junit.Assert.assertNotNull(euclidean1DHyperplane35);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math3.util.FastMath.log(350.0d, 0.28091705788171395d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.21674808971281914d) + "'", double2 == (-0.21674808971281914d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet6 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet(0.0d, (double) (short) 100, (double) 0, (double) (byte) 100, 4.9E-324d, (double) 52.000004f);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform7 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion8 = polyhedronsSet6.applyTransform(euclidean3DTransform7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double20 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        double double32 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D24, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine37 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D35, vector2D36);
        double double38 = vector2D36.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D39, vector2D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D36.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine49 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D47, vector2D48);
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getNorm1();
        double[] doubleArray52 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        line5.translateToPoint(vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str57 = vector2D56.toString();
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, 4.9E-324d);
        boolean boolean61 = line5.isParallelTo(line60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str64 = vector2D63.toString();
        double double65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D62, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line67 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D63, 4.9E-324d);
        double double68 = line67.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine71 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D69, vector2D70);
        double double72 = vector2D70.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine75 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D73, vector2D74);
        double double76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D70, vector2D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = line67.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D78 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str80 = vector2D79.toString();
        double double81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D78, vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Line line83 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D79, 4.9E-324d);
        double double84 = line83.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = line67.intersection(line83);
        boolean boolean86 = line60.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line83);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0; 0}" + "'", str57.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "{0; 0}" + "'", str64.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 4.9E-324d + "'", double68 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector2D78);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "{0; 0}" + "'", str80.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 4.9E-324d + "'", double84 == 4.9E-324d);
        org.junit.Assert.assertNull(vector2D85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.Object[] objArray4 = new java.lang.Object[] { vector2D3 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, objArray4);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 4.0d, objArray4);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane1 = null;
        org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space> spaceBoundaryAttribute2 = new org.apache.commons.math3.geometry.partitioning.BoundaryAttribute<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceSubHyperplane1);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane3 = spaceBoundaryAttribute2.getPlusInside();
        org.junit.Assert.assertNull(spaceSubHyperplane3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        boolean boolean3 = subLine2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine6 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D4, vector2D5);
        boolean boolean7 = subLine6.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str10 = vector2D9.toString();
        double double11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line13 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D9, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane14 = subLine6.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line13);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane15 = subLine2.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine6);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane16 = subLine6.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion17 = subLine6.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0; 0}" + "'", str10.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane14);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane15);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane16);
        org.junit.Assert.assertNotNull(euclidean1DRegion17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double2 = vector3D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        double double3 = vector3D0.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D0.scalarMultiply(98.88936844130657d);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double2 = vector3D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D1);
        double double3 = vector3D0.getZ();
        double double4 = vector3D0.getNorm1();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) -1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str3 = vector2D2.toString();
        double double4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D1, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0; 0}" + "'", str3.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = plane3.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = plane3.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = plane3.getU();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane7 = plane3.wholeHyperplane();
        boolean boolean8 = subPlane7.isEmpty();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion9 = subPlane7.getRemainingRegion();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(plane4);
        org.junit.Assert.assertNotNull(plane5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(subPlane7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(euclidean2DRegion9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.Object[] objArray4 = new java.lang.Object[] { vector2D3 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray4);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray4);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray4);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(3.7325112480890414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.903919468089377d + "'", double1 == 20.903919468089377d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane37 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D34, vector3D35, vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane38 = plane37.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet39 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40, vector3D41, vector3D42);
        org.apache.commons.math3.geometry.partitioning.Side side44 = polyhedronsSet39.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane43);
        plane37.reset(plane43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D47, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane50 = plane49.wholeHyperplane();
        double double51 = plane37.getOffset(plane49);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree52 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet53 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree52);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree54 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet55 = polygonsSet53.buildNew(euclidean2DBSPTree54);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane56 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane37, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D57, vector3D58, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane61 = plane60.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine64 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D62, vector2D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = plane60.getPointAt(vector2D63, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D66.scalarMultiply((double) (byte) -1);
        boolean boolean69 = plane37.contains(vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D32, vector3D66);
        double double71 = vector3D70.getDelta();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(subPlane38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + side44 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side44.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(subPlane50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(polygonsSet55);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(subPlane61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        double[] doubleArray9 = new double[] { (byte) 0, 100.0d, (-0.6321205588285577d), 1L, 52 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray9);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple11 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree3 = euclidean3DBSPTree2.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet4 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree6 = polyhedronsSet4.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree9 = polyhedronsSet7.getTree(false);
        euclidean3DBSPTree6.insertInTree(euclidean3DBSPTree9, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree12 = euclidean3DBSPTree6.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet13 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree15 = polyhedronsSet13.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet16 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree18 = polyhedronsSet16.getTree(false);
        euclidean3DBSPTree15.insertInTree(euclidean3DBSPTree18, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree21 = euclidean3DBSPTree15.getParent();
        euclidean3DBSPTree12.insertInTree(euclidean3DBSPTree15, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane27 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D25, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = plane27.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = plane27.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane27.getU();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane31 = plane27.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree32 = euclidean3DBSPTree12.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane31);
        org.apache.commons.math3.geometry.partitioning.BSPTree.LeafMerger<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DLeafMerger33 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree34 = euclidean3DBSPTree2.merge(euclidean3DBSPTree32, euclidean3DLeafMerger33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree3);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree6);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree9);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree12);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree18);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree21);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(plane28);
        org.junit.Assert.assertNotNull(plane29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(subPlane31);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree32);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = orientedPoint9.getLocation();
        boolean boolean11 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint4.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D14);
        org.apache.commons.math3.geometry.partitioning.Region.Location location16 = intervalsSet12.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform17 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion18 = intervalsSet12.applyTransform(euclidean1DTransform17);
        double double19 = intervalsSet12.getInf();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + location16 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location16.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.NEGATIVE_INFINITY + "'", double19 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        boolean boolean3 = subLine2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str6 = vector2D5.toString();
        double double7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane10 = subLine2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line9);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform11 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane12 = subLine2.applyTransform(euclidean2DTransform11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0; 0}" + "'", str6.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = line5.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray8 = polygonsSet7.getVertices();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(polygonsSet7);
        org.junit.Assert.assertNotNull(vector2DArray8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = orientedPoint9.getLocation();
        boolean boolean11 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint4.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList13 = intervalsSet12.asList();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector14 = intervalsSet12.getBarycenter();
        double double15 = intervalsSet12.getSup();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet12.applyTransform(euclidean1DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = euclidean1DAbstractRegion17.getTree(false);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertNotNull(intervalList13);
        org.junit.Assert.assertNotNull(euclidean1DVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree19);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree11 = polyhedronsSet9.getTree(false);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector12 = polyhedronsSet9.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D3.subtract(euclidean3DVector12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.negate();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean3DVector12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double20 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        double double32 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D24, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine37 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D35, vector2D36);
        double double38 = vector2D36.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D39, vector2D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D36.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine49 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D47, vector2D48);
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getNorm1();
        double[] doubleArray52 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        line5.translateToPoint(vector2D46);
        line5.setOriginOffset((double) (short) 0);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine57 = line5.wholeHyperplane();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(subLine57);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Line line34 = null;
        try {
            boolean boolean35 = line33.isSimilarTo(line34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        double double3 = vector2D1.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = vector2D1.getZero();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (-1), 1079410688);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 100, (float) (-1), 1076101151);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = line5.getPointAt(vector1D16, 1.5607966601082315d);
        boolean boolean19 = vector2D18.isInfinite();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-53) + "'", int1 == (-53));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        boolean boolean3 = subLine2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str6 = vector2D5.toString();
        double double7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane10 = subLine2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line9.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D15, vector1D17);
        double double19 = vector1D17.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D24, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D17.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double30 = vector1D28.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        boolean boolean31 = vector1D28.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = line9.getPointAt(vector1D28, (double) '4');
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = line9.copySelf();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0; 0}" + "'", str6.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane10);
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(line34);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree5 = polyhedronsSet3.getTree(false);
        euclidean3DBSPTree2.insertInTree(euclidean3DBSPTree5, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree8 = euclidean3DBSPTree2.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree11 = polyhedronsSet9.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = polyhedronsSet12.getTree(false);
        euclidean3DBSPTree11.insertInTree(euclidean3DBSPTree14, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree11.getParent();
        euclidean3DBSPTree8.insertInTree(euclidean3DBSPTree11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree20 = euclidean3DBSPTree8.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree21 = euclidean3DBSPTree20.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet22 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree24 = polyhedronsSet22.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree27 = polyhedronsSet25.getTree(false);
        euclidean3DBSPTree24.insertInTree(euclidean3DBSPTree27, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree30 = euclidean3DBSPTree24.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double35 = vector3D33.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D31.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        euclidean3DBSPTree30.setAttribute((java.lang.Object) vector3D36);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet38 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double43 = vector3D41.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D39.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.partitioning.Region.Location location45 = polyhedronsSet38.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D41.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D47, vector3D48, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double55 = vector3D53.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = vector3D51.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane57 = plane50.translate(vector3D51);
        double double58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D41, vector3D51);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree59 = euclidean3DBSPTree30.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        euclidean3DBSPTree21.insertInTree(euclidean3DBSPTree59, false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree8);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree20);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree21);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree24);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree27);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + location45 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location45.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(plane57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree59);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        boolean boolean9 = vector3D8.isInfinite();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.partitioning.Side side5 = polyhedronsSet0.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double12 = vector3D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Line line15 = plane4.intersection(plane14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D16, vector3D17, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str24 = vector2D23.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = vector2D22.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = plane21.getPointAt(vector2D25, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Rotation rotation28 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane29 = plane4.rotate(vector3D27, rotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0; 0}" + "'", str24.equals("{0; 0}"));
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector3D27);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(99.0d);
        java.text.NumberFormat numberFormat2 = null;
        try {
            java.lang.String str3 = vector1D1.toString(numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(1.5607966593453682d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.42706125860767d + "'", double1 == 89.42706125860767d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = plane4.copySelf();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) plane4);
        plane4.revertSelf();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(plane5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.partitioning.Side side5 = polyhedronsSet0.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane4);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet6 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double11 = vector3D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D7.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.partitioning.Region.Location location13 = polyhedronsSet6.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = plane4.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = plane4.getOrigin();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + location13 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location13.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector3D16);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector3 = polyhedronsSet0.getBarycenter();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector4 = polyhedronsSet0.getBarycenter();
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean3DVector3);
        org.junit.Assert.assertNotNull(euclidean3DVector4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(22.0d, 0.0d, 94.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D1.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double7 = vector1D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D10.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D6.subtract((-17.000003814697266d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        double double19 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection23 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException25 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10.0f, (java.lang.Number) 3, (int) (byte) 1, orderDirection23, true);
        int int26 = nonMonotonicSequenceException25.getIndex();
        java.lang.Number number27 = nonMonotonicSequenceException25.getPrevious();
        boolean boolean28 = vector1D2.equals((java.lang.Object) nonMonotonicSequenceException25);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet29 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet30 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree32 = polyhedronsSet30.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet33 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree35 = polyhedronsSet33.getTree(false);
        euclidean3DBSPTree32.insertInTree(euclidean3DBSPTree35, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet38 = polyhedronsSet29.buildNew(euclidean3DBSPTree35);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet39 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D40, vector3D41, vector3D42);
        org.apache.commons.math3.geometry.partitioning.Side side44 = polyhedronsSet39.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane43);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane43);
        org.apache.commons.math3.geometry.partitioning.Side side46 = polyhedronsSet38.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane43);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree48 = polyhedronsSet38.getTree(true);
        boolean boolean49 = vector1D2.equals((java.lang.Object) euclidean3DBSPTree48);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 3 + "'", number27.equals(3));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree32);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree35);
        org.junit.Assert.assertNotNull(polyhedronsSet38);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + side44 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side44.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertTrue("'" + side46 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side46.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(euclidean3DBSPTree48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        double double1 = vector3D0.getNorm1();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (-1604780033), (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet5 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((double) 'a', 0.0d, (double) 35, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        double double11 = vector2D8.getNorm1();
        double[] doubleArray12 = vector2D8.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = vector2D6.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.partitioning.Region.Location location14 = polygonsSet5.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet15 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine18 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D16, vector2D17);
        boolean boolean19 = subLine18.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine22 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D20, vector2D21);
        boolean boolean23 = subLine22.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str26 = vector2D25.toString();
        double double27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D24, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Line line29 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D25, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane30 = subLine22.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line29);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane31 = subLine18.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine22);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane32 = subLine22.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane33 = polygonsSet15.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) euclidean2DAbstractSubHyperplane32);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane34 = polygonsSet5.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) euclidean2DAbstractSubHyperplane32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vector2DArray35 = polygonsSet5.getVertices();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException36 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) vector2DArray35);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + location14 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location14.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{0; 0}" + "'", str26.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane30);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane31);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane32);
        org.junit.Assert.assertNotNull(euclidean2DSubHyperplane33);
        org.junit.Assert.assertNull(euclidean2DSubHyperplane34);
        org.junit.Assert.assertNotNull(vector2DArray35);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.7212442199534053d, 299.99999999999994d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7212442199534053d + "'", double2 == 0.7212442199534053d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 52);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        java.lang.String str18 = vector1D17.toString();
        double double19 = vector1D15.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str22 = vector2D21.toString();
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D20, vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D21, 4.9E-324d);
        double double26 = line25.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D27, vector2D28);
        double double30 = vector2D28.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine33 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D31, vector2D32);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D28, vector2D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = line25.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double40 = vector1D38.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double45 = vector1D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        double double46 = vector1D39.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint51 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D48, true);
        double double52 = vector1D44.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = line25.getPointAt(vector1D44, 1.5707963267948966d);
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D15, vector1D44);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{-1}" + "'", str18.equals("{-1}"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.0d) + "'", double19 == (-0.0d));
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{0; 0}" + "'", str22.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.9E-324d + "'", double26 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane3 = subLine2.getHyperplane();
        java.util.List<org.apache.commons.math3.geometry.euclidean.twod.Segment> segmentList4 = subLine2.getSegments();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(euclidean2DHyperplane3);
        org.junit.Assert.assertNotNull(segmentList4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.partitioning.Side side5 = polyhedronsSet0.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane9 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D6, vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double12 = vector3D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D10.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D7, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Line line15 = plane4.intersection(plane14);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet16 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet17 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree19 = polyhedronsSet17.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet20 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree22 = polyhedronsSet20.getTree(false);
        euclidean3DBSPTree19.insertInTree(euclidean3DBSPTree22, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = polyhedronsSet16.buildNew(euclidean3DBSPTree22);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet26 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet27 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree29 = polyhedronsSet27.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet30 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree32 = polyhedronsSet30.getTree(false);
        euclidean3DBSPTree29.insertInTree(euclidean3DBSPTree32, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet35 = polyhedronsSet26.buildNew(euclidean3DBSPTree32);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector36 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree37 = euclidean3DBSPTree32.getCell(euclidean3DVector36);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane41 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D38, vector3D39, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane42 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane43 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane47 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D44, vector3D45, vector3D46);
        boolean boolean48 = plane43.isSimilarTo(plane47);
        boolean boolean49 = euclidean3DBSPTree32.insertCut((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane43);
        org.apache.commons.math3.geometry.partitioning.Side side50 = polyhedronsSet25.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane43);
        plane43.revertSelf();
        plane4.reset(plane43);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(line15);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree19);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree22);
        org.junit.Assert.assertNotNull(polyhedronsSet25);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree29);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree32);
        org.junit.Assert.assertNotNull(polyhedronsSet35);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + side50 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side50.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet1 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double6 = vector3D4.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D2.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.partitioning.Region.Location location8 = polyhedronsSet1.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D4.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane13 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D10, vector3D11, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double18 = vector3D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = plane13.translate(vector3D14);
        double double21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D4, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane25 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D22, vector3D23, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane26 = plane25.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D27, vector2D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = plane25.getPointAt(vector2D28, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line34 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D14, vector3D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str37 = vector2D36.toString();
        double double38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D35, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Line line40 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D36, 4.9E-324d);
        double double41 = line40.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine44 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D42, vector2D43);
        double double45 = vector2D43.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine48 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D46, vector2D47);
        double double49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D43, vector2D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = line40.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = line34.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D51);
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + location8 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location8.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(plane20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(subPlane26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{0; 0}" + "'", str37.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.9E-324d + "'", double41 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint30 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D27, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = orientedPoint30.getLocation();
        boolean boolean32 = orientedPoint25.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint30);
        org.apache.commons.math3.geometry.partitioning.Side side33 = subOrientedPoint20.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint30);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint34 = orientedPoint30.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint39 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D36, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = orientedPoint39.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint45 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D42, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint50 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D47, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = orientedPoint50.getLocation();
        boolean boolean52 = orientedPoint45.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint50);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet53 = orientedPoint45.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList54 = intervalsSet53.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint55 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint39, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D57);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint60 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D57, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D62);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint65 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D62, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = orientedPoint65.getLocation();
        boolean boolean67 = orientedPoint60.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint65);
        org.apache.commons.math3.geometry.partitioning.Side side68 = subOrientedPoint55.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = orientedPoint65.getLocation();
        boolean boolean70 = orientedPoint34.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint65);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + side33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side33.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(orientedPoint34);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(intervalsSet53);
        org.junit.Assert.assertNotNull(intervalList54);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + side68 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.HYPER + "'", side68.equals(org.apache.commons.math3.geometry.partitioning.Side.HYPER));
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.geometry.partitioning.Region.Location[] locationArray0 = new org.apache.commons.math3.geometry.partitioning.Region.Location[] {};
        double[] doubleArray2 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple3 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray2, (double) 10.0f);
        double[] doubleArray7 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple8 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray7);
        double double9 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray5, doubleArray7);
        double[] doubleArray13 = new double[] { ' ', 10L, 0.6610060414837631d };
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray13);
        double double15 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray5, doubleArray13);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection16, false);
        try {
            boolean boolean20 = org.apache.commons.math3.util.MathArrays.isMonotonic(locationArray0, orderDirection16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(locationArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 22.0d + "'", double15 == 22.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        boolean boolean3 = subLine2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str6 = vector2D5.toString();
        double double7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane10 = subLine2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line9.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D15, vector1D17);
        double double19 = vector1D17.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D24, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D17.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double30 = vector1D28.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        boolean boolean31 = vector1D28.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = line9.getPointAt(vector1D28, (double) '4');
        line9.setAngle(4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0; 0}" + "'", str6.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane10);
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(vector2D33);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, true);
        org.junit.Assert.assertNotNull(vector1D0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine5 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D3, vector2D4);
        double double6 = vector2D4.getNorm();
        double double7 = vector2D4.getNorm1();
        double[] doubleArray8 = vector2D4.toArray();
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray1, doubleArray8);
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple10 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        double[] doubleArray12 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple13 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray12);
        double[] doubleArray14 = orderedTuple13.getComponents();
        int int15 = orderedTuple10.compareTo(orderedTuple13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        java.lang.String str19 = vector1D18.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D24, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double33 = vector1D31.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D32, vector1D34);
        double double36 = vector1D34.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double42 = vector1D40.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D41, vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D34.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double47 = vector1D45.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        boolean boolean48 = vector1D45.isInfinite();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        java.lang.String str52 = vector1D51.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D18, 2.6991118430775187d, vector1D24, 4.9E-324d, vector1D45, 8.0d, vector1D51);
        boolean boolean54 = orderedTuple10.equals((java.lang.Object) vector1D18);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{-1}" + "'", str19.equals("{-1}"));
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{-1}" + "'", str52.equals("{-1}"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(17.01175199973875d, 90.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = vector2D0.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line8 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, (-0.6321205588285577d));
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet5 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line7 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane8 = polyhedronsSet5.firstIntersection(vector3D6, line7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.partitioning.Region.Location location10 = polyhedronsSet5.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D0.subtract((double) (short) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double14 = vector3D12.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D12.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D12);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + location10 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location10.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.geometry.euclidean.oned.Interval interval2 = new org.apache.commons.math3.geometry.euclidean.oned.Interval((double) 52.000004f, (double) '#');
        java.lang.Class<?> wildcardClass3 = interval2.getClass();
        double double4 = interval2.getUpper();
        double double5 = interval2.getLength();
        double double6 = interval2.getLength();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-17.000003814697266d) + "'", double5 == (-17.000003814697266d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-17.000003814697266d) + "'", double6 == (-17.000003814697266d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(299.99999999999994d, (double) 1615462400, 0.0d);
        java.lang.Class<?> wildcardClass4 = vector3D3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree34 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D13);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double20 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        double double32 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D24, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine37 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D35, vector2D36);
        double double38 = vector2D36.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine41 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D39, vector2D40);
        double double42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D36, vector2D40);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = vector2D36.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine49 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D47, vector2D48);
        double double50 = vector2D48.getNorm();
        double double51 = vector2D48.getNorm1();
        double[] doubleArray52 = vector2D48.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = vector2D46.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        line5.translateToPoint(vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str57 = vector2D56.toString();
        double double58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D55, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Line line60 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D56, 4.9E-324d);
        boolean boolean61 = line5.isParallelTo(line60);
        org.apache.commons.math3.geometry.euclidean.twod.Line line62 = line60.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet63 = line60.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet68 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((double) 'a', 0.0d, (double) 35, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine72 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D70, vector2D71);
        double double73 = vector2D71.getNorm();
        double double74 = vector2D71.getNorm1();
        double[] doubleArray75 = vector2D71.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = vector2D69.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        org.apache.commons.math3.geometry.partitioning.Region.Location location77 = polygonsSet68.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet78 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine81 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D79, vector2D80);
        boolean boolean82 = subLine81.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine85 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D83, vector2D84);
        boolean boolean86 = subLine85.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str89 = vector2D88.toString();
        double double90 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D87, vector2D88);
        org.apache.commons.math3.geometry.euclidean.twod.Line line92 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D88, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane93 = subLine85.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line92);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane94 = subLine81.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) subLine85);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane95 = subLine85.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane96 = polygonsSet78.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) euclidean2DAbstractSubHyperplane95);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSubHyperplane97 = polygonsSet68.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) euclidean2DAbstractSubHyperplane95);
        boolean boolean98 = polygonsSet63.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet68);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0; 0}" + "'", str57.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(line62);
        org.junit.Assert.assertNotNull(polygonsSet63);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertTrue("'" + location77 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location77.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertNotNull(vector2D84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "{0; 0}" + "'", str89.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane93);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane94);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane95);
        org.junit.Assert.assertNotNull(euclidean2DSubHyperplane96);
        org.junit.Assert.assertNull(euclidean2DSubHyperplane97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet7 = line5.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree9 = polygonsSet7.getTree(false);
        double double10 = polygonsSet7.getSize();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str13 = vector2D12.toString();
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D11, vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D12, 4.9E-324d);
        double double17 = line16.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet18 = line16.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree20 = polygonsSet18.getTree(false);
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet21 = polygonsSet7.buildNew(euclidean2DBSPTree20);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(polygonsSet7);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{0; 0}" + "'", str13.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.9E-324d + "'", double17 == 4.9E-324d);
        org.junit.Assert.assertNotNull(polygonsSet18);
        org.junit.Assert.assertNotNull(euclidean2DBSPTree20);
        org.junit.Assert.assertNotNull(polygonsSet21);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = line33.getOrigin();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D34);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean5 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray1, orderDirection3, true);
        double[] doubleArray7 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple8 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray7);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray7, orderDirection9, true);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection9, false, false);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10.0f, (java.lang.Number) 3, (int) (byte) 1, orderDirection3, true);
        int int6 = nonMonotonicSequenceException5.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = plane4.getV();
        java.lang.String str6 = vector3D5.toString();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{(NaN); (NaN); (NaN)}" + "'", str6.equals("{(NaN); (NaN); (NaN)}"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        boolean boolean3 = subLine2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str6 = vector2D5.toString();
        double double7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane10 = subLine2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line9.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        java.lang.String str20 = vector1D19.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine24 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D22, vector2D23);
        double double25 = vector2D23.getNorm();
        double double26 = vector2D23.getNorm1();
        double[] doubleArray27 = vector2D23.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine30 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D28, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D28.negate();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine35 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D33, vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = vector2D28.add((-17.000003814697266d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        line11.reset(vector2D23, vector2D36);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0; 0}" + "'", str6.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane10);
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{-1}" + "'", str20.equals("{-1}"));
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D36);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.Object[] objArray7 = new java.lang.Object[] { vector2D6 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable5, objArray7);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math3.exception.MathArithmeticException(localizable4, objArray7);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math3.exception.NullArgumentException(localizable3, objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, localizable1, objArray7);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane4 = plane3.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane8 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D5, vector3D6, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane9 = plane8.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet10 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane14 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D11, vector3D12, vector3D13);
        org.apache.commons.math3.geometry.partitioning.Side side15 = polyhedronsSet10.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane14);
        plane8.reset(plane14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane20 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D17, vector3D18, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane21 = plane20.wholeHyperplane();
        double double22 = plane8.getOffset(plane20);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree23 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet24 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree23);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree25 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet26 = polygonsSet24.buildNew(euclidean2DBSPTree25);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane27 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet26);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane28 = subPlane4.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane27);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DRegion29 = euclidean3DAbstractSubHyperplane28.getRemainingRegion();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane33 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D30, vector3D31, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane34 = plane33.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet35 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D37, vector3D38);
        org.apache.commons.math3.geometry.partitioning.Side side40 = polyhedronsSet35.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane39);
        plane33.reset(plane39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D42, vector3D43, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane46 = plane45.wholeHyperplane();
        double double47 = plane33.getOffset(plane45);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree48 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet49 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(euclidean2DBSPTree48);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DBSPTree50 = null;
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet51 = polygonsSet49.buildNew(euclidean2DBSPTree50);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane52 = new org.apache.commons.math3.geometry.euclidean.threed.SubPlane((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane33, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) polygonsSet51);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane53 = euclidean3DAbstractSubHyperplane28.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane52);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractSubHyperplane54 = subPlane52.copySelf();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(subPlane4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(subPlane9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + side15 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side15.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(subPlane21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertNotNull(polygonsSet26);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane28);
        org.junit.Assert.assertNotNull(euclidean2DRegion29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(subPlane34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + side40 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side40.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(subPlane46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(polygonsSet51);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane53);
        org.junit.Assert.assertNotNull(euclidean3DAbstractSubHyperplane54);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D1.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double7 = vector1D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D10.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D6.subtract((-17.000003814697266d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        double double19 = vector1D2.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        double double20 = vector1D6.getX();
        boolean boolean21 = vector1D6.isInfinite();
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray1 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple2 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray1);
        double[] doubleArray3 = orderedTuple2.getComponents();
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray3, 2.0d);
        int int6 = org.apache.commons.math3.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1076101151 + "'", int6 == 1076101151);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((double) 'a', 0.0d, (double) 35, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine8 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D6, vector2D7);
        double double9 = vector2D7.getNorm();
        double double10 = vector2D7.getNorm1();
        double[] doubleArray11 = vector2D7.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = vector2D5.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.partitioning.Region.Location location13 = polygonsSet4.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double14 = polygonsSet4.getBoundarySize();
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + location13 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE + "'", location13.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.OUTSIDE));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 243.99999809265137d + "'", double14 == 243.99999809265137d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double39 = vector3D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D35.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.partitioning.Region.Location location41 = polyhedronsSet34.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43, vector3D44, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double51 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D47.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = plane46.translate(vector3D47);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D37, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane58 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D56, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane59 = plane58.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine62 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D60, vector2D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = plane58.getPointAt(vector2D61, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D64.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line67 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D47, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet68 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double73 = vector3D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D69.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.Region.Location location75 = polyhedronsSet68.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree76 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D71.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = line67.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D77);
        boolean boolean79 = line33.isSimilarTo(line67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = line33.pointAt((double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.threed.Line line82 = new org.apache.commons.math3.geometry.euclidean.threed.Line(line33);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D84 = vector3D83.normalize();
        double double85 = line33.distance(vector3D84);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + location41 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location41.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(plane53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(subPlane59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + location75 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location75.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(vector3D84);
        org.junit.Assert.assertEquals((double) double85, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line2 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane3 = polyhedronsSet0.firstIntersection(vector3D1, line2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double6 = vector3D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane11 = polyhedronsSet8.firstIntersection(vector3D9, line10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.partitioning.Region.Location location13 = polyhedronsSet8.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        double double14 = polyhedronsSet8.getSize();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform15 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion16 = polyhedronsSet8.applyTransform(euclidean3DTransform15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = null;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet18 = polyhedronsSet8.translate(vector3D17);
        double double19 = polyhedronsSet18.getBoundarySize();
        boolean boolean20 = polyhedronsSet0.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet18);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNull(euclidean3DSubHyperplane11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + location13 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location13.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion16);
        org.junit.Assert.assertNotNull(polyhedronsSet18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        float[] floatArray0 = null;
        float[] floatArray1 = null;
        float[] floatArray2 = new float[] {};
        float[] floatArray8 = new float[] { (short) 1, (short) 0, 10, 1.0f, (short) 100 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray8);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(floatArray1, floatArray8);
        float[] floatArray17 = new float[] { 10L, (short) 100, (-127), (-1023), ' ', 97.00001f };
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(floatArray1, floatArray17);
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray17);
        float[] floatArray25 = new float[] { (-53), 0, 10.0f, ' ', 1L };
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray25);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double9 = vector3D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D5.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = plane4.translate(vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.0f, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet13 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double18 = vector3D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.partitioning.Region.Location location20 = polyhedronsSet13.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Line line21 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D12, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet22 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double27 = vector3D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D23.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.partitioning.Region.Location location29 = polyhedronsSet22.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree30 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D25.getZero();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D31.scalarMultiply(2.995592469141819E14d);
        double double34 = line21.distance(vector3D33);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(plane11);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + location20 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location20.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + location29 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location29.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane6 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane7 = plane6.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.partitioning.Side side13 = polyhedronsSet8.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane12);
        plane6.reset(plane12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D15, vector3D16, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane19 = plane18.wholeHyperplane();
        double double20 = plane6.getOffset(plane18);
        org.apache.commons.math3.geometry.partitioning.Side side21 = polyhedronsSet0.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane18);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet22 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree24 = polyhedronsSet22.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree27 = polyhedronsSet25.getTree(false);
        euclidean3DBSPTree24.insertInTree(euclidean3DBSPTree27, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree30 = euclidean3DBSPTree24.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet31 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree33 = polyhedronsSet31.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree36 = polyhedronsSet34.getTree(false);
        euclidean3DBSPTree33.insertInTree(euclidean3DBSPTree36, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree39 = euclidean3DBSPTree33.getParent();
        euclidean3DBSPTree30.insertInTree(euclidean3DBSPTree33, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree42 = euclidean3DBSPTree30.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree43 = euclidean3DBSPTree30.copySelf();
        euclidean3DBSPTree30.setAttribute((java.lang.Object) 1.3440585709080678E43d);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet46 = polyhedronsSet0.buildNew(euclidean3DBSPTree30);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(subPlane7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + side13 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side13.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(subPlane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + side21 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side21.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(euclidean3DBSPTree24);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree27);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree30);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree33);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree36);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree39);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree42);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree43);
        org.junit.Assert.assertNotNull(polyhedronsSet46);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane3 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D0, vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane3);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = plane4.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane6 = plane4.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree10 = polyhedronsSet8.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet11 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree13 = polyhedronsSet11.getTree(false);
        euclidean3DBSPTree10.insertInTree(euclidean3DBSPTree13, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet16 = polyhedronsSet7.buildNew(euclidean3DBSPTree13);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet17 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane21 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D18, vector3D19, vector3D20);
        org.apache.commons.math3.geometry.partitioning.Side side22 = polyhedronsSet17.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane21);
        org.apache.commons.math3.geometry.partitioning.Side side24 = polyhedronsSet16.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = plane21.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane26 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(plane21);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSplitSubHyperplane27 = subPlane6.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane21);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(plane5);
        org.junit.Assert.assertNotNull(subPlane6);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree13);
        org.junit.Assert.assertNotNull(polyhedronsSet16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + side22 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side22.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertTrue("'" + side24 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side24.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(polyhedronsSet25);
        org.junit.Assert.assertNotNull(euclidean3DSplitSubHyperplane27);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = orientedPoint9.getLocation();
        boolean boolean11 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint4.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList13 = intervalsSet12.asList();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector14 = intervalsSet12.getBarycenter();
        double double15 = intervalsSet12.getSup();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree17 = intervalsSet12.getTree(true);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion18 = intervalsSet12.copySelf();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertNotNull(intervalList13);
        org.junit.Assert.assertNotNull(euclidean1DVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane5 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D2, vector3D3, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane6 = plane5.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = plane5.getPointAt(vector2D8, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D14, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane17 = plane16.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine20 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D18, vector2D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = plane16.getPointAt(vector2D19, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D22.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = polyhedronsSet12.translate(vector3D24);
        double double26 = vector3D24.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane27 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D11, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane31 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D28, vector3D29, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane32 = plane31.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine35 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D33, vector2D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = plane31.getPointAt(vector2D34, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D37.scalarMultiply((double) (byte) -1);
        double double40 = vector3D37.getNorm1();
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D11, vector3D37);
        double double42 = vector3D37.getDelta();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(subPlane6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(subPlane17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(polyhedronsSet25);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(subPlane32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D5);
        double double7 = vector1D5.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D12, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D5.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double18 = vector1D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D17.scalarMultiply(94.0d);
        org.apache.commons.math3.geometry.Space space21 = vector1D20.getSpace();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(space21);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 10, 0.0d, 90.0d, 4.69041575982343d, (double) (-127), (double) 1076101151);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.3666484575486258E11d) + "'", double6 == (-1.3666484575486258E11d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree5 = polyhedronsSet3.getTree(false);
        euclidean3DBSPTree2.insertInTree(euclidean3DBSPTree5, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree8 = euclidean3DBSPTree2.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree11 = polyhedronsSet9.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = polyhedronsSet12.getTree(false);
        euclidean3DBSPTree11.insertInTree(euclidean3DBSPTree14, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree11.getParent();
        euclidean3DBSPTree8.insertInTree(euclidean3DBSPTree11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree20 = euclidean3DBSPTree8.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree21 = euclidean3DBSPTree8.getParent();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str24 = vector2D23.toString();
        double double25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D22, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, 4.9E-324d);
        double double28 = line27.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine31 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D29, vector2D30);
        double double32 = vector2D30.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine35 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D33, vector2D34);
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D30, vector2D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = line27.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double42 = vector1D40.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D45.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        double double48 = vector1D41.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint53 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D50, true);
        double double54 = vector1D46.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = line27.getPointAt(vector1D46, 1.5707963267948966d);
        line27.revertSelf();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree58 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) line27);
        euclidean3DBSPTree21.insertInTree(euclidean3DBSPTree58, false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree8);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree20);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree21);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0; 0}" + "'", str24.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.9E-324d + "'", double28 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D56);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet2 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane6 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D3, vector3D4, vector3D5);
        org.apache.commons.math3.geometry.partitioning.Side side7 = polyhedronsSet2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8, vector3D9, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double16 = vector3D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D12.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane18 = plane11.translate(vector3D12);
        boolean boolean19 = plane6.isSimilarTo(plane18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = plane18.getU();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (-1L), vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D23.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane28 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D25, vector3D26, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane29 = plane28.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine32 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D30, vector2D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = plane28.getPointAt(vector2D31, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet35 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D37, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane40 = plane39.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine43 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D41, vector2D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = plane39.getPointAt(vector2D42, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = vector3D45.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet48 = polyhedronsSet35.translate(vector3D47);
        double double49 = vector3D47.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D24, vector3D34, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet51 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line53 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane54 = polyhedronsSet51.firstIntersection(vector3D52, line53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double57 = vector3D55.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        org.apache.commons.math3.geometry.partitioning.Region.Location location58 = polyhedronsSet51.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        double double59 = vector3D47.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        java.lang.Object obj60 = null;
        boolean boolean61 = vector3D47.equals(obj60);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet65 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double70 = vector3D68.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D69);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = vector3D66.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.partitioning.Region.Location location72 = polyhedronsSet65.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D73 = vector3D68.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D64.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D68);
        org.apache.commons.math3.geometry.euclidean.threed.Line line75 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D63, vector3D74);
        double[] doubleArray76 = vector3D74.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(225.40215564304685d, vector3D20, 2.3978952727983707d, vector3D47, 5.298342365610589d, vector3D74);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + side7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side7.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(plane18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(subPlane29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(subPlane40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(polyhedronsSet48);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + location58 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location58.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertTrue("'" + location72 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location72.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D73);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D3, vector1D5);
        double double7 = vector1D5.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D12, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D5.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double18 = vector1D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D17.scalarMultiply(1.1102230246251565E-16d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D21.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1.0f));
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = vector1D24.normalize();
        double double26 = vector1D24.getNormInf();
        double double27 = vector1D21.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double28 = vector1D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double29 = vector1D24.getNormSq();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int[] intArray0 = null;
        try {
            int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree1);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet2);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = null;
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = intervalsSet2.buildNew(euclidean1DBSPTree4);
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion6 = intervalsSet5.copySelf();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intervalsSet5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(94.0d, (double) 90L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94.0d + "'", double2 == 94.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree2 = polyhedronsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet3 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree5 = polyhedronsSet3.getTree(false);
        euclidean3DBSPTree2.insertInTree(euclidean3DBSPTree5, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree8 = euclidean3DBSPTree2.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet9 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree11 = polyhedronsSet9.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet12 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree14 = polyhedronsSet12.getTree(false);
        euclidean3DBSPTree11.insertInTree(euclidean3DBSPTree14, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree17 = euclidean3DBSPTree11.getParent();
        euclidean3DBSPTree8.insertInTree(euclidean3DBSPTree11, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree20 = euclidean3DBSPTree8.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree21 = euclidean3DBSPTree8.getParent();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet22 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree24 = polyhedronsSet22.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet25 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree27 = polyhedronsSet25.getTree(false);
        euclidean3DBSPTree24.insertInTree(euclidean3DBSPTree27, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree30 = euclidean3DBSPTree24.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet31 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree33 = polyhedronsSet31.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree36 = polyhedronsSet34.getTree(false);
        euclidean3DBSPTree33.insertInTree(euclidean3DBSPTree36, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree39 = euclidean3DBSPTree33.getParent();
        euclidean3DBSPTree30.insertInTree(euclidean3DBSPTree33, true);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree42 = euclidean3DBSPTree30.getParent();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree43 = euclidean3DBSPTree42.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D44.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane49 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D46, vector3D47, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane50 = plane49.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine53 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D51, vector2D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = plane49.getPointAt(vector2D52, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet56 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane60 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D57, vector3D58, vector3D59);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane61 = plane60.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine64 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D62, vector2D63);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = plane60.getPointAt(vector2D63, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D68 = vector3D66.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet69 = polyhedronsSet56.translate(vector3D68);
        double double70 = vector3D68.getX();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane71 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D45, vector3D55, vector3D68);
        boolean boolean72 = vector3D45.isNaN();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree73 = euclidean3DBSPTree42.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D45);
        org.apache.commons.math3.geometry.partitioning.BSPTree.LeafMerger<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DLeafMerger74 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree75 = euclidean3DBSPTree21.merge(euclidean3DBSPTree73, euclidean3DLeafMerger74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean3DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree8);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree11);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree14);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree17);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree20);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree21);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree24);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree27);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree30);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree33);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree36);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree39);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree42);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(subPlane50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertNotNull(subPlane61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D68);
        org.junit.Assert.assertNotNull(polyhedronsSet69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree73);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line2 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane3 = polyhedronsSet0.firstIntersection(vector3D1, line2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.partitioning.Region.Location location5 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        double double6 = polyhedronsSet0.getSize();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DTransform7 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion8 = polyhedronsSet0.applyTransform(euclidean3DTransform7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane13 = plane12.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane14 = euclidean3DAbstractRegion8.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane13);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + location5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location5.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(subPlane13);
        org.junit.Assert.assertNotNull(euclidean3DSubHyperplane14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, 2.6881171418161356E43d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D0, vector2D1);
        boolean boolean3 = subLine2.isEmpty();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str6 = vector2D5.toString();
        double double7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D4, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Line line9 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D5, 4.9E-324d);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DSplitSubHyperplane10 = subLine2.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line9);
        org.apache.commons.math3.geometry.euclidean.twod.Line line11 = line9.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = line11.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        double double18 = line11.getAngle();
        double double19 = line11.getAngle();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0; 0}" + "'", str6.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean2DSplitSubHyperplane10);
        org.junit.Assert.assertNotNull(line11);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.9E-324d + "'", double18 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.9E-324d + "'", double19 == 4.9E-324d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint25 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = orientedPoint25.getLocation();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane27 = subOrientedPoint20.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint25);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet28 = orientedPoint25.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet31 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((-17.000003814697266d), 52.000003814697266d);
        boolean boolean32 = intervalsSet28.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint37 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D34, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint42 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D39, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = orientedPoint42.getLocation();
        boolean boolean44 = orientedPoint37.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint42);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet45 = orientedPoint37.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList46 = intervalsSet45.asList();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector47 = intervalsSet45.getBarycenter();
        double double48 = intervalsSet45.getSup();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree50 = intervalsSet45.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet51 = intervalsSet31.buildNew(euclidean1DBSPTree50);
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(euclidean1DSplitSubHyperplane27);
        org.junit.Assert.assertNotNull(intervalsSet28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(vector1D34);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(intervalsSet45);
        org.junit.Assert.assertNotNull(intervalList46);
        org.junit.Assert.assertNotNull(euclidean1DVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree50);
        org.junit.Assert.assertNotNull(intervalsSet51);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 1079410688);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str2 = vector2D1.toString();
        double double3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D0, vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Line line5 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D1, 4.9E-324d);
        double double6 = line5.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine9 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D7, vector2D8);
        double double10 = vector2D8.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine13 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D11, vector2D12);
        double double14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D8, vector2D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = line5.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double20 = vector1D18.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double26 = vector1D19.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint31 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D28, true);
        double double32 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = line5.getPointAt(vector1D24, 1.5707963267948966d);
        double double35 = vector2D34.getNormInf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane39 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D36, vector3D37, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane40 = plane39.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine43 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D41, vector2D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = plane39.getPointAt(vector2D42, (double) '#');
        double double46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D34, vector2D42);
        java.lang.String str47 = vector2D42.toString();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine51 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D49, vector2D50);
        double double52 = vector2D50.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine55 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D53, vector2D54);
        double double56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D50, vector2D54);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-1.0f), vector2D50);
        double double58 = vector2D42.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D50);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0; 0}" + "'", str2.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.5707963267948966d + "'", double35 == 1.5707963267948966d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(subPlane40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.4674011002723395d + "'", double46 == 2.4674011002723395d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{0; 0}" + "'", str47.equals("{0; 0}"));
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonsSet4 = new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet((double) 'a', 0.0d, (double) 35, (double) 10.000001f);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str7 = vector2D6.toString();
        double double8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D5, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Line line10 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D6, 4.9E-324d);
        double double11 = line10.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine14 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D12, vector2D13);
        double double15 = vector2D13.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine18 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D16, vector2D17);
        double double19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D13, vector2D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = line10.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = vector1D23.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double30 = vector1D28.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        double double31 = vector1D24.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint36 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D33, true);
        double double37 = vector1D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = line10.getPointAt(vector1D29, 1.5707963267948966d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine42 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D40, vector2D41);
        double double43 = vector2D41.getNorm();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D44, vector2D45);
        double double47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D41, vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = vector2D41.scalarMultiply((double) ' ');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = line10.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine54 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D52, vector2D53);
        double double55 = vector2D53.getNorm();
        double double56 = vector2D53.getNorm1();
        double[] doubleArray57 = vector2D53.toArray();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = vector2D51.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D53);
        line10.translateToPoint(vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        java.lang.String str62 = vector2D61.toString();
        double double63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D60, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Line line65 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D61, 4.9E-324d);
        boolean boolean66 = line10.isParallelTo(line65);
        org.apache.commons.math3.geometry.euclidean.twod.Line line67 = line10.copySelf();
        double double68 = line67.getOriginOffset();
        org.apache.commons.math3.geometry.partitioning.Side side69 = polygonsSet4.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line67);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0; 0}" + "'", str7.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.9E-324d + "'", double11 == 4.9E-324d);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "{0; 0}" + "'", str62.equals("{0; 0}"));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(line67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + side69 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.MINUS + "'", side69.equals(org.apache.commons.math3.geometry.partitioning.Side.MINUS));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 127L, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 127.0f + "'", float2 == 127.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 10, (int) (byte) 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0737418550010472E11d, 97.00000762939453d, 17.01175199973875d, 350.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0415296818664295E13d + "'", double4 == 1.0415296818664295E13d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double7 = vector1D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D10.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        double double13 = vector1D6.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D6.subtract((-17.000003814697266d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D21.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double28 = vector1D26.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        double double29 = vector1D22.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint34 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D31, true);
        double double35 = vector1D27.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        java.lang.Object obj36 = null;
        boolean boolean37 = vector1D31.equals(obj36);
        double double38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D18, vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double44 = vector1D42.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D43, vector1D45);
        double double47 = vector1D45.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double53 = vector1D51.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D52, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D45.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double62 = vector1D60.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double67 = vector1D65.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        double double68 = vector1D61.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D71);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = vector1D61.subtract((-17.000003814697266d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D72);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = vector1D52.add(1.0E52d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D72);
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1076101151, vector1D1, (double) 35L, vector1D31, 97.00000762939453d, vector1D74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertNotNull(vector1D74);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double5 = vector3D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.partitioning.Region.Location location7 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D3.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane12 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D9, vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double17 = vector3D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D13.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane19 = plane12.translate(vector3D13);
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D3, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane24 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D21, vector3D22, vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane25 = plane24.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine28 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D26, vector2D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = plane24.getPointAt(vector2D27, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet34 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double39 = vector3D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D35.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.partitioning.Region.Location location41 = polyhedronsSet34.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane46 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D43, vector3D44, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double51 = vector3D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D50);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = vector3D47.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane53 = plane46.translate(vector3D47);
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D37, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane58 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D55, vector3D56, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane59 = plane58.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine62 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D60, vector2D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = plane58.getPointAt(vector2D61, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = vector3D64.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line67 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D47, vector3D66);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet68 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double73 = vector3D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D72);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D74 = vector3D69.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.Region.Location location75 = polyhedronsSet68.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree76 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>((java.lang.Object) vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = vector3D71.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = line67.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D77);
        boolean boolean79 = line33.isSimilarTo(line67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = line67.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Line line81 = null;
        try {
            double double82 = line67.distance(line81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + location7 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location7.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(plane19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(subPlane25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + location41 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location41.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(plane53);
        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(subPlane59);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertNotNull(vector3D72);
        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D74);
        org.junit.Assert.assertTrue("'" + location75 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location75.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(vector3D80);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = orientedPoint9.getLocation();
        boolean boolean11 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint4.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList13 = intervalsSet12.asList();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector14 = intervalsSet12.getBarycenter();
        double double15 = intervalsSet12.getSup();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet12.applyTransform(euclidean1DTransform16);
        double double18 = euclidean1DAbstractRegion17.getBoundarySize();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree20 = euclidean1DAbstractRegion17.getTree(true);
        double double21 = euclidean1DAbstractRegion17.getSize();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intervalsSet12);
        org.junit.Assert.assertNotNull(intervalList13);
        org.junit.Assert.assertNotNull(euclidean1DVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 1079410688, 98.88936844130657d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07941056E9f + "'", float2 == 1.07941056E9f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = null;
        org.apache.commons.math3.geometry.euclidean.threed.Line line2 = null;
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane3 = polyhedronsSet0.firstIntersection(vector3D1, line2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.partitioning.Region.Location location5 = polyhedronsSet0.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        double double6 = polyhedronsSet0.getSize();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane11 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D8, vector3D9, vector3D10);
        org.apache.commons.math3.geometry.partitioning.Side side12 = polyhedronsSet7.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane16 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D13, vector3D14, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double21 = vector3D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D17.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane23 = plane16.translate(vector3D17);
        boolean boolean24 = plane11.isSimilarTo(plane23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = plane23.getU();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet26 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double31 = vector3D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D27.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.partitioning.Region.Location location33 = polyhedronsSet26.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D29.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane38 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D35, vector3D36, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        double double43 = vector3D41.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D39.add((double) (byte) 1, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane45 = plane38.translate(vector3D39);
        double double46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D29, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane50 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D47, vector3D48, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane51 = plane50.wholeHyperplane();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine54 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D52, vector2D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = plane50.getPointAt(vector2D53, (double) '#');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D56.scalarMultiply((double) (byte) -1);
        org.apache.commons.math3.geometry.euclidean.threed.Line line59 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D39, vector3D58);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane60 = polyhedronsSet0.firstIntersection(vector3D25, line59);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet61 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree63 = polyhedronsSet61.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet64 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree66 = polyhedronsSet64.getTree(false);
        euclidean3DBSPTree63.insertInTree(euclidean3DBSPTree66, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree69 = euclidean3DBSPTree63.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet70 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree72 = polyhedronsSet70.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet73 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree75 = polyhedronsSet73.getTree(false);
        euclidean3DBSPTree72.insertInTree(euclidean3DBSPTree75, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree78 = euclidean3DBSPTree72.getParent();
        euclidean3DBSPTree69.insertInTree(euclidean3DBSPTree72, true);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane84 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D81, vector3D82, vector3D83);
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane85 = plane84.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane86 = plane84.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D87 = plane84.getU();
        org.apache.commons.math3.geometry.euclidean.threed.SubPlane subPlane88 = plane84.wholeHyperplane();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree89 = euclidean3DBSPTree69.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane88);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DSubHyperplane90 = polyhedronsSet0.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) subPlane88);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector91 = polyhedronsSet0.getBarycenter();
        org.junit.Assert.assertNull(euclidean3DSubHyperplane3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + location5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location5.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + side12 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side12.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(plane23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + location33 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location33.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(plane45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(subPlane51);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNull(euclidean3DSubHyperplane60);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree63);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree66);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree69);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree72);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree75);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree78);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertNotNull(vector3D82);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertNotNull(plane85);
        org.junit.Assert.assertNotNull(plane86);
        org.junit.Assert.assertNotNull(vector3D87);
        org.junit.Assert.assertNotNull(subPlane88);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree89);
        org.junit.Assert.assertNotNull(euclidean3DSubHyperplane90);
        org.junit.Assert.assertNotNull(euclidean3DVector91);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(2.4674011002723395d, Double.POSITIVE_INFINITY, 0.9999877116507956d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple5 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray4);
        double[] doubleArray6 = orderedTuple5.getComponents();
        double[] doubleArray8 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple9 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray8);
        double[] doubleArray11 = new double[] { 10 };
        org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple orderedTuple12 = new org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple(doubleArray11);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray11, orderDirection13, true);
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection13, false);
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray6, orderDirection13, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException21 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 9223372036854775807L, (java.lang.Number) 2.6991118430775187d, 0, orderDirection13, true);
        int int22 = nonMonotonicSequenceException21.getIndex();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D1);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D1, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D7, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint15 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D12, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = orientedPoint15.getLocation();
        boolean boolean17 = orientedPoint10.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint15);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = orientedPoint10.wholeSpace();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList19 = intervalsSet18.asList();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint20 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane21 = subOrientedPoint20.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane22 = subOrientedPoint20.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint27 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D24, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint32 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D29, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = orientedPoint32.getLocation();
        boolean boolean34 = orientedPoint27.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint32);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet35 = orientedPoint27.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D37);
        org.apache.commons.math3.geometry.partitioning.Region.Location location39 = intervalsSet35.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint44 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D41, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint49 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D46, true);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = orientedPoint49.getLocation();
        boolean boolean51 = orientedPoint44.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint49);
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion52 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint53 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint44, euclidean1DRegion52);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane54 = intervalsSet35.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint53);
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane55 = euclidean1DAbstractSubHyperplane22.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(intervalsSet18);
        org.junit.Assert.assertNotNull(intervalList19);
        org.junit.Assert.assertNotNull(euclidean1DHyperplane21);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane22);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(intervalsSet35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertTrue("'" + location39 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location39.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane54);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet0 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NaN;
        org.apache.commons.math3.geometry.euclidean.threed.Plane plane4 = new org.apache.commons.math3.geometry.euclidean.threed.Plane(vector3D1, vector3D2, vector3D3);
        org.apache.commons.math3.geometry.partitioning.Side side5 = polyhedronsSet0.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) plane4);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D, org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean3DAbstractRegion6 = polyhedronsSet0.copySelf();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet7 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet8 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree10 = polyhedronsSet8.getTree(false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet11 = new org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DBSPTree13 = polyhedronsSet11.getTree(false);
        euclidean3DBSPTree10.insertInTree(euclidean3DBSPTree13, false);
        org.apache.commons.math3.geometry.euclidean.threed.PolyhedronsSet polyhedronsSet16 = polyhedronsSet7.buildNew(euclidean3DBSPTree13);
        double double17 = polyhedronsSet7.getSize();
        boolean boolean18 = euclidean3DAbstractRegion6.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) polyhedronsSet7);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + side5 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.BOTH + "'", side5.equals(org.apache.commons.math3.geometry.partitioning.Side.BOTH));
        org.junit.Assert.assertNotNull(euclidean3DAbstractRegion6);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree10);
        org.junit.Assert.assertNotNull(euclidean3DBSPTree13);
        org.junit.Assert.assertNotNull(polyhedronsSet16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = null;
        try {
            double double2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double5 = vector1D3.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double10 = vector1D8.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        double double11 = vector1D4.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint16 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D13, true);
        double double17 = vector1D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D21.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D22, vector1D24);
        double double26 = vector1D24.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double32 = vector1D30.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D31, vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D24.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double37 = vector1D35.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = vector1D13.add(4.9E-324d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double44 = vector1D42.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D43, vector1D45);
        double double47 = vector1D45.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double53 = vector1D51.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceSq(vector1D52, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D45.subtract((double) 52, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        double double58 = vector1D56.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D57);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D57.scalarMultiply(1.1102230246251565E-16d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 10L, vector1D38, (double) (-1L), vector1D57);
        double double62 = vector1D57.getNorm();
        double double63 = vector1D57.getNorm();
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
    }
}

