import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.7853981633974483d, (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        long[] longArray5 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray11 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray17 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[][] longArray18 = new long[][] { longArray5, longArray11, longArray17 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray18);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray18);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray18);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D2, (double) (byte) 10, vector2D7, (double) 0L, vector2D11, (double) 100, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line32 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D30, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D19, (double) (byte) 10, vector2D24, (double) 0L, vector2D28, (double) 100, vector2D30);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D11, vector2D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D36, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D39, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        java.lang.String str43 = vector3D42.toString();
        double double44 = vector3D35.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D50, vector3D51);
        double double53 = vector3D49.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(45.9826643981951d, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D35.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        boolean boolean56 = vector2D11.equals((java.lang.Object) vector3D35);
        double double57 = vector2D11.getNorm1();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{0; 0; 0}" + "'", str43.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-1.0d) + "'", double53 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
        notStrictlyPositiveException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 10);
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        double[] doubleArray19 = new double[] { 10L, (byte) 10, 1, ' ' };
        double[] doubleArray26 = new double[] { 1L, 100.0f, 100.0f, (-1), 1.0f, (short) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray19, doubleArray26);
        java.lang.Object[] objArray30 = new java.lang.Object[] { ' ', doubleArray19, 100.0f, 10L };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException12, localizable13, objArray30);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException6, localizable10, objArray30);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        boolean boolean34 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean35 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 231.0d + "'", double27 == 231.0d);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double8 = vector1D6.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double11 = vector1D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D3, (double) 10, vector1D9, (double) 0, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double26 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double29 = vector1D27.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = vector1D25.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double34 = vector1D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D21, (double) 10, vector1D27, (double) 0, vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1752011936438014d, vector1D3, (double) 'a', vector1D32, (double) 1L, vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = vector1D3.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double44 = vector1D42.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double48 = vector1D46.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = vector1D47.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double56 = vector1D54.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D43, (double) 10, vector1D49, (double) 0, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double62 = vector1D60.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double66 = vector1D64.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double69 = vector1D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = vector1D65.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double74 = vector1D72.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D61, (double) 10, vector1D67, (double) 0, vector1D72);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1752011936438014d, vector1D43, (double) 'a', vector1D72, (double) 1L, vector1D77);
        double double79 = vector1D3.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint81 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, true);
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint83 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D3, true);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList0 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet1 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList0);
        double double2 = intervalsSet1.getBoundarySize();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        double[] doubleArray3 = vector3D0.toArray();
        double[] doubleArray8 = new double[] { 10L, (byte) 10, 1, ' ' };
        double[] doubleArray15 = new double[] { 1L, 100.0f, 100.0f, (-1), 1.0f, (short) 10 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray15, (double) 10.0f);
        double double19 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D20, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D21.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D24, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D27, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D25.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D21.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D34, vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D37, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D35.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D38);
        java.lang.String str41 = vector3D40.toString();
        double double42 = vector3D33.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D21.subtract(2.2250738585072014E-307d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D33);
        double[] doubleArray44 = vector3D33.toArray();
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray44);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 231.0d + "'", double16 == 231.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.739336492890995d + "'", double19 == 4.739336492890995d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{0; 0; 0}" + "'", str41.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + Double.POSITIVE_INFINITY + "'", double42 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D8, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D4.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D16, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D21, vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D22.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = vector3D17.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        double double26 = vector3D9.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D28, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D29.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D33, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D37, vector3D38);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D40, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = vector3D38.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = vector3D34.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D47);
        double double49 = vector3D46.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D51, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = vector3D52.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D31, (double) (-1.0f), vector3D34, (double) 10L, vector3D46, (double) 1, vector3D54);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D9, vector3D31);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D56);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, false);
        orientedPoint2.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = orientedPoint2.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = orientedPoint2.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = orientedPoint2.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = orientedPoint2.wholeSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double19 = vector1D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double24 = vector1D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D11, (double) 10, vector1D17, (double) 0, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double30 = vector1D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double34 = vector1D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double37 = vector1D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = vector1D33.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double42 = vector1D40.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D29, (double) 10, vector1D35, (double) 0, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1752011936438014d, vector1D11, (double) 'a', vector1D40, (double) 1L, vector1D45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = vector1D11.getZero();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double49 = vector1D48.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D48.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        double double54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D47, vector1D53);
        org.apache.commons.math3.geometry.partitioning.Region.Location location55 = intervalsSet7.checkPoint((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.junit.Assert.assertNotNull(orientedPoint4);
        org.junit.Assert.assertNull(vector1D5);
        org.junit.Assert.assertNull(vector1D6);
        org.junit.Assert.assertNotNull(intervalsSet7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + location55 + "' != '" + org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE + "'", location55.equals(org.apache.commons.math3.geometry.partitioning.Region.Location.INSIDE));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) 0.0f);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane2 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList3 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList3);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint5 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet4);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane6 = subOrientedPoint5.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane7 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList8 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet9 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList8);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint10 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane7, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet9);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane11 = subOrientedPoint5.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint10);
        boolean boolean12 = euclidean1DAbstractSubHyperplane11.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree13 = euclidean1DBSPTree1.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane11);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane6);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree13);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double4 = vector1D2.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D3);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double8 = vector1D6.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double11 = vector1D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D7.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D3, (double) 10, vector1D9, (double) 0, vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        boolean boolean19 = vector1D3.equals((java.lang.Object) intervalsSet18);
        org.apache.commons.math3.geometry.Space space20 = vector1D3.getSpace();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double23 = vector1D21.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double26 = vector1D24.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D22.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        double double28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D3, vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1.0000001f, vector1D3);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(space20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D2.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D5);
        double double8 = vector3D7.getDelta();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D9, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D12, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D10.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.scalarMultiply((double) '4');
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D19, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = vector3D20.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D24, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D28, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D31, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D29.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D25.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D37, vector3D38);
        double double40 = vector3D37.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D42, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D43.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D22, (double) (-1.0f), vector3D25, (double) 10L, vector3D37, (double) 1, vector3D45);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D47, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D48.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D51, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D54, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D52.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D48.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D59 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D37, vector3D57);
        double double60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D17, vector3D57);
        double double61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D7, vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(2.2250738585072014E-307d, vector3D57);
        boolean boolean63 = vector3D57.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_J;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D57, vector3D64);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(1.5574077246549023d, 0.5d, 2.0d, 2.4024190860152324d, 231.0d, 200.00499987500626d, 0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 46206.7385131608d + "'", double8 == 46206.7385131608d);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double double2 = org.apache.commons.math3.util.FastMath.min(10.04987467217948d, (-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8414709848078965d) + "'", double2 == (-0.8414709848078965d));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray6 = new long[] { 3, (-1), (byte) 10, (-1L), '4' };
        long[] longArray12 = new long[] { 3, (-1), (byte) 10, (-1L), '4' };
        long[] longArray18 = new long[] { 3, (-1), (byte) 10, (-1L), '4' };
        long[][] longArray19 = new long[][] { longArray6, longArray12, longArray18 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) longArray19);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList1 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList1);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint3 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet2);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane4 = subOrientedPoint3.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane9 = subOrientedPoint3.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint8);
        boolean boolean10 = euclidean1DAbstractSubHyperplane9.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform12 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion13 = intervalsSet11.applyTransform(euclidean1DTransform12);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree15 = euclidean1DAbstractRegion13.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane16 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList17 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet18 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList17);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint19 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane16, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet18);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane20 = subOrientedPoint19.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane21 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList22 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet23 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList22);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane21, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet23);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane25 = subOrientedPoint19.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint24);
        boolean boolean26 = euclidean1DAbstractSubHyperplane25.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree27 = euclidean1DBSPTree15.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane25);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane28 = euclidean1DAbstractSubHyperplane25.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane29 = euclidean1DAbstractSubHyperplane9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane25);
        boolean boolean30 = euclidean1DAbstractSubHyperplane9.isEmpty();
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane4);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion13);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree15);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane20);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree27);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane28);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D1, vector3D2);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D2.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D6, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D11.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D7.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D19, vector3D20);
        double double22 = vector3D19.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D24, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D25.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D4, (double) (-1.0f), vector3D7, (double) 10L, vector3D19, (double) 1, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D29, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D30.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D33, vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D36, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D34.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = vector3D30.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D19, vector3D39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D42, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D43.negate();
        double double46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D19, vector3D43);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double49 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D47, vector3D48);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D48.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D51, vector3D52);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D54, vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = vector3D52.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D55);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D48.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D57);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double63 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D61, vector3D62);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D64, vector3D65);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = vector3D62.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D65);
        java.lang.String str68 = vector3D67.toString();
        double double69 = vector3D60.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = vector3D48.subtract(2.2250738585072014E-307d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D60);
        double double71 = vector3D70.getNormInf();
        double double72 = vector3D43.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D70);
        double[] doubleArray73 = vector3D43.toArray();
        double[] doubleArray74 = null;
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equals(doubleArray73, doubleArray74);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D54);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D57);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertNotNull(vector3D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{0; 0; 0}" + "'", str68.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + Double.POSITIVE_INFINITY + "'", double71 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + Double.POSITIVE_INFINITY + "'", double72 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray6 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray12 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray18 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[][] longArray19 = new long[][] { longArray6, longArray12, longArray18 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray19);
        org.apache.commons.math3.exception.MathInternalError mathInternalError21 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) longArray19);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 2.4024190860152324d, (double) 9.999999f, 3.984137914278307E171d, (double) (byte) 1, 8.536995818712418d, (double) 3, (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.9841375343213066E172d + "'", double8 == 3.9841375343213066E172d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 1, (float) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = euclidean1DAbstractRegion2.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane9 = subOrientedPoint8.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane10 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList11 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList11);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint13 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane10, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet12);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane14 = subOrientedPoint8.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint13);
        boolean boolean15 = euclidean1DAbstractSubHyperplane14.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = euclidean1DBSPTree4.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane14);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane17 = euclidean1DAbstractSubHyperplane14.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane18 = euclidean1DAbstractSubHyperplane14.copySelf();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree4);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane9);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree16);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane17);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane18);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double1 = vector1D0.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D0.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double10 = vector1D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double14 = vector1D12.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D13);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double17 = vector1D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D13.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D9, (double) 10, vector1D15, (double) 0, vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = vector1D0.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = vector1D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double30 = vector1D28.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D26.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        double double32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D31);
        double double33 = vector1D0.getNormInf();
        java.lang.String str34 = vector1D0.toString();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{0}" + "'", str34.equals("{0}"));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D3);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line16 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D14, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D3, (double) (byte) 10, vector2D8, (double) 0L, vector2D12, (double) 100, vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(231.0d, vector2D17);
        double double19 = vector2D18.getNormInf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D26);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D33, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D22, (double) (byte) 10, vector2D27, (double) 0L, vector2D31, (double) 100, vector2D33);
        double double37 = vector2D22.getNorm1();
        double double38 = vector2D22.getX();
        double double39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D18, vector2D22);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector3 = euclidean1DAbstractRegion2.getBarycenter();
        double double4 = euclidean1DAbstractRegion2.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane5 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList6 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet7 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList6);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane5, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet7);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree10 = intervalsSet7.getTree(true);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree10);
        boolean boolean12 = euclidean1DAbstractRegion2.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet11);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DVector3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D5.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D1.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D14, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D17, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D15.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        java.lang.String str21 = vector3D20.toString();
        double double22 = vector3D13.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D1.subtract(2.2250738585072014E-307d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D13);
        double[] doubleArray24 = vector3D13.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D25, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D28, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = vector3D26.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D29);
        double double32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D13, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D34, vector3D35);
        double[] doubleArray37 = vector3D34.toArray();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D39, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D40.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double45 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D43, vector3D44);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D44.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = vector3D40.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double54 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D52, vector3D53);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D56 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double57 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D55, vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D58 = vector3D53.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D56);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D60 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D61 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double62 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D60, vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D63 = vector3D61.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = vector3D56.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D61);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = vector3D61.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D66 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D67 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double68 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D66, vector3D67);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D69 = vector3D67.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D70 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D71 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double72 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D70, vector3D71);
        double double73 = vector3D69.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D71);
        double double74 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D65, vector3D71);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D76 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D77 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D78 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double79 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D77, vector3D78);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D80 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D81 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double82 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D80, vector3D81);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D83 = vector3D78.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D81);
        java.lang.String str84 = vector3D83.toString();
        double double85 = vector3D76.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D83);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D86 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, vector3D50, (double) 10.0f, vector3D71, 45.9826643981951d, vector3D83);
        double double87 = vector3D34.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D86);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D88 = vector3D13.add((-6.053272382792838d), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D34);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D> euclidean3DVector89 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D90 = vector3D88.crossProduct(euclidean3DVector89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0; 0; 0}" + "'", str21.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertNotNull(vector3D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D52);
        org.junit.Assert.assertNotNull(vector3D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertNotNull(vector3D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D58);
        org.junit.Assert.assertNotNull(vector3D60);
        org.junit.Assert.assertNotNull(vector3D61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D63);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
        org.junit.Assert.assertNotNull(vector3D66);
        org.junit.Assert.assertNotNull(vector3D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D69);
        org.junit.Assert.assertNotNull(vector3D70);
        org.junit.Assert.assertNotNull(vector3D71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + (-1.0d) + "'", double73 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.0d + "'", double74 == 2.0d);
        org.junit.Assert.assertNotNull(vector3D76);
        org.junit.Assert.assertNotNull(vector3D77);
        org.junit.Assert.assertNotNull(vector3D78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D80);
        org.junit.Assert.assertNotNull(vector3D81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "{0; 0; 0}" + "'", str84.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 109.0d + "'", double87 == 109.0d);
        org.junit.Assert.assertNotNull(vector3D88);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = euclidean1DAbstractRegion2.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = euclidean1DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane6 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList7 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList7);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet8);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane10 = subOrientedPoint9.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane11 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList12);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet13);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane15 = subOrientedPoint9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = euclidean1DBSPTree5.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint9);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane17 = subOrientedPoint9.copySelf();
        boolean boolean18 = subOrientedPoint9.isEmpty();
        boolean boolean19 = subOrientedPoint9.isEmpty();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree4);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane15);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree16);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D2, (double) (byte) 10, vector2D7, (double) 0L, vector2D11, (double) 100, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D27);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line32 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D30, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D19, (double) (byte) 10, vector2D24, (double) 0L, vector2D28, (double) 100, vector2D30);
        double double34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distance(vector2D11, vector2D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D36, vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D39, vector3D40);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = vector3D37.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D40);
        java.lang.String str43 = vector3D42.toString();
        double double44 = vector3D35.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D42);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D47 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D46, vector3D47);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D49 = vector3D47.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D51 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double52 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D50, vector3D51);
        double double53 = vector3D49.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D51);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D54 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(45.9826643981951d, vector3D49);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D55 = vector3D35.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D49);
        boolean boolean56 = vector2D11.equals((java.lang.Object) vector3D35);
        double double57 = vector3D35.getNormSq();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{0; 0; 0}" + "'", str43.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + Double.POSITIVE_INFINITY + "'", double44 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertNotNull(vector3D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D49);
        org.junit.Assert.assertNotNull(vector3D50);
        org.junit.Assert.assertNotNull(vector3D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-1.0d) + "'", double53 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + Double.POSITIVE_INFINITY + "'", double57 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (-1023), (-1));
        int int4 = dimensionMismatchException3.getDimension();
        int int5 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = euclidean1DAbstractRegion2.getTree(false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = euclidean1DBSPTree4.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane6 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList7 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet8 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList7);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint9 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane6, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet8);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane10 = subOrientedPoint9.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane11 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList12 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet13 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList12);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint14 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane11, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet13);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane15 = subOrientedPoint9.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint14);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree16 = euclidean1DBSPTree5.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint9);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane17 = subOrientedPoint9.copySelf();
        boolean boolean18 = subOrientedPoint9.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint21 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D19, false);
        orientedPoint21.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint23 = orientedPoint21.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = orientedPoint21.getLocation();
        boolean boolean25 = orientedPoint21.isDirect();
        try {
            org.apache.commons.math3.geometry.partitioning.SubHyperplane.SplitSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSplitSubHyperplane26 = subOrientedPoint9.split((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree4);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane10);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane15);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree16);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(orientedPoint23);
        org.junit.Assert.assertNull(vector1D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D10, vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D8.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        double double14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D6, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D13.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D16, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Line line20 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D15, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = line20.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = null;
        try {
            double double23 = line20.distance(line22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D21);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        double double3 = vector3D0.getNormSq();
        double[] doubleArray4 = vector3D0.toArray();
        double double5 = vector3D0.getX();
        boolean boolean6 = vector3D0.isInfinite();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        long[] longArray6 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray12 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray18 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[][] longArray19 = new long[][] { longArray6, longArray12, longArray18 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray19);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) longArray19);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform4 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion5 = intervalsSet3.applyTransform(euclidean1DTransform4);
        boolean boolean6 = intervalsSet0.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet3);
        double double7 = intervalsSet3.getSup();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector8 = intervalsSet3.getBarycenter();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DVector8);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, false);
        orientedPoint2.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = orientedPoint2.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, false);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = orientedPoint7.copySelf();
        boolean boolean10 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = orientedPoint9.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet12 = orientedPoint9.wholeSpace();
        org.junit.Assert.assertNotNull(orientedPoint4);
        org.junit.Assert.assertNotNull(orientedPoint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(vector1D11);
        org.junit.Assert.assertNotNull(intervalsSet12);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 128, (java.lang.Number) 1.0000001f, (int) '4', orderDirection3, false);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line2 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D16, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D5, (double) (byte) 10, vector2D10, (double) 0L, vector2D14, (double) 100, vector2D16);
        line2.translateToPoint(vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line2);
        double double22 = line21.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Line line23 = line21.copySelf();
        line21.setAngle(2.7182818284d);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.1752011936438014d + "'", double22 == 1.1752011936438014d);
        org.junit.Assert.assertNotNull(line23);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.822482662536952d) + "'", double1 == (-1.822482662536952d));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line2 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D16, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D5, (double) (byte) 10, vector2D10, (double) 0L, vector2D14, (double) 100, vector2D16);
        line2.translateToPoint(vector2D14);
        double double21 = line2.getAngle();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform23 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion24 = intervalsSet22.applyTransform(euclidean1DTransform23);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet25 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform26 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion27 = intervalsSet25.applyTransform(euclidean1DTransform26);
        boolean boolean28 = intervalsSet22.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine29 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet25);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane30 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList31 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet32 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList31);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint33 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane30, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet32);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector34 = intervalsSet32.getBarycenter();
        java.util.List<org.apache.commons.math3.geometry.euclidean.oned.Interval> intervalList35 = intervalsSet32.asList();
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine36 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line2, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet32);
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DTransform37 = null;
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane38 = subLine36.applyTransform(euclidean2DTransform37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.1752011936438014d + "'", double21 == 1.1752011936438014d);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion24);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(euclidean1DVector34);
        org.junit.Assert.assertNotNull(intervalList35);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = euclidean1DAbstractRegion2.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double21 = vector1D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D8, (double) 10, vector1D14, (double) 0, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = vector1D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double31 = vector1D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double34 = vector1D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D26, (double) 10, vector1D32, (double) 0, vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1752011936438014d, vector1D8, (double) 'a', vector1D37, (double) 1L, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D45.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double54 = vector1D52.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D50.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double59 = vector1D57.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D46, (double) 10, vector1D52, (double) 0, vector1D57);
        double double61 = vector1D42.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree62 = euclidean1DBSPTree4.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree63 = euclidean1DBSPTree62.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double65 = vector1D64.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = vector1D64.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D68);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree70 = euclidean1DBSPTree62.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree4);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree62);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree63);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree70);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D2, vector3D3);
        double[] doubleArray5 = vector3D2.toArray();
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.0d, doubleArray5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.scale((double) (-1.0f), doubleArray5);
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        boolean boolean1 = vector1D0.isNaN();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double3 = vector1D2.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) 1);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D2.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double12 = vector1D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double19 = vector1D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D15.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double24 = vector1D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D23);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D11, (double) 10, vector1D17, (double) 0, vector1D22);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = vector1D2.add(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D25);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double29 = vector1D27.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double32 = vector1D30.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = vector1D28.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        double double34 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D2, vector1D33);
        double double35 = vector1D2.getNormInf();
        double double36 = vector1D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D2);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 52.0f);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D2.subtract(0.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D40);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D3, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D1.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D8, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D4.add((double) 10.0f, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D9.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D14, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D18, vector3D19);
        double double21 = vector3D17.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        double double22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance1(vector3D13, vector3D19);
        boolean boolean23 = vector3D19.isInfinite();
        org.apache.commons.math3.geometry.Space space24 = vector3D19.getSpace();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(space24);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) 0.0f);
        euclidean1DBSPTree1.setAttribute((java.lang.Object) 5.298292365610485d);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList5 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList5);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet6);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane8 = subOrientedPoint7.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane9 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList10 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet11 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList10);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane9, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet11);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane13 = subOrientedPoint7.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint12);
        boolean boolean14 = euclidean1DAbstractSubHyperplane13.isEmpty();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet15 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform16 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion17 = intervalsSet15.applyTransform(euclidean1DTransform16);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree19 = euclidean1DAbstractRegion17.getTree(false);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane20 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList21 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet22 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList21);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint23 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane20, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet22);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane24 = subOrientedPoint23.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane25 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList26 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet27 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList26);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint28 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane25, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet27);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane29 = subOrientedPoint23.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint28);
        boolean boolean30 = euclidean1DAbstractSubHyperplane29.isEmpty();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree31 = euclidean1DBSPTree19.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane29);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane32 = euclidean1DAbstractSubHyperplane29.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane33 = euclidean1DAbstractSubHyperplane13.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane29);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane34 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList35 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet36 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList35);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint37 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane34, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet36);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane38 = subOrientedPoint37.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane39 = null;
        java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>> euclidean1DSubHyperplaneList40 = new java.util.ArrayList<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet41 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet((java.util.Collection<org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>>) euclidean1DSubHyperplaneList40);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint42 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane39, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet41);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane43 = subOrientedPoint37.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint42);
        double double44 = subOrientedPoint37.getSize();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane45 = euclidean1DAbstractSubHyperplane29.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) subOrientedPoint37);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree46 = euclidean1DBSPTree1.split((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane8);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion17);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree19);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane24);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree31);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane32);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane33);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane38);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane45);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree46);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D7, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D5.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D1.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D11.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D15, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D18, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = vector3D16.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        java.lang.String str22 = vector3D21.toString();
        double double23 = vector3D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D25, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D26.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D29, vector3D30);
        double double32 = vector3D28.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(45.9826643981951d, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D14.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D12.subtract((double) 10, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        java.text.NumberFormat numberFormat36 = null;
        java.lang.String str37 = vector3D35.toString(numberFormat36);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{0; 0; 0}" + "'", str22.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{(-Infinity); (-Infinity); (-Infinity)}" + "'", str37.equals("{(-Infinity); (-Infinity); (-Infinity)}"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line2 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line18 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D16, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D5, (double) (byte) 10, vector2D10, (double) 0L, vector2D14, (double) 100, vector2D16);
        line2.translateToPoint(vector2D14);
        org.apache.commons.math3.geometry.euclidean.twod.Line line21 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line2);
        double double22 = line21.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line25 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D23, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = line21.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line27 = line21.getReverse();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line43 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D41, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D30, (double) (byte) 10, vector2D35, (double) 0L, vector2D39, (double) 100, vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        boolean boolean46 = vector2D45.isNaN();
        org.apache.commons.math3.geometry.euclidean.twod.Line line47 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D39, vector2D45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = line27.toSubSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = vector1D48.getZero();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.1752011936438014d + "'", double22 == 1.1752011936438014d);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(line27);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D49);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(3.0f, 1.0000001f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D2, (double) (byte) 10, vector2D7, (double) 0L, vector2D11, (double) 100, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D20, (double) (byte) 10, vector2D25, (double) 0L, vector2D29, (double) 100, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D11.subtract(141.78504857706258d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line51 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D49, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D38, (double) (byte) 10, vector2D43, (double) 0L, vector2D47, (double) 100, vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D64);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line69 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D67, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D56, (double) (byte) 10, vector2D61, (double) 0L, vector2D65, (double) 100, vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = vector2D47.subtract(141.78504857706258d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = vector2D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        double double73 = vector2D20.getNormSq();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line76 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D74, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D79);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D83 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D84 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D83);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D87);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line92 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D90, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D93 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D79, (double) (byte) 10, vector2D84, (double) 0L, vector2D88, (double) 100, vector2D90);
        line76.translateToPoint(vector2D88);
        org.apache.commons.math3.geometry.euclidean.twod.Line line95 = new org.apache.commons.math3.geometry.euclidean.twod.Line(line76);
        double double96 = line95.getAngle();
        org.apache.commons.math3.geometry.euclidean.twod.Line line97 = line95.copySelf();
        boolean boolean98 = vector2D20.equals((java.lang.Object) line97);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D83);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertNotNull(vector2D90);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 1.1752011936438014d + "'", double96 == 1.1752011936438014d);
        org.junit.Assert.assertNotNull(line97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D0, false);
        orientedPoint2.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = orientedPoint2.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, false);
        orientedPoint7.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint9 = orientedPoint7.copySelf();
        boolean boolean10 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint9);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint11 = orientedPoint9.wholeHyperplane();
        org.junit.Assert.assertNotNull(orientedPoint4);
        org.junit.Assert.assertNotNull(orientedPoint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(subOrientedPoint11);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 0L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D2, (double) (byte) 10, vector2D7, (double) 0L, vector2D11, (double) 100, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D20, (double) (byte) 10, vector2D25, (double) 0L, vector2D29, (double) 100, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D11.subtract(141.78504857706258d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double36 = vector2D20.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D39);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D43);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D47);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line52 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D50, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D39, (double) (byte) 10, vector2D44, (double) 0L, vector2D48, (double) 100, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D61);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line70 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D68, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D57, (double) (byte) 10, vector2D62, (double) 0L, vector2D66, (double) 100, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = vector2D48.subtract(141.78504857706258d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line73 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D20, vector2D48);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D72);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform1 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion2 = intervalsSet0.applyTransform(euclidean1DTransform1);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree4 = euclidean1DAbstractRegion2.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double9 = vector1D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D8);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double16 = vector1D14.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D12.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double21 = vector1D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D8, (double) 10, vector1D14, (double) 0, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double27 = vector1D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double31 = vector1D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D33 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double34 = vector1D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D33);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D30.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double39 = vector1D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D26, (double) 10, vector1D32, (double) 0, vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(1.1752011936438014d, vector1D8, (double) 'a', vector1D37, (double) 1L, vector1D42);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double47 = vector1D45.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double51 = vector1D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double54 = vector1D52.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D50.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double59 = vector1D57.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D46, (double) 10, vector1D52, (double) 0, vector1D57);
        double double61 = vector1D42.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree62 = euclidean1DBSPTree4.getCell((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree63 = euclidean1DBSPTree62.copySelf();
        java.lang.Object obj64 = euclidean1DBSPTree62.getAttribute();
        java.lang.Object obj65 = euclidean1DBSPTree62.getAttribute();
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree4);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree62);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree63);
        org.junit.Assert.assertTrue("'" + obj64 + "' != '" + true + "'", obj64.equals(true));
        org.junit.Assert.assertTrue("'" + obj65 + "' != '" + true + "'", obj65.equals(true));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        long[] longArray5 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray11 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[] longArray17 = new long[] { '#', 1L, (short) -1, (byte) 100, 'a' };
        long[][] longArray18 = new long[][] { longArray5, longArray11, longArray17 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray18);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray18);
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double6 = vector1D4.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double10 = vector1D8.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D9);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double13 = vector1D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = vector1D9.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D11);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double18 = vector1D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (-1), vector1D5, (double) 10, vector1D11, (double) 0, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double22 = vector1D20.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        double double23 = vector1D5.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(141.78504857706258d, vector1D1, 0.5820867577167843d, vector1D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D14);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        long long2 = org.apache.commons.math3.util.FastMath.min(128L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>((java.lang.Object) 0.0f);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = euclidean1DBSPTree1.copySelf();
        org.junit.Assert.assertNotNull(euclidean1DBSPTree2);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (short) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D0, vector3D1);
        double double3 = vector3D0.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D8, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D11, vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D9.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D5.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D17, vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D20, vector3D21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D18.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D21);
        java.lang.String str24 = vector3D23.toString();
        double double25 = vector3D16.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        double double26 = vector3D14.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Line line27 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D28, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double33 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D31, vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = vector3D29.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D32);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D34.scalarMultiply((double) '4');
        double double37 = line27.getAbscissa(vector3D34);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine38 = line27.wholeLine();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0; 0; 0}" + "'", str24.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(subLine38);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D4, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D5.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D9, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D10.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D13, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D16, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D14.crossProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D10.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double24 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D22, vector3D23);
        double double25 = vector3D22.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D27, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D28.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D7, (double) (-1.0f), vector3D10, (double) 10L, vector3D22, (double) 1, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = vector3D10.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) (byte) 0, vector3D1, 0.0d, vector3D10);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D10);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line15 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D13, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D2, (double) (byte) 10, vector2D7, (double) 0L, vector2D11, (double) 100, vector2D13);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D24);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line33 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D31, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D20, (double) (byte) 10, vector2D25, (double) 0L, vector2D29, (double) 100, vector2D31);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = vector2D11.subtract(141.78504857706258d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double36 = vector2D20.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line39 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D37, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D42);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D46);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 3, vector2D50);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Line line55 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D53, 1.1752011936438014d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((-1.5707963267948966d), vector2D42, (double) (byte) 10, vector2D47, (double) 0L, vector2D51, (double) 100, vector2D53);
        line39.translateToPoint(vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = vector2D20.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.Space space59 = vector2D51.getSpace();
        double double60 = vector2D51.getNormInf();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(space59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }
}

