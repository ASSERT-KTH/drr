import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        double double1 = org.apache.commons.math.special.Erf.erf(0.005415418498470302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.006110585680164324d + "'", double1 == 0.006110585680164324d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        double double1 = org.apache.commons.math.special.Gamma.digamma(4.600161852571429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4134798960816806d + "'", double1 == 1.4134798960816806d);
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test03");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        int int14 = randomDataImpl1.nextInt((-1), (int) (byte) 0);
//        try {
//            double double17 = randomDataImpl1.nextF(10.0d, (-4.440892098500626E-16d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0 is smaller than, or equal to, the minimum (0): degrees of freedom (-0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0514d5d2d4" + "'", str3.equals("0514d5d2d4"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0036458577161680955d + "'", double6 == 0.0036458577161680955d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9359b045084bccf2849207ad079abe972c64fd167c5dffc58d70d3ac386dc3d344e636280d4da5d408fbb157e090f9c22178" + "'", str11.equals("9359b045084bccf2849207ad079abe972c64fd167c5dffc58d70d3ac386dc3d344e636280d4da5d408fbb157e090f9c22178"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(16.681468293841263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5551207260043634d + "'", double1 == 2.5551207260043634d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9943084731581333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10674206259953686d + "'", double1 == 0.10674206259953686d);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        double double12 = randomDataImpl1.nextGaussian(0.6470434810831891d, 4.158638853279167d);
//        int[] intArray15 = randomDataImpl1.nextPermutation(36, 10);
//        long long17 = randomDataImpl1.nextPoisson(30.192931321154465d);
//        randomDataImpl1.reSeed();
//        try {
//            long long21 = randomDataImpl1.nextSecureLong(65L, (long) 17);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 65 is larger than, or equal to, the maximum (17): lower bound (65) must be strictly less than upper bound (17)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "099137d1b3" + "'", str3.equals("099137d1b3"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.625874489747926E-5d + "'", double6 == 6.625874489747926E-5d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.576893169822184d + "'", double12 == 3.576893169822184d);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 26L + "'", long17 == 26L);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-38.410952501900226d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
        randomDataImpl1.reSeedSecure(100L);
        randomDataImpl1.reSeed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.773691189871375d, (double) 52.0f);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.9999999999999327d);
        double double6 = normalDistributionImpl2.density((double) 54L);
        double double8 = normalDistributionImpl2.cumulativeProbability((-2.5759913295192365d));
        double double9 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 386.6536880723989d + "'", double4 == 386.6536880723989d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.00463303177278039d + "'", double6 == 0.00463303177278039d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.4666682541391603d + "'", double8 == 0.4666682541391603d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.773691189871375d + "'", double9 == 1.773691189871375d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) convergenceException8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5.421010862427522E-20d, (java.lang.Number) 1.000000082240371E-9d, false);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(number6, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number10 = numberIsTooLargeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException16, "hi!", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable31, objArray32);
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray42);
        java.lang.Object[] objArray45 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException9, localizable31, objArray45);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (-1.0f), (java.lang.Number) 31.887903591703434d, false);
        java.lang.Object[] objArray57 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("", objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable31, objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(5, "118fb6d83ba3d07086c21079786b3b1c57b", objArray57);
        org.apache.commons.math.exception.util.Localizable localizable61 = maxIterationsExceededException60.getSpecificPattern();
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNull(localizable61);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray25 = numberIsTooLargeException24.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray25);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException30, "hi!", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray58);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException48, "hi!", objArray58);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43, localizable44, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException43);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray70 = numberIsTooLargeException69.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray70);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43, "fd838e104c", objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(localizable20, objArray70);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray70);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        double double16 = randomDataImpl1.nextCauchy(0.7539022543433046d, 8.343266443619277E-4d);
//        double double19 = randomDataImpl1.nextBeta((double) 20.0f, (double) 62L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2975da280d" + "'", str3.equals("2975da280d"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.004205714142702122d + "'", double6 == 0.004205714142702122d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.7532281264523758d + "'", double16 == 0.7532281264523758d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.24908777765877213d + "'", double19 == 0.24908777765877213d);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.8332895743202293d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3664942529198356d + "'", double1 == 1.3664942529198356d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 41.0f, (java.lang.Number) 7.93449583848838E-5d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 41.0f + "'", number4.equals(41.0f));
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test16");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        try {
//            double double7 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "64e0652c55" + "'", str3.equals("64e0652c55"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8b27bc00b587c9a0c0464c23c2e28329c73" + "'", str5.equals("8b27bc00b587c9a0c0464c23c2e28329c73"));
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test17");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeed();
//        double double10 = randomDataImpl1.nextChiSquare(0.46910687614821883d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.28320065858155746d + "'", double10 == 0.28320065858155746d);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(63520.31010288529d, 0.0d, 0.10674206259953686d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test19");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double10 = randomDataImpl1.nextT(205.16819948264123d);
//        randomDataImpl1.reSeed(34L);
//        double double15 = randomDataImpl1.nextGaussian((-0.3684134059513968d), 0.44256975423046224d);
//        double double17 = randomDataImpl1.nextT(1.5539007412633712d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 83L + "'", long8 == 83L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.008174731752161005d) + "'", double10 == (-0.008174731752161005d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.1578595126318345d + "'", double15 == 0.1578595126318345d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8470297744059464d + "'", double17 == 0.8470297744059464d);
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) (byte) 10);
        java.lang.Number number21 = notStrictlyPositiveException20.getMin();
        java.lang.Number number22 = notStrictlyPositiveException20.getMin();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0 + "'", number22.equals(0));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
        double double4 = normalDistributionImpl2.density((-0.6695702094400313d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, number20, (java.lang.Number) 7L, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 32);
        java.lang.Class<?> wildcardClass26 = notStrictlyPositiveException25.getClass();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.008363317100349871d, (java.lang.Number) 0.7278624522467747d, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray18);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException8, "hi!", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException26, "hi!", objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21, localizable22, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = mathException40.getSpecificPattern();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathException40);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertNull(localizable42);
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test24");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
//        double double11 = normalDistributionImpl10.sample();
//        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        long long15 = randomDataImpl1.nextSecureLong((long) (short) -1, 27L);
//        int int18 = randomDataImpl1.nextBinomial(20, 0.0d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1b8e591a15" + "'", str3.equals("1b8e591a15"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0024294110635075246d + "'", double6 == 0.0024294110635075246d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 33.6923643615397d + "'", double11 == 33.6923643615397d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.184205337077884d + "'", double12 == 32.184205337077884d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 18L + "'", long15 == 18L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1,537,001,168,096,474.8 is larger than, or equal to, the maximum (50)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1,537,001,168,096,474.8 is larger than, or equal to, the maximum (50)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.754166282558079d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.86842747685577d + "'", double1 == 0.86842747685577d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray6 = numberIsTooLargeException5.getArguments();
        java.lang.Throwable throwable9 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14);
        java.lang.Throwable[] throwableArray16 = outOfRangeException14.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable9, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (32) exceeded", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "015b695622", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, "hi!", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException40, "hi!", objArray50);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, localizable36, objArray50);
        java.lang.Object[] objArray55 = new java.lang.Object[] { objArray6, maxIterationsExceededException18, mathException35 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException(52, "0f998412e01df876a4b5169e3609c7b", objArray55);
        int int57 = maxIterationsExceededException56.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 52 + "'", int57 == 52);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(5.631679556835387E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3153002.7934442116d + "'", double1 == 3153002.7934442116d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable19);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 4.7581537309045485d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 18L, (float) 92L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(8.465716632595732E-61d, (double) 17, 1.7105767271703536d, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 17 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.0276542587345318E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.695987050078124d + "'", double1 == 20.695987050078124d);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        double double1 = org.apache.commons.math.util.FastMath.cos(30.01678921323695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17081720469979234d + "'", double1 == 0.17081720469979234d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(32.8212332640116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2017319161229d + "'", double1 == 3.2017319161229d);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.513878063373301E-4d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1, (java.lang.Number) Double.NaN);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertNull(localizable6);
    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test40");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double8 = randomDataImpl1.nextCauchy((-48.21273601220948d), (double) (short) 100);
//        int int11 = randomDataImpl1.nextBinomial(2, 1.7935950387059276E-11d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fe033e0c5c" + "'", str3.equals("fe033e0c5c"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c40976220f0e7b4a6b5a4fb95d36717371a" + "'", str5.equals("c40976220f0e7b4a6b5a4fb95d36717371a"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-8.515361613836276d) + "'", double8 == (-8.515361613836276d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        int int2 = org.apache.commons.math.util.FastMath.max(71, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.29133340463048707d, 399.1324859400626d, 0.0d);
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        outOfRangeException4.addSuppressed((java.lang.Throwable) convergenceException12);
        java.lang.Number number14 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (byte) 0 + "'", number14.equals((byte) 0));
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.199329338564076E-7d, 1.2960550997063713E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.199329338564077E-7d + "'", double2 == 3.199329338564077E-7d);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 95L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.246996370178386d + "'", double1 == 5.246996370178386d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 58);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58 + "'", int1 == 58);
    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test48");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextCauchy((double) (byte) 0, (double) (byte) 100);
//        try {
//            double double9 = randomDataImpl1.nextWeibull((-3.9964692763675984d), 2.770916827395189d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.996 is smaller than, or equal to, the minimum (0): shape (-3.996)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6cf4300b1a" + "'", str3.equals("6cf4300b1a"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-25.900161166618744d) + "'", double6 == (-25.900161166618744d));
//    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 2, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test50");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextChiSquare(31.887903591703434d);
//        double double11 = randomDataImpl1.nextUniform((-0.017453292519943292d), (double) 52.0f);
//        double double14 = randomDataImpl1.nextWeibull(0.606111934732855d, 0.0018452162759392634d);
//        int int17 = randomDataImpl1.nextBinomial((int) (short) 1, 0.0d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3a8b050af8" + "'", str3.equals("3a8b050af8"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "81be3e3380aaf3a5e56005a75d23bd4fde3" + "'", str5.equals("81be3e3380aaf3a5e56005a75d23bd4fde3"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 20.805660365700618d + "'", double8 == 20.805660365700618d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 27.557050078943995d + "'", double11 == 27.557050078943995d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.815709100991843E-6d + "'", double14 == 5.815709100991843E-6d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextChiSquare(31.887903591703434d);
//        double double11 = randomDataImpl1.nextUniform((-0.017453292519943292d), (double) 52.0f);
//        double double14 = randomDataImpl1.nextWeibull(0.606111934732855d, 0.0018452162759392634d);
//        java.lang.String str16 = randomDataImpl1.nextHexString((int) '4');
//        int int19 = randomDataImpl1.nextSecureInt(7, (int) ' ');
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2fbc570a38" + "'", str3.equals("2fbc570a38"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a24363d968e2e1192aedbbb16bb1703bf59" + "'", str5.equals("a24363d968e2e1192aedbbb16bb1703bf59"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.36060677069511d + "'", double8 == 35.36060677069511d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 28.380804553288975d + "'", double11 == 28.380804553288975d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.9369587700952292E-5d + "'", double14 == 2.9369587700952292E-5d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4a930b85aff0f34a24efc42f684bf2cf65d03ac706ec07d016de" + "'", str16.equals("4a930b85aff0f34a24efc42f684bf2cf65d03ac706ec07d016de"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 22 + "'", int19 == 22);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException21);
        java.lang.Throwable[] throwableArray23 = outOfRangeException21.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "hi!", (java.lang.Object[]) throwableArray23);
        java.lang.Number number25 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray26 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (short) -1 + "'", number25.equals((short) -1));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.008174731752161005d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }
}

