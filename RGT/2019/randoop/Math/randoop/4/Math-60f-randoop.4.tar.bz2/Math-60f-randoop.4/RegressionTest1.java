import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.452083264627525d + "'", double3 == 32.452083264627525d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.20190983713248d + "'", double4 == 32.20190983713248d);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 10, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(number30, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number34 = numberIsTooLargeException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException40, "hi!", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable55, objArray56);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray66);
        java.lang.Object[] objArray69 = maxIterationsExceededException68.getArguments();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException33, localizable55, objArray69);
        java.lang.Throwable[] throwableArray71 = mathException70.getSuppressed();
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(throwable5, localizable25, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable74, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("hi!", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, localizable25, objArray77);
        java.lang.Class<?> wildcardClass81 = convergenceException80.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(wildcardClass81);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double8 = randomDataImpl1.nextCauchy((-48.21273601220948d), (double) (short) 100);
//        randomDataImpl1.reSeedSecure((long) 10);
//        long long13 = randomDataImpl1.nextSecureLong((long) (byte) 1, (long) 47);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d8d1a947b4" + "'", str3.equals("d8d1a947b4"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "53c98040b32be21f4cfd579a64f94ed969c" + "'", str5.equals("53c98040b32be21f4cfd579a64f94ed969c"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 75.38981143754893d + "'", double8 == 75.38981143754893d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 39L + "'", long13 == 39L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.731159635128785E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.731159635128786E-4d + "'", double1 == 7.731159635128786E-4d);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        try {
//            double double12 = randomDataImpl1.nextGamma((-4.440892098500626E-16d), (-85.51912676833847d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ae6f4434d3" + "'", str3.equals("ae6f4434d3"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.01033413315580572d + "'", double6 == 0.01033413315580572d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 46 + "'", int9 == 46);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 20.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(61.10581557694123d, (double) 32);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.abs(31.887903591703434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.887903591703434d + "'", double1 == 31.887903591703434d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = org.apache.commons.math.util.FastMath.abs(28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '4');
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray6);
        java.lang.Throwable[] throwableArray8 = maxIterationsExceededException7.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("07fed30fbb18f696a01badcd81556aca", (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "078245433591c4262de8a5eee3b457f4cb9977a8767bc443d144ea52d3b17158e28c3aa80c57d4bcd4d43c93d30e94256c26", (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 31);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.MathException: ", "0080e400647a9996c7656373dce0d47be14");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0080e400647a9996c7656373dce0d47be14");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9e732232ef" + "'", str3.equals("9e732232ef"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0047871521297659595d + "'", double6 == 0.0047871521297659595d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 48 + "'", int9 == 48);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(number2, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, "hi!", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable27, objArray28);
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray38);
        java.lang.Object[] objArray41 = maxIterationsExceededException40.getArguments();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, localizable27, objArray41);
        boolean boolean43 = numberIsTooLargeException5.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("hi!", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable51 = convergenceException50.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException56, "hi!", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException("", objArray84);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException86 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray84);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException74, "hi!", objArray84);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException69, localizable70, objArray84);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("", objArray84);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, localizable51, objArray84);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(52, "3e0333205c", objArray84);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray84);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 27L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 27.0f + "'", float2 == 27.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0034349072766937565d, 71.9106325463476d);
        normalDistributionImpl2.reseedRandomGenerator(16L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8860927126647652d, (-9.242343461887508E9d), (-0.3666540377767577d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -9,242,343,461.888 is smaller than, or equal to, the minimum (0): standard deviation (-9,242,343,461.888)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.587 is larger than, or equal to, the maximum (-1)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.587 is larger than, or equal to, the maximum (-1)"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
        randomDataImpl1.reSeedSecure(100L);
        long long8 = randomDataImpl1.nextPoisson(1.0E-323d);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
        try {
            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        double double9 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 2147483647);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) (byte) 1);
//        try {
//            int[] intArray14 = randomDataImpl0.nextPermutation(52, 2147483647);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than the maximum (52): permutation size (2,147,483,647) exceeds permuation domain (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-39.383768067680286d) + "'", double6 == (-39.383768067680286d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-3.008536949747936E9d) + "'", double9 == (-3.008536949747936E9d));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "f" + "'", str11.equals("f"));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure();
        try {
            long long4 = randomDataImpl1.nextPoisson((-1.2320429179887327d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.232 is smaller than, or equal to, the minimum (0): mean (-1.232)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        outOfRangeException4.addSuppressed((java.lang.Throwable) convergenceException12);
        java.lang.String str14 = convergenceException12.getPattern();
        java.lang.Class<?> wildcardClass15 = convergenceException12.getClass();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 65L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8268286794901034d + "'", double1 == 0.8268286794901034d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        outOfRangeException6.addSuppressed((java.lang.Throwable) convergenceException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21, "hi!", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException42, "hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable37, objArray52);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35, "hi!", objArray52);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable16, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "2cf469d315be094006b6222e0b9cafbd631", objArray52);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2960550997063713E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2960550997063713E13d + "'", double1 == 1.2960550997063713E13d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        int int11 = randomDataImpl1.nextSecureInt(1, 10);
//        try {
//            int int14 = randomDataImpl1.nextPascal((-1), (double) 10L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c857f1baa0" + "'", str3.equals("c857f1baa0"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b076bf87744cf807bd15282015dec969628" + "'", str5.equals("b076bf87744cf807bd15282015dec969628"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "79835afbd37abbe82b9e181e6ac3cedfc78" + "'", str8.equals("79835afbd37abbe82b9e181e6ac3cedfc78"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
//        randomDataImpl1.reSeedSecure(100L);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 100);
//        double double11 = randomDataImpl1.nextWeibull(0.75d, 0.75d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.41068390737762d + "'", double8 == 35.41068390737762d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.030741315797152516d + "'", double11 == 0.030741315797152516d);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample((int) '4');
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double4 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double5 = normalDistributionImpl0.cumulativeProbability((-0.5309649148733837d), (double) ' ');
        double double8 = normalDistributionImpl0.cumulativeProbability(0.75d, 1.000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7022784538745496d + "'", double5 == 0.7022784538745496d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.06797209868738197d + "'", double8 == 0.06797209868738197d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException9, "hi!", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException27, "hi!", objArray37);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22, localizable23, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray37);
        outOfRangeException4.addSuppressed((java.lang.Throwable) convergenceException42);
        java.lang.Object[] objArray44 = convergenceException42.getArguments();
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 32, 19.6635246692434d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.006440572383272472d + "'", double2 == 0.006440572383272472d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.934495855139244E-5d, 1.0000000130764508d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9999999999999327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6449340668483272d + "'", double1 == 1.6449340668483272d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(19.6635246692434d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.470844369773625E-22d + "'", double2 == 2.470844369773625E-22d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        boolean boolean17 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number18 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, "hi!", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getGeneralPattern();
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, number39, (java.lang.Number) 7L, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray60);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException50, "hi!", objArray60);
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) 1, mathException63 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("hi!", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(100, "org.apache.commons.math.MathException: ", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable38, objArray64);
        boolean boolean68 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-0.5872139151569291d) + "'", number18.equals((-0.5872139151569291d)));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        java.lang.String str11 = randomDataImpl1.nextHexString(20);
//        long long13 = randomDataImpl1.nextPoisson(0.00396779555086805d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f0ce897b6a" + "'", str3.equals("f0ce897b6a"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.017891914980129264d + "'", double6 == 0.017891914980129264d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ecaaa6fe75514e5fa932" + "'", str11.equals("ecaaa6fe75514e5fa932"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.rint((-38.410952501900226d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-38.0d) + "'", double1 == (-38.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        java.lang.Number number17 = numberIsTooLargeException3.getMax();
        java.lang.Number number18 = numberIsTooLargeException3.getMax();
        java.lang.Number number19 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) -1 + "'", number17.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) -1 + "'", number18.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) -1 + "'", number19.equals((short) -1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1, (java.lang.Number) Double.NaN);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "5f4d053aaf", objArray8);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0794415416798357d + "'", double1 == 2.0794415416798357d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
        randomDataImpl1.reSeedSecure(100L);
        try {
            long long8 = randomDataImpl1.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        try {
//            double double11 = randomDataImpl1.nextF((double) 0.0f, (-19.801480349880638d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5f6f8d7d6d" + "'", str3.equals("5f6f8d7d6d"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "caf577fb1e8f58e4ac3716ca09cc36fdcf7" + "'", str5.equals("caf577fb1e8f58e4ac3716ca09cc36fdcf7"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4f6ded7a00abe10e0220ab0961c5b11c314" + "'", str8.equals("4f6ded7a00abe10e0220ab0961c5b11c314"));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0015515614761480293d, (java.lang.Number) 0.29547209042283173d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.log(0.05860802438421144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.836883656889741d) + "'", double1 == (-2.836883656889741d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.1977461928657023d, (java.lang.Number) 0.15088231516747197d, (java.lang.Number) 35.41068390737762d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 35.41068390737762d + "'", number4.equals(35.41068390737762d));
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric((int) (byte) -1, 100, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4504e38155" + "'", str3.equals("4504e38155"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021816075007576444d + "'", double6 == 0.021816075007576444d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 39 + "'", int9 == 39);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 3);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.8194542120086394d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3401075359731442d + "'", double1 == 1.3401075359731442d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 88L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 88 + "'", int1 == 88);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
//        randomDataImpl1.reSeedSecure(100L);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 100);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 45.74233668895053d + "'", double8 == 45.74233668895053d);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) 'a');
        double double5 = normalDistributionImpl0.getMean();
        double double6 = normalDistributionImpl0.getMean();
        double double8 = normalDistributionImpl0.density((double) '4');
        double double10 = normalDistributionImpl0.density(0.0d);
        normalDistributionImpl0.reseedRandomGenerator(65L);
        normalDistributionImpl0.reseedRandomGenerator(65L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.max(59.0d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 59.0d + "'", double2 == 59.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 7L, (float) 8L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, "hi!", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable21, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, "hi!", objArray41);
        java.lang.Object[] objArray45 = new java.lang.Object[] { (short) 1, mathException44 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("hi!", objArray45);
        java.lang.Object[] objArray47 = convergenceException46.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable21, objArray47);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12, "hi!", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable27, objArray28);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray32);
        java.lang.Throwable[] throwableArray34 = maxIterationsExceededException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable27, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "c739a3ccec8742fd4a95e607c30f9ce562d", (java.lang.Object[]) throwableArray34);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.501389356330087d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.14228409249034d + "'", double1 == 89.14228409249034d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeed((long) 1);
        randomDataImpl1.reSeedSecure(0L);
        randomDataImpl1.reSeed((long) 18);
        try {
            int int14 = randomDataImpl1.nextSecureInt(36, 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 36 is larger than, or equal to, the maximum (9): lower bound (36) must be strictly less than upper bound (9)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.ulp(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9721522630525295E-31d + "'", double1 == 1.9721522630525295E-31d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21, "hi!", objArray31);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable17, objArray31);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray31);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        double double8 = randomDataImpl1.nextGaussian((-4.568877933480165d), 3.941597514286071d);
//        double double10 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.042213345986285d + "'", double8 == 5.042213345986285d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.10137427916442361d + "'", double10 == 0.10137427916442361d);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.apache.commons.math.util.FastMath.max(110L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.15471352636830865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 18);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 18.0f + "'", float1 == 18.0f);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        long long8 = randomDataImpl0.nextPoisson(2.718281828459045d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.4527921556925363d) + "'", double6 == (-2.4527921556925363d));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-85.51912676833847d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(30.192931321154465d, (double) '4', 12.801827480081469d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 58L, (float) 2147483647);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 58.0f + "'", float2 == 58.0f);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        double double9 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 2147483647);
//        try {
//            java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-23.004822096331175d) + "'", double6 == (-23.004822096331175d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.130303177827671E10d + "'", double9 == 1.130303177827671E10d);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double9 = randomDataImpl1.nextGamma((double) 100, 37.95743042488804d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ba45ed67a7" + "'", str3.equals("ba45ed67a7"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6f860318ff04c606d1ce00679b15ae015fc" + "'", str5.equals("6f860318ff04c606d1ce00679b15ae015fc"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4204.718035204538d + "'", double9 == 4204.718035204538d);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.FastMath.atan2(12.801827480081469d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4158213582911419d + "'", double2 == 1.4158213582911419d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, "hi!", objArray32);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-4.568877933480165d), (java.lang.Number) 1.0d, (java.lang.Number) 1);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18, localizable37, objArray50);
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException57);
        java.lang.Throwable[] throwableArray59 = outOfRangeException57.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, (java.lang.Object[]) throwableArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException60);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray59);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 20, (long) 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0015498655649075325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.000000000000001d + "'", double1 == 4.000000000000001d);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        int int11 = randomDataImpl1.nextSecureInt(1, 10);
//        try {
//            long long14 = randomDataImpl1.nextLong(95L, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 95 is larger than, or equal to, the maximum (1): lower bound (95) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bb29b1b5d1" + "'", str3.equals("bb29b1b5d1"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f8cf25c2a06cd0c2cbf02df692fe5c7ddd6" + "'", str5.equals("f8cf25c2a06cd0c2cbf02df692fe5c7ddd6"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "48247d6e4d4384fa40341ef2b776b1f685f" + "'", str8.equals("48247d6e4d4384fa40341ef2b776b1f685f"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.343266443619277E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.339787873579797E-4d + "'", double1 == 8.339787873579797E-4d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.008920749618263389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5618754588538566d + "'", double1 == 1.5618754588538566d);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 31);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int19 = randomDataImpl1.nextPascal((int) (short) 0, 24.350573990402296d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 24.351 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "533182b5d1" + "'", str3.equals("533182b5d1"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.00181303814919726d + "'", double6 == 0.00181303814919726d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 2.220446049250313E-16d);
        boolean boolean25 = notStrictlyPositiveException24.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0054084682946609255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-185.46358606610423d) + "'", double1 == (-185.46358606610423d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        long long1 = org.apache.commons.math.util.FastMath.abs(387L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 387L + "'", long1 == 387L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0276542587345318E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7935950387059276E-11d + "'", double1 == 1.7935950387059276E-11d);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        double double11 = randomDataImpl1.nextGaussian(2.7653056371838693d, 0.0034349072766937565d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f9c618a759" + "'", str3.equals("f9c618a759"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ff5f02692ce829c0014187cb3993cf1704c" + "'", str5.equals("ff5f02692ce829c0014187cb3993cf1704c"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "563eaff985361506ba36d42219642a2e8a3" + "'", str8.equals("563eaff985361506ba36d42219642a2e8a3"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.763878680115019d + "'", double11 == 2.763878680115019d);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double8 = randomDataImpl1.nextCauchy((-48.21273601220948d), (double) (short) 100);
//        randomDataImpl1.reSeedSecure((long) 10);
//        long long13 = randomDataImpl1.nextSecureLong((long) (byte) 1, (long) 47);
//        try {
//            long long15 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e9227fa698" + "'", str3.equals("e9227fa698"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7f7223b4427fb33a2eab2f78f58880df1f0" + "'", str5.equals("7f7223b4427fb33a2eab2f78f58880df1f0"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 207.97054990087761d + "'", double8 == 207.97054990087761d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 38L + "'", long13 == 38L);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893713d) + "'", double1 == (-0.5440211108893713d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.948645195086131d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.948645195086131d + "'", double1 == 0.948645195086131d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable31, objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException28, "hi!", objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
        java.lang.Throwable throwable44 = null;
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException49);
        java.lang.Throwable[] throwableArray51 = outOfRangeException49.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(throwable44, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (32) exceeded", (java.lang.Object[]) throwableArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, localizable43, (java.lang.Object[]) throwableArray51);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray51);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9439456942725643d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3806392494386521d + "'", double1 == 1.3806392494386521d);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextCauchy(0.010369588560374107d, (double) 32);
//        try {
//            randomDataImpl1.setSecureAlgorithm("c739a3ccec8742fd4a95e607c30f9ce562d", "d95e9236e7");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: d95e9236e7");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cb169bf562" + "'", str3.equals("cb169bf562"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-8.925052659489605d) + "'", double7 == (-8.925052659489605d));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        long long1 = org.apache.commons.math.util.FastMath.abs(27L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 27L + "'", long1 == 27L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeedSecure((long) (short) 10);
        randomDataImpl1.reSeedSecure((long) 48);
        try {
            double double12 = randomDataImpl1.nextF((-128.51581295729892d), 0.637123491124997d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -128.516 is smaller than, or equal to, the minimum (0): degrees of freedom (-128.516)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0015498655649075325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int1 = org.apache.commons.math.util.FastMath.abs(18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double4 = normalDistributionImpl0.density((double) 'a');
//        double double5 = normalDistributionImpl0.getMean();
//        double double6 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.density((double) '4');
//        double double10 = normalDistributionImpl0.density(0.0d);
//        double double11 = normalDistributionImpl0.sample();
//        double double13 = normalDistributionImpl0.cumulativeProbability(0.5269660623826669d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2498519270394195d) + "'", double11 == (-1.2498519270394195d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.7008914219119176d + "'", double13 == 0.7008914219119176d);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (byte) 100, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        outOfRangeException4.addSuppressed((java.lang.Throwable) convergenceException12);
        java.lang.String str14 = convergenceException12.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.470844369773625E-22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable20, objArray21);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable20, objArray23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray40);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException30, "hi!", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray50 = numberIsTooLargeException49.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable45, objArray50);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException55);
        java.lang.Throwable[] throwableArray57 = outOfRangeException55.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException63, "hi!", objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable59, objArray73);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray92 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException("", objArray92);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable84, localizable85, objArray92);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException82, "hi!", objArray92);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException("", objArray92);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable45, objArray92);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray92);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.199329338564076E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0276542587345318E-9d, number1, true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        outOfRangeException4.addSuppressed((java.lang.Throwable) convergenceException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) Double.NaN, (java.lang.Number) 0.0d, (java.lang.Number) (short) -1);
        java.lang.Number number19 = outOfRangeException18.getHi();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) -1 + "'", number19.equals((short) -1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.01745506503622958d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017609200952467312d) + "'", double1 == (-0.017609200952467312d));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
//        double double3 = normalDistributionImpl2.sample();
//        normalDistributionImpl2.reseedRandomGenerator((-1L));
//        double double7 = normalDistributionImpl2.density((-3.721719480081721d));
//        double double8 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.640215781452156d + "'", double3 == 32.640215781452156d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6931471805599453d + "'", double8 == 0.6931471805599453d);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-38.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        java.lang.String str11 = randomDataImpl1.nextHexString(20);
//        try {
//            int int14 = randomDataImpl1.nextPascal(0, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c1310ba48e" + "'", str3.equals("c1310ba48e"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0071603815666498654d + "'", double6 == 0.0071603815666498654d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1e3bf0a8f2dc10654c6b" + "'", str11.equals("1e3bf0a8f2dc10654c6b"));
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int2 = org.apache.commons.math.util.FastMath.max(20, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 95L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 95 + "'", int1 == 95);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.030741315797152516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.761347651855685d + "'", double1 == 1.761347651855685d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 36);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 36.0f + "'", float1 == 36.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 0.3996581954612728d, (java.lang.Number) 30.192931321154465d, false);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(number27, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number31 = numberIsTooLargeException30.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, "hi!", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException51.getGeneralPattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable52, objArray53);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray63);
        java.lang.Object[] objArray66 = maxIterationsExceededException65.getArguments();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException30, localizable52, objArray66);
        java.lang.Throwable[] throwableArray68 = mathException67.getSuppressed();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable18, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 0.07836479909182345d, (java.lang.Number) 0.9999683920075999d, (java.lang.Number) 0.014300169858597285d);
        java.lang.Number number74 = outOfRangeException73.getHi();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 0.014300169858597285d + "'", number74.equals(0.014300169858597285d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 9223372036854775807L, (float) 110L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 110.0f + "'", float2 == 110.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.2498519270394195d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6016394733470016d) + "'", double1 == (-1.6016394733470016d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 10, 10.0d);
        double[] doubleArray7 = normalDistributionImpl0.sample((int) (byte) 10);
        double double9 = normalDistributionImpl0.density(0.0d);
        try {
            double double11 = normalDistributionImpl0.inverseCumulativeProbability(1.761347651855685d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.761 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3989422804014327d + "'", double9 == 0.3989422804014327d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.6695702094400313d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        int int14 = randomDataImpl1.nextInt((-1), (int) (byte) 0);
//        double double16 = randomDataImpl1.nextT((double) 65L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3a6845fa26" + "'", str3.equals("3a6845fa26"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.594129713975868E-4d + "'", double6 == 7.594129713975868E-4d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a8a3955e469decb8813a69495f01c7a3ddd63795e771bfbea9a8a37761b8df20bf4b399aebd9a3c5ddaa008be717ae462ef" + "'", str11.equals("0a8a3955e469decb8813a69495f01c7a3ddd63795e771bfbea9a8a37761b8df20bf4b399aebd9a3c5ddaa008be717ae462ef"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.025193579327866752d) + "'", double16 == (-0.025193579327866752d));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.2320429179887327d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8889859343334499d) + "'", double1 == (-0.8889859343334499d));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        long long7 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double10 = randomDataImpl1.nextF((double) 1, (double) 32);
//        randomDataImpl1.reSeed(0L);
//        try {
//            long long15 = randomDataImpl1.nextSecureLong((long) 32, 7L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (7): lower bound (32) must be strictly less than upper bound (7)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "67fc86fb47" + "'", str3.equals("67fc86fb47"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b54514fde088240cbad5a30c6ccb3b183fb" + "'", str5.equals("b54514fde088240cbad5a30c6ccb3b183fb"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01842766947409594d + "'", double10 == 0.01842766947409594d);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double11 = randomDataImpl1.nextWeibull(0.6931471805599453d, 0.002695222488444281d);
//        double double14 = randomDataImpl1.nextUniform(0.0d, 0.03140541886289395d);
//        try {
//            int int18 = randomDataImpl1.nextHypergeometric(0, 18, 50);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 38L + "'", long8 == 38L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004238821458030244d + "'", double11 == 0.004238821458030244d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.008562520040133772d + "'", double14 == 0.008562520040133772d);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        int[] intArray11 = randomDataImpl1.nextPermutation((int) '4', (int) (short) 1);
//        int int15 = randomDataImpl1.nextHypergeometric((int) (short) 100, 1, 20);
//        try {
//            double double17 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 62L + "'", long8 == 62L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(25.668476728767978d, 0.47237076358094937d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 25.668476728767974d + "'", double2 == 25.668476728767974d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        int[] intArray11 = randomDataImpl1.nextPermutation((int) '4', (int) (short) 1);
//        double double14 = randomDataImpl1.nextGamma(4.000000000000001d, 0.15471352636830865d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 94L + "'", long8 == 94L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5846268783300651d + "'", double14 == 0.5846268783300651d);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        double double8 = randomDataImpl1.nextWeibull(2.1447987906960946d, 0.47237076358094937d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.4716622348245448d + "'", double8 == 0.4716622348245448d);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double10 = randomDataImpl1.nextT(205.16819948264123d);
//        randomDataImpl1.reSeed(34L);
//        try {
//            int[] intArray15 = randomDataImpl1.nextPermutation(95, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 76L + "'", long8 == 76L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.6527793566641178d) + "'", double10 == (-0.6527793566641178d));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray25 = numberIsTooLargeException24.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray25);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 73L, (java.lang.Number) 0.8860927126647652d, (java.lang.Number) 2L);
        java.lang.Throwable[] throwableArray31 = outOfRangeException30.getSuppressed();
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 105L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 105.0f + "'", float1 == 105.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.47237076358094937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.064851118560412d + "'", double1 == 27.064851118560412d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "118fb6d83ba3d07086c21079786b3b1c57b", objArray2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.158638853279167d + "'", double2 == 4.158638853279167d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5694353436354335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2445555806216725d) + "'", double1 == (-0.2445555806216725d));
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double8 = randomDataImpl1.nextCauchy((-48.21273601220948d), (double) (short) 100);
//        long long11 = randomDataImpl1.nextLong(86L, (long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "237afcfeed" + "'", str3.equals("237afcfeed"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7d3a808cd0f77a80f5e2150f6eaed2e44ea" + "'", str5.equals("7d3a808cd0f77a80f5e2150f6eaed2e44ea"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 21.489422392471504d + "'", double8 == 21.489422392471504d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 86L + "'", long11 == 86L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1776.169164905552d + "'", double1 == 1776.169164905552d);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeed();
//        double double11 = randomDataImpl1.nextF(1.3806392494386521d, 2.766388578064682d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7372566545756909d + "'", double11 == 0.7372566545756909d);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.3401075359731442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.3666540377767577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        try {
//            java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bce0bfeb2b" + "'", str3.equals("bce0bfeb2b"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.501389356330087d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.766388578064682d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) 'a');
        double double5 = normalDistributionImpl0.getMean();
        double double6 = normalDistributionImpl0.getMean();
        double double8 = normalDistributionImpl0.density((double) '4');
        double double10 = normalDistributionImpl0.density(0.0d);
        normalDistributionImpl0.reseedRandomGenerator(65L);
        double double13 = normalDistributionImpl0.sample();
        double double15 = normalDistributionImpl0.density(0.0010560289896658199d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8889953962329269d + "'", double13 == 0.8889953962329269d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3989420579518323d + "'", double15 == 0.3989420579518323d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (-4.568877933480165d), (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.Number number23 = outOfRangeException22.getHi();
        java.lang.String str24 = outOfRangeException22.toString();
        java.lang.Number number25 = outOfRangeException22.getArgument();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1 + "'", number23.equals(1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -4.569 out of [1, 1] range: -4.569" + "'", str24.equals("org.apache.commons.math.exception.OutOfRangeException: -4.569 out of [1, 1] range: -4.569"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-4.568877933480165d) + "'", number25.equals((-4.568877933480165d)));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.8810899941038624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.003015864504352809d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5677804577187566d + "'", double1 == 1.5677804577187566d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeed((long) 1);
        randomDataImpl1.reSeedSecure(0L);
        double double12 = randomDataImpl1.nextGamma((double) 73L, 12.801827480081469d);
        try {
            int int15 = randomDataImpl1.nextInt(100, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (36): lower bound (100) must be strictly less than upper bound (36)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 999.0352190672713d + "'", double12 == 999.0352190672713d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.761347651855685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3315140559166503d + "'", double1 == 1.3315140559166503d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable25, objArray26);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable25, objArray39);
        java.lang.Number number41 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0.606111934732855d + "'", number41.equals(0.606111934732855d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6930493724754014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 37.95743042488804d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.0276542587345318E-9d, (double) 18.0f, 1.4158213582911419d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(number25, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number29 = numberIsTooLargeException28.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray45);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException35, "hi!", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray45);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable50, objArray51);
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray61);
        java.lang.Object[] objArray64 = maxIterationsExceededException63.getArguments();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException28, localizable50, objArray64);
        java.lang.Throwable[] throwableArray66 = mathException65.getSuppressed();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(throwable0, localizable20, (java.lang.Object[]) throwableArray66);
        java.lang.Object[] objArray76 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray76);
        java.lang.Object[] objArray79 = maxIterationsExceededException78.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable20, objArray79);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.421010862427522E-20d, 32.76046727429972d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6547416180111248E-21d + "'", double2 == 1.6547416180111248E-21d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7249165551445564d) + "'", double1 == (-0.7249165551445564d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.log(0.29133340463048707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2332869472676689d) + "'", double1 == (-1.2332869472676689d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.0592232274909887d), 1.970526002457483d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double4 = normalDistributionImpl0.density((double) 'a');
//        double double5 = normalDistributionImpl0.getMean();
//        double double6 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.density((double) '4');
//        double double10 = normalDistributionImpl0.density(0.0d);
//        double double11 = normalDistributionImpl0.sample();
//        double double13 = normalDistributionImpl0.density((-0.6695702094400313d));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.04648081670268201d + "'", double11 == 0.04648081670268201d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.31882890568747096d + "'", double13 == 0.31882890568747096d);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("585100984a", objArray8);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5705654518541791d + "'", double1 == 0.5705654518541791d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long2 = org.apache.commons.math.util.FastMath.min(3L, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.8414709848078965d), (-4.16038520882935d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8414709848078966d) + "'", double2 == (-0.8414709848078966d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray8);
        java.lang.String str11 = maxIterationsExceededException10.toString();
        java.lang.String str12 = maxIterationsExceededException10.getPattern();
        java.lang.Object[] objArray13 = maxIterationsExceededException10.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str11.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double5 = normalDistributionImpl0.cumulativeProbability((-0.5309649148733837d), (double) ' ');
        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10L);
        double double9 = normalDistributionImpl0.density(0.0018452162759392634d);
        double double11 = normalDistributionImpl0.density(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7022784538745496d + "'", double5 == 0.7022784538745496d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3989416012380639d + "'", double9 == 0.3989416012380639d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4227843322079321d + "'", double1 == 0.4227843322079321d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int2 = org.apache.commons.math.util.FastMath.max(29, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.8268286794901034d, (java.lang.Number) 32.640215781452156d, true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.3989422804014327d, (double) '#');
        double[] doubleArray4 = normalDistributionImpl2.sample(6);
        double[] doubleArray6 = normalDistributionImpl2.sample((int) (byte) 10);
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability(0.7327540948844548d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) (short) 100);
        double double6 = normalDistributionImpl0.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0276542587345318E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0276542587345318E-9d + "'", double1 == 1.0276542587345318E-9d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5772156649015329d, 0.02377827058524365d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5772156649015328d + "'", double2 == 0.5772156649015328d);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        randomDataImpl1.reSeedSecure((long) 16);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dc1e201576" + "'", str3.equals("dc1e201576"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextSecureLong((long) (short) 10, 106L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24cd1e14f4" + "'", str3.equals("24cd1e14f4"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.044181817812709E-4d + "'", double6 == 3.044181817812709E-4d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 68L + "'", long9 == 68L);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution10 = null;
//        try {
//            double double11 = randomDataImpl1.nextInversionDeviate(continuousDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e318e31434" + "'", str3.equals("e318e31434"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e6ee8b4c176a84079d9fada32ece2753e55" + "'", str5.equals("e6ee8b4c176a84079d9fada32ece2753e55"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5429e347f108f8406a0b0ddf3a18cbfb2c4" + "'", str8.equals("5429e347f108f8406a0b0ddf3a18cbfb2c4"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability(12.188542027763553d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 12.189 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1776.169164905552d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.631679556835387E-4d + "'", double1 == 5.631679556835387E-4d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9129311827723892d + "'", double1 == 1.9129311827723892d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable20, objArray21);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray25);
        java.lang.Throwable[] throwableArray27 = maxIterationsExceededException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable20, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(localizable29);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray2);
        java.lang.String str4 = maxIterationsExceededException3.getPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.934495855139244E-5d, 31.887903591703434d, (double) 88L);
        normalDistributionImpl3.reseedRandomGenerator((long) 32);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.rint(33.01166427675536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.0d + "'", double1 == 33.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.004947214450574307d, (java.lang.Number) 0.8623188722876839d, (java.lang.Number) (-295.25552065913223d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0L, (java.lang.Number) 1.1774215933195176d, (java.lang.Number) 0.6470434810831891d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double10 = randomDataImpl1.nextT(205.16819948264123d);
//        randomDataImpl1.reSeed(34L);
//        double double14 = randomDataImpl1.nextChiSquare((double) 106L);
//        double double16 = randomDataImpl1.nextT((double) 28);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 62L + "'", long8 == 62L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8069061696794684d + "'", double10 == 0.8069061696794684d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 114.39639083088666d + "'", double14 == 114.39639083088666d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.4534260731669825d) + "'", double16 == (-0.4534260731669825d));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39908993417905747d) + "'", double1 == (-0.39908993417905747d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.special.Erf.erf(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.011010127267165E-16d + "'", double1 == 5.011010127267165E-16d);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        int[] intArray11 = randomDataImpl1.nextPermutation((int) '4', (int) (short) 1);
//        double double14 = randomDataImpl1.nextCauchy((double) (short) 0, 0.6931471805599453d);
//        try {
//            double double17 = randomDataImpl1.nextWeibull(0.3989416012380639d, (-185.46358606610423d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -185.464 is smaller than, or equal to, the minimum (0): scale (-185.464)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 81L + "'", long8 == 81L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9868025392431493d + "'", double14 == 0.9868025392431493d);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) (short) 100);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        double double6 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.3684134059513968d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0034349072766937565d, 71.9106325463476d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability((-0.5309649148733837d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.531 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextBeta((double) (short) 1, 1.5370011680964748E15d);
//        try {
//            long long9 = randomDataImpl0.nextLong((long) (short) 100, 54L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (54): lower bound (100) must be strictly less than upper bound (54)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.3989422804014327d, (double) '#');
        double double4 = normalDistributionImpl2.density((double) 106L);
        double double6 = normalDistributionImpl2.inverseCumulativeProbability(0.5772156649015328d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2024811977090607E-4d + "'", double4 == 1.2024811977090607E-4d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.216086251614523d + "'", double6 == 7.216086251614523d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(2147483647, localizable9, objArray10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.special.Erf.erf((-38.410952501900226d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        double double9 = randomDataImpl0.nextCauchy((double) (byte) -1, (double) 2147483647);
//        int int12 = randomDataImpl0.nextSecureInt(10, 52);
//        try {
//            int int15 = randomDataImpl0.nextPascal(15, (double) 2L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15.851602421509515d) + "'", double6 == (-15.851602421509515d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.542341122612489E9d + "'", double9 == 5.542341122612489E9d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 28 + "'", int12 == 28);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.39908993417905747d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9214150088568995d + "'", double1 == 0.9214150088568995d);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(31);
//        double double8 = randomDataImpl0.nextF((double) 36.0f, (double) 110.0f);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "83fec0640ec538590989e37c757e490" + "'", str5.equals("83fec0640ec538590989e37c757e490"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8804557064049551d + "'", double8 == 0.8804557064049551d);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        double double11 = randomDataImpl1.nextChiSquare(0.008554418607742533d);
//        int int14 = randomDataImpl1.nextPascal(9, 1.0E-323d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "48338b5648" + "'", str3.equals("48338b5648"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0026841704660672005d + "'", double6 == 0.0026841704660672005d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-323d + "'", double11 == 1.0E-323d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) 'a');
        double double5 = normalDistributionImpl0.getMean();
        double double7 = normalDistributionImpl0.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 43L, (float) 78L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 43.0f + "'", float2 == 43.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6L, (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1, (java.lang.Number) Double.NaN);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.log(22.724778562915525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.12345589580993d + "'", double1 == 3.12345589580993d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.ceil(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.35083000971366424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9321183878737558d + "'", double1 == 0.9321183878737558d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        outOfRangeException5.addSuppressed((java.lang.Throwable) convergenceException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) Double.NaN, (java.lang.Number) 0.0d, (java.lang.Number) (short) -1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 1.1774215933195176d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException25, "hi!", objArray35);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 0.3996581954612728d, (java.lang.Number) 30.192931321154465d, false);
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(number49, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("", objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable61, localizable62, objArray69);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException59, "hi!", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("", objArray69);
        org.apache.commons.math.exception.util.Localizable localizable74 = convergenceException73.getGeneralPattern();
        java.lang.Object[] objArray75 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable74, objArray75);
        java.lang.Object[] objArray85 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException("", objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray85);
        java.lang.Object[] objArray88 = maxIterationsExceededException87.getArguments();
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException52, localizable74, objArray88);
        java.lang.Throwable[] throwableArray90 = mathException89.getSuppressed();
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable15, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException96 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.6931471805599453d, (java.lang.Number) (-59.07586455318917d), true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(number53);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray90);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable25, objArray26);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable25, objArray39);
        boolean boolean41 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable43, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("hi!", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException54, "hi!", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray82 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException("", objArray82);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable74, localizable75, objArray82);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException72, "hi!", objArray82);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException67, localizable68, objArray82);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException("", objArray82);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable49, objArray82);
        org.apache.commons.math.exception.util.Localizable localizable89 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertNull(localizable89);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) (short) 100);
        double double6 = normalDistributionImpl0.cumulativeProbability((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.27853002397319443d + "'", double6 == 0.27853002397319443d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException22);
        java.lang.Throwable[] throwableArray24 = outOfRangeException22.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, "hi!", (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray24);
        java.lang.String str27 = mathException26.getPattern();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 10, 10.0d);
//        double[] doubleArray7 = normalDistributionImpl0.sample((int) (byte) 10);
//        double double9 = normalDistributionImpl0.density(0.0d);
//        double double10 = normalDistributionImpl0.sample();
//        double double11 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3989422804014327d + "'", double9 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.4747221747776881d) + "'", double10 == (-0.4747221747776881d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3078752130143855E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0034349072766937565d, 71.9106325463476d);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) -1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int1 = org.apache.commons.math.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        double double16 = randomDataImpl1.nextGaussian(2.718281828459045d, 399.1324859400626d);
//        try {
//            int int19 = randomDataImpl1.nextPascal(2, 25.668476728767978d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 25.668 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6d512fc931" + "'", str3.equals("6d512fc931"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.052103679994988E-4d + "'", double6 == 5.052103679994988E-4d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-848.5226251229967d) + "'", double16 == (-848.5226251229967d));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        boolean boolean17 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean18 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number19 = numberIsTooLargeException3.getArgument();
        java.lang.Number number20 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-0.5872139151569291d) + "'", number19.equals((-0.5872139151569291d)));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (short) -1 + "'", number20.equals((short) -1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable1, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("hi!", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, "b703f51248", objArray12);
        java.lang.String str16 = convergenceException6.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.ConvergenceException: hi!" + "'", str16.equals("org.apache.commons.math.ConvergenceException: hi!"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.298342365610589d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 10, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException11, "hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(number31, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number35 = numberIsTooLargeException34.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException41, "hi!", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException55.getGeneralPattern();
        java.lang.Object[] objArray57 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable56, objArray57);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray67);
        java.lang.Object[] objArray70 = maxIterationsExceededException69.getArguments();
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException34, localizable56, objArray70);
        java.lang.Throwable[] throwableArray72 = mathException71.getSuppressed();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable6, localizable26, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable75, objArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("hi!", objArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable26, objArray78);
        java.lang.Object[] objArray90 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException("", objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray90);
        java.lang.Object[] objArray93 = maxIterationsExceededException92.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable26, objArray93);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(objArray93);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9321183878737558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03052892462557961d) + "'", double1 == (-0.03052892462557961d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6020599913279624d + "'", double1 == 0.6020599913279624d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.12345589580993d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9931154986385148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.006908308872464028d) + "'", double1 == (-0.006908308872464028d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9899924966004454d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1598173999482984d) + "'", double1 == (-1.1598173999482984d));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double5 = normalDistributionImpl0.cumulativeProbability((-0.5309649148733837d), (double) ' ');
//        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10L);
//        double double8 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7022784538745496d + "'", double5 == 0.7022784538745496d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.2042460196834086d) + "'", double8 == (-1.2042460196834086d));
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) 'a');
        try {
            double double6 = normalDistributionImpl0.inverseCumulativeProbability((-1.2042460196834086d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.204 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.9999683920075999d, true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.5309649148733837d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7570777049615482d) + "'", double1 == (-0.7570777049615482d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.23606797749979d + "'", double1 == 2.23606797749979d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.10137427916442361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3183932775113564d + "'", double1 == 0.3183932775113564d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
        randomDataImpl1.reSeedSecure(100L);
        long long8 = randomDataImpl1.nextPoisson(1.0E-323d);
        try {
            double double11 = randomDataImpl1.nextGamma(0.0d, (-16.857679757182947d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.773691189871375d, (double) 52.0f);
        try {
            double double5 = normalDistributionImpl2.cumulativeProbability(0.9321183878737558d, 1.3956623916831184E-9d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 20);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 20.0f + "'", float1 == 20.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0015515614761480293d, (java.lang.Number) 0.29547209042283173d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        boolean boolean18 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number19 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, "hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, number40, (java.lang.Number) 7L, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray61);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException51, "hi!", objArray61);
        java.lang.Object[] objArray65 = new java.lang.Object[] { (short) 1, mathException64 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("hi!", objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(100, "org.apache.commons.math.MathException: ", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable39, objArray65);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 0.29133340463048707d, number70, false);
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable39, objArray73);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-0.5872139151569291d) + "'", number19.equals((-0.5872139151569291d)));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.773691189871375d, (double) 52.0f);
        double double4 = normalDistributionImpl2.cumulativeProbability((-2.2570957787672725d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.46910687614821883d + "'", double4 == 0.46910687614821883d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.1977461928657023d, (java.lang.Number) 0.15088231516747197d, (java.lang.Number) 35.41068390737762d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1.198 out of [0.151, 35.411] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 1.198 out of [0.151, 35.411] range"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0015498655649075325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(114.39639083088666d, 0.5846268783300651d, (double) 105.0f, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextChiSquare(31.887903591703434d);
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric(31, 2147483647, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than the maximum (31): number of successes (2,147,483,647) must be less than or equal to population size (31)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16cf506a29" + "'", str3.equals("16cf506a29"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1fde203dbe8dc36ed289b21ccbacb357ffc" + "'", str5.equals("1fde203dbe8dc36ed289b21ccbacb357ffc"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 31.72260920991519d + "'", double8 == 31.72260920991519d);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        long long2 = org.apache.commons.math.util.FastMath.max(41L, (long) 48);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextCauchy(0.010369588560374107d, (double) 32);
//        int int11 = randomDataImpl1.nextHypergeometric(52, (int) (byte) 1, 7);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3142966ba9" + "'", str3.equals("3142966ba9"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.9403584653981307d) + "'", double7 == (-0.9403584653981307d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double5 = normalDistributionImpl0.cumulativeProbability((-0.5309649148733837d), (double) ' ');
        double double7 = normalDistributionImpl0.cumulativeProbability((double) 10L);
        normalDistributionImpl0.reseedRandomGenerator(7L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7022784538745496d + "'", double5 == 0.7022784538745496d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        int[] intArray11 = randomDataImpl1.nextPermutation((int) '4', (int) (short) 1);
//        long long13 = randomDataImpl1.nextPoisson(0.0034349072766937565d);
//        try {
//            java.lang.String str15 = randomDataImpl1.nextHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 46L + "'", long8 == 46L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0d, (java.lang.Number) 11013.232874703393d, false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray32);
        java.lang.Object[] objArray35 = maxIterationsExceededException34.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable23, objArray35);
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, number37, (java.lang.Number) 38L, true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.018838243234234782d, (-0.01745506503622958d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0717889667529197d + "'", double2 == 1.0717889667529197d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        float float1 = org.apache.commons.math.util.FastMath.abs(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double8 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2306bf75db" + "'", str3.equals("2306bf75db"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1cd0696d746a3b942e9406655eba6ad6714" + "'", str5.equals("1cd0696d746a3b942e9406655eba6ad6714"));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        long long7 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double10 = randomDataImpl1.nextF((double) 1, (double) 32);
//        randomDataImpl1.reSeed(0L);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed((long) 28);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5994c374b9" + "'", str3.equals("5994c374b9"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3bca3ab12520b49b1d2d275a5340ae1cc22" + "'", str5.equals("3bca3ab12520b49b1d2d275a5340ae1cc22"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 114L + "'", long7 == 114L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.7105767271703536d + "'", double10 == 1.7105767271703536d);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.8804557064049551d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9870302745542343d + "'", double1 == 1.9870302745542343d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 38L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 38L + "'", long2 == 38L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0264017010081258d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.026407837152621846d + "'", double1 == 0.026407837152621846d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.5309649148733837d), 8.343267411578593E-4d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0026841704660672005d, 0.0d, 0.0d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextChiSquare(31.887903591703434d);
//        double double11 = randomDataImpl1.nextUniform((-0.017453292519943292d), (double) 52.0f);
//        double double14 = randomDataImpl1.nextWeibull(0.606111934732855d, 0.0018452162759392634d);
//        try {
//            java.lang.String str16 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8ed84161f8" + "'", str3.equals("8ed84161f8"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ec39aa88ad545c54b431a8ac35388a228ce" + "'", str5.equals("ec39aa88ad545c54b431a8ac35388a228ce"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 31.127278745676044d + "'", double8 == 31.127278745676044d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 46.20492842314502d + "'", double11 == 46.20492842314502d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0019520849346914254d + "'", double14 == 0.0019520849346914254d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.special.Erf.erf(25.668476728767978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.3877787807814457E-17d, (double) 88L, (-4.440892098500626E-16d), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 88 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.tan(4204.718035204538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1905081680480696d + "'", double1 == 3.1905081680480696d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        java.lang.String str11 = randomDataImpl1.nextHexString(20);
//        int int14 = randomDataImpl1.nextInt(0, 28);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e6d34e5f15" + "'", str3.equals("e6d34e5f15"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.018642661230142885d + "'", double6 == 0.018642661230142885d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "289df3a3172d99a9cbc3" + "'", str11.equals("289df3a3172d99a9cbc3"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getSpecificPattern();
        java.lang.Number number7 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.606111934732855d + "'", number4.equals(0.606111934732855d));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNull(number7);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        int int14 = randomDataImpl1.nextInt((-1), (int) (byte) 0);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fc71a95f94" + "'", str3.equals("fc71a95f94"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.007319239485697828d + "'", double6 == 0.007319239485697828d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "e5dd417b2e5174edb6202a5cd29257caf98e4d8e4c8d012ef5251b851da40efc1ba4bbf7f6c83089e6ba3a424f87d48489f8" + "'", str11.equals("e5dd417b2e5174edb6202a5cd29257caf98e4d8e4c8d012ef5251b851da40efc1ba4bbf7f6c83089e6ba3a424f87d48489f8"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        double double11 = randomDataImpl1.nextChiSquare(0.008554418607742533d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(32);
//        try {
//            int int16 = randomDataImpl1.nextBinomial((int) (byte) -1, (-2.836883656889741d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e2fe635e13" + "'", str3.equals("e2fe635e13"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.008190487609664662d + "'", double6 == 0.008190487609664662d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-323d + "'", double11 == 1.0E-323d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0c829651dc5d182ad5ecac93a9126f91" + "'", str13.equals("0c829651dc5d182ad5ecac93a9126f91"));
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.75d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 0, 0.0d, (double) 94L, (int) (byte) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(32);
        java.lang.Object[] objArray2 = maxIterationsExceededException1.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        outOfRangeException7.addSuppressed((java.lang.Throwable) convergenceException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) Double.NaN, (java.lang.Number) 0.0d, (java.lang.Number) (short) -1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 1.1774215933195176d);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray32);
        java.lang.Object[] objArray35 = maxIterationsExceededException34.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable17, objArray35);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeed((long) 1);
        randomDataImpl1.reSeedSecure(0L);
        double double12 = randomDataImpl1.nextGamma((double) 73L, 12.801827480081469d);
        try {
            int int15 = randomDataImpl1.nextZipf((int) '4', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 999.0352190672713d + "'", double12 == 999.0352190672713d);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double7 = randomDataImpl1.nextExponential(1.7182818284590453d);
//        java.lang.String str9 = randomDataImpl1.nextHexString(36);
//        double double11 = randomDataImpl1.nextExponential(1.0d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9732296641" + "'", str3.equals("9732296641"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2bdea93f7905309cc8715cb3f42ff2a35af" + "'", str5.equals("2bdea93f7905309cc8715cb3f42ff2a35af"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.660374579706445d + "'", double7 == 2.660374579706445d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "e5d9ce58ac751c33b3bd1bbc080e6ba4bbdd" + "'", str9.equals("e5d9ce58ac751c33b3bd1bbc080e6ba4bbdd"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6187774595471821d + "'", double11 == 0.6187774595471821d);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.014300169858597285d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4891.709715267259d + "'", double1 == 4891.709715267259d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeed((long) 1);
        randomDataImpl1.reSeedSecure(0L);
        double double12 = randomDataImpl1.nextGamma((double) 73L, 12.801827480081469d);
        double double14 = randomDataImpl1.nextT((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 999.0352190672713d + "'", double12 == 999.0352190672713d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.23339672951208426d) + "'", double14 == (-0.23339672951208426d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.Throwable throwable2 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7);
        java.lang.Throwable[] throwableArray9 = outOfRangeException7.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(throwable2, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (32) exceeded", (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((-1), "77624cdaaac4173c05d5", (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 36);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (byte) 100, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 100 + "'", number4.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 47, (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        long long1 = org.apache.commons.math.util.FastMath.abs(106L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 106L + "'", long1 == 106L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1977461928657023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (-4.568877933480165d), (java.lang.Number) 1.0d, (java.lang.Number) 1);
        java.lang.String str23 = outOfRangeException22.toString();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -4.569 out of [1, 1] range: -4.569" + "'", str23.equals("org.apache.commons.math.exception.OutOfRangeException: -4.569 out of [1, 1] range: -4.569"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(32);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
        java.lang.Object[] objArray6 = notStrictlyPositiveException5.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "", objArray6);
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0015515614761480293d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5692447646962244d + "'", double1 == 1.5692447646962244d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.0054084682946609255d, (java.lang.Number) (-2.8460841427129617d), (java.lang.Number) 59.18142598372261d);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "0244d863e0", objArray5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.606111934732855d + "'", number4.equals(0.606111934732855d));
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 10, 10.0d);
//        double[] doubleArray7 = normalDistributionImpl0.sample((int) (byte) 10);
//        double double9 = normalDistributionImpl0.density(0.0d);
//        double double10 = normalDistributionImpl0.sample();
//        double double11 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3989422804014327d + "'", double9 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.552230979162594d + "'", double10 == 1.552230979162594d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.500947896551658d) + "'", double11 == (-0.500947896551658d));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.970526002457483d, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.651498724127711d + "'", double2 == 7.651498724127711d);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        int int10 = randomDataImpl1.nextPascal((int) ' ', 0.8810899941038624d);
//        try {
//            double double13 = randomDataImpl1.nextGamma((-4.16038520882935d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.16 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "cd7dc50d85" + "'", str7.equals("cd7dc50d85"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.9173087126372744E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.91730871263727E14d + "'", double1 == 2.91730871263727E14d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
        double double6 = randomDataImpl0.nextBeta((double) (short) 1, 1.5370011680964748E15d);
        try {
            int int9 = randomDataImpl0.nextPascal(36, 281.26745188383904d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 281.267 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.018642661230142885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018644821425581503d + "'", double1 == 0.018644821425581503d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) (byte) 10);
        boolean boolean21 = notStrictlyPositiveException20.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        double double12 = randomDataImpl1.nextGaussian(0.6470434810831891d, 4.158638853279167d);
//        double double14 = randomDataImpl1.nextT(6073.352628386726d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ecc575596b" + "'", str3.equals("ecc575596b"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.29823235108913E-4d + "'", double6 == 6.29823235108913E-4d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 41 + "'", int9 == 41);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.968007686032135d + "'", double12 == 1.968007686032135d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.291547545349534d + "'", double14 == 0.291547545349534d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 7L, 4204.718035204538d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        java.lang.String str18 = mathException16.toString();
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable21, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("hi!", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable29, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, "b703f51248", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable19, objArray32);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str18.equals("org.apache.commons.math.MathException: hi!"));
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        long long10 = randomDataImpl1.nextSecureLong(0L, (long) 32);
//        int int13 = randomDataImpl1.nextZipf((int) (short) 100, 0.9931154986385148d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "7ecef91df5" + "'", str7.equals("7ecef91df5"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6L + "'", long10 == 6L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6187774595471821d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7866240903679356d + "'", double1 == 0.7866240903679356d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray32);
        java.lang.Object[] objArray35 = maxIterationsExceededException34.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable23, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 54L, (java.lang.Number) 0.008920749618263389d, false);
        boolean boolean41 = numberIsTooSmallException40.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        double double11 = randomDataImpl1.nextChiSquare(0.008554418607742533d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(32);
//        double double16 = randomDataImpl1.nextWeibull((double) 18, 1.3440585709080678E43d);
//        try {
//            int int20 = randomDataImpl1.nextHypergeometric((-1), (int) (short) 100, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f951394cf3" + "'", str3.equals("f951394cf3"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.028113261360296866d + "'", double6 == 0.028113261360296866d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.49033358838019736d + "'", double11 == 0.49033358838019736d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2b5d3e6f281b742e842c2c2ea8a94098" + "'", str13.equals("2b5d3e6f281b742e842c2c2ea8a94098"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.3676526691575618E43d + "'", double16 == 1.3676526691575618E43d);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.017609200952467312d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01760920095246731d) + "'", double1 == (-0.01760920095246731d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
        double double6 = randomDataImpl0.nextBeta((double) (short) 1, 1.5370011680964748E15d);
        randomDataImpl0.reSeed();
        try {
            int[] intArray10 = randomDataImpl0.nextPermutation((int) (byte) -1, 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 9 is larger than the maximum (-1): permutation size (9) exceeds permuation domain (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        long long7 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double10 = randomDataImpl1.nextF((double) 1, (double) 32);
//        randomDataImpl1.reSeed(0L);
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric((int) (byte) 1, 32, 3);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (1): number of successes (32) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "be8d857535" + "'", str3.equals("be8d857535"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "838eedee235065937d3cf69402f0ad1411f" + "'", str5.equals("838eedee235065937d3cf69402f0ad1411f"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 114L + "'", long7 == 114L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.9619881032800677d + "'", double10 == 1.9619881032800677d);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.rint(12.188542027763553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1, (java.lang.Number) Double.NaN);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 387L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.961005339623274d + "'", double1 == 5.961005339623274d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double7 = randomDataImpl1.nextExponential(1.7182818284590453d);
//        java.lang.String str9 = randomDataImpl1.nextHexString(36);
//        randomDataImpl1.reSeed(387L);
//        int int14 = randomDataImpl1.nextInt(0, 47);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bbc036789b" + "'", str3.equals("bbc036789b"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a8d43977d5a18d8f71a2fac0776e01f116d" + "'", str5.equals("a8d43977d5a18d8f71a2fac0776e01f116d"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.5519553055127902d + "'", double7 == 1.5519553055127902d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2e6ec0c04c932478cb8427ac2ea1f9fd2a55" + "'", str9.equals("2e6ec0c04c932478cb8427ac2ea1f9fd2a55"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36 + "'", int14 == 36);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable0, objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        boolean boolean17 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number18 = numberIsTooLargeException3.getArgument();
        java.lang.Number number19 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-0.5872139151569291d) + "'", number18.equals((-0.5872139151569291d)));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) -1 + "'", number19.equals((short) -1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) ' ');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(281.26745188383904d, 25.668476728767974d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 281.267451883839d + "'", double2 == 281.267451883839d);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
//        randomDataImpl1.reSeedSecure(100L);
//        double double9 = randomDataImpl1.nextGaussian(5.298342365610589d, 0.4716622348245448d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.7581537309045485d + "'", double9 == 4.7581537309045485d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 10, 10.0d);
        double double7 = normalDistributionImpl0.cumulativeProbability(5.091664233263755E12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray25 = numberIsTooLargeException24.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray42);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException32, "hi!", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray42);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable20, objArray42);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) (-0.017609200952467312d));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8862293353978659d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.774692927339821d + "'", double1 == 0.774692927339821d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.03052892462557961d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.127235520414196d + "'", double1 == 32.127235520414196d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.5309649148733837d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure((long) 48);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = normalDistributionImpl10.density(1.0E-9d);
//        double double14 = normalDistributionImpl10.density((double) 'a');
//        double double17 = normalDistributionImpl10.cumulativeProbability(1.0E-9d, 0.7327540948844548d);
//        double double18 = normalDistributionImpl10.getMean();
//        double double19 = normalDistributionImpl10.sample();
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.3989422804014327d + "'", double12 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.26814578754952245d + "'", double17 == 0.26814578754952245d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.43729660672331816d + "'", double19 == 0.43729660672331816d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.6221568198407287d) + "'", double20 == (-0.6221568198407287d));
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextSecureLong((long) (short) 10, 106L);
//        try {
//            java.lang.String str11 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "420c9a6aa1" + "'", str3.equals("420c9a6aa1"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.003062730641772942d + "'", double6 == 0.003062730641772942d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 93L + "'", long9 == 93L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 43.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5777218104420236E-30d + "'", double1 == 1.5777218104420236E-30d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl1.nextZipf(32, (double) 7.0f);
//        randomDataImpl1.reSeedSecure();
//        double double16 = randomDataImpl1.nextT(4.7581537309045485d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "55d50b681f" + "'", str3.equals("55d50b681f"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6b9cb2825d9dff6624d08d23634c7622dce" + "'", str5.equals("6b9cb2825d9dff6624d08d23634c7622dce"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "bfab9f6f8df9d9aa63c208cf74517422d74" + "'", str8.equals("bfab9f6f8df9d9aa63c208cf74517422d74"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "bf68ac453fc4a485607ce96d0b000912" + "'", str10.equals("bf68ac453fc4a485607ce96d0b000912"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.9027442163606954d) + "'", double16 == (-1.9027442163606954d));
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        long long8 = randomDataImpl0.nextPoisson(2.718281828459045d);
//        randomDataImpl0.reSeedSecure();
//        double double11 = randomDataImpl0.nextExponential((double) '#');
//        try {
//            double double13 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-10.090183818664181d) + "'", double6 == (-10.090183818664181d));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 63.25274913923526d + "'", double11 == 63.25274913923526d);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 95, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.606111934732855d + "'", number4.equals(0.606111934732855d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.606111934732855d + "'", number5.equals(0.606111934732855d));
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int2 = org.apache.commons.math.util.FastMath.min(88, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.3315140559166503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7932993691410499d + "'", double1 == 0.7932993691410499d);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        try {
//            double double9 = randomDataImpl0.nextF(1.5777218104420236E-30d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 22.502680268993625d + "'", double6 == 22.502680268993625d);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        double double11 = randomDataImpl1.nextGaussian(2.7653056371838693d, 0.0034349072766937565d);
//        double double14 = randomDataImpl1.nextWeibull(0.75d, 0.067847338176858d);
//        try {
//            long long17 = randomDataImpl1.nextLong(48L, (long) 18);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 48 is larger than, or equal to, the maximum (18): lower bound (48) must be strictly less than upper bound (18)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9e8da56c05" + "'", str3.equals("9e8da56c05"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ec684f1f22a7ffae7d952ff89f7e103d015" + "'", str5.equals("ec684f1f22a7ffae7d952ff89f7e103d015"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5a9a4bd0c30f41e48ee8a346a03a71f7c50" + "'", str8.equals("5a9a4bd0c30f41e48ee8a346a03a71f7c50"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.7643846390747244d + "'", double11 == 2.7643846390747244d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.11793916005854349d + "'", double14 == 0.11793916005854349d);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.asin((-3.595767019810072d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.atanh(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) 7.651498724127711d, true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 71L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 71 + "'", int1 == 71);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.017609200952467312d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1774215933195176d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray17);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException7, "hi!", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable22, objArray23);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray27);
        java.lang.Throwable[] throwableArray29 = maxIterationsExceededException28.getSuppressed();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable22, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray45);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException35, "hi!", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray45);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable50, number51, (java.lang.Number) 7L, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 32);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray65);
        java.lang.Object[] objArray68 = maxIterationsExceededException67.getArguments();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable50, objArray68);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable22, objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(2, "2ae1e499f698f12016eeec07247f739ee78", objArray68);
        int int72 = maxIterationsExceededException71.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double11 = randomDataImpl1.nextWeibull(0.6931471805599453d, 0.002695222488444281d);
//        int int15 = randomDataImpl1.nextHypergeometric(100, (int) (short) 10, 28);
//        long long18 = randomDataImpl1.nextLong((long) 'a', 106L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 93L + "'", long8 == 93L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.881528736590465E-4d + "'", double11 == 4.881528736590465E-4d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
//        randomDataImpl1.reSeedSecure(100L);
//        long long8 = randomDataImpl1.nextPoisson(1.0E-323d);
//        double double11 = randomDataImpl1.nextCauchy((-1.2246467991473532E-16d), 0.010369588560374107d);
//        randomDataImpl1.reSeedSecure(0L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.004551311003636792d + "'", double11 == 0.004551311003636792d);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double2 = org.apache.commons.math.util.FastMath.max(0.29133340463048707d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.29133340463048707d + "'", double2 == 0.29133340463048707d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (short) -1, (java.lang.Number) Double.NaN);
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.25000000029961156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.255412812202581d + "'", double1 == 0.255412812202581d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.9721522630525295E-31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.97215226305253E-31d + "'", double1 == 1.97215226305253E-31d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8904e96172" + "'", str3.equals("8904e96172"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3L + "'", long6 == 3L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, "hi!", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) convergenceException26);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable21);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.10137427916442361d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable25, objArray26);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable25, objArray39);
        boolean boolean41 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean42 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test375");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double4 = normalDistributionImpl0.density((double) 'a');
//        double double5 = normalDistributionImpl0.getMean();
//        double double6 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.density((double) '4');
//        double double10 = normalDistributionImpl0.density(0.0d);
//        double double11 = normalDistributionImpl0.sample();
//        double double13 = normalDistributionImpl0.inverseCumulativeProbability(1.617185871519405E-4d);
//        normalDistributionImpl0.reseedRandomGenerator(20L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.2580519526305511d) + "'", double11 == (-0.2580519526305511d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-3.595767019810072d) + "'", double13 == (-3.595767019810072d));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.631679556835387E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0005633265645297d + "'", double1 == 1.0005633265645297d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.cos(37.95743042488804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9668208717742803d + "'", double1 == 0.9668208717742803d);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 5, 0.00743658438525312d, 999.0352190672713d);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.006929558532804d + "'", double4 == 5.006929558532804d);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.718281828459045d, 0.003434900522220323d, (-48.21273601220948d));
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability((double) 47, 0.8069061696794684d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(32);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
        java.lang.Object[] objArray8 = notStrictlyPositiveException7.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(88, "45a1a6042f", objArray8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable25, objArray26);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable25, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 4.9E-324d);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException43);
        java.lang.String str45 = numberIsTooLargeException3.toString();
        boolean boolean46 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0.606)" + "'", str45.equals("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0.606)"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        double double8 = randomDataImpl1.nextCauchy((-48.21273601220948d), (double) (short) 100);
//        randomDataImpl1.reSeedSecure((long) 10);
//        long long13 = randomDataImpl1.nextSecureLong((long) (byte) 1, (long) 47);
//        try {
//            int int16 = randomDataImpl1.nextSecureInt(97, 48);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (48): lower bound (97) must be strictly less than upper bound (48)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "471dd2baf0" + "'", str3.equals("471dd2baf0"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e652e5af67626c5fe42405e6fbeee1f5c51" + "'", str5.equals("e652e5af67626c5fe42405e6fbeee1f5c51"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-103.69977780904695d) + "'", double8 == (-103.69977780904695d));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7L + "'", long1 == 7L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, "hi!", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5370011680964748E15d, (java.lang.Number) 50L, false);
        java.lang.Object[] objArray26 = numberIsTooLargeException25.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable21, objArray26);
        java.lang.Throwable throwable28 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException33);
        java.lang.Throwable[] throwableArray35 = outOfRangeException33.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable28, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (32) exceeded", (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable21, (java.lang.Object[]) throwableArray35);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 1.1102230246251565E-16d, number39, false);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 41L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3984349353005491E17d + "'", double1 == 6.3984349353005491E17d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable3, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("hi!", objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(throwable0, "9809c961a6626bb1fac11f840be47038cca", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException26, "hi!", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable21, objArray36);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, "hi!", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable0, objArray36);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray36);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        long long6 = randomDataImpl1.nextLong((long) 32, (long) (byte) 100);
//        java.lang.String str8 = randomDataImpl1.nextHexString(10);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "151198a60c" + "'", str3.equals("151198a60c"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 92L + "'", long6 == 92L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "df0d6421b1" + "'", str8.equals("df0d6421b1"));
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        long long1 = org.apache.commons.math.util.FastMath.abs(105L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 105L + "'", long1 == 105L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21, "hi!", objArray31);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable17, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray48 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray48);
        outOfRangeException41.addSuppressed((java.lang.Throwable) convergenceException49);
        java.lang.Object[] objArray51 = outOfRangeException41.getArguments();
        mathException16.addSuppressed((java.lang.Throwable) outOfRangeException41);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray51);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(31);
//        try {
//            randomDataImpl0.setSecureAlgorithm("e9ef5748cdd3241382b84a0343c45bea", "078245433591c4262de8a5eee3b457f4cb9977a8767bc443d144ea52d3b17158e28c3aa80c57d4bcd4d43c93d30e94256c26");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 078245433591c4262de8a5eee3b457f4cb9977a8767bc443d144ea52d3b17158e28c3aa80c57d4bcd4d43c93d30e94256c26");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4c5197a960c12aacb5c1469eb064395" + "'", str5.equals("4c5197a960c12aacb5c1469eb064395"));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 0.3996581954612728d, (java.lang.Number) 30.192931321154465d, false);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(number27, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number31 = numberIsTooLargeException30.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, "hi!", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException51.getGeneralPattern();
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable52, objArray53);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray63);
        java.lang.Object[] objArray66 = maxIterationsExceededException65.getArguments();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException30, localizable52, objArray66);
        java.lang.Throwable[] throwableArray68 = mathException67.getSuppressed();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable18, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 0.07836479909182345d, (java.lang.Number) 0.9999683920075999d, (java.lang.Number) 0.014300169858597285d);
        java.lang.Throwable throwable76 = null;
        java.lang.Number number80 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number80);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException81);
        java.lang.Throwable[] throwableArray83 = outOfRangeException81.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException(throwable76, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (32) exceeded", (java.lang.Object[]) throwableArray83);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "015b695622", (java.lang.Object[]) throwableArray83);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException(localizable18, (java.lang.Object[]) throwableArray83);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(throwableArray83);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.004947214450574307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004947194270341328d + "'", double1 == 0.004947194270341328d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.6449340668481562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.tanh(32.127235520414196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        outOfRangeException24.addSuppressed((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException39, "hi!", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("", objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException60, "hi!", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable55, objArray70);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException53, "hi!", objArray70);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable34, objArray70);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException18, "1094da2698554c760fd2bdc788f1c8540df3543851603a91e6e3511295424ab9d4e07765e982c64953aa6aa694ac5218a781", objArray70);
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException78.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException81 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
        java.lang.Object[] objArray82 = notStrictlyPositiveException81.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException(throwable0, localizable79, objArray82);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(localizable79);
        org.junit.Assert.assertNotNull(objArray82);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double10 = randomDataImpl1.nextT(205.16819948264123d);
//        randomDataImpl1.reSeed(34L);
//        int int15 = randomDataImpl1.nextPascal(100, 0.0d);
//        try {
//            java.lang.String str17 = randomDataImpl1.nextHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 90L + "'", long8 == 90L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.6229127871269484d + "'", double10 == 2.6229127871269484d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-16.857679757182947d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.log(6.29823235108913E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.370071357140604d) + "'", double1 == (-7.370071357140604d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int2 = org.apache.commons.math.util.FastMath.min(28, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 6.29823235108913E-4d, false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (short) 10, (java.lang.Number) 1, false);
        java.lang.Number number29 = numberIsTooLargeException28.getMax();
        java.lang.Object[] objArray30 = numberIsTooLargeException28.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable0, objArray30);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1 + "'", number29.equals(1));
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) 'a');
        double double7 = normalDistributionImpl0.cumulativeProbability(1.0E-9d, 0.7327540948844548d);
        double double8 = normalDistributionImpl0.getMean();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.26814578754952245d + "'", double7 == 0.26814578754952245d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.718281828459045d, 0.003434900522220323d, (-48.21273601220948d));
        double double5 = normalDistributionImpl3.density((double) 10L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6483608274590866d, (-0.9443504370351304d), 3.174802103936399d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.5309649148733837d), 1.0264863006379712d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.sinh(20.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4258259770489514E8d + "'", double1 == 2.4258259770489514E8d);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test412");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextChiSquare(31.887903591703434d);
//        int int11 = randomDataImpl1.nextSecureInt(9, 48);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8a3666d988" + "'", str3.equals("8a3666d988"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b5472f7678d3f47e04d8f0e675bf3a395b0" + "'", str5.equals("b5472f7678d3f47e04d8f0e675bf3a395b0"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 41.251060545595756d + "'", double8 == 41.251060545595756d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 25 + "'", int11 == 25);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNull(localizable25);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-3.9964692763675984d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5869338582795511d) + "'", double1 == (-1.5869338582795511d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) Double.NaN, (java.lang.Number) (-0.9583907740748763d), (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 0.3996581954612728d, (java.lang.Number) 30.192931321154465d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) (short) -1, (java.lang.Number) 0, (java.lang.Number) (byte) 0);
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray39);
        outOfRangeException32.addSuppressed((java.lang.Throwable) convergenceException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException40.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) 10, (java.lang.Number) 1L, (java.lang.Number) 10);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable42, objArray47);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable42);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(1.0E-9d);
        double double4 = normalDistributionImpl0.density((double) 'a');
        double double5 = normalDistributionImpl0.getMean();
        double double6 = normalDistributionImpl0.getMean();
        double[] doubleArray8 = normalDistributionImpl0.sample((int) (short) 1);
        try {
            double[] doubleArray10 = normalDistributionImpl0.sample((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.9129311827723892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.089108549016012d + "'", double1 == 1.089108549016012d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, "hi!", objArray32);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17, localizable18, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.String str38 = convergenceException37.toString();
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException37.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.ConvergenceException: " + "'", str38.equals("org.apache.commons.math.ConvergenceException: "));
        org.junit.Assert.assertNotNull(localizable39);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable20, objArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(32);
        java.lang.Object[] objArray2 = maxIterationsExceededException1.getArguments();
        java.lang.Throwable[] throwableArray3 = maxIterationsExceededException1.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable25, objArray26);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable25, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 4.9E-324d);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException43);
        java.lang.Number number45 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0.606111934732855d + "'", number45.equals(0.606111934732855d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.525161361065413d + "'", double1 == 8.525161361065413d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5705654518541791d, 0.9314614933708413d, (double) 16L, 5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5751609400920701d + "'", double4 == 0.5751609400920701d);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "533fa1d0b6" + "'", str3.equals("533fa1d0b6"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dd1127d0f898b04ce50631a67d58d02f999" + "'", str8.equals("dd1127d0f898b04ce50631a67d58d02f999"));
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(59.18142598372261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 59.18142598372262d + "'", double1 == 59.18142598372262d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 48, 88L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 88L + "'", long2 == 88L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.9E-324d, (java.lang.Number) (-0.017453292519943292d), (java.lang.Number) 3.199329338564076E-7d);
        convergenceException7.addSuppressed((java.lang.Throwable) outOfRangeException12);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        double double12 = randomDataImpl1.nextGaussian(0.6470434810831891d, 4.158638853279167d);
//        double double15 = randomDataImpl1.nextBeta(30.801616763608024d, 1.1977461928657023d);
//        java.lang.String str17 = randomDataImpl1.nextSecureHexString(32);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1939a4bd15" + "'", str3.equals("1939a4bd15"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.004145145602012776d + "'", double6 == 0.004145145602012776d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.803895506761905d + "'", double12 == 4.803895506761905d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9943084731581333d + "'", double15 == 0.9943084731581333d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dd22e18f568c6662da3d253c659e015e" + "'", str17.equals("dd22e18f568c6662da3d253c659e015e"));
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test429");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        long long9 = randomDataImpl1.nextLong(0L, 10L);
//        double double11 = randomDataImpl1.nextChiSquare(0.008554418607742533d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(32);
//        double double16 = randomDataImpl1.nextWeibull((double) 18, 1.3440585709080678E43d);
//        try {
//            int int19 = randomDataImpl1.nextPascal((int) (byte) 100, (-1.1174547283891925d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.117 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "656503bb72" + "'", str3.equals("656503bb72"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.004733436473738242d + "'", double6 == 0.004733436473738242d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-323d + "'", double11 == 1.0E-323d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "48e13ca712009aadb4a03b725f7bfc1e" + "'", str13.equals("48e13ca712009aadb4a03b725f7bfc1e"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4146709471443497E43d + "'", double16 == 1.4146709471443497E43d);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextSecureInt(2147483647, 18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (18): lower bound (2,147,483,647) must be strictly less than upper bound (18)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, "hi!", objArray32);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-4.568877933480165d), (java.lang.Number) 1.0d, (java.lang.Number) 1);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18, localizable37, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException63, "hi!", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: hi!", objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(7, "63de2ac8bba1abb7edeacdf7473527052a0", objArray73);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18, "423a77f9b7", objArray73);
        java.lang.Object[] objArray82 = mathException81.getArguments();
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.9E-324d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 387L, (-185.46358606610423d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 386.99999999999994d + "'", double2 == 386.99999999999994d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.631679556835387E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.631680152213182E-4d + "'", double1 == 5.631680152213182E-4d);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.502818138177393d + "'", double3 == 31.502818138177393d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6931471805599453d + "'", double4 == 0.6931471805599453d);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) (short) -1, 0);
//        randomDataImpl1.reSeedSecure(100L);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("1992168b6a635a1d74bfaf069810c815948", "c739a3ccec8742fd4a95e607c30f9ce562d");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c739a3ccec8742fd4a95e607c30f9ce562d");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 83.99773258750342d + "'", double8 == 83.99773258750342d);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        double double9 = randomDataImpl1.nextCauchy(0.0d, 5.006929558532804d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bd2cbe9d56" + "'", str3.equals("bd2cbe9d56"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3L + "'", long6 == 3L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.5060691575309575d) + "'", double9 == (-0.5060691575309575d));
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double2 = org.apache.commons.math.util.FastMath.pow(32.127235520414196d, 0.8069061696794684d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.440136107437066d + "'", double2 == 16.440136107437066d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int2 = org.apache.commons.math.util.FastMath.max(7, 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.851651954097903E8d, 5.961005339623274d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        long long1 = org.apache.commons.math.util.FastMath.round(1.6449340668483272d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        double double8 = randomDataImpl1.nextGaussian((-4.568877933480165d), 3.941597514286071d);
//        double double11 = randomDataImpl1.nextF(3.141592653589793d, 0.255412812202581d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.1505012069885474d + "'", double8 == 2.1505012069885474d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4425027.396943756d + "'", double11 == 4425027.396943756d);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (-4.568877933480165d), (java.lang.Number) 1.0d, (java.lang.Number) 1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 0.8860927126647652d);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(36, "2cf469d315be094006b6222e0b9cafbd631", objArray10);
        java.lang.Object[] objArray14 = maxIterationsExceededException13.getArguments();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6187774595471821d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8145881872604601d + "'", double1 == 0.8145881872604601d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(36, "2cf469d315be094006b6222e0b9cafbd631", objArray10);
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(number14, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, "hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable39, objArray40);
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray50);
        java.lang.Object[] objArray53 = maxIterationsExceededException52.getArguments();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException17, localizable39, objArray53);
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13, localizable39, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9943084731581333d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.signum(114.39639083088666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test449");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        double double6 = randomDataImpl0.nextCauchy(7.934495855139244E-5d, (double) 34L);
//        long long8 = randomDataImpl0.nextPoisson(2.718281828459045d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 5, 0.00743658438525312d, 999.0352190672713d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double16 = randomDataImpl0.nextUniform(0.26814578754952245d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.268 is larger than, or equal to, the maximum (0): lower bound (0.268) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.689798523996929d + "'", double6 == 8.689798523996929d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.0d + "'", double13 == 5.0d);
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test450");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
//        double double11 = normalDistributionImpl10.sample();
//        double double12 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        double double13 = normalDistributionImpl10.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b2001fb058" + "'", str3.equals("b2001fb058"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.00797845032867582d + "'", double6 == 0.00797845032867582d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 31.761156310010467d + "'", double11 == 31.761156310010467d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 31.391090637118005d + "'", double12 == 31.391090637118005d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.6931471805599453d + "'", double13 == 0.6931471805599453d);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.FastMath.sin(32.41739544489645d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8422637316233598d + "'", double1 == 0.8422637316233598d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 50L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0710678118654755d + "'", double1 == 7.0710678118654755d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int1 = org.apache.commons.math.util.FastMath.round(58.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58 + "'", int1 == 58);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test454");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double10 = randomDataImpl1.nextT(205.16819948264123d);
//        randomDataImpl1.reSeed(34L);
//        long long14 = randomDataImpl1.nextPoisson(2.7653056371838693d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 46L + "'", long8 == 46L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3953517761334897d + "'", double10 == 0.3953517761334897d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3L + "'", long14 == 3L);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0015515614761480293d, (java.lang.Number) 0.29547209042283173d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test456");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        double double12 = randomDataImpl1.nextGaussian(0.6470434810831891d, 4.158638853279167d);
//        double double15 = randomDataImpl1.nextBeta(30.801616763608024d, 1.1977461928657023d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.773691189871375d, (double) 52.0f);
//        double double19 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        double double20 = normalDistributionImpl18.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5f3186b560" + "'", str3.equals("5f3186b560"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.513878063373301E-4d + "'", double6 == 5.513878063373301E-4d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-4.582819475215012d) + "'", double12 == (-4.582819475215012d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9826339965249867d + "'", double15 == 0.9826339965249867d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-69.36316004863725d) + "'", double19 == (-69.36316004863725d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 52.0d + "'", double20 == 52.0d);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test457");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-69.36316004863725d), 1.3078752130143855E43d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.801582108272478E43d) + "'", double4 == (-1.801582108272478E43d));
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.4666682541391603d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4891.709715267259d, 1.9129311827723892d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4891.709715267258d + "'", double2 == 4891.709715267258d);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test460");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double10 = randomDataImpl1.nextT(205.16819948264123d);
//        randomDataImpl1.reSeed(34L);
//        double double15 = randomDataImpl1.nextGaussian((-0.3684134059513968d), 0.44256975423046224d);
//        randomDataImpl1.reSeed(78L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 93L + "'", long8 == 93L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.2431670702146738d) + "'", double10 == (-2.2431670702146738d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.1578595126318345d + "'", double15 == 0.1578595126318345d);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test461");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextChiSquare(31.887903591703434d);
//        double double11 = randomDataImpl1.nextUniform((-0.017453292519943292d), (double) 52.0f);
//        randomDataImpl1.reSeedSecure((long) (-1));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6e250cb2dc" + "'", str3.equals("6e250cb2dc"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1686e8c43721c806c88775f900da471b931" + "'", str5.equals("1686e8c43721c806c88775f900da471b931"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 30.01678921323695d + "'", double8 == 30.01678921323695d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.91838996776829d + "'", double11 == 9.91838996776829d);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(78.0922235533153d, (-2.2570957787672725d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 10.0f, number28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException29);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("hi!", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "a04ec54c0f", objArray41);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException23, "151198a60c", objArray41);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray41);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test465");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        double double11 = randomDataImpl1.nextGaussian(2.7653056371838693d, 0.0034349072766937565d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(16);
//        double double15 = randomDataImpl1.nextChiSquare(999.0352190672713d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "225e3aa525" + "'", str3.equals("225e3aa525"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a9368e4a7f5de1693db984fbf97a6fd3824" + "'", str5.equals("a9368e4a7f5de1693db984fbf97a6fd3824"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6a9236b6265f41f6c11f3d7c47acd192a2e" + "'", str8.equals("6a9236b6265f41f6c11f3d7c47acd192a2e"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.769162204979267d + "'", double11 == 2.769162204979267d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "c8909ff54d7b1be9" + "'", str13.equals("c8909ff54d7b1be9"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 966.3065389378377d + "'", double15 == 966.3065389378377d);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable1, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray11);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 0.9321183878737558d, (java.lang.Number) 63520.31010288529d, (java.lang.Number) 0.291547545349534d);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test467");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) '#');
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str8 = randomDataImpl1.nextHexString((int) '#');
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) ' ');
//        long long12 = randomDataImpl1.nextPoisson(0.06879385441271617d);
//        double double15 = randomDataImpl1.nextGaussian(0.0264017010081258d, 0.9999999999999327d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bb0f82a402" + "'", str3.equals("bb0f82a402"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "27c279c71c0318324e842b387913c3524b0" + "'", str5.equals("27c279c71c0318324e842b387913c3524b0"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4230766d2675450b9602f342b37ac31c0bb" + "'", str8.equals("4230766d2675450b9602f342b37ac31c0bb"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9b4724655fcb05d98ceafceeff5a85e4" + "'", str10.equals("9b4724655fcb05d98ceafceeff5a85e4"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.8239219866086068d) + "'", double15 == (-0.8239219866086068d));
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.02323585633605363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.57656326028743d) + "'", double1 == (-43.57656326028743d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 10, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (short) -1, (java.lang.Number) 1, false);
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(number30, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number34 = numberIsTooLargeException33.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException40, "hi!", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        java.lang.Object[] objArray56 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable55, objArray56);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray66);
        java.lang.Object[] objArray69 = maxIterationsExceededException68.getArguments();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException33, localizable55, objArray69);
        java.lang.Throwable[] throwableArray71 = mathException70.getSuppressed();
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(throwable5, localizable25, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable74, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("hi!", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, localizable25, objArray77);
        java.lang.String str81 = convergenceException80.getPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "" + "'", str81.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.470844369773625E-22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.470844369773625E-22d + "'", double1 == 2.470844369773625E-22d);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test471");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextCauchy((double) (byte) 0, (double) (byte) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "f2589dc67b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f2589dc67b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "65afe8fbbd" + "'", str3.equals("65afe8fbbd"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 133.93195538764974d + "'", double6 == 133.93195538764974d);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test472");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.6931471805599453d);
//        double double3 = normalDistributionImpl2.sample();
//        normalDistributionImpl2.reseedRandomGenerator((-1L));
//        double double7 = normalDistributionImpl2.density((-3.721719480081721d));
//        double double8 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.895546135399748d + "'", double3 == 31.895546135399748d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 33.237497454686014d + "'", double8 == 33.237497454686014d);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        boolean boolean17 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number18 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, "hi!", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getGeneralPattern();
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, number39, (java.lang.Number) 7L, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray60);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException50, "hi!", objArray60);
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) 1, mathException63 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("hi!", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(100, "org.apache.commons.math.MathException: ", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable38, objArray64);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        java.lang.String str69 = convergenceException67.toString();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-0.5872139151569291d) + "'", number18.equals((-0.5872139151569291d)));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "org.apache.commons.math.ConvergenceException: " + "'", str69.equals("org.apache.commons.math.ConvergenceException: "));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test474");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextBeta(0.7327540948844548d, (double) 100.0f);
//        int int9 = randomDataImpl1.nextInt(0, (int) '4');
//        try {
//            double double12 = randomDataImpl1.nextWeibull((-1.2332869472676689d), 7.731159635128786E-4d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.233 is smaller than, or equal to, the minimum (0): shape (-1.233)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dca8a1e9bd" + "'", str3.equals("dca8a1e9bd"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.020356089050501288d + "'", double6 == 0.020356089050501288d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 46 + "'", int9 == 46);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.abs(39.109078465911004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.109078465911004d + "'", double1 == 39.109078465911004d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.2024811977090607E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0987256093348007E-6d + "'", double1 == 2.0987256093348007E-6d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeed((long) 1);
        java.lang.String str9 = randomDataImpl1.nextHexString(71);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "f3559a3b581c3899ef8e7be81279cde87c4cacb57038c6896571acd55d052b2855593e7" + "'", str9.equals("f3559a3b581c3899ef8e7be81279cde87c4cacb57038c6896571acd55d052b2855593e7"));
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test478");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal((int) ' ', 0.0d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(31);
//        try {
//            double double7 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "18d4c4ecd7ec33898dfbc673d5a53b5" + "'", str5.equals("18d4c4ecd7ec33898dfbc673d5a53b5"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21, "hi!", objArray31);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable17, objArray31);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray39);
        java.lang.Throwable[] throwableArray41 = maxIterationsExceededException40.getSuppressed();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, "", (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(localizable43);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test480");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        int[] intArray11 = randomDataImpl1.nextPermutation((int) '4', (int) (short) 1);
//        try {
//            long long14 = randomDataImpl1.nextSecureLong(38L, 34L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 38 is larger than, or equal to, the maximum (34): lower bound (38) must be strictly less than upper bound (34)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 20.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7144176165949068d + "'", double1 == 2.7144176165949068d);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test482");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeed();
//        double double11 = randomDataImpl1.nextBeta(0.014300169858597285d, 1.2024811977090607E-4d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.999999998939652d + "'", double11 == 0.999999998939652d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.special.Erf.erf((-4.440892098500626E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.011010127267165E-16d) + "'", double1 == (-5.011010127267165E-16d));
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test484");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
//        long long8 = randomDataImpl1.nextSecureLong((long) ' ', (long) (short) 100);
//        double double11 = randomDataImpl1.nextWeibull(0.6931471805599453d, 0.002695222488444281d);
//        double double13 = randomDataImpl1.nextExponential((double) 1.0f);
//        double double16 = randomDataImpl1.nextGamma((double) 28L, 1.970526002457483d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 57L + "'", long8 == 57L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.174812738735875E-5d + "'", double11 == 5.174812738735875E-5d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8176495172341062d + "'", double13 == 0.8176495172341062d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 54.52592309703006d + "'", double16 == 54.52592309703006d);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6050701709847575d + "'", double1 == 4.6050701709847575d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.special.Erf.erf((-4.16038520882935d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999959874021d) + "'", double1 == (-0.9999999959874021d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 100, (int) (short) 1);
        randomDataImpl1.reSeedSecure((long) (short) 10);
        randomDataImpl1.reSeedSecure((long) 48);
        randomDataImpl1.reSeedSecure(110L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.01760920095246731d), (java.lang.Number) 1.0276542587345318E-9d, number2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 63520.31010288529d, (java.lang.Number) 0.003434900522220323d, (java.lang.Number) (-0.9443504370351304d));
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.9443504370351304d) + "'", number4.equals((-0.9443504370351304d)));
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test492");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(1.0E-9d);
//        double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 10, 10.0d);
//        double[] doubleArray7 = normalDistributionImpl0.sample((int) (byte) 10);
//        double double9 = normalDistributionImpl0.density(0.0d);
//        double double10 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator((long) (short) 0);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3989422804014327d + "'", double9 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3678407272686666d + "'", double10 == 0.3678407272686666d);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.466711037884725d + "'", double1 == 3.466711037884725d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-85.51912676833847d), 59.18142598372262d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, number21, (java.lang.Number) 7L, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "hi!", objArray35);
        java.lang.Object[] objArray38 = maxIterationsExceededException37.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable20, objArray38);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray53);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException43, "hi!", objArray53);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.5872139151569291d), (java.lang.Number) (short) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 10.0d, 0L, 10.0f, (-1L), 10.0f };
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("", objArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray71);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException61, "hi!", objArray71);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56, localizable57, objArray71);
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray79);
        java.lang.Throwable[] throwableArray81 = maxIterationsExceededException80.getSuppressed();
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56, "", (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException(6, localizable20, (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException83);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray81);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.4223903734353027d, (-0.0643321090394411d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.3806392494386521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14008021554825187d + "'", double1 == 0.14008021554825187d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.05860802438421144d, 0.9931154986385148d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.013771948303472392d + "'", double2 == 0.013771948303472392d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(number2, (java.lang.Number) 0.606111934732855d, true);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 'a', 1 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable10, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        java.lang.Object[] objArray16 = convergenceException15.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "015b695622", objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException18.getGeneralPattern();
        int int20 = maxIterationsExceededException18.getMaxIterations();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32 + "'", int20 == 32);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(18, "3e0333205c", objArray2);
    }
}

