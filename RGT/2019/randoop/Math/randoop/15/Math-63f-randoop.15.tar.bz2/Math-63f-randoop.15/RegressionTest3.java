import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 286.4788975654116d + "'", double1 == 286.4788975654116d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.503599627370496E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.503599627370496E15d + "'", double1 == 4.503599627370496E15d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        long long2 = org.apache.commons.math.util.FastMath.max(351L, (-8447890881994136687L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 351L + "'", long2 == 351L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        float float2 = org.apache.commons.math.util.FastMath.max(1048576.0f, (float) 1095479168L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.09547917E9f + "'", float2 == 1.09547917E9f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2.0f, 0.8221188003905089d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.584967478670572d, (java.lang.Number) 341642502, 33974111, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.signum(14.556090791759079d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        long long1 = org.apache.commons.math.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(198760639L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1752011936438014d, (java.lang.Number) (-1048577), 1040712641, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.5323384274693232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2619600956683044d + "'", double1 == 1.2619600956683044d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray17);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.0d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 198760607 + "'", int18 == 198760607);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.1582918005242d + "'", double19 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 101.1582918005242d + "'", double20 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1.03355648E10f, 3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(800, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 852 + "'", int2 == 852);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.6057648134614585d), 0.0d, 3333);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1726527327, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.485919022334542E85d + "'", double2 == 6.485919022334542E85d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1991599724L, (int) '4', 877278303);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1076101120L, (-19337682720L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-18261581600L) + "'", long2 == (-18261581600L));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray13 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        java.lang.Class<?> wildcardClass31 = doubleArray24.getClass();
        double[] doubleArray35 = new double[] { '#', 1.0d, 'a' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray41 = new double[] { '#', 1.0d, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray41);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray41);
        double[] doubleArray64 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray68 = new double[] { '#', 1.0d, 'a' };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray68);
        double[] doubleArray74 = new double[] { '#', 1.0d, 'a' };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 877278303 + "'", int30 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 103.12613635737547d + "'", double36 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 103.12613635737547d + "'", double37 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 877278303 + "'", int43 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 198760607 + "'", int56 == 198760607);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.1582918005242d + "'", double57 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.1582918005242d + "'", double58 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 103.12613635737547d + "'", double69 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 877278303 + "'", int77 == 877278303);
        org.junit.Assert.assertEquals((double) double78, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.0f), (-71535587));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0947125472611012d + "'", double1 == 2.0947125472611012d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1095479168);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1580182805) + "'", int1 == (-1580182805));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(852);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.726527371E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13713890125560907d) + "'", double1 == (-0.13713890125560907d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 989493378);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray19 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.0d);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 8.298330314378324d);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray19);
        double[] doubleArray36 = null;
        try {
            double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 198760607 + "'", int20 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 877278303);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 877278272 + "'", int1 == 877278272);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-0.4376423325770494d), 99.99499987499378d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-10.158170418955065d), (double) 375616613L, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1726527423), 1095479168);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483646) + "'", int2 == (-2147483646));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(800);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1726527360));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-3628800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1048576, (long) 198760639);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 208415635800064L + "'", long2 == 208415635800064L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 198760607);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.107611678628125d + "'", double1 == 19.107611678628125d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1726527360), 3.626860407847019d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.712794303894043d + "'", double2 == 1.712794303894043d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1078001664, (-18261581600L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078001664L + "'", long2 == 1078001664L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, 1683002521388203394L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(34, 33974111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33974145 + "'", int2 == 33974145);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9995192260716705d), 9.000484749877465d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1726527327, (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1726527327 + "'", int2 == 1726527327);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1, (-0.01057259048763172d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5813685233753891d + "'", double2 == 1.5813685233753891d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-22), 0.36601461728382423d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.132741228718345d + "'", double2 == 3.132741228718345d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.033203346412116204d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03320944765421979d) + "'", double1 == (-0.03320944765421979d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.0959191077119637d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, (-1580182805));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int2 = org.apache.commons.math.util.MathUtils.pow(198760639, 11L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1829609409) + "'", int2 == (-1829609409));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3333);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(34, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-45.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1112248228));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1370.371413881156d, 35651585);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2740.742827762312d + "'", double2 == 2740.742827762312d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999329299739067d + "'", double1 == 0.999329299739067d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1040712641);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2L, 50L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-48L) + "'", long2 == (-48L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.7184493636924868d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, (-5063141360940L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1347840285), (-1580182805), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.NEGATIVE_INFINITY + "'", float3 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1L, (long) (-96));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0959191077119637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4572292555561042d + "'", double1 == 0.4572292555561042d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 3.0d);
        java.lang.Class<?> wildcardClass20 = doubleArray12.getClass();
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((-8.4478909E18f), 341642502, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-128256026) + "'", int35 == (-128256026));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 14218459054895680L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.42184592E16f + "'", float2 == 1.42184592E16f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7745966692414834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7147031929542251d + "'", double1 == 0.7147031929542251d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1726527327), (-9.892273157211768E10d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.726527327E9d) + "'", double2 == (-1.726527327E9d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1807701355);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(35651586, 54766527);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1582015220), (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-48L), (float) 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33.0f + "'", float2 == 33.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 3.0d);
        java.lang.Class<?> wildcardClass11 = doubleArray3.getClass();
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray18 = null;
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray25 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray15);
        double[] doubleArray33 = new double[] { '#', 1.0d, 'a' };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray39 = new double[] { '#', 1.0d, 'a' };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray45 = new double[] { '#', 1.0d, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray53 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray53);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray39);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 198760607 + "'", int26 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 103.12613635737547d + "'", double28 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 103.12613635737547d + "'", double34 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 103.12613635737547d + "'", double35 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 877278303 + "'", int41 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 877278303 + "'", int47 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 198760607 + "'", int54 == 198760607);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 101.1582918005242d + "'", double55 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.1582918005242d + "'", double56 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 877278303 + "'", int59 == 877278303);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 877278303, (long) 1807701355);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 754210295535290399L + "'", long2 == 754210295535290399L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-6.30716580272248E-4d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.math.util.FastMath.atan(59873.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570779624775624d + "'", double1 == 1.570779624775624d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1944683746737277d + "'", double1 == 1.1944683746737277d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 21.456318727726337d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int2 = org.apache.commons.math.util.FastMath.min(260, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray13 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        java.lang.Class<?> wildcardClass31 = doubleArray24.getClass();
        double[] doubleArray35 = new double[] { '#', 1.0d, 'a' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray41 = new double[] { '#', 1.0d, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray41);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray41);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 9.237173456633567d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 877278303 + "'", int30 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 103.12613635737547d + "'", double36 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 103.12613635737547d + "'", double37 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 877278303 + "'", int43 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 198760607 + "'", int56 == 198760607);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.1582918005242d + "'", double57 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.1582918005242d + "'", double58 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 'a');
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) ' ');
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 100);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 32);
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (-1580182805));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '#', 1.0d, 'a' };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray14 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray18);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray14);
        try {
            double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 103.12613635737547d + "'", double6 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 103.12613635737547d + "'", double9 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-2.7797302154510816E57d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0649086950273192E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0649086950273192E21d + "'", double1 == 1.0649086950273192E21d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.FastMath.log(1.2619600956683044d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.232666143704921d + "'", double1 == 0.232666143704921d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 6.283185307179586d, 198760640);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 198,760,639 and 198,760,640 are not strictly increasing (6.283 >= 100)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 198,760,639 and 198,760,640 are not strictly increasing (6.283 >= 100)"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1580182805));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.873953557219664d) + "'", double1 == (-21.873953557219664d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(341642502, 198760639);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double2 = org.apache.commons.math.util.FastMath.max(2.2396109578603927d, 9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.848857801796104d + "'", double2 == 9.848857801796104d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.298330314378324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.298330314378326d + "'", double1 == 8.298330314378326d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getPrevious();
        java.lang.String str15 = nonMonotonousSequenceException10.toString();
        int int16 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1040712641 + "'", number14.equals(1040712641));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly decreasing (1,040,712,641 <= 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly decreasing (1,040,712,641 <= 0)"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.0857586789923365d), (-0.7921204236492381d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-4.9E-324d), (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1074790400), 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074789600) + "'", int2 == (-1074789600));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) 1683002521388203393L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.68300252E18f + "'", float2 == 1.68300252E18f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1582015220), (-0.9589328250406132d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.0d, (double) (-96));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 989493378, (-1582015220));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7745966692414834d, (java.lang.Number) 800L, 99);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 800L + "'", number4.equals(800L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 32L, (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray32 = new double[] { '#', 1.0d, 'a' };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray44 = new double[] { '#', 1.0d, 'a' };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray52 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray52);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray32);
        double[] doubleArray61 = new double[] { '#', 1.0d, 'a' };
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray67 = new double[] { '#', 1.0d, 'a' };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray73 = new double[] { '#', 1.0d, 'a' };
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double[] doubleArray81 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray73, doubleArray81);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray81);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray67);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray67);
        java.lang.Class<?> wildcardClass88 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 877278303 + "'", int20 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198760607 + "'", int27 == 198760607);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.1582918005242d + "'", double28 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 103.12613635737547d + "'", double33 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 103.12613635737547d + "'", double34 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 877278303 + "'", int40 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 877278303 + "'", int46 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 198760607 + "'", int53 == 198760607);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 101.1582918005242d + "'", double54 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 101.1582918005242d + "'", double55 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 103.12613635737547d + "'", double62 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 103.12613635737547d + "'", double63 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 877278303 + "'", int69 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 103.12613635737547d + "'", double74 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 877278303 + "'", int75 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 198760607 + "'", int82 == 198760607);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 101.1582918005242d + "'", double83 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 101.1582918005242d + "'", double84 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass88);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(104.41264291262816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.708880793217597d + "'", double1 == 4.708880793217597d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1987606070);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 983569537);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1000.3721285031997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.60127426900851d + "'", double1 == 7.60127426900851d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1728455558494460171L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2453876422820638371L + "'", long2 == 2453876422820638371L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 989493378, 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.FastMath.asin(23.140692632779267d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 0, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1001116801, 2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.384185791015625E-7d + "'", double2 == 2.384185791015625E-7d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 198760607 + "'", int14 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(5.2964307604833567E18d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.2964307604833567E18d + "'", double2 == 5.2964307604833567E18d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(351L, (-1074789600));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 34L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5290826861200238d + "'", double1 == 0.5290826861200238d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { '#', 1.0d, 'a' };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray17);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray66 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray52);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 103.12613635737547d + "'", double30 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 198760607 + "'", int38 == 198760607);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 101.1582918005242d + "'", double39 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 877278303 + "'", int54 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 198760607 + "'", int67 == 198760607);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 877278303 + "'", int74 == 877278303);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-3628802));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628802L + "'", long2 == 3628802L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.atanh(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.7265273709999998E9d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-5815114969559414353L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.8151149695594148E18d) + "'", double1 == (-5.8151149695594148E18d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.726527327E9d), (java.lang.Number) (-9.369284411097881E148d), 35651586, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.3370706212950894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8078724507617987d + "'", double1 == 2.8078724507617987d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3628800.0d, (-128256026));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.054073333740234375d) + "'", double2 == (-0.054073333740234375d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray13 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray30 = new double[] { '#', 1.0d, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray36 = new double[] { '#', 1.0d, 'a' };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray44 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray44);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray44);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray55);
        double[] doubleArray62 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray62);
        double[] doubleArray68 = new double[] { '#', 1.0d, 'a' };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray76 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray68);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray68);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray30);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 877278303 + "'", int32 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 103.12613635737547d + "'", double37 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 877278303 + "'", int38 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 198760607 + "'", int45 == 198760607);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 101.1582918005242d + "'", double46 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.1582918005242d + "'", double47 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 103.12613635737547d + "'", double54 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 198760607 + "'", int63 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 103.12613635737547d + "'", double69 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 877278303 + "'", int70 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 198760607 + "'", int77 == 198760607);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 101.1582918005242d + "'", double78 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 103.12613635737547d + "'", double82 == 103.12613635737547d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.FastMath.expm1(8.804475161328668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6662.999849939978d + "'", double1 == 6662.999849939978d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1, (long) 1987606070);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1987606069L) + "'", long2 == (-1987606069L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.054073333740234375d), (double) 1987606070);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.720525689491096E-11d) + "'", double2 == (-2.720525689491096E-11d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.60127426900851d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.151910363098194d + "'", double1 == 2.151910363098194d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(852);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1394038287));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(6.362265131567328d, 1.4163847498715596d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(32, 877278272);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1191.557996762041d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 34, (-95));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        long long2 = org.apache.commons.math.util.FastMath.max(206124209575858481L, (long) (-1726527327));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 206124209575858481L + "'", long2 == 206124209575858481L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.2075343299958265d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 32, (double) 3628800.0f, (-0.7359704175800968d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.848857801796104d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(198760639);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean14 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.07859149E9f, (java.lang.Number) 0.1900628023411102d, (int) (byte) 100, orderDirection9, true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1074789600), 5063141360940L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        long long2 = org.apache.commons.math.util.MathUtils.pow(375616613L, 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7627252785293671909L + "'", long2 == 7627252785293671909L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int int2 = org.apache.commons.math.util.FastMath.max(99, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 198760639L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 33);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 33974111);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 33974111L + "'", long1 == 33974111L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int int2 = org.apache.commons.math.util.FastMath.min((-1048577), (-1112248228));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1112248228) + "'", int2 == (-1112248228));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) (-206124209575858481L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.06124208E17f) + "'", float2 == (-2.06124208E17f));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 52, 1.07610112E9d, (-0.09238692595529725d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-45.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-3628800), (-1394038287));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        int int13 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number14 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 0 + "'", number14.equals((short) 0));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.4463520074491623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5640818416723474d + "'", double1 == 1.5640818416723474d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1048577), (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1048577.0f) + "'", float2 == (-1048577.0f));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray13 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int[] intArray19 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray19);
        int[] intArray33 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray40 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray33);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray19);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray56 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray56);
        int[] intArray62 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray69 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray62);
        int[] intArray76 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray83 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray76);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray62);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray62);
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 104.40785411069419d + "'", double14 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 104.40785411069419d + "'", double27 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 104.40785411069419d + "'", double41 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 104.40785411069419d + "'", double57 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 104.40785411069419d + "'", double70 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 104.40785411069419d + "'", double84 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0442841955015905d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04333167032927429d + "'", double1 == 0.04333167032927429d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 350L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009430054193516519d + "'", double1 == 0.009430054193516519d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        long long1 = org.apache.commons.math.util.FastMath.abs(98L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 98L + "'", long1 == 98L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.signum(100.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long1 = org.apache.commons.math.util.FastMath.abs((-784346679231569093L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 784346679231569093L + "'", long1 == 784346679231569093L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1726527327L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-8.4478909E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 198760639);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9876063900000003E8d + "'", double1 == 1.9876063900000003E8d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-48L), (long) 54766527);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 54766479L + "'", long2 == 54766479L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4258259770489514E8d, (java.lang.Number) 1.0f, (-1));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (1 >= 242,582,597.705)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (1 >= 242,582,597.705)"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 100, 1078001664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.548739357257748d + "'", double1 == 11.548739357257748d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(5.203117510034154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3333);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3333L + "'", long1 == 3333L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.6354383327736465E10d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 160777445 + "'", int1 == 160777445);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 754210295535290399L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double2 = org.apache.commons.math.util.FastMath.min(1.496106270390805d, (-2.720525689491096E-11d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.720525689491096E-11d) + "'", double2 == (-2.720525689491096E-11d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.19240232444172617d, 0.7248430881283403d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.30280622144666264d + "'", double2 == 0.30280622144666264d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(6.938893903907228E-18d, (-1726527327), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-5063141360940L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6972569584681471d) + "'", double1 == (-0.6972569584681471d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1001116801, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1829609409), (double) (-22));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(341642467, 1347840285);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1074789600), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9602525677891275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9799247765972281d + "'", double1 == 0.9799247765972281d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.7465010457261463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(100, (-71535587));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        long long1 = org.apache.commons.math.util.FastMath.abs(5296430760483356672L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5296430760483356672L + "'", long1 == 5296430760483356672L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 7627252785293671909L, (-3628800));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str7 = nonMonotonousSequenceException6.toString();
        boolean boolean8 = nonMonotonousSequenceException6.getStrict();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 0.75d, (int) (short) 0, orderDirection10, false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(99, (-3628800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(271620299);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        long long2 = org.apache.commons.math.util.FastMath.max(1095479168L, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1095479168L + "'", long2 == 1095479168L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 8.298330314378324d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.000484749877465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0000807905583917d + "'", double1 == 3.0000807905583917d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray11);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 877278303 + "'", int14 == 877278303);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 39505836933114013L, 6662.999849939978d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        long long1 = org.apache.commons.math.util.FastMath.round(2.6622890612135942E-8d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1991599724, 198);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.0280589699575455d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6579440004976962d) + "'", double1 == (-1.6579440004976962d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1556.0255852847893d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1078001664);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 33974111);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.341109351360387d + "'", double1 == 17.341109351360387d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(54766527, 271620299);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int2 = org.apache.commons.math.util.FastMath.min((-71535587), 1040712641);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-71535587) + "'", int2 == (-71535587));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 33, 1078034432);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3324781745314725889L + "'", long2 == 3324781745314725889L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        long long1 = org.apache.commons.math.util.FastMath.abs(1095479168L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1095479168L + "'", long1 == 1095479168L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3332L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 190909.5373375903d + "'", double1 == 190909.5373375903d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.0779393487549d + "'", double1 == 21.0779393487549d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 50L, (-0.03549223717331409d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03549223717331409d) + "'", double2 == (-0.03549223717331409d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int2 = org.apache.commons.math.util.FastMath.min((-1726527327), (-3628802));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1726527327) + "'", int2 == (-1726527327));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 877278272, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.772782719999999E8d + "'", double2 == 8.772782719999999E8d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 95L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(21.509799193225255d, 0.4572292555561042d, (-9.369284411097881E148d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1048577), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 3332.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3332.0d + "'", double1 == 3332.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, 1991599724);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double1 = org.apache.commons.math.util.FastMath.rint(14.556090791759079d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.0d + "'", double1 == 15.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-5.8151149695594148E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.396207121659021E-8d, (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.396207121659021E-8d + "'", double2 == 3.396207121659021E-8d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        boolean boolean10 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(260);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int2 = org.apache.commons.math.util.MathUtils.pow(54766527, 1991599724L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1862128895) + "'", int2 == (-1862128895));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.2003257647899614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9995506592478776d + "'", double1 == 0.9995506592478776d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1987606070, (long) (-1726527360));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1726527360), 4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1394038287), (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean13 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.98760602E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1991599724L, (long) (-71535587));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10335565084L, (float) 33974111);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.3974112E7f + "'", float2 == 3.3974112E7f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.floor(5.8151149695594148E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.8151149695594148E18d + "'", double1 == 5.8151149695594148E18d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1580182805));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1078034335L, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078034333L + "'", long2 == 1078034333L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3332);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 190909.5373375903d + "'", double1 == 190909.5373375903d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(4, 198760607);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 795042428 + "'", int2 == 795042428);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1076101120, (-0.054073333740234375d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray31 = new double[] { '#', 1.0d, 'a' };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray41);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray47);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray47);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 198760607 + "'", int24 == 198760607);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 101.1582918005242d + "'", double25 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.1582918005242d + "'", double26 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 103.12613635737547d + "'", double32 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 103.12613635737547d + "'", double33 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 198760607 + "'", int42 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 198760607 + "'", int56 == 198760607);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.1582918005242d + "'", double57 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-3628800));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1728455610552533823L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(8.772782719999999E8d, 3307.3117116835433d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8221188003905089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014348679909360423d + "'", double1 == 0.014348679909360423d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.7031839360032603E-108d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7031839360032603E-108d) + "'", double1 == (-1.7031839360032603E-108d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9905373453108037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.1230361788159142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8432863502253889d + "'", double1 == 0.8432863502253889d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1394038287));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6389612763136348d, 1.8189854738044024E42d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6389612763136348d + "'", double2 == 0.6389612763136348d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(52, 795042428);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-3628800), (-565729435));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4345658706984465d, (java.lang.Number) 32, 1078034432, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9995506592478776d, (java.lang.Number) (short) 0, 271620299, orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 784346679231569093L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.8434667923156915E17d + "'", double2 == 7.8434667923156915E17d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 229.1831180523293d + "'", double1 == 229.1831180523293d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.05774784932115d + "'", double1 == 10.05774784932115d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 54766527);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0753787168225966d) + "'", double1 == (-0.0753787168225966d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.033203346412116204d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.033203346412116204d + "'", double1 == 0.033203346412116204d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 1.1102230246251565E-16d);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray38);
        double[] doubleArray52 = null;
        try {
            double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 877278303 + "'", int40 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 208415635800064L, 54766527, 852);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.968492992744144d, (java.lang.Number) 0.0d, 260, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 259 and 260 are not strictly decreasing (0 <= 7.968)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 259 and 260 are not strictly decreasing (0 <= 7.968)"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1829609409), 1726527327);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(34.0d, (double) (short) 10, (-8.4478908838308741E18d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6108652381980153d + "'", double1 == 0.6108652381980153d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.acos(3628800.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.FastMath.ulp(21.509799193225255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 160777445, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1991599724);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 877278303 + "'", int6 == 877278303);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double2 = org.apache.commons.math.util.FastMath.max(104.41264291262816d, (-7.640113401817825d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 104.41264291262816d + "'", double2 == 104.41264291262816d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4258259770489514E8d, (java.lang.Number) 1.0f, (-1));
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection8, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.String str19 = nonMonotonousSequenceException15.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException15.getDirection();
        boolean boolean21 = nonMonotonousSequenceException15.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0f + "'", number17.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 100, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(8.142219984546603E-13d, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) Float.NaN, 44.26015131959809d, 1.1230361788159142d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.105427357601002E-15d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03513821552068763d) + "'", double2 == (-0.03513821552068763d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 989493378);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(198760867L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198760867L + "'", long2 == 198760867L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-45L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        long long2 = org.apache.commons.math.util.FastMath.min(1078034333L, (long) (-1582015220));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1582015220L) + "'", long2 == (-1582015220L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 198760607 + "'", number7.equals(198760607));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 198760607 + "'", number8.equals(198760607));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray31 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray38 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray38);
        int[] intArray44 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray51 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray44);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray44);
        java.lang.Class<?> wildcardClass55 = intArray4.getClass();
        int[] intArray60 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray67 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray60);
        int[] intArray74 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray81 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray81);
        int[] intArray87 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray94 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray94);
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray94);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray94);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 104.40785411069419d + "'", double39 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 104.40785411069419d + "'", double52 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 104.40785411069419d + "'", double68 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 104.40785411069419d + "'", double82 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 104.40785411069419d + "'", double95 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 104.40785411069419d + "'", double96 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 135 + "'", int97 == 135);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 10, 198760639);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-198760629) + "'", int2 == (-198760629));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double1 = org.apache.commons.math.util.FastMath.abs(20.796610271965545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610271965545d + "'", double1 == 20.796610271965545d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray17);
        double[] doubleArray29 = new double[] { '#', 1.0d, 'a' };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray35 = new double[] { '#', 1.0d, 'a' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray41 = new double[] { '#', 1.0d, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray49 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray49);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 103.12613635737547d + "'", double22 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 877278303 + "'", int23 == 877278303);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 103.12613635737547d + "'", double30 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 103.12613635737547d + "'", double36 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 877278303 + "'", int37 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 877278303 + "'", int43 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 198760607 + "'", int50 == 198760607);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 101.1582918005242d + "'", double51 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 101.1582918005242d + "'", double52 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { '#', 1.0d, 'a' };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray26 = new double[] { '#', 1.0d, 'a' };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray20);
        double[] doubleArray43 = new double[] { '#', 1.0d, 'a' };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray46 = null;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray46);
        double[] doubleArray53 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray53);
        double[] doubleArray59 = new double[] { '#', 1.0d, 'a' };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray67 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray67);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray59);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray43);
        java.lang.Class<?> wildcardClass72 = doubleArray3.getClass();
        double[] doubleArray76 = new double[] { '#', 1.0d, 'a' };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray79 = null;
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        java.lang.Class<?> wildcardClass83 = doubleArray76.getClass();
        double[] doubleArray87 = new double[] { '#', 1.0d, 'a' };
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray87);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 103.12613635737547d + "'", double21 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 877278303 + "'", int22 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 103.12613635737547d + "'", double27 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 877278303 + "'", int28 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 198760607 + "'", int35 == 198760607);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.1582918005242d + "'", double36 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 101.1582918005242d + "'", double37 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 103.12613635737547d + "'", double44 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 198760607 + "'", int54 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 103.12613635737547d + "'", double60 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 877278303 + "'", int61 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 198760607 + "'", int68 == 198760607);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 103.12613635737547d + "'", double77 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 103.12613635737547d + "'", double78 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 103.12613635737547d + "'", double81 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 877278303 + "'", int82 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 103.12613635737547d + "'", double88 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 103.12613635737547d + "'", double89 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 877278303 + "'", int90 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double2 = org.apache.commons.math.util.MathUtils.log(286.4788975654116d, 99.99499987499378d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8139612867178604d + "'", double2 == 0.8139612867178604d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double1 = org.apache.commons.math.util.FastMath.log10(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.041914824263685d + "'", double1 == 4.041914824263685d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 260, 1.090905898573277d, (double) (-1726527327));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int int1 = org.apache.commons.math.util.MathUtils.sign(877278272);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.03549223717331409d), (double) 784346679231569093L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1726527371L), (double) 1095479168L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.095479168E9d + "'", double2 == 1.095479168E9d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1078001664, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900544 + "'", int2 == 1900544);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-98922731572L), 754210295535290399L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1347840285), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.584073464102069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-3628802), 3333);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.24871540768837d + "'", double1 == 22.24871540768837d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str14 = nonMonotonousSequenceException10.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str17 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', 852);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-800) + "'", int2 == (-800));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9124034991009714d + "'", double1 == 0.9124034991009714d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.987606016E9d, (double) 5296430760682117539L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 3332, (long) 160777445);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection17, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection17, false);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        boolean boolean23 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.4372836722600485E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8388608.0d + "'", double1 == 8388608.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 351L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4345658706984465d, (double) 1040712641);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.175656695020835E-10d + "'", double2 == 4.175656695020835E-10d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.9442157056960553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.090905898573277d + "'", double1 == 1.090905898573277d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074789600), (long) 35651585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-98922731572L), (-10L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 989227315720L + "'", long2 == 989227315720L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1726527423), (-1394038287));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-332489136) + "'", int2 == (-332489136));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        long long1 = org.apache.commons.math.util.FastMath.abs(1024927401L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1024927401L + "'", long1 == 1024927401L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray18 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        int[] intArray32 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray39 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray32);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray18);
        int[] intArray43 = new int[] {};
        int[] intArray48 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray55 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray55);
        int[] intArray61 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray68 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray61);
        int[] intArray75 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray82 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray75, intArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray75);
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray61);
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray61);
        java.lang.Class<?> wildcardClass87 = intArray18.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 104.40785411069419d + "'", double13 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 104.40785411069419d + "'", double26 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 104.40785411069419d + "'", double40 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 104.40785411069419d + "'", double56 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 104.40785411069419d + "'", double69 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 104.40785411069419d + "'", double83 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(wildcardClass87);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1582015220), (long) (-565729435));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5063141360940L, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray18 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        int[] intArray32 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray39 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray39);
        int[] intArray45 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray52 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray45);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray45);
        int[] intArray60 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray67 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray67);
        int[] intArray73 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray80 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray73);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray73);
        try {
            double double84 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 104.40785411069419d + "'", double13 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 104.40785411069419d + "'", double26 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 104.40785411069419d + "'", double40 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 104.40785411069419d + "'", double53 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 104.40785411069419d + "'", double68 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 104.40785411069419d + "'", double81 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-8.4478909E18f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7445033845407723d + "'", double1 == 0.7445033845407723d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int int1 = org.apache.commons.math.util.MathUtils.hash(18.84955592153876d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1057093806 + "'", int1 == 1057093806);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-2147483646));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.98760639E8d, (java.lang.Number) 10.000000000000002d, (-1074790400));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str14 = nonMonotonousSequenceException10.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException10.getDirection();
        boolean boolean16 = nonMonotonousSequenceException10.getStrict();
        int int17 = nonMonotonousSequenceException10.getIndex();
        java.lang.Class<?> wildcardClass18 = nonMonotonousSequenceException10.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.095479168E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 34L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.0d + "'", double1 == 34.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-98922731572L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.027313232421875d + "'", double2 == 1.027313232421875d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35L, (java.lang.Number) (-206124209575858481L), 1078591488);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 3.0d);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray19);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray30 = new double[] { '#', 1.0d, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray38 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray38);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 2.0d);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 877278303 + "'", int8 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 130.0d + "'", double20 == 130.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 877278303 + "'", int26 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 877278303 + "'", int32 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 198760607 + "'", int39 == 198760607);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 101.1582918005242d + "'", double41 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-3628800), 3324781745314725889L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 54766527, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.19066108E8d + "'", double2 == 2.19066108E8d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.000629915570948d, 74.20321057778875d, 17.341109351360387d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10000, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) -1, (double) 1048576);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.536743164059608E-7d) + "'", double2 == (-9.536743164059608E-7d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.831008000716576E22d, 8.298330314378326d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1726527327), 1048576);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray32);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray18);
        double[] doubleArray40 = new double[] { '#', 1.0d, 'a' };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray43);
        double[] doubleArray50 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray50);
        double[] doubleArray56 = new double[] { '#', 1.0d, 'a' };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray64 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray64);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray56);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray56);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 877278303 + "'", int8 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 877278303 + "'", int20 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 877278303 + "'", int26 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 198760607 + "'", int33 == 198760607);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 101.1582918005242d + "'", double34 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.1582918005242d + "'", double35 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 103.12613635737547d + "'", double41 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 198760607 + "'", int51 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 103.12613635737547d + "'", double57 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 877278303 + "'", int58 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 198760607 + "'", int65 == 198760607);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 101.1582918005242d + "'", double66 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-3.380514157859815d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.059001102464937116d) + "'", double1 == (-0.059001102464937116d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 0.37424182806052114d, (-1726527327));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.301801982276166d, (java.lang.Number) (-12.806875836617005d), 100, orderDirection7, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection13, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        java.lang.String str22 = nonMonotonousSequenceException19.toString();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        double double2 = org.apache.commons.math.util.MathUtils.log((-5.8151149695594148E18d), 7.4372836722600485E22d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.090905898573277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0444644075186462d + "'", double1 == 1.0444644075186462d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.7031839360032603E-108d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.9726167450333283E-110d) + "'", double1 == (-2.9726167450333283E-110d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { '#', 1.0d, 'a' };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray17);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray66 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray52);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray80 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 103.12613635737547d + "'", double30 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 198760607 + "'", int38 == 198760607);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 101.1582918005242d + "'", double39 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 877278303 + "'", int54 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 198760607 + "'", int67 == 198760607);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 877278303 + "'", int74 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 198760607 + "'", int81 == 198760607);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 98.0d + "'", double82 == 98.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1862128895), (float) 1726527424);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.72652749E9f + "'", float2 == 1.72652749E9f);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1933768272), (-1582015220));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 877278272, (long) 3332);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.203117510034154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        float float2 = org.apache.commons.math.util.FastMath.min(1.07610112E9f, 3.41642464E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.41642464E8f + "'", float2 == 3.41642464E8f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1076101120, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1582015220), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3332);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 10.0f, 0.0d, 3.8104773811248975d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.37424182806052114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3742418280605212d + "'", double1 == 0.3742418280605212d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10, (-1.726527488E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str14 = nonMonotonousSequenceException10.toString();
        java.lang.Number number15 = nonMonotonousSequenceException10.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100.0f + "'", number15.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1048576);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3487781810466677E7d + "'", double1 == 1.3487781810466677E7d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 0, (double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-71535587));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (byte) 10, (double) 7627252785293671909L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.6272527852936714E18d + "'", double2 == 7.6272527852936714E18d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.531148101376695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8768611881641145d + "'", double1 == 0.8768611881641145d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(orderDirection8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean13 = nonMonotonousSequenceException9.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2740.742827762312d, (double) (byte) 10, (double) 1728455558494460171L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 198760639L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4779940175198476d + "'", double1 == 2.4779940175198476d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 0.37424182806052114d, (-1726527327));
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1726527327) + "'", int4 == (-1726527327));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int2 = org.apache.commons.math.util.FastMath.max(54766527, 1001116801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1001116801 + "'", int2 == 1001116801);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.4210854715202004E-14d, 1.07610112E9d, (-1.0280589699575455d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1752011936438014d, (java.lang.Number) (-1048577), 1040712641, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.1752011936438014d + "'", number6.equals(1.1752011936438014d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        java.lang.Class<?> wildcardClass16 = doubleArray9.getClass();
        double[] doubleArray20 = new double[] { '#', 1.0d, 'a' };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray20);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 103.12613635737547d + "'", double11 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 877278303 + "'", int15 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 103.12613635737547d + "'", double21 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 103.12613635737547d + "'", double22 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 877278303 + "'", int23 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1987606070, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1987606070 + "'", int2 == 1987606070);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 99, 2453876422820638371L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2453876422820638470L + "'", long2 == 2453876422820638470L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 1, (float) 1347840285L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.9876064E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1726527327), (long) 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, (-198760629));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.6499264843595548E31d, (-2), (-332489136));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double1 = org.apache.commons.math.util.FastMath.abs((-21.873953557219664d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.873953557219664d + "'", double1 == 21.873953557219664d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3332.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3332.0000000000005d + "'", double1 == 3332.0000000000005d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getPrevious();
        int int15 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number23 = nonMonotonousSequenceException19.getArgument();
        int int24 = nonMonotonousSequenceException19.getIndex();
        int int25 = nonMonotonousSequenceException19.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException19.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1040712641 + "'", number14.equals(1040712641));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0L + "'", number23.equals(0L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(800.0d, (double) 34.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.451392524090465d + "'", double2 == 33.451392524090465d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1987606070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1987606070 + "'", int2 == 1987606070);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-96));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-96.0d) + "'", double1 == (-96.0d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 795042428, 350L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 795042778L + "'", long2 == 795042778L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', (long) (-1347840285));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9801672890054735d + "'", double1 == 0.9801672890054735d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 3628800);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2453876422820638371L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2453876422820638371L + "'", long2 == 2453876422820638371L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 877278272);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3333L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 116655L + "'", long2 == 116655L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.804475161328668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.80447516132867d + "'", double1 == 8.80447516132867d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4258259770489514E8d, (java.lang.Number) 1.0f, (-1));
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1593279779200L, (java.lang.Number) (-0.0332033464121162d), 1040712641, orderDirection9, true);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0 + "'", number14.equals(0));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35, 2.584073464102069d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1991599724L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.726527361E9d), 1.8115262724608532d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-3628802), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3628801.9999999995d) + "'", double2 == (-3628801.9999999995d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(12900.52438982139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12900.524389821392d + "'", double1 == 12900.524389821392d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 983569537);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray31 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray38 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray38);
        int[] intArray44 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray51 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray44);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray44);
        int[] intArray59 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray66 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray66);
        int[] intArray72 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray79 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray72);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray72);
        int[] intArray83 = null;
        try {
            int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 104.40785411069419d + "'", double39 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 104.40785411069419d + "'", double52 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 104.40785411069419d + "'", double67 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 104.40785411069419d + "'", double80 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '#', 1.0d, 'a' };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 1.1102230246251565E-16d);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        try {
            double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 877278303 + "'", int6 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 877278303 + "'", int18 == 877278303);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 877278303 + "'", int19 == 877278303);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(198760605L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198760605L + "'", long2 == 198760605L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1394038287), 1726527424);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.99189285848507d) + "'", double1 == (-0.99189285848507d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(5063141360940L, (long) (-3628800));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60L + "'", long2 == 60L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 98, (long) 877278272);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 85973270656L + "'", long2 == 85973270656L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 198760607 + "'", int18 == 198760607);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.1582918005242d + "'", double19 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 101.1582918005242d + "'", double20 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.198039027185569d + "'", double21 == 10.198039027185569d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        int int1 = org.apache.commons.math.util.MathUtils.sign(3333);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 3332.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.804475206364689d + "'", double1 == 8.804475206364689d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3.831008000716576E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 54766479L);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 103.12613635737547d + "'", double9 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-19337682720L), 1991599724);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(852, 1347840285);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1829609409));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        double double1 = org.apache.commons.math.util.FastMath.sin(9.89493378E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9953239514266732d + "'", double1 == 0.9953239514266732d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-3628800), 1057093806);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(101.1582918005242d, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(3332);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-565729435));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.8078724507617987d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8078724507617987d + "'", double1 == 2.8078724507617987d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-19337682720L), (long) (-128256026));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(116655L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11665500L + "'", long2 == 11665500L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1199.659016775285d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 366582743 + "'", int1 == 366582743);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double2 = org.apache.commons.math.util.FastMath.max((-2.9726167450333283E-110d), 0.0442841955015905d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0442841955015905d + "'", double2 == 0.0442841955015905d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        int int2 = org.apache.commons.math.util.FastMath.min(98, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-2), (-71535587));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) Float.NaN, (-2.582159357367483E-12d), 3628800);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7655452576123303d + "'", double1 == 1.7655452576123303d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str12 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 198760639L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 3628800);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 198760639L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1048576);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 198);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 5063141360940L);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (-3628802));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 14218459054895680L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2L, 33974145);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-332489136), 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-332488336L) + "'", long2 == (-332488336L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3.41642464E8f, (double) 1987606070, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-128256026), (-128256026), (-71535587));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.4798904282216196d, (double) 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7147031929542251d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6553932708281036d + "'", double1 == 0.6553932708281036d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getPrevious();
        int int15 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number23 = nonMonotonousSequenceException19.getArgument();
        int int24 = nonMonotonousSequenceException19.getIndex();
        int int25 = nonMonotonousSequenceException19.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.String str27 = nonMonotonousSequenceException19.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1040712641 + "'", number14.equals(1040712641));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0L + "'", number23.equals(0L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str27.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(341642502);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 852, 341642467);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1048577), 2.3536109559791604E92d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3536109559791604E92d + "'", double2 == 2.3536109559791604E92d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 104.40785411069419d + "'", double13 == 104.40785411069419d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(156.3608363030788d, (double) 989227315720L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) (-1726527327));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.72652736E9f) + "'", float2 == (-1.72652736E9f));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800, (java.lang.Number) (-9.369284411097881E148d), (int) (short) 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3628800 + "'", number4.equals(3628800));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-8.4478908838308741E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.FastMath.atanh(17.341109351360387d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { '#', 1.0d, 'a' };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray26 = new double[] { '#', 1.0d, 'a' };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray20);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.9968748198371793d);
        double[] doubleArray45 = new double[] { '#', 1.0d, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray51 = new double[] { '#', 1.0d, 'a' };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray57 = new double[] { '#', 1.0d, 'a' };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray65);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        double[] doubleArray73 = new double[] { '#', 1.0d, 'a' };
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray76 = null;
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 3.0d);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray80);
        double[] doubleArray85 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray89 = new double[] { '#', 1.0d, 'a' };
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray85, doubleArray89);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 103.12613635737547d + "'", double21 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 877278303 + "'", int22 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 103.12613635737547d + "'", double27 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 877278303 + "'", int28 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 198760607 + "'", int35 == 198760607);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.1582918005242d + "'", double36 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 101.1582918005242d + "'", double37 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 103.12613635737547d + "'", double52 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 877278303 + "'", int53 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 103.12613635737547d + "'", double58 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 877278303 + "'", int59 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 198760607 + "'", int66 == 198760607);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 101.1582918005242d + "'", double67 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 103.12613635737547d + "'", double74 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 103.12613635737547d + "'", double78 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 130.0d + "'", double82 == 130.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 103.12613635737547d + "'", double90 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1040712641 + "'", int92 == 1040712641);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double2 = org.apache.commons.math.util.FastMath.max((-2.582159357367483E-12d), (double) 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.07610112E9d + "'", double2 == 1.07610112E9d);
    }
}

