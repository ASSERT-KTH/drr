import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long1 = org.apache.commons.math.util.MathUtils.sign(350L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.69314718055995d + "'", double1 == 52.69314718055995d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, 1728455558494460171L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1683002521388203393L, (int) (short) 0, 1048576);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection4, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 98);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 98L + "'", long1 == 98L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math.util.FastMath.min(0.383039069605237d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.03613739811852401d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03549223717331409d) + "'", double1 == (-0.03549223717331409d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.248699261236361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(198760640, (-1933768272));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1726527327));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1726527327 + "'", int1 == 1726527327);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1078034432);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 100.00499987500626d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.53096491487338d + "'", double2 == 100.53096491487338d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = throwableArray8.getClass();
        java.lang.Class<?> wildcardClass10 = throwableArray8.getClass();
        java.lang.Class<?> wildcardClass11 = throwableArray8.getClass();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(52L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9968748198371793d, (double) 198760639L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.015453888922038E-9d + "'", double2 == 5.015453888922038E-9d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1726527327);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1078034432);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5707963267948963d, (double) 1, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.asin(8.3350745897699942E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.math.util.MathUtils.pow(34, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1987606070);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.1752011936438014d, Double.NaN, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.0d, 0.36601461728382423d, 98);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.07610112E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int2 = org.apache.commons.math.util.MathUtils.pow(34, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1L), 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 103.12613635737547d + "'", double2 == 103.12613635737547d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) 1048576);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1048576.0f + "'", float2 == 1048576.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4778789368178313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.4163847498715594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4163847498715596d + "'", double1 == 1.4163847498715596d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1726527424);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963262156994d + "'", double1 == 1.5707963262156994d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.acosh(8.3350745897699942E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.26015131959809d + "'", double1 == 44.26015131959809d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 52L, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5707963267948963d, (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.563115149540037d + "'", double2 == 9.563115149540037d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray11);
        double[] doubleArray18 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray22);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        try {
            double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 877278303 + "'", int14 == 877278303);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1040712641 + "'", int25 == 1040712641);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1933768272), 3332);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.03549223717331409d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.938893903907228E-18d + "'", double1 == 6.938893903907228E-18d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.5707963267948966d), (double) (-1));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.968492992744144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7646819113192036d + "'", double1 == 2.7646819113192036d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.NaN, (double) 350L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double2 = org.apache.commons.math.util.FastMath.max(22026.465794806718d, (-0.7184493636924868d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22026.465794806718d + "'", double2 == 22026.465794806718d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 341642467, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5815114969559414353L + "'", long2 == 5815114969559414353L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long1 = org.apache.commons.math.util.FastMath.round(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { '#', 1.0d, 'a' };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray17);
        double[] doubleArray45 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray49 = new double[] { '#', 1.0d, 'a' };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray49);
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 103.12613635737547d + "'", double30 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 198760607 + "'", int38 == 198760607);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 101.1582918005242d + "'", double39 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 103.12613635737547d + "'", double50 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 260, (long) 198760607);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198760867L + "'", long2 == 198760867L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1001116801, (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707962928328254d + "'", double2 == 1.5707962928328254d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5529523200824553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5529523200824553d + "'", double1 == 0.5529523200824553d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1076101120, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.07610112E9d + "'", double2 == 1.07610112E9d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8115262724608532d + "'", double1 == 1.8115262724608532d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 34, (double) 3332, 1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (byte) -1, (-1726527423));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int1 = org.apache.commons.math.util.MathUtils.sign(3332);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double2 = org.apache.commons.math.util.FastMath.min(1.8115262724608532d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8115262724608532d + "'", double2 == 1.8115262724608532d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0927837451120071d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35L, 3.0d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.142219984546603E-13d, 0.9276132068968583d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7921204236492381d) + "'", double1 == (-0.7921204236492381d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 198760607 + "'", int7 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4163847498715594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1230361788159142d + "'", double1 == 1.1230361788159142d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 33974111, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1L, 2.7646819113192036d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        long long2 = org.apache.commons.math.util.MathUtils.pow(198760867L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8447890881994136687L) + "'", long2 == (-8447890881994136687L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-10.158170418955065d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9968748198371793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.546754179225521d + "'", double1 == 1.546754179225521d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.503599627370496E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(341642467, 877278303);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        try {
            double double7 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.37424182806052114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3660146172838242d + "'", double1 == 0.3660146172838242d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-95L), 33974111, 1726527424);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(350L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 351L + "'", long2 == 351L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1726527371L), 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = null;
        try {
            double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 877278303 + "'", int8 == 877278303);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 0, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, 1726527424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 203.03237633534846d + "'", double2 == 203.03237633534846d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double[] doubleArray4 = new double[] { 2.1256138592702154d, 2.0d, 34.0d, 1.7453292519943295d };
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (2.126 >= 2)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1078034432, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(6.101477379184951E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9905373453108037d) + "'", double1 == (-0.9905373453108037d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.4163847498715596d, 0.0d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 3332);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.723478758647246d + "'", double1 == 57.723478758647246d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.726527371E9d), 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3536109559791604E92d + "'", double2 == 2.3536109559791604E92d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1726527327, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 197.58936642730797d + "'", double2 == 197.58936642730797d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9442157056960553d + "'", double1 == 0.9442157056960553d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1726527371L), 341642502);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4463520074491623d + "'", double1 == 2.4463520074491623d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.033203346412116204d) + "'", double1 == (-0.033203346412116204d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 8335074589769994240L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) -1, 1048576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1048577) + "'", int2 == (-1048577));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.tanh(34.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 33974111, (double) 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 198760867L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1726527327));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1728455558494460171L, 260);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 206124209575858481L + "'", long2 == 206124209575858481L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3628800L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 260, 206124209575858481L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7745966692414834d + "'", double1 == 0.7745966692414834d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 3332);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 10, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 52.0f, (double) 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(11013.232874703393d, 5.298292365610485d, (double) 3628800L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(351L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1683002521388203394L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.0d + "'", double1 == 256.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 33974111, (long) 341642502);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 375616613L + "'", long2 == 375616613L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.99499987499378d + "'", double1 == 99.99499987499378d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6487212707001282d + "'", double1 == 1.6487212707001282d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 'a', 198760640, (int) (byte) 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 800, 1.546754179225521d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.546754179225521d + "'", double2 == 1.546754179225521d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(44.26015131959809d, 33974111, 1040712641);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.4163847498715594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.190119636789327d + "'", double1 == 1.190119636789327d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.8115262724608532d, (double) 3332);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.651533448556522d + "'", double2 == 13.651533448556522d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1040712641);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8212846155616313d + "'", double1 == 0.8212846155616313d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.546754179225521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1894212981280368d + "'", double1 == 0.1894212981280368d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.6487212707001282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2003257647899614d + "'", double1 == 4.2003257647899614d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.4258259770489514E8d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1076101120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101120 + "'", int2 == 1076101120);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8335074589769994240L, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.9876064E8f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.847379800543134d) + "'", double1 == (-13.847379800543134d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(341642502, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1556.0255852847893d + "'", double2 == 1556.0255852847893d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19240232444172617d + "'", double1 == 0.19240232444172617d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(800.0f, 800, 1987606070);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1048576);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97, 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1726527371L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1726527360) + "'", int1 == (-1726527360));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.033203346412116204d), 1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0332033464121162d) + "'", double2 == (-0.0332033464121162d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.07610112E9d, (-0.9905373453108037d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection13, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (35 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 877278303 + "'", int8 == 877278303);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.922085313399045d + "'", double1 == 22.922085313399045d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (long) (-1726527360));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) 'a', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.1752011936438014d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 98);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(33974111);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        int int12 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(3332);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23699.91953449629d + "'", double1 == 23699.91953449629d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09238692595529725d) + "'", double1 == (-0.09238692595529725d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 877278303 + "'", int15 == 877278303);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 198760607);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1933768272));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189854738044024E42d + "'", double1 == 1.8189854738044024E42d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6931471805599453d, 0.0d, 256.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3628800, (long) 198760640);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198760640L + "'", long2 == 198760640L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1933768272), 1726527327);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.537297501373361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5681821962429564d + "'", double1 == 0.5681821962429564d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        long long1 = org.apache.commons.math.util.FastMath.abs(5815114969559414353L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5815114969559414353L + "'", long1 == 5815114969559414353L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.341475017011044d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 1.1102230246251565E-16d);
        double[] doubleArray30 = new double[] { '#', 1.0d, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray30);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 103.12613635737547d + "'", double32 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 877278303 + "'", int33 == 877278303);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        long long1 = org.apache.commons.math.util.FastMath.abs(1108998363917509632L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1108998363917509632L + "'", long1 == 1108998363917509632L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 8.3350745897699942E18d + "'", number4.equals(8.3350745897699942E18d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1048576, 206124209575858481L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 100, 0.4345658706984465d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int1 = org.apache.commons.math.util.FastMath.abs(198760607);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 198760607 + "'", int1 == 198760607);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(198760607, 3628800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9442157056960553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7567135923167221d + "'", double1 == 0.7567135923167221d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) ' ', 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.9442157056960553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.090905898573277d + "'", double1 == 1.090905898573277d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(198760640, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 198760640 + "'", int2 == 198760640);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1726527423), 1040712641);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1078034432);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1001116801, 1001116801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 983569537 + "'", int2 == 983569537);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(800, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.6487212707001282d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, 341642467);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1108998363917509632L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', 1683002521388203393L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray7 = new double[] { '#', 1.0d, 'a' };
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        double[] doubleArray13 = new double[] { '#', 1.0d, 'a' };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray18 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        int[] intArray32 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray39 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray32);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray18);
        int[] intArray47 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray54 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray54);
        int[] intArray60 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray67 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray60);
        int[] intArray74 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray81 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray81);
        int[] intArray87 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray94 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray94);
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray87);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray87);
        java.lang.Class<?> wildcardClass98 = intArray87.getClass();
        int int99 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray87);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 104.40785411069419d + "'", double13 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 104.40785411069419d + "'", double26 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 104.40785411069419d + "'", double40 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 104.40785411069419d + "'", double55 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 104.40785411069419d + "'", double68 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 104.40785411069419d + "'", double82 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 104.40785411069419d + "'", double95 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertNotNull(wildcardClass98);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 0 + "'", int99 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, 33974111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(100L, (-8447890881994136687L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4163847498715594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 341642467, 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-9.892273157211768E10d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1726527424, 0, 198760640);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 34, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 34);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray14 = null;
        try {
            double double15 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 341642467);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 341642467L + "'", long2 == 341642467L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1108998363917509664L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9355672849590824E16d + "'", double1 == 1.9355672849590824E16d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1726527327), (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1001116801, (-0.0332033464121162d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796326828063d + "'", double2 == 1.570796326828063d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1726527424);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.892273460879399E10d + "'", double1 == 9.892273460879399E10d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.626860407847019d + "'", double1 == 3.626860407847019d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-95L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-95) + "'", int1 == (-95));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4258259770489514E8d, (java.lang.Number) 1.0f, (-1));
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.4258259770489514E8d + "'", number5.equals(2.4258259770489514E8d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Class<?> wildcardClass14 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5681821962429564d, 29937.070865949758d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-95));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        long long2 = org.apache.commons.math.util.FastMath.min(97L, 375616613L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.7031839360032603E-108d), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9968748198371793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double2 = org.apache.commons.math.util.FastMath.pow(Double.NEGATIVE_INFINITY, (double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 97, 198760640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 17.499999999999996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.84955592153876d + "'", double2 == 18.84955592153876d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(33974111, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1933768272), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610271965545d + "'", double1 == 20.796610271965545d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.142219984546603E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.142219984546603E-13d + "'", double1 == 8.142219984546603E-13d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 10.0f, (double) 1987606070);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9876060676852348E9d + "'", double2 == 1.9876060676852348E9d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1040712641, (-95));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(3628800, 198760607);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.atan(8.3350745897699942E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.FastMath.ceil(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1048577), (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3628800);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3628800.0f + "'", float1 == 3628800.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1726527360));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.726527361E9d) + "'", double1 == (-1.726527361E9d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1048577), (long) 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35651585 + "'", int2 == 35651585);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray7 = new double[] { '#', 1.0d, 'a' };
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        try {
            double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        float float2 = org.apache.commons.math.util.MathUtils.round(Float.NaN, 1076101120);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (byte) -1, (-1933768272), 1078034432);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.7219067166708869d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.signum(7.968492992744144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.831008000716577E22d, 104.40785411069419d, (double) 2L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        int int11 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        long long1 = org.apache.commons.math.util.FastMath.round((-9.892273157211768E10d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-98922731572L) + "'", long1 == (-98922731572L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int int1 = org.apache.commons.math.util.FastMath.round(1.9876064E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 198760640 + "'", int1 == 198760640);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1683002521388203394L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.19240232444172617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1900628023411102d + "'", double1 == 0.1900628023411102d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.563115149540037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7115.053031976556d + "'", double1 == 7115.053031976556d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-225.95084645419513d) + "'", double1 == (-225.95084645419513d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.3536109559791604E92d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9995192260716705d) + "'", double1 == (-0.9995192260716705d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.7646819113192036d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double2 = org.apache.commons.math.util.FastMath.atan2(18.84955592153876d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 800L + "'", long1 == 800L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1726527423));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(33974111, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33974111 + "'", int2 == 33974111);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-95), 0.1900628023411102d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1900628023411102d + "'", double2 == 0.1900628023411102d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1726527327), 1001116801);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4350707652395722591L) + "'", long2 == (-4350707652395722591L));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1933768272), (double) 1683002521388203393L, (double) 8335074589769994240L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.3536109559791604E92d, 1001116801, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.6057648134614585d), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.floor(52.66337773023506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 97, (int) (short) -1, (-1726527423));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963267948966d, (double) (short) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5614.986392282068d, (double) 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray10 = null;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray10);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-8447890881994136687L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.4478909E18f) + "'", float2 == (-8.4478909E18f));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1726527371L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 375616613L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.75616613E8d + "'", double1 == 3.75616613E8d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (-1L), (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8306408778607839d + "'", double1 == 0.8306408778607839d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray27 = new int[] {};
        int[] intArray32 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray39 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray39);
        int[] intArray45 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray52 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray45);
        int[] intArray59 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray66 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray59);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray45);
        int[] intArray74 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray81 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray81);
        int[] intArray87 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray94 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray94);
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray94);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray74);
        int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray74);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 104.40785411069419d + "'", double40 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 104.40785411069419d + "'", double53 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 104.40785411069419d + "'", double67 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 104.40785411069419d + "'", double82 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 104.40785411069419d + "'", double95 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 104.40785411069419d + "'", double96 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(9.563115149540037d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 198760867L, (double) Float.POSITIVE_INFINITY, 34);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1683002521388203394L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 351L, 800, 35651585);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4221817809573358E-5d + "'", double1 == 2.4221817809573358E-5d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.6057648134614585d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 3.0d);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray11);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 198760607 + "'", int7 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1726527360), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 877278303 + "'", int19 == 877278303);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        float float2 = org.apache.commons.math.util.FastMath.min(Float.POSITIVE_INFINITY, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.8302447490652984d), 3.383637840322284d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(100, 198760640);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 800.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 800.0d + "'", double1 == 800.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 983569537);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6354383327736465E10d + "'", double1 == 5.6354383327736465E10d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9968748198371793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.00313007373653843d) + "'", double1 == (-0.00313007373653843d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.4463520074491623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4463520074491627d + "'", double1 == 2.4463520074491627d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int2 = org.apache.commons.math.util.MathUtils.pow(32, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.09238692595529725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 198760639L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.107611839625807d + "'", double1 == 19.107611839625807d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 198760640);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.9995192260716705d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.640113401817825d) + "'", double1 == (-7.640113401817825d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-8447890881994136687L), (-1933768272));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.369284411097881E148d) + "'", double2 == (-9.369284411097881E148d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1726527423));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9996581403525306d + "'", double1 == 0.9996581403525306d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 3332, 7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3331.9999999999995d + "'", double2 == 3331.9999999999995d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 260, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1726527327));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray32);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray18);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray12);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 877278303 + "'", int8 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 877278303 + "'", int20 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 877278303 + "'", int26 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 198760607 + "'", int33 == 198760607);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 101.1582918005242d + "'", double34 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.1582918005242d + "'", double35 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 877278303 + "'", int38 == 877278303);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-8447890881994136687L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 3628800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1095479168 + "'", int1 == 1095479168);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1108998363917509664L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07011222389235412d + "'", double1 == 0.07011222389235412d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        double[] doubleArray19 = null;
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-4.9E-324d), (double) 341642502, 4.2003257647899614d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection9, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection9, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (1 < 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1726527327, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.19240232444172617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-10.158170418955065d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12900.52438982139d + "'", double1 == 12900.52438982139d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.03549223717331409d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int int2 = org.apache.commons.math.util.FastMath.min(3332, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.237173456633567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5135.981619451371d + "'", double1 == 5135.981619451371d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.sin(44.26015131959809d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2742927516703394d + "'", double1 == 0.2742927516703394d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0407126409999999E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.763171547166394d + "'", double1 == 20.763171547166394d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3332);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3332.0f + "'", float1 == 3332.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9276132068968583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5997455785530094d + "'", double1 == 0.5997455785530094d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.1256138592702154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.190119636789327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611504d + "'", double1 == 81.55795945611504d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.9512437185814275d, 1.5574077246549023d, (double) 2L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(20.796610271965545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610271965548d + "'", double1 == 20.796610271965548d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray21 = new double[] { '#', 1.0d, 'a' };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray24 = null;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 3.0d);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray21);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 103.12613635737547d + "'", double22 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.0d + "'", double30 == 98.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.383637840322284d, 20.796610271965545d, (double) 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.36601461728382423d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36601461728382423d + "'", double2 == 0.36601461728382423d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.8115262724608532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8115262724608534d + "'", double1 == 1.8115262724608534d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 198760607 + "'", int24 == 198760607);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 101.1582918005242d + "'", double25 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.1582918005242d + "'", double26 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 103.12613635737547d + "'", double28 == 103.12613635737547d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        long long1 = org.apache.commons.math.util.FastMath.round(3.7465010457261463d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.09238692595529725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09251840775524439d) + "'", double1 == (-0.09251840775524439d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.9876064E8f, (double) (-95L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        int[] intArray30 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray37 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        int[] intArray44 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray51 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray57 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray64 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray57);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray57);
        int[] intArray72 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray79 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray79);
        int[] intArray85 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray92 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray85);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray85);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray57);
        java.lang.Class<?> wildcardClass97 = intArray4.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 104.40785411069419d + "'", double38 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 104.40785411069419d + "'", double52 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 104.40785411069419d + "'", double65 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 104.40785411069419d + "'", double80 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 104.40785411069419d + "'", double93 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertNotNull(wildcardClass97);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-4350707652395722591L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0927837451120071d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 198760640, (float) 1987606070);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.98760602E9f + "'", float2 == 1.98760602E9f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(32, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, 1987606070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1987606070 + "'", int2 == 1987606070);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1726527360));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.96252510231819d) + "'", double1 == (-21.96252510231819d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5998406268185329d + "'", double1 == 0.5998406268185329d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 3628800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3628800) + "'", int2 == (-3628800));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable throwable7 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.1752011936438014d + "'", number6.equals(1.1752011936438014d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(341642467L, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1024927401L + "'", long2 == 1024927401L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1095479168);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1095479168L + "'", long1 == 1095479168L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.07011222389235412d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.798179868358115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3358206909936043d + "'", double1 == 1.3358206909936043d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-95L), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4940L) + "'", long2 == (-4940L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1024927401L, (-4940L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5063141360940L) + "'", long2 == (-5063141360940L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.FastMath.max((-225.95084645419513d), 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.574710978503383d + "'", double2 == 4.574710978503383d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 98, 0.5681821962429564d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.532536430142315d + "'", double2 == 13.532536430142315d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1048577));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1048577.0d) + "'", double1 == (-1048577.0d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-9.369284411097881E148d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.sinh(103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0625413722248835E44d + "'", double1 == 3.0625413722248835E44d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(33974111, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1370.371413881156d + "'", double2 == 1370.371413881156d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3332);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3332L + "'", long1 == 3332L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number14 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 8.3350745897699942E18d + "'", number14.equals(8.3350745897699942E18d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-71535587) + "'", int1 == (-71535587));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 375616613L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1), (double) (-8.4478909E18f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number6, 10, orderDirection14, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.String str18 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.7265273709999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1199.659016775285d) + "'", double1 == (-1199.659016775285d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-1933768272));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(198760640, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 198760639 + "'", int2 == 198760639);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(100, 98);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray13 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        java.lang.Class<?> wildcardClass31 = doubleArray24.getClass();
        double[] doubleArray35 = new double[] { '#', 1.0d, 'a' };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray41 = new double[] { '#', 1.0d, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray41);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray41);
        java.lang.Class<?> wildcardClass62 = doubleArray41.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 877278303 + "'", int30 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 103.12613635737547d + "'", double36 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 103.12613635737547d + "'", double37 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 877278303 + "'", int43 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 198760607 + "'", int56 == 198760607);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.1582918005242d + "'", double57 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.1582918005242d + "'", double58 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 983569537, 34.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.835695369999999E8d + "'", double2 == 9.835695369999999E8d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double2 = org.apache.commons.math.util.FastMath.min(800.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 800, (double) 34, 98.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9589328250406132d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01673653510240943d) + "'", double1 == (-0.01673653510240943d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 1040712641);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1078591488);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 100, 52.69314718055995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4338530951473415E105d + "'", double2 == 2.4338530951473415E105d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 198760867L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.4372836722600485E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189854738044024E42d + "'", double1 == 1.8189854738044024E42d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.7921204236492381d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9142752346107732d) + "'", double1 == (-0.9142752346107732d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        int[] intArray30 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray37 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        try {
            int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 104.40785411069419d + "'", double38 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1048577), 9.835695369999999E8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1987606070);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, (-95));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(33, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2L, 3628800);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 198760607);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.301801982276166d + "'", double1 == 2.301801982276166d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (long) (-1726527327));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int2 = org.apache.commons.math.util.FastMath.min(341642467, 1726527327);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 341642467 + "'", int2 == 341642467);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        int[] intArray30 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray37 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray45 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray52 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        int[] intArray58 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray65 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray65);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray65);
        int[] intArray69 = null;
        try {
            int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 104.40785411069419d + "'", double38 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 104.40785411069419d + "'", double53 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 104.40785411069419d + "'", double66 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 104.40785411069419d + "'", double67 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 98 + "'", int68 == 98);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        long long2 = org.apache.commons.math.util.FastMath.min(5815114969559414353L, (long) (-1726527327));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1726527327L) + "'", long2 == (-1726527327L));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.298292365610485d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298292365610485d + "'", double2 == 5.298292365610485d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        float float3 = org.apache.commons.math.util.MathUtils.round(100.0f, 983569537, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.570796326828063d, (-0.03613739811852401d), (double) 98);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.03613739811852401d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.30716580272248E-4d) + "'", double1 == (-6.30716580272248E-4d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        long long1 = org.apache.commons.math.util.FastMath.abs((-95L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 95L + "'", long1 == 95L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        long long2 = org.apache.commons.math.util.FastMath.min(5L, 198760639L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int1 = org.apache.commons.math.util.FastMath.round(3628800.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.8306408778607839d, (double) 375616613L, 3628800);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(17.499999999999996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        float float1 = org.apache.commons.math.util.FastMath.abs(3332.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3332.0f + "'", float1 == 3332.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 20L, 1726527327, 1040712641);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        long long2 = org.apache.commons.math.util.FastMath.max(35L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        long long1 = org.apache.commons.math.util.FastMath.round(34.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 34L + "'", long1 == 34L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray16 = new double[] { '#', 1.0d, 'a' };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray19);
        double[] doubleArray26 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray26);
        double[] doubleArray32 = new double[] { '#', 1.0d, 'a' };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray32);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray16);
        double[] doubleArray48 = new double[] { '#', 1.0d, 'a' };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray54 = new double[] { '#', 1.0d, 'a' };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray60 = new double[] { '#', 1.0d, 'a' };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double[] doubleArray68 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray54, doubleArray68);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        double[] doubleArray76 = new double[] { '#', 1.0d, 'a' };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray79 = null;
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, 3.0d);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray83);
        try {
            double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 103.12613635737547d + "'", double9 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198760607 + "'", int27 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 103.12613635737547d + "'", double33 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 877278303 + "'", int34 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 198760607 + "'", int41 == 198760607);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.1582918005242d + "'", double42 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 59839.14171519782d + "'", double44 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 103.12613635737547d + "'", double49 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 103.12613635737547d + "'", double50 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 103.12613635737547d + "'", double55 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 877278303 + "'", int56 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 103.12613635737547d + "'", double61 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 877278303 + "'", int62 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 198760607 + "'", int69 == 198760607);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 101.1582918005242d + "'", double70 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 101.1582918005242d + "'", double71 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 103.12613635737547d + "'", double77 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 103.12613635737547d + "'", double78 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 103.12613635737547d + "'", double81 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 59873.352250245545d + "'", double85 == 59873.352250245545d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        int[] intArray30 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray37 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray45 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray52 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        int[] intArray58 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray65 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray65);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray45);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 104.40785411069419d + "'", double38 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 104.40785411069419d + "'", double53 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 104.40785411069419d + "'", double66 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 104.40785411069419d + "'", double67 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.831008000716577E22d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.831008000716576E22d + "'", double2 == 3.831008000716576E22d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1048577), 33);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1347840285) + "'", int2 == (-1347840285));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4258259770489514E8d, (java.lang.Number) 1.0f, (-1));
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.ulp(20.796610271965545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1933768272));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str21 = nonMonotonousSequenceException20.toString();
        boolean boolean22 = nonMonotonousSequenceException20.getStrict();
        java.lang.String str23 = nonMonotonousSequenceException20.toString();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        int int25 = nonMonotonousSequenceException16.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        int int27 = nonMonotonousSequenceException16.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1726527423), 800);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-10.158170418955065d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1991599724 + "'", int1 == 1991599724);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1726527371L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray46 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray64 = new double[] { '#', 1.0d, 'a' };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double[] doubleArray72 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray64, doubleArray72);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray72);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray52);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 877278303 + "'", int40 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 198760607 + "'", int47 == 198760607);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 101.1582918005242d + "'", double48 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 103.12613635737547d + "'", double54 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 103.12613635737547d + "'", double65 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 877278303 + "'", int66 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 198760607 + "'", int73 == 198760607);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 101.1582918005242d + "'", double74 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 101.1582918005242d + "'", double75 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(22026.465794806718d, 0.798179868358115d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9012931422694237d + "'", double2 == 3.9012931422694237d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1991599724);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1991599724L + "'", long1 == 1991599724L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        long long1 = org.apache.commons.math.util.FastMath.abs((-5063141360940L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5063141360940L + "'", long1 == 5063141360940L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(10, 35651585);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(10.0d, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.3660146172838242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7153185320319555d + "'", double1 == 0.7153185320319555d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1078591488, (-1726527423));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.7567135923167221d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7567135923167221d + "'", double1 == 0.7567135923167221d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1726527360), 3.0d, 0.3660146172838242d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(5.298292365610485d, (int) (byte) 1, 198760607);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(52.69314718055995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        long long1 = org.apache.commons.math.util.FastMath.round(130.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 130L + "'", long1 == 130L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-1.0d), 100.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int1 = org.apache.commons.math.util.FastMath.abs(1048576);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1048576 + "'", int1 == 1048576);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 375616613L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double2 = org.apache.commons.math.util.FastMath.atan2(10.000000000000002d, (double) 375616613L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6622890612135942E-8d + "'", double2 == 2.6622890612135942E-8d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-71535587), 1048576);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        float float2 = org.apache.commons.math.util.FastMath.max(800.0f, (float) 341642467L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.41642464E8f + "'", float2 == 3.41642464E8f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(5L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 3.0d);
        java.lang.Class<?> wildcardClass11 = doubleArray3.getClass();
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray13 = null;
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 877278303 + "'", int12 == 877278303);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.140692632779267d + "'", double1 == 23.140692632779267d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.033203346412116204d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9442157056960553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4798904282216196d + "'", double1 == 1.4798904282216196d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 33);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 33.0f + "'", float1 == 33.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.298292365610485d, 100.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        int int2 = org.apache.commons.math.util.FastMath.max((-71535587), 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.4372836722600485E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.437283672260049E22d + "'", double1 == 7.437283672260049E22d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1024927401L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1024927401L + "'", long1 == 1024927401L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.000000000000001d + "'", double1 == 5.000000000000001d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(57.723478758647246d, 2.4258259770489514E8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-4350707652395722591L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.FastMath.atan((-9.892273157211768E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267847878d) + "'", double1 == (-1.5707963267847878d));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        long long2 = org.apache.commons.math.util.MathUtils.pow(4L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        long long1 = org.apache.commons.math.util.FastMath.round(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        int[] intArray30 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray37 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        int[] intArray43 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray50 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray43);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray30);
        int[] intArray59 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray66 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray66);
        int[] intArray72 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray79 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray79);
        int[] intArray85 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray92 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray85);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray72);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray59);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 104.40785411069419d + "'", double38 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 104.40785411069419d + "'", double51 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 104.40785411069419d + "'", double67 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 104.40785411069419d + "'", double80 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 104.40785411069419d + "'", double93 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
    }
}

