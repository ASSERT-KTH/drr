import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1991599724, 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9968748198371794d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 'a');
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) ' ');
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 100);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 39505836933114013L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str21 = nonMonotonousSequenceException20.toString();
        boolean boolean22 = nonMonotonousSequenceException20.getStrict();
        java.lang.String str23 = nonMonotonousSequenceException20.toString();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        int int25 = nonMonotonousSequenceException16.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException10.getDirection();
        boolean boolean28 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1580182805));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '#', 1.0d, 'a' };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray30 = new double[] { '#', 1.0d, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray38 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray38);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray18);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray53 = new double[] { '#', 1.0d, 'a' };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray59 = new double[] { '#', 1.0d, 'a' };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray67 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray67);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray53);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray53);
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 877278303 + "'", int6 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 198760607 + "'", int13 == 198760607);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.1582918005242d + "'", double14 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 103.12613635737547d + "'", double20 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 877278303 + "'", int26 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 877278303 + "'", int32 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 198760607 + "'", int39 == 198760607);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 101.1582918005242d + "'", double41 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 103.12613635737547d + "'", double49 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 103.12613635737547d + "'", double54 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 877278303 + "'", int55 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 103.12613635737547d + "'", double60 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 877278303 + "'", int61 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 198760607 + "'", int68 == 198760607);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 101.1582918005242d + "'", double70 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) 198760867L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int int2 = org.apache.commons.math.util.FastMath.min((-2), (-96));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-96) + "'", int2 == (-96));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5707963262156994d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1048576, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1048608 + "'", int2 == 1048608);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1048608);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0080812763654225E7d + "'", double1 == 6.0080812763654225E7d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.6313083693369503E35d, 3.970291913552122d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1991599724);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.804475161328668d, (java.lang.Number) (-0.627482429927895d), 32);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) -1, (-0.6159478842956411d), 1.4163847498715594d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double1 = org.apache.commons.math.util.FastMath.atanh(13.651533448556522d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray7 = new double[] { '#', 1.0d, 'a' };
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray7);
        double[] doubleArray13 = new double[] { '#', 1.0d, 'a' };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray13);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 877278303 + "'", int16 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1933768272), 1048608);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1934816880) + "'", int2 == (-1934816880));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1752011936438014d, (java.lang.Number) (-1048577), 1040712641, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 3.0d, 1726527327, orderDirection6, false);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        int int1 = org.apache.commons.math.util.FastMath.round((-2.06124208E17f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection11, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection11, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean17 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 198760639);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 198760639L + "'", long1 == 198760639L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        double double1 = org.apache.commons.math.util.FastMath.signum(44.26015131959809d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (-48L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-48L) + "'", long2 == (-48L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) 'a', 795042428);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-10L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5440211108893698d + "'", double1 == 0.5440211108893698d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double1 = org.apache.commons.math.util.FastMath.expm1(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10335565084L, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11415139612L + "'", long2 == 11415139612L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1881832321521423d) + "'", double1 == (-0.1881832321521423d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 'a');
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) ' ');
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 100);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 32);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 800);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray44 = new double[] { '#', 1.0d, 'a' };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray50 = new double[] { '#', 1.0d, 'a' };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray58 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray58);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray66 = new double[] { '#', 1.0d, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 3.0d);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray73);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 0.7153185320319555d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 877278303 + "'", int46 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 103.12613635737547d + "'", double51 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 877278303 + "'", int52 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 198760607 + "'", int59 == 198760607);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.1582918005242d + "'", double60 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.1582918005242d + "'", double61 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 103.12613635737547d + "'", double67 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 103.12613635737547d + "'", double71 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 59873.352250245545d + "'", double75 == 59873.352250245545d);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray10 = new double[] { '#', 1.0d, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray16 = new double[] { '#', 1.0d, 'a' };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray30);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray16);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray41 = null;
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 3.0d);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray16);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 877278303 + "'", int6 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 103.12613635737547d + "'", double11 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 877278303 + "'", int18 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 101.1582918005242d + "'", double33 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 103.12613635737547d + "'", double43 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 877278303 + "'", int48 == 877278303);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 1347840285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.4376423325770494d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6455566361489027d + "'", double1 == 0.6455566361489027d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 3324781745314725889L, 271620299);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.2741746203232303E79d) + "'", double2 == (-4.2741746203232303E79d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 35651585, 1726527327L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35651585L + "'", long2 == 35651585L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        long long1 = org.apache.commons.math.util.FastMath.round(1.98760607E8d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 198760607L + "'", long1 == 198760607L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1726527327), 1048576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1778384897 + "'", int2 == 1778384897);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 852);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.6159478842956411d), 81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6159478842956411d) + "'", double2 == (-0.6159478842956411d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-95), 1726527327, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-5815114969559414353L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 3.0d);
        java.lang.Class<?> wildcardClass11 = doubleArray3.getClass();
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray18 = null;
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray25 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray15);
        double[] doubleArray33 = new double[] { '#', 1.0d, 'a' };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray43 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray43);
        double[] doubleArray54 = new double[] { '#', 1.0d, 'a' };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray57 = null;
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        java.lang.Class<?> wildcardClass61 = doubleArray54.getClass();
        double[] doubleArray65 = new double[] { '#', 1.0d, 'a' };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray71 = new double[] { '#', 1.0d, 'a' };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray77 = new double[] { '#', 1.0d, 'a' };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double[] doubleArray85 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray77, doubleArray85);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray71, doubleArray85);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray71);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray71);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 198760607 + "'", int26 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 103.12613635737547d + "'", double28 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 103.12613635737547d + "'", double34 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 103.12613635737547d + "'", double35 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 103.12613635737547d + "'", double38 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 877278303 + "'", int39 == 877278303);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 877278303 + "'", int40 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 103.12613635737547d + "'", double55 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 103.12613635737547d + "'", double56 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 103.12613635737547d + "'", double66 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 103.12613635737547d + "'", double67 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 103.12613635737547d + "'", double72 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 877278303 + "'", int73 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 103.12613635737547d + "'", double78 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 877278303 + "'", int79 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 198760607 + "'", int86 == 198760607);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 101.1582918005242d + "'", double87 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 101.1582918005242d + "'", double88 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertEquals((double) double91, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        int int2 = org.apache.commons.math.util.FastMath.min(99, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 1.1102230246251565E-16d);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray38);
        double[] doubleArray54 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray61);
        double[] doubleArray68 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray68);
        double[] doubleArray74 = new double[] { '#', 1.0d, 'a' };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray82 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray74, doubleArray82);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray74);
        double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray58);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 877278303 + "'", int40 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 103.12613635737547d + "'", double60 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 198760607 + "'", int69 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 877278303 + "'", int76 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 198760607 + "'", int83 == 198760607);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 101.1582918005242d + "'", double84 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 59839.14171519782d + "'", double86 == 59839.14171519782d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 103.12613635737547d + "'", double87 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.35151428327459d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7104084308153318d + "'", double1 == 0.7104084308153318d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) ' ');
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (-1934816880));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1683002521388203393L, (float) 35651585L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.5651584E7f + "'", float2 == 3.5651584E7f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 1683002521388203394L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray31 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray31);
        double[] doubleArray37 = new double[] { '#', 1.0d, 'a' };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray43 = new double[] { '#', 1.0d, 'a' };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray49 = new double[] { '#', 1.0d, 'a' };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray57 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray57);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray37);
        double[] doubleArray66 = new double[] { '#', 1.0d, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray72 = new double[] { '#', 1.0d, 'a' };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        double[] doubleArray78 = new double[] { '#', 1.0d, 'a' };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double[] doubleArray86 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray72, doubleArray86);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray72);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 877278303 + "'", int18 == 877278303);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 198760607 + "'", int32 == 198760607);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 101.1582918005242d + "'", double33 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 103.12613635737547d + "'", double38 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 103.12613635737547d + "'", double44 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 877278303 + "'", int45 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 103.12613635737547d + "'", double50 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 877278303 + "'", int51 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 198760607 + "'", int58 == 198760607);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.1582918005242d + "'", double59 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.1582918005242d + "'", double60 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 103.12613635737547d + "'", double67 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 103.12613635737547d + "'", double73 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 877278303 + "'", int74 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 103.12613635737547d + "'", double79 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 877278303 + "'", int80 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 198760607 + "'", int87 == 198760607);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 101.1582918005242d + "'", double88 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.1582918005242d + "'", double89 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (-1074789600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074789600) + "'", int2 == (-1074789600));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1807701355, (float) 198760639L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.9876064E8f + "'", float2 == 1.9876064E8f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) ' ');
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 198760639L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1048576);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 35);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 271620299);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4345658706984465d, (java.lang.Number) 32, 1078034432, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection9, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException11.toString();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException11.getClass();
        java.lang.Number number16 = nonMonotonousSequenceException11.getPrevious();
        boolean boolean17 = nonMonotonousSequenceException11.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(orderDirection12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 35651585, (-1726527360), 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) ' ');
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 198760639L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1048576);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 35);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 3.0d);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 54766527);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 877278303 + "'", int8 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 130.0d + "'", double20 == 130.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        double double1 = org.apache.commons.math.util.FastMath.sin(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5675694228314199d + "'", double1 == 0.5675694228314199d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(795042778L, 33974111L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27010871589520358L + "'", long2 == 27010871589520358L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0444644075186462d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0444644075186464d + "'", double1 == 1.0444644075186464d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        int int13 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.6487212707001282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9740769841801067d + "'", double1 == 0.9740769841801067d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 983569537);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-983569537) + "'", int2 == (-983569537));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.373400766945016d + "'", double1 == 1.373400766945016d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(341642502, 366582743);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1829609409));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int1 = org.apache.commons.math.util.FastMath.abs(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 'a', (-0.6159478842956411d), (-4.2741746203232303E79d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.07859149E9f, 1040712641);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 198);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-332489136));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-45.0f), (java.lang.Number) (-0.03513821552068763d), 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.203117510034154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray31 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray31);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray17);
        double[] doubleArray39 = new double[] { '#', 1.0d, 'a' };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 1.1102230246251565E-16d);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray39);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 877278303 + "'", int19 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 198760607 + "'", int32 == 198760607);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 101.1582918005242d + "'", double33 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 101.1582918005242d + "'", double34 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 877278303 + "'", int41 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 103.12613635737547d + "'", double44 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray25 = null;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        java.lang.Class<?> wildcardClass29 = doubleArray22.getClass();
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray22);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 103.12613635737547d + "'", double27 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 877278303 + "'", int28 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.07610112E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.031853083407121d + "'", double1 == 9.031853083407121d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1556.0255852847893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.043037431402084d + "'", double1 == 8.043037431402084d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 9.835695369999999E8d);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 198760607 + "'", int24 == 198760607);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 101.1582918005242d + "'", double25 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.1582918005242d + "'", double26 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 7.626445578167115E8d + "'", double30 == 7.626445578167115E8d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        float float1 = org.apache.commons.math.util.FastMath.abs(34.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 34.0f + "'", float1 == 34.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(33974145, 341642502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-307668357) + "'", int2 == (-307668357));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35651585, 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1212153857 + "'", int2 == 1212153857);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1040712641, (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.043037431402084d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999997934922273d + "'", double1 == 0.9999997934922273d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9589328250406132d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-784346679231569093L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-784346679231569093L) + "'", long2 == (-784346679231569093L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Class<?> wildcardClass7 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2147483646), 3333);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection17, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection17, false);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Number number23 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection32, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException34.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number27, 10, orderDirection35, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number23, (java.lang.Number) 4.9E-324d, 3332, orderDirection35, false);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.2742927516703394d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100.0f, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2453876422820638470L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4059676247428248E20d + "'", double1 == 1.4059676247428248E20d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        long long2 = org.apache.commons.math.util.MathUtils.pow(97L, 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2848847076375955649L + "'", long2 == 2848847076375955649L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.726527369279165E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.726527369E9d) + "'", double1 == (-1.726527369E9d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) (-565729435));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.6572941E8f) + "'", float2 == (-5.6572941E8f));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(877278303);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1078034432, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray44 = new double[] { '#', 1.0d, 'a' };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray50 = new double[] { '#', 1.0d, 'a' };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray58 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray58);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray66 = new double[] { '#', 1.0d, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 3.0d);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray73);
        double[] doubleArray76 = null;
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 877278303 + "'", int46 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 103.12613635737547d + "'", double51 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 877278303 + "'", int52 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 198760607 + "'", int59 == 198760607);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.1582918005242d + "'", double60 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.1582918005242d + "'", double61 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 103.12613635737547d + "'", double67 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 103.12613635737547d + "'", double71 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 59873.352250245545d + "'", double75 == 59873.352250245545d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray31 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray38 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray38);
        int[] intArray44 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray51 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray44);
        int[] intArray58 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray65 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int[] intArray71 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray78 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray71);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray71);
        java.lang.Class<?> wildcardClass82 = intArray31.getClass();
        int[] intArray87 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray94 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray87);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray31);
        int[] intArray98 = null;
        try {
            int int99 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 104.40785411069419d + "'", double39 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 104.40785411069419d + "'", double52 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 104.40785411069419d + "'", double66 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 104.40785411069419d + "'", double79 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 104.40785411069419d + "'", double95 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection17, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection17, false);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.String str23 = nonMonotonousSequenceException21.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (983,569,537 < 5,614.986)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (983,569,537 < 5,614.986)"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int int2 = org.apache.commons.math.util.MathUtils.pow(795042428, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1.72652736E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.994948473403427d + "'", double1 == 6.994948473403427d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-5.6572941E8f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2118067156) + "'", int1 == (-2118067156));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.89493378E8d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13466940 + "'", int1 == 13466940);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray19 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.0d);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 8.298330314378324d);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray19);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 198760607 + "'", int20 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 198760607 + "'", int36 == 198760607);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 198760607 + "'", int37 == 198760607);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 198760607 + "'", int38 == 198760607);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1347840285, 754210295535290399L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1347840285L + "'", long2 == 1347840285L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-2.582159357367483E-12d), (double) 85973270656L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.003444370168644E-23d) + "'", double2 == (-3.003444370168644E-23d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(198760640L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198760640L + "'", long2 == 198760640L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1.98760602E9f, 34, 795042428);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(74.20321057778875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.614128544303757d + "'", double1 == 8.614128544303757d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 54766479L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray19 = new double[] { '#', 1.0d, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray27 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray19);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 198760607 + "'", int14 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 103.12613635737547d + "'", double20 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 198760607 + "'", int28 == 198760607);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.1582918005242d + "'", double29 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        java.lang.Class<?> wildcardClass27 = intArray4.getClass();
        int[] intArray32 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray39 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray39);
        int[] intArray45 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray52 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray32);
        int[] intArray56 = new int[] {};
        int[] intArray61 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray68 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray68);
        int[] intArray74 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray81 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray74);
        int[] intArray88 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray95 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray88, intArray95);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray88);
        int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray74);
        try {
            double double99 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 104.40785411069419d + "'", double40 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 104.40785411069419d + "'", double53 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 104.40785411069419d + "'", double69 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 104.40785411069419d + "'", double82 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 104.40785411069419d + "'", double96 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.8078724507617987d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1.07859149E9f, 1040712641);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.102242548116635E298d + "'", double2 == 2.102242548116635E298d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray18 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray25);
        int[] intArray31 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray38 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray31);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        try {
            double double42 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 104.40785411069419d + "'", double13 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 104.40785411069419d + "'", double26 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 104.40785411069419d + "'", double39 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        int int2 = org.apache.commons.math.util.MathUtils.pow(366582743, 1078001664);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1023934465 + "'", int2 == 1023934465);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.237173456633567d, (double) 1078034432);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.568532861697655E-9d + "'", double2 == 8.568532861697655E-9d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1048577));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1048577.0d) + "'", double1 == (-1048577.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray20 = new double[] { '#', 1.0d, 'a' };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray26 = new double[] { '#', 1.0d, 'a' };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray20);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray20);
        double[] doubleArray40 = null;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 103.12613635737547d + "'", double21 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 877278303 + "'", int22 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 103.12613635737547d + "'", double27 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 877278303 + "'", int28 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 198760607 + "'", int35 == 198760607);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.1582918005242d + "'", double36 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 101.1582918005242d + "'", double37 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getPrevious();
        int int15 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number23 = nonMonotonousSequenceException19.getArgument();
        int int24 = nonMonotonousSequenceException19.getIndex();
        int int25 = nonMonotonousSequenceException19.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number27 = nonMonotonousSequenceException19.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1040712641 + "'", number14.equals(1040712641));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0L + "'", number23.equals(0L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 198760607 + "'", number27.equals(198760607));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.546754179225521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.696202386462975d + "'", double1 == 4.696202386462975d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-983569537));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0959191077119637d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9124034991009714d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double double1 = org.apache.commons.math.util.FastMath.acosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass10 = doubleArray3.getClass();
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray14);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 44.26015131959809d);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 1.1102230246251565E-16d);
        double[] doubleArray29 = null;
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray29);
        try {
            double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 877278303 + "'", int26 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray19 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.0d);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 8.298330314378324d);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray19);
        java.lang.Class<?> wildcardClass36 = doubleArray11.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 198760607 + "'", int20 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.75616613E8d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 116655L, 3.626860407847019d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 34, (double) (-8.4478909E18f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-48L), 1095479168, 1057093806);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-4.9E-324d) + "'", number6.equals((-4.9E-324d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1212153857);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1100091392 + "'", int1 == 1100091392);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.4779940175198476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.986016221524985d + "'", double1 == 0.986016221524985d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4258259770489514E8d, (java.lang.Number) 1.0f, (-1));
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection8, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        java.lang.Number number17 = nonMonotonousSequenceException15.getPrevious();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.String str19 = nonMonotonousSequenceException15.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException15.getDirection();
        boolean boolean21 = nonMonotonousSequenceException15.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Class<?> wildcardClass23 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0f + "'", number17.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(99.99499987499378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.7359704175800968d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int int2 = org.apache.commons.math.util.FastMath.max((-96), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        double double1 = org.apache.commons.math.util.FastMath.signum((-3628801.9999999995d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray31 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray31);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        double[] doubleArray39 = new double[] { '#', 1.0d, 'a' };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray42);
        double[] doubleArray49 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray49);
        double[] doubleArray55 = new double[] { '#', 1.0d, 'a' };
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray63 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray55, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray55);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray55);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 877278303 + "'", int19 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 198760607 + "'", int32 == 198760607);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 101.1582918005242d + "'", double33 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 101.1582918005242d + "'", double34 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 103.12613635737547d + "'", double41 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 198760607 + "'", int50 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 103.12613635737547d + "'", double56 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 877278303 + "'", int57 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 198760607 + "'", int64 == 198760607);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 101.1582918005242d + "'", double65 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        long long1 = org.apache.commons.math.util.FastMath.abs((-3628780L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628780L + "'", long1 == 3628780L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 5063141360940L);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 198760639L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 1900544);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 2147483647);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 198760639L, Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7627252785293671909L, (java.lang.Number) 10000, (-565729435), orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) (-332488336L), 0, orderDirection10, true);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(800L, 1726527327L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1381221861600L + "'", long2 == 1381221861600L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (-5.06314136094E12d));
        java.lang.Number number12 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException23.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number16, 10, orderDirection24, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 4.9E-324d, 3332, orderDirection24, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection24, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (1 <= 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 103.12613635737547d + "'", double9 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1048608, 1212153857);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 366582743, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1862128895), 1987606070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125477175 + "'", int2 == 125477175);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.0000000000000004d, 1057093806);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.789048565205904E52d) + "'", double2 == (-4.789048565205904E52d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 5L, 33974111);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-5815114969559414353L), (double) 1048608, (-4.9E-324d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection11, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection11, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0 + "'", number17.equals(0));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 2453876422820638470L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.726527327E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1987606070);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24895925166644647d) + "'", double1 == (-0.24895925166644647d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str14 = nonMonotonousSequenceException10.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7745966692414834d, (java.lang.Number) 800L, 99);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 98 and 99 are not strictly increasing (800 >= 0.775)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 98 and 99 are not strictly increasing (800 >= 0.775)"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        double double1 = org.apache.commons.math.util.FastMath.log10(12900.52438982139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.110607364173441d + "'", double1 == 4.110607364173441d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 60L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.986016221524985d, 1.2619600956683044d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.986016221524985d + "'", double2 == 0.986016221524985d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 800, (long) 3332);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3332L + "'", long2 == 3332L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 97);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 35651585);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) (-2147483648));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.203117510034154d, (java.lang.Number) (-0.033203346412116204d), 1040712641);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1048576);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2848847076375955649L, 5296430760682117539L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7839891422640569791L) + "'", long2 == (-7839891422640569791L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1347840285));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1347840256) + "'", int1 == (-1347840256));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.6272527852936714E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.88236814017905d + "'", double1 == 18.88236814017905d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.9876063900000003E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.98760639E8d + "'", double1 == 1.98760639E8d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-21.873953557219664d), (-10.158170418955065d), (double) 3.3974112E7f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        double double1 = org.apache.commons.math.util.FastMath.expm1(100.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.571337886088074E43d + "'", double1 == 4.571337886088074E43d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double1 = org.apache.commons.math.util.FastMath.rint(100.00499987500626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.3350745897699942E18d + "'", number5.equals(8.3350745897699942E18d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 97);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 3628800);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 32L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger15);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 3628800);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 198760639L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1048576);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, (long) 1726527424);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1726527424L + "'", long2 == 1726527424L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1388145748023352E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.848985985226562d + "'", double1 == 23.848985985226562d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        float float1 = org.apache.commons.math.util.FastMath.abs(3.5651584E7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.5651584E7f + "'", float1 == 3.5651584E7f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        double double2 = org.apache.commons.math.util.MathUtils.round(19.107611678628125d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.0d + "'", double2 == 19.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1394038287));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(8.80447516132867d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3331.9998499399812d + "'", double1 == 3331.9998499399812d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 877278272, 271620299);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1726527360));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.9876060676852348E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.138814390129578E11d + "'", double1 == 1.138814390129578E11d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.4163847498715596d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.190119636789327d + "'", double1 == 1.190119636789327d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3332L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3332L + "'", long2 == 3332L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(198760607, 341642502);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 540403109 + "'", int2 == 540403109);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.203117510034154d, (java.lang.Number) (-0.033203346412116204d), 1040712641);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.1752011936438014d + "'", number6.equals(1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not decreasing (1.175 < �)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not decreasing (1.175 < �)"));
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1078034432);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.49155243011387d + "'", double1 == 21.49155243011387d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1112248228), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1112248228) + "'", int2 == (-1112248228));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 34.0f, (double) 33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9915343417267494d + "'", double2 == 0.9915343417267494d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.8151149695594148E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 3324781745314725889L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.32478188E18f + "'", float2 == 3.32478188E18f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray13 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray32);
        double[] doubleArray40 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray45 = new double[] { '#', 1.0d, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray48 = null;
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 3.0d);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray45);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 8.298330314378324d);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray40);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 877278303 + "'", int10 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 877278303 + "'", int26 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 198760607 + "'", int33 == 198760607);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 101.1582918005242d + "'", double34 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 198760607 + "'", int41 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 103.12613635737547d + "'", double50 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 198760607 + "'", int57 == 198760607);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 198760607 + "'", int58 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number13 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.627482429927895d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1807701355, 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 3.0d);
        java.lang.Class<?> wildcardClass11 = doubleArray3.getClass();
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray18 = null;
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray18);
        double[] doubleArray25 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray15);
        double[] doubleArray33 = new double[] { '#', 1.0d, 'a' };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray39 = new double[] { '#', 1.0d, 'a' };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray45 = new double[] { '#', 1.0d, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray53 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray53);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray39);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 5296430760483356672L);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray64 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray68 = new double[] { '#', 1.0d, 'a' };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray68);
        double[] doubleArray74 = new double[] { '#', 1.0d, 'a' };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 198760607 + "'", int26 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 103.12613635737547d + "'", double28 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 103.12613635737547d + "'", double34 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 103.12613635737547d + "'", double35 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 877278303 + "'", int41 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 877278303 + "'", int47 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 198760607 + "'", int54 == 198760607);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 101.1582918005242d + "'", double55 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.1582918005242d + "'", double56 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 103.12613635737547d + "'", double61 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 103.12613635737547d + "'", double69 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 877278303 + "'", int77 == 877278303);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 877278303 + "'", int78 == 877278303);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1074789600), 3332);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) Float.NEGATIVE_INFINITY, 43.8067120067666d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1.07859149E9f, (double) '4', (-21.96252510231819d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 198760639L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1048576);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 35);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-1726527360));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        java.lang.Class<?> wildcardClass16 = doubleArray11.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.198039027185569d + "'", double14 == 10.198039027185569d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 198760607 + "'", int15 == 198760607);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-25.092534979676547d) + "'", double1 == (-25.092534979676547d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number6, 10, orderDirection14, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.String str18 = nonMonotonousSequenceException16.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0f, (java.lang.Number) 3.174802103936399d, 2147483647, orderDirection26, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly decreasing (null <= 341,642,502)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly decreasing (null <= 341,642,502)"));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-3628800), 1987606070, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.503599627370496E15d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.503599627370496E15d + "'", double2 == 4.503599627370496E15d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1726527327), (long) (-1829609409));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1052956880791606581L + "'", long2 == 1052956880791606581L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-96), (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1900544, (-1933768272));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        int int2 = org.apache.commons.math.util.MathUtils.pow(983569537, (long) 1023934465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1587549313 + "'", int2 == 1587549313);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(94.81203007518798d, (double) 198760640L, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(260, (-1112248228));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1778384897, 198760640);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(208415635800064L, (long) 16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.19240232444172617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 198760640L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.3459295198712498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12902231848200288d + "'", double1 == 0.12902231848200288d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9912260756924949d + "'", double1 == 1.9912260756924949d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { '#', 1.0d, 'a' };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray17);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray66 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray52);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 0.0d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 103.12613635737547d + "'", double30 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 198760607 + "'", int38 == 198760607);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 101.1582918005242d + "'", double39 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 877278303 + "'", int54 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 198760607 + "'", int67 == 198760607);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(doubleArray73);
    }
}

