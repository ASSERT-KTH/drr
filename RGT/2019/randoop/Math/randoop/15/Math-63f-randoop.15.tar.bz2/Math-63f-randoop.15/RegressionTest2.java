import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection15, true);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100.0f + "'", number18.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1040712641 + "'", number11.equals(1040712641));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.033203346412116204d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0005512817509647d + "'", double1 == 1.0005512817509647d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 198760607);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.98760607E8d + "'", double1 == 1.98760607E8d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5.0d, (double) (-1726527371L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.726527369279165E9d) + "'", double2 == (-1.726527369279165E9d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.FastMath.min((-1933768272), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1933768272) + "'", int2 == (-1933768272));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2), (long) 98);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 3332, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5296430760483356672L + "'", long2 == 5296430760483356672L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.9276132068968583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int1 = org.apache.commons.math.util.MathUtils.sign(341642502);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 260);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        float float2 = org.apache.commons.math.util.FastMath.min(1.98760602E9f, (float) 4L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 0.37424182806052114d, (-1726527327));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.142219984546603E-13d + "'", number5.equals(8.142219984546603E-13d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1108998363917509664L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.04493090544391d + "'", double1 == 18.04493090544391d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray17);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.0d);
        double[] doubleArray26 = new double[] { '#', 1.0d, 'a' };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double[] doubleArray42 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray50 = null;
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 3.0d);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 8.298330314378324d);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray42);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (-0.8302447490652984d));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 198760607 + "'", int18 == 198760607);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.1582918005242d + "'", double19 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 101.1582918005242d + "'", double20 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 103.12613635737547d + "'", double27 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 877278303 + "'", int28 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 198760607 + "'", int35 == 198760607);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.1582918005242d + "'", double36 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 198760607 + "'", int43 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 103.12613635737547d + "'", double49 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 103.12613635737547d + "'", double52 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray31 = new double[] { '#', 1.0d, 'a' };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray34);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray40 = new double[] { '#', 1.0d, 'a' };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray40);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 198760607 + "'", int24 == 198760607);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 101.1582918005242d + "'", double25 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.1582918005242d + "'", double26 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 103.12613635737547d + "'", double32 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 103.12613635737547d + "'", double33 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 877278303 + "'", int36 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 103.12613635737547d + "'", double41 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 877278303 + "'", int48 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 877278303 + "'", int54 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 198760607 + "'", int61 == 198760607);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 101.1582918005242d + "'", double62 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 101.1582918005242d + "'", double63 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int int1 = org.apache.commons.math.util.MathUtils.sign(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.cosh(59839.14171519782d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.8856731442731174d, 198760639);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.7797302154510816E57d) + "'", double2 == (-2.7797302154510816E57d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1040712641, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 375616613L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        long long2 = org.apache.commons.math.util.MathUtils.pow(5L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-71535587), 1040712641);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1112248228) + "'", int2 == (-1112248228));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        int int14 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (100 >= 8,335,074,589,769,994,200)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1991599724L, (long) 800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1593279779200L + "'", long2 == 1593279779200L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1001116801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1370.371413881156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int1 = org.apache.commons.math.util.MathUtils.sign(800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double[] doubleArray2 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray9);
        double[] doubleArray16 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray22 = new double[] { '#', 1.0d, 'a' };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray44 = new double[] { '#', 1.0d, 'a' };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray50 = new double[] { '#', 1.0d, 'a' };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray58 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray58);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        double[] doubleArray66 = new double[] { '#', 1.0d, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 3.0d);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray73);
        double[] doubleArray79 = new double[] { '#', 1.0d, 'a' };
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray87 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int88 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray79, doubleArray87);
        double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray79);
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 103.12613635737547d + "'", double8 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 198760607 + "'", int17 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 103.12613635737547d + "'", double23 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 198760607 + "'", int31 == 198760607);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 101.1582918005242d + "'", double32 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 59839.14171519782d + "'", double34 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 103.12613635737547d + "'", double40 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 877278303 + "'", int46 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 103.12613635737547d + "'", double51 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 877278303 + "'", int52 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 198760607 + "'", int59 == 198760607);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.1582918005242d + "'", double60 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.1582918005242d + "'", double61 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 103.12613635737547d + "'", double67 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 103.12613635737547d + "'", double71 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 59873.352250245545d + "'", double75 == 59873.352250245545d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 103.12613635737547d + "'", double80 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 877278303 + "'", int81 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 198760607 + "'", int88 == 198760607);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.1582918005242d + "'", double89 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 59839.14174862076d + "'", double90 == 59839.14174862076d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 103.12613635737547d + "'", double91 == 103.12613635737547d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1199.659016775285d), (java.lang.Number) 0, 0, orderDirection3, false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.7184493636924868d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 989493378 + "'", int1 == 989493378);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1078591488, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6389612763136348d + "'", double1 == 0.6389612763136348d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 0, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8856731442731174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7248430881283403d + "'", double1 == 0.7248430881283403d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1347840285), 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        int int2 = org.apache.commons.math.util.FastMath.min((-1048577), 1987606070);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1048577) + "'", int2 == (-1048577));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger5 = null;
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(989493378, 1726527327);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 3628800L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1095479168 + "'", int1 == 1095479168);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.tanh(94.81203007518798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray19 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 3.0d);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray24);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 8.298330314378324d);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray19);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 198760607 + "'", int20 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 103.12613635737547d + "'", double29 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 198760607 + "'", int36 == 198760607);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99627207622075d + "'", double1 == 0.99627207622075d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.537297501373361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2), 3628800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-3628802) + "'", int2 == (-3628802));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(13.532536430142315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 376769.64165434643d + "'", double1 == 376769.64165434643d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.7031839360032603E-108d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7818280418450374E-124d + "'", double1 == 3.7818280418450374E-124d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.07610112E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0927837451120071d + "'", double1 == 0.0927837451120071d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(130L, (long) (-1726527423));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.03549223717331409d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000629915570948d + "'", double1 == 1.000629915570948d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.537297501373361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0442841955015905d + "'", double1 == 0.0442841955015905d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray17);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 198760607 + "'", int18 == 198760607);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.1582918005242d + "'", double19 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 101.1582918005242d + "'", double20 == 101.1582918005242d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.7184493636924868d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6159478842956411d) + "'", double1 == (-0.6159478842956411d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 198760607);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number6, 10, orderDirection14, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8221188003905089d + "'", double1 == 0.8221188003905089d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 3L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.6159478842956411d), 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 800.0f, (java.lang.Number) (-1), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 800.0f + "'", number4.equals(800.0f));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.090905898573277d, (double) 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.8151149695594148E18d + "'", double2 == 5.8151149695594148E18d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(20L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.726527369279165E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.380514157859815d) + "'", double1 == (-3.380514157859815d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6931471805599453d, (double) 3628800);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection24, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection24, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (1 <= 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 198760607 + "'", int18 == 198760607);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.1582918005242d + "'", double19 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 101.1582918005242d + "'", double20 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.4345658706984465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0959191077119637d + "'", double1 == 1.0959191077119637d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 10, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-22) + "'", int2 == (-22));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3246090892520057d + "'", double1 == 1.3246090892520057d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.1894212981280368d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5743054480847022d + "'", double1 == 0.5743054480847022d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2), (long) 877278303);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-5063141360940L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.Number number3 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection12, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number7, 10, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 4.9E-324d, 3332, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 800, 0, orderDirection15, true);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1991599724, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.7621956910836314d, (double) 198760867L, 0.1894212981280368d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.489757452525488d + "'", double1 == 21.489757452525488d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1L, (-22));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 8335074589769994240L, (-1.7265273709999998E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.726527488E9d) + "'", double2 == (-1.726527488E9d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(5296430760483356672L, 198760867L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5296430760682117539L + "'", long2 == 5296430760682117539L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray19 = new double[] { '#', 1.0d, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray27 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray34 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray38);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { '#', 1.0d, 'a' };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray51 = new double[] { '#', 1.0d, 'a' };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray57 = new double[] { '#', 1.0d, 'a' };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray65);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        double[] doubleArray73 = new double[] { '#', 1.0d, 'a' };
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray76 = null;
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 3.0d);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray80);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 877278303 + "'", int15 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 103.12613635737547d + "'", double20 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 198760607 + "'", int28 == 198760607);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.1582918005242d + "'", double29 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 877278303 + "'", int41 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 103.12613635737547d + "'", double52 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 877278303 + "'", int53 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 103.12613635737547d + "'", double58 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 877278303 + "'", int59 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 198760607 + "'", int66 == 198760607);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 101.1582918005242d + "'", double67 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 103.12613635737547d + "'", double74 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 103.12613635737547d + "'", double78 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 94.81203007518798d + "'", double82 == 94.81203007518798d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 198760867L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.35151428327459d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1), (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(97, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 33.0f, (double) 1987606070);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.0d + "'", double2 == 33.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray10 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray14 = new double[] { '#', 1.0d, 'a' };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray17);
        double[] doubleArray24 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray24);
        double[] doubleArray30 = new double[] { '#', 1.0d, 'a' };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray38 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray38);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray30);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray14);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray66 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        double[] doubleArray74 = new double[] { '#', 1.0d, 'a' };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray77 = null;
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 3.0d);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray81);
        double[] doubleArray87 = new double[] { '#', 1.0d, 'a' };
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        double[] doubleArray95 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int96 = org.apache.commons.math.util.MathUtils.hash(doubleArray95);
        double double97 = org.apache.commons.math.util.MathUtils.distance(doubleArray87, doubleArray95);
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray87);
        double double99 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 198760607 + "'", int25 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 877278303 + "'", int32 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 198760607 + "'", int39 == 198760607);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 59839.14171519782d + "'", double42 == 59839.14171519782d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 877278303 + "'", int54 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 198760607 + "'", int67 == 198760607);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 103.12613635737547d + "'", double75 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 103.12613635737547d + "'", double76 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 103.12613635737547d + "'", double79 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 59873.352250245545d + "'", double83 == 59873.352250245545d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 103.12613635737547d + "'", double88 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 877278303 + "'", int89 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 198760607 + "'", int96 == 198760607);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 101.1582918005242d + "'", double97 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 59839.14174862076d + "'", double98 == 59839.14174862076d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 103.12613635737547d + "'", double99 == 103.12613635737547d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray6);
        double[] doubleArray13 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray13);
        double[] doubleArray19 = new double[] { '#', 1.0d, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray27 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray19);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 198760607 + "'", int14 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 103.12613635737547d + "'", double20 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 198760607 + "'", int28 == 198760607);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.1582918005242d + "'", double29 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 103.12613635737547d + "'", double31 == 103.12613635737547d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 0, 989493378);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 5296430760483356672L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.98760602E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.987606016E9d + "'", double1 == 1.987606016E9d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        float float2 = org.apache.commons.math.util.MathUtils.round(Float.NaN, (-1726527360));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (-1 >= -0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1) + "'", number7.equals((-1)));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, 1987606070);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1726527371L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1048577.0d), 1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 198760639L);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-1726527371L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1001116801, (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076101120L + "'", long2 == 1076101120L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8335074589769994240L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1048576);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.556090791759079d + "'", double1 == 14.556090791759079d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 3332);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.804475206364689d + "'", double1 == 8.804475206364689d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1726527423), 1076101120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1726527423L) + "'", long2 == (-1726527423L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number15 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1040712641 + "'", number14.equals(1040712641));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1040712641 + "'", number15.equals(1040712641));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int2 = org.apache.commons.math.util.FastMath.min(341642502, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable throwable14 = null;
        try {
            nonMonotonousSequenceException9.addSuppressed(throwable14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 35651585, 32, 260);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.tan(130.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5323384274693232d + "'", double1 == 2.5323384274693232d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', (float) (-10L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1726527360), (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5403023058681398d, (double) 35L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.35151428327459d, 5.000000000000001d, 2.5323384274693232d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2), 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        long long1 = org.apache.commons.math.util.FastMath.round(7.4372836722600485E22d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-22), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 0, (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1048577));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9727535843134413d) + "'", double1 == (-0.9727535843134413d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 260);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 260 + "'", int1 == 260);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 351L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3687784289075653E152d + "'", double1 == 1.3687784289075653E152d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 198760639L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 99);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) ' ');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        int int13 = nonMonotonousSequenceException5.getIndex();
        int int14 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5707963262156994d, 2.3536109559791604E92d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.673984594714845E-93d + "'", double2 == 6.673984594714845E-93d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-3628802), 1078591488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.8115262724608532d, 7115.053031976556d, 21.489757452525488d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1048576, 1593279779200L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.8189854738044024E42d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1388145748023352E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 375616613L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.509799193225255d + "'", double1 == 21.509799193225255d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 198760639L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.98760639E8d + "'", double1 == 1.98760639E8d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-3628800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(104.41264291262816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1086760407418709E45d + "'", double1 == 1.1086760407418709E45d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1726527424);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0133588174776167E7d + "'", double1 == 3.0133588174776167E7d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1048577.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-5063141360940L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3431851641374776E20d + "'", double1 == 3.3431851641374776E20d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.floor(59873.352250245545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 59873.0d + "'", double1 == 59873.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.831008000716576E22d, (double) 1991599724L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 989493378);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.3660146172838242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 100, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly decreasing (100 <= 0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100.0f + "'", number10.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0f + "'", number12.equals(100.0f));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7745966692414834d, (java.lang.Number) 198760639L, (int) (byte) 1, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 33974111, (-1347840285));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double[] doubleArray5 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = new double[] { '#', 1.0d, 'a' };
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 3.0d);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray10);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 8.298330314378324d);
        double[] doubleArray24 = new double[] { '#', 1.0d, 'a' };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double[] doubleArray34 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray24);
        double[] doubleArray40 = new double[] { 59874.14171519782d, (-1.0f) };
        double[] doubleArray44 = new double[] { '#', 1.0d, 'a' };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray47);
        double[] doubleArray54 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray54);
        double[] doubleArray60 = new double[] { '#', 1.0d, 'a' };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double[] doubleArray68 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray68);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray60);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray44);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 198760607 + "'", int6 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 103.12613635737547d + "'", double11 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 103.12613635737547d + "'", double25 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 198760607 + "'", int35 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 198760607 + "'", int55 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 103.12613635737547d + "'", double61 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 877278303 + "'", int62 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 198760607 + "'", int69 == 198760607);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 101.1582918005242d + "'", double70 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 59839.14171519782d + "'", double72 == 59839.14171519782d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int2 = org.apache.commons.math.util.MathUtils.pow(341642467, 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 271620299 + "'", int2 == 271620299);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray32 = new double[] { '#', 1.0d, 'a' };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray38 = new double[] { '#', 1.0d, 'a' };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray44 = new double[] { '#', 1.0d, 'a' };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray52 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray52);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray32);
        double[] doubleArray61 = new double[] { '#', 1.0d, 'a' };
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray67 = new double[] { '#', 1.0d, 'a' };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray73 = new double[] { '#', 1.0d, 'a' };
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double[] doubleArray81 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray73, doubleArray81);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray81);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray67);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray67);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 877278303 + "'", int20 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 198760607 + "'", int27 == 198760607);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.1582918005242d + "'", double28 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 103.12613635737547d + "'", double33 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 103.12613635737547d + "'", double34 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 103.12613635737547d + "'", double39 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 877278303 + "'", int40 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 103.12613635737547d + "'", double45 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 877278303 + "'", int46 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 198760607 + "'", int53 == 198760607);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 101.1582918005242d + "'", double54 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 101.1582918005242d + "'", double55 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 103.12613635737547d + "'", double62 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 103.12613635737547d + "'", double63 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 877278303 + "'", int69 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 103.12613635737547d + "'", double74 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 877278303 + "'", int75 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 198760607 + "'", int82 == 198760607);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 101.1582918005242d + "'", double83 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 101.1582918005242d + "'", double84 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1726527423), (float) 1078591488);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07859149E9f + "'", float2 == 1.07859149E9f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray8 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray12);
        double[] doubleArray18 = new double[] { '#', 1.0d, 'a' };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray18);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 989493378, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1347840285));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1347840285 + "'", int2 == 1347840285);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5063141360940L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.1752011936438014d + "'", number7.equals(1.1752011936438014d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.8189854738044024E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4376423325770494d) + "'", double1 == (-0.4376423325770494d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2, 5.015453888922038E-9d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        int int9 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9968748198371793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9968748198371794d + "'", double1 == 0.9968748198371794d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray9 = new double[] { '#', 1.0d, 'a' };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray15 = new double[] { '#', 1.0d, 'a' };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray31 = new double[] { '#', 1.0d, 'a' };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray34);
        double[] doubleArray41 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray41);
        double[] doubleArray47 = new double[] { '#', 1.0d, 'a' };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray47);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray47);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 2.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.12613635737547d + "'", double5 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.12613635737547d + "'", double10 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 877278303 + "'", int11 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.12613635737547d + "'", double16 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 198760607 + "'", int24 == 198760607);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 101.1582918005242d + "'", double25 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.1582918005242d + "'", double26 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 103.12613635737547d + "'", double32 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 103.12613635737547d + "'", double33 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 198760607 + "'", int42 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 877278303 + "'", int49 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 198760607 + "'", int56 == 198760607);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.1582918005242d + "'", double57 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(97.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-5063141360940L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-17171.438718794747d) + "'", double1 == (-17171.438718794747d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 198760639, (long) 35651585);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35651585L + "'", long2 == 35651585L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1048577));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(877278303, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1726527327));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1726527327) + "'", int2 == (-1726527327));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-2), (-1726527327));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.8460065493236117E48d) + "'", double2 == (-5.8460065493236117E48d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.987606016E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.125853202993979d) + "'", double1 == (-1.125853202993979d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int2 = org.apache.commons.math.util.FastMath.min(3628800, 198760640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3628800 + "'", int2 == 3628800);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(198760640, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 198760640 + "'", int2 == 198760640);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-1048577));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(59873.0d, (-9.892273157211768E10d), (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1991599724L, 2, (-1726527327));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-784346679231569093L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.98760602E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.103343925013753d + "'", double1 == 22.103343925013753d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-95), (long) (-2));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3628800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 35651585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35651585 + "'", int2 == 35651585);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '4', (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-45L) + "'", long2 == (-45L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(3332, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3333 + "'", int2 == 3333);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 800.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8939696481970214d + "'", double1 == 0.8939696481970214d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(9.237173456633567d, 3332, 341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) (-1347840285));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1347840285L + "'", long2 == 1347840285L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1726527327), (long) 3628800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1726527327L) + "'", long2 == (-1726527327L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray23 = new double[] { '#', 1.0d, 'a' };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { '#', 1.0d, 'a' };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray17);
        double[] doubleArray46 = new double[] { '#', 1.0d, 'a' };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray52 = new double[] { '#', 1.0d, 'a' };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray58 = new double[] { '#', 1.0d, 'a' };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray66 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray66);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray52);
        java.lang.Number number75 = null;
        java.lang.Number number79 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection84, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection87 = nonMonotonousSequenceException86.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 341642502, number79, 10, orderDirection87, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException91 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number75, (java.lang.Number) 4.9E-324d, 3332, orderDirection87, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 29937.070865949758d, (java.lang.Number) 0.9276132068968583d, (int) (short) -1, orderDirection87, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection87, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (1 <= 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 103.12613635737547d + "'", double24 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 877278303 + "'", int25 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 103.12613635737547d + "'", double30 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 877278303 + "'", int31 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 198760607 + "'", int38 == 198760607);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 101.1582918005242d + "'", double39 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 101.1582918005242d + "'", double40 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 103.12613635737547d + "'", double47 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 103.12613635737547d + "'", double48 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 103.12613635737547d + "'", double53 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 877278303 + "'", int54 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 877278303 + "'", int60 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 198760607 + "'", int67 == 198760607);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 101.1582918005242d + "'", double68 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 101.1582918005242d + "'", double69 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection87 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection87.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-10.0f), 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(98L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7359704175800968d) + "'", double1 == (-0.7359704175800968d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int1 = org.apache.commons.math.util.FastMath.abs(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.9727535843134413d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-22), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(57.723478758647246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3307.3117116835433d + "'", double1 == 3307.3117116835433d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 989493378);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.89493378E8d + "'", double1 == 9.89493378E8d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 198760639L);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (-5063141360940L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.673984594714845E-93d, 0.5529523200824553d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 5296430760483356672L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.2964307604833567E18d + "'", double1 == 5.2964307604833567E18d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(877278303, (-1726527327));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 0, 5815114969559414353L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5815114969559414353L) + "'", long2 == (-5815114969559414353L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(206124209575858481L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-206124209575858481L) + "'", long2 == (-206124209575858481L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8306408778607839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.6622890612135942E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.662289061213595E-8d + "'", double1 == 2.662289061213595E-8d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 103.12613635737547d + "'", double17 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 989493378, (double) 95L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.894933779999999E8d + "'", double2 == 9.894933779999999E8d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1726527360));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 97, 5063141360940L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 98, 3628800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.7219067166708869d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5296430760682117539L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-8.4478909E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.4478908838308741E18d) + "'", double1 == (-8.4478908838308741E18d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 34L, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1991599724, (-22));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9995192260716705d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-95), (-1048577), 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (-3628800));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-3628802), (-1), 1991599724);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 3332L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.804475161328668d + "'", double1 == 8.804475161328668d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(32.0d, (-7.640113401817825d), (double) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9905373453108037d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1991599724L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.105351214710193d + "'", double1 == 22.105351214710193d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 1347840285);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray11);
        double[] doubleArray17 = new double[] { '#', 1.0d, 'a' };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray17);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 198760607 + "'", int12 == 198760607);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.1582918005242d + "'", double13 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 103.12613635737547d + "'", double18 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 103.12613635737547d + "'", double19 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 103.12613635737547d + "'", double22 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 877278303 + "'", int23 == 877278303);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 877278303 + "'", int24 == 877278303);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1726527423), (-1726527327));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-96) + "'", int2 == (-96));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(20L, 206124209575858481L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 206124209575858501L + "'", long2 == 206124209575858501L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(18.84955592153876d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.84955592153876d + "'", double2 == 18.84955592153876d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1683002521388203394L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 10, (-1347840285));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9640275800758169d) + "'", double1 == (-0.9640275800758169d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1108998363917509664L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(20L, (long) 3628800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3628780L) + "'", long2 == (-3628780L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.log1p(197.58936642730797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.291239207515518d + "'", double1 == 5.291239207515518d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int2 = org.apache.commons.math.util.FastMath.max(2, 33974111);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33974111 + "'", int2 == 33974111);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(341642502, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.abs(20.796610271965548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610271965548d + "'", double1 == 20.796610271965548d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double2 = org.apache.commons.math.util.FastMath.max(800.0d, (-0.6159478842956411d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 800.0d + "'", double2 == 800.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 8335074589769994240L, 1078034432);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.3350745897699942E18d + "'", double2 == 8.3350745897699942E18d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-98922731572L), 3.831008000716576E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.582159357367483E-12d) + "'", double2 == (-2.582159357367483E-12d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.3246090892520057d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long2 = org.apache.commons.math.util.FastMath.min(350L, (long) 1001116801);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350L + "'", long2 == 350L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1040712641);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 800.0d, (java.lang.Number) (-71535587), 1040712641);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1728455558494460171L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, 35651585);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35651586 + "'", int2 == 35651586);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.2003257647899614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3370706212950894d + "'", double1 == 1.3370706212950894d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) (-10L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-10L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-71535587));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.098687220090918E9d) + "'", double1 == (-4.098687220090918E9d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.0133588174776167E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int1 = org.apache.commons.math.util.FastMath.round(33.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 34, (long) 34);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-5063141360940L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0280589699575455d) + "'", double1 == (-1.0280589699575455d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 34, (long) 341642467);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 341642467L + "'", long2 == 341642467L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-45L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-45.0f) + "'", float2 == (-45.0f));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1991599724, (-1933768272), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1L, 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1726527360), 271620299);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.8115262724608532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3459295198712498d + "'", double1 == 1.3459295198712498d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 2, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-22));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1078034432, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078034335L + "'", long2 == 1078034335L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 198760607 + "'", number8.equals(198760607));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.75616613E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.75616613E8d + "'", double1 == 3.75616613E8d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(34.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.584073464102069d + "'", double2 == 2.584073464102069d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.8115262724608532d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.3978952727983707d, (-2), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(33974111, (-1726527423));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-6.30716580272248E-4d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0857586789923365d) + "'", double1 == (-0.0857586789923365d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1001116801, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0063135934339496E275d + "'", double2 == 1.0063135934339496E275d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.683317618811995E36d + "'", double1 == 8.683317618811995E36d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 0.37424182806052114d, (-1726527327));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.968492992744144d, (java.lang.Number) 0.0d, 260, orderDirection9, true);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.37424182806052114d + "'", number5.equals(0.37424182806052114d));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.968492992744144d, (java.lang.Number) 0.0d, 260, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1), (int) ' ');
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.4221817809573358E-5d, (double) (-4350707652395722591L), 0.7248430881283403d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1095479168, 1040712641);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54766527 + "'", int2 == 54766527);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(97, 35651585);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-22), 3307.3117116835433d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-22), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-22) + "'", int2 == (-22));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1347840285);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1347840285L + "'", long1 == 1347840285L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.835695369999999E8d, (java.lang.Number) 0.36787944117144233d, 97, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9602525677891275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 0, 198760640);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-3628802), 54766527);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long2 = org.apache.commons.math.util.FastMath.min(9223372036854775807L, 1683002521388203394L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1683002521388203394L + "'", long2 == 1683002521388203394L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-71535587), (long) 271620299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-565729435) + "'", int2 == (-565729435));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-98922731572L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 198760639, (-71535587));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1001116801, (-1726527423L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1728455610552533823L + "'", long2 == 1728455610552533823L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1726527371L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 0.37424182806052114d, (-1726527327));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.37424182806052114d + "'", number5.equals(0.37424182806052114d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1726527327) + "'", int6 == (-1726527327));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 198760639, (long) 34);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198760605L + "'", long2 == 198760605L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 341642467L, 13.651533448556522d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 3332L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1095479168, 52.66337773023506d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707962787215244d + "'", double2 == 1.5707962787215244d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.9589328250406132d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.496106270390805d + "'", double1 == 1.496106270390805d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1347840285));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 33.0f, (double) 341642467L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(9.892273460879399E10d, 1347840285, (-1726527327));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.8115262724608534d, (double) (-95));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.12252626670378d + "'", double2 == 3.12252626670378d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 34L + "'", long1 == 34L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.7248430881283403d, 32, 3628800);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(341642467, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3332, 198760639, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int[] intArray18 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        int[] intArray32 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray39 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray32);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray18);
        java.lang.Class<?> wildcardClass43 = intArray18.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 104.40785411069419d + "'", double13 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 104.40785411069419d + "'", double26 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 104.40785411069419d + "'", double40 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1347840285), 0.75d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4345658706984465d, (java.lang.Number) 32, 1078034432, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.496106270390805d, (java.lang.Number) 1.07610112E9f, 198760639, orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 34L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.0d + "'", double1 == 34.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 10, (long) (-1933768272));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-19337682720L) + "'", long2 == (-19337682720L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.00313007373653843d), (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.6057648134614585d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01057259048763172d) + "'", double1 == (-0.01057259048763172d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 33.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2075343299958265d + "'", double1 == 3.2075343299958265d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1040712641);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.456318727726337d + "'", double1 == 21.456318727726337d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(198760867L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10335565084L + "'", long2 == 10335565084L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1L, (double) 1726527424);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.asin((-2.7797302154510816E57d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 18.84955592153876d, (-1726527360), orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5614.986392282068d, (java.lang.Number) 983569537, 97, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4163847498715594d, (java.lang.Number) 1.9876060676852348E9d, 260, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1L, (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1726527423), 3333);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 33974111);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.531148101376695d + "'", double1 == 7.531148101376695d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 206124209575858481L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5707962928328254d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.396207121659021E-8d + "'", double1 == 3.396207121659021E-8d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        long long2 = org.apache.commons.math.util.FastMath.min(8335074589769994240L, (long) 3333);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3333L + "'", long2 == 3333L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.03549223717331409d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 877278303 + "'", int15 == 877278303);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 877278303 + "'", int16 == 877278303);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 877278303 + "'", int17 == 877278303);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int2 = org.apache.commons.math.util.FastMath.min(198760607, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5435938534266416E16d + "'", double1 == 4.5435938534266416E16d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1991599724);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5815114969559414353L, (float) 10335565084L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.03355648E10f + "'", float2 == 1.03355648E10f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.9905373453108037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 341642502, (-1112248228), 198760639);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-95L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-95L) + "'", long1 == (-95L));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', (-8.4478909E18f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.4478909E18f) + "'", float2 == (-8.4478909E18f));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.asinh(22.103343925013753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7893874043040556d + "'", double1 == 3.7893874043040556d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(206124209575858481L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 34, (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int2 = org.apache.commons.math.util.FastMath.min(983569537, (-96));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-96) + "'", int2 == (-96));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(98, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 198 + "'", int2 == 198);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8856731442731174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 1726527424);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) (-1726527423L), 2147483647);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.4338530951473415E105d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9999999999999999d, (double) 206124209575858501L, 3628800.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long2 = org.apache.commons.math.util.FastMath.max((-8447890881994136687L), (-95L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-95L) + "'", long2 == (-95L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray11);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 877278303 + "'", int14 == 877278303);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-71535587), 5063141360940L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1394038287) + "'", int2 == (-1394038287));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.9876060676852348E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.544021006546534d) + "'", double1 == (-0.544021006546534d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 98);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-5063141360940L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.06314136094E12d) + "'", double1 == (-5.06314136094E12d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6487212707001282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.806875836617005d) + "'", double1 == (-12.806875836617005d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.7853981633974483d, (double) (-784346679231569093L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long1 = org.apache.commons.math.util.MathUtils.sign(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1078034335L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-4350707652395722591L), (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 4.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1991599724, 3333);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.5403023058681398d, (-96));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long2 = org.apache.commons.math.util.FastMath.max((-4350707652395722591L), 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.570796326828063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8104773811248975d + "'", double1 == 3.8104773811248975d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0063135934339496E275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1078591488);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.627482429927895d) + "'", double1 == (-0.627482429927895d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(2147483647, (long) (-1394038287));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int[] intArray4 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray11 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray11);
        int[] intArray17 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray24 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray24);
        int[] intArray30 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray37 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray30);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray17);
        int[] intArray45 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray52 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        int[] intArray58 = new int[] { (short) 1, (short) 0, '#', (byte) -1 };
        int[] intArray65 = new int[] { (short) 1, (short) 1, (byte) -1, 'a', 10, (short) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray58);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray45);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 104.40785411069419d + "'", double12 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 104.40785411069419d + "'", double25 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 104.40785411069419d + "'", double38 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 104.40785411069419d + "'", double53 == 104.40785411069419d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 104.40785411069419d + "'", double66 == 104.40785411069419d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 4L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray20 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray20);
        double[] doubleArray28 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray33 = new double[] { '#', 1.0d, 'a' };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 3.0d);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray33);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 8.298330314378324d);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray28);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray28);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 877278303 + "'", int14 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 198760607 + "'", int21 == 198760607);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 101.1582918005242d + "'", double22 == 101.1582918005242d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 198760607 + "'", int29 == 198760607);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 103.12613635737547d + "'", double34 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 103.12613635737547d + "'", double35 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 103.12613635737547d + "'", double38 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4700036292457355d + "'", double1 == 0.4700036292457355d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 3332L, (-1112248228));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6499264843595548E31d + "'", double2 == 1.6499264843595548E31d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.7153185320319555d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1076101120);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6592875426872326d + "'", double1 == 0.6592875426872326d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(14.556090791759079d, 35651585);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.112181583518158d + "'", double2 == 29.112181583518158d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1726527327L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.72652736E9f + "'", float1 == 1.72652736E9f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1726527327));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long1 = org.apache.commons.math.util.FastMath.round(3.7893874043040556d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1991599724L, (float) 198760640);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.9876064E8f + "'", float2 == 1.9876064E8f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.98760602E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.103343925013753d + "'", double1 == 22.103343925013753d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray13 = new double[] { '#', 1.0d, 'a' };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray19 = new double[] { '#', 1.0d, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray25 = new double[] { '#', 1.0d, 'a' };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray19);
        double[] doubleArray41 = new double[] { '#', 1.0d, 'a' };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray44 = null;
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 3.0d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray48);
        double[] doubleArray54 = new double[] { '#', 1.0d, 'a' };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray57 = null;
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, 3.0d);
        java.lang.Class<?> wildcardClass62 = doubleArray54.getClass();
        double[] doubleArray66 = new double[] { '#', 1.0d, 'a' };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray69);
        double[] doubleArray76 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray76);
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray66);
        double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray66);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 877278303 + "'", int9 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.12613635737547d + "'", double14 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 103.12613635737547d + "'", double15 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 103.12613635737547d + "'", double20 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 103.12613635737547d + "'", double26 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 877278303 + "'", int27 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 198760607 + "'", int34 == 198760607);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.1582918005242d + "'", double35 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.1582918005242d + "'", double36 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 103.12613635737547d + "'", double42 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 103.12613635737547d + "'", double43 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 103.12613635737547d + "'", double46 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 94.81203007518798d + "'", double50 == 94.81203007518798d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 103.12613635737547d + "'", double55 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 103.12613635737547d + "'", double56 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 103.12613635737547d + "'", double59 == 103.12613635737547d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 103.12613635737547d + "'", double67 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 103.12613635737547d + "'", double68 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 198760607 + "'", int77 == 198760607);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 103.12613635737547d + "'", double79 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.5707963267847878d), (-0.9640275800758169d), (double) 52L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-3628802));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1112248228));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1683002521388203393L, (-1), 34);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1001116801);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.000484749877465d + "'", double1 == 9.000484749877465d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 3628800);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 198760639L);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) 11L, (int) 'a', 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 5296430760682117539L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.8067120067666d + "'", double1 == 43.8067120067666d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 3628800.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3628800.0f + "'", float2 == 3628800.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double[] doubleArray3 = new double[] { '#', 1.0d, 'a' };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 1.1102230246251565E-16d);
        double[] doubleArray11 = new double[] { '#', 1.0d, 'a' };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray11);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.12613635737547d + "'", double4 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 877278303 + "'", int5 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 103.12613635737547d + "'", double12 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 877278303 + "'", int14 == 877278303);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 877278303 + "'", int16 == 877278303);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-565729435));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1347840285);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.00229985101404d + "'", double1 == 2.00229985101404d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9905373453108037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-96));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.000629915570948d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6566128730773926E-10d + "'", double1 == 4.6566128730773926E-10d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        long long1 = org.apache.commons.math.util.FastMath.abs((-10L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3628800);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 3628800);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 'a');
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) ' ');
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 35651586);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3628800);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1726527327, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1726527327L + "'", long2 == 1726527327L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 198760639, 198760867L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 39505836933114013L + "'", long2 == 39505836933114013L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1001116801);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1000.3721285031997d + "'", double1 == 1000.3721285031997d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 198760640, (long) (-71535587));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14218459054895680L + "'", long2 == 14218459054895680L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.3350745897699942E18d, (java.lang.Number) 100.0f, (int) (short) -1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 98);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 0, (long) (-22));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 22L + "'", long2 == 22L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double[] doubleArray2 = new double[] { (byte) 1, Double.NaN };
        double[] doubleArray6 = new double[] { '#', 1.0d, 'a' };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { '#', 1.0d, 'a' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray19 = new double[] { '#', 1.0d, 'a' };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray27 = new double[] { 10.0f, (short) -1, (-1), (-1L), (-1.0d) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 22.103343925013753d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.12613635737547d + "'", double7 == 103.12613635737547d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 103.12613635737547d + "'", double13 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 877278303 + "'", int15 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 103.12613635737547d + "'", double20 == 103.12613635737547d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 877278303 + "'", int21 == 877278303);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 198760607 + "'", int28 == 198760607);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.1582918005242d + "'", double29 == 101.1582918005242d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(33974111, (-1347840285));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 3.41642464E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1582015220) + "'", int1 == (-1582015220));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.570796326828063d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1807701355 + "'", int1 == 1807701355);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-5063141360940L), (java.lang.Number) 2L, 1726527424, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3628800, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(20.796610271965548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1191.557996762041d + "'", double1 == 1191.557996762041d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = org.apache.commons.math.util.FastMath.min(341642502, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(100L, (-206124209575858481L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 98L, 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        long long1 = org.apache.commons.math.util.FastMath.abs(35651585L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35651585L + "'", long1 == 35651585L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-3628802));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(341642502, (-95));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1048577));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(350L, (long) 800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 34.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078001664 + "'", int1 == 1078001664);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) 1.1752011936438014d, (int) (byte) -1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1040712641, (int) '#', orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException10.getPrevious();
        int int15 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1040712641 + "'", number14.equals(1040712641));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(29937.070865949758d, (-0.0332033464121162d), (double) 32.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int1 = org.apache.commons.math.util.FastMath.abs((-3628800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) 198760607, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (198,760,607 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.log1p(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(989493378, (-1112248228));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.662289061213595E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6622890612135942E-8d + "'", double1 == 2.6622890612135942E-8d);
    }
}

