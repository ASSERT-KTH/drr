import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(4);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test2");
        double double1 = org.apache.commons.math.util.FastMath.log1p(57.29577951308233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.065529698164491d + "'", double1 == 4.065529698164491d);
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test3");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test4");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test5() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test5");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.multiply(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        boolean boolean24 = dfp8.greaterThan(dfp23);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test6() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test6");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.floor();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp35, dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp9.newInstance(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode49 = dfpField46.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.getLn10();
        java.lang.String str51 = dfp50.toString();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp44.subtract(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp50.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + roundingMode49 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode49.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2.302585092994" + "'", str51.equals("2.302585092994"));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test7() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test7");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test8() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test8");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4051.542025492601d + "'", double1 == 4051.542025492601d);
    }

    @Test
    public void test9() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test9");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.ceil();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.power10((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.rint();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.ceil();
        java.lang.String str31 = dfp27.toString();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getE();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.subtract(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp40.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp27.subtract(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getE();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getE();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.subtract(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getE();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp57.sqrt();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp48.multiply(dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.power10((int) (short) 0);
        boolean boolean63 = dfp61.equals((java.lang.Object) 16);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField65.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp61.add(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp45.multiply(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp23.newInstance(dfp69);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2.718281828459" + "'", str31.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
    }
}

