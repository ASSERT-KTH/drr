import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.6321205588285577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0344439357957027d + "'", double2 == 2.0344439357957027d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1452076054732987038L + "'", long2 == 1452076054732987038L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) -1, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        try {
            int int7 = mersenneTwister1.nextInt((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int2 = org.apache.commons.math.util.FastMath.max(10000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100.0f, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 10);
        mersenneTwister1.setSeed((long) 100);
        int int4 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 338087802 + "'", int4 == 338087802);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.rint(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1452076054732987038L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.cos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.util.FastMath.max(10.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 100);
        try {
            int int3 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 338087802);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = org.apache.commons.math.util.FastMath.max(4, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1452076054732987038L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.81952596821637d + "'", double1 == 41.81952596821637d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0553194731804223d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.713324084587196d + "'", double2 == 1.713324084587196d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 338087802);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10000, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10000L, (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10000.0f + "'", float2 == 10000.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8582226493088282d) + "'", double1 == (-0.8582226493088282d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.18750655394138943d) + "'", double1 == (-0.18750655394138943d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        boolean boolean24 = dfp21.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 4, true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.log((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5553480614894135d + "'", double1 == 3.5553480614894135d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.log1p(41.81952596821637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7569942127643507d + "'", double1 == 3.7569942127643507d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 839849605, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.398496E8f + "'", float2 == 8.398496E8f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308233d + "'", double1 == 57.29577951308233d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-32767), (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32766.999999999996d) + "'", double2 == (-32766.999999999996d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double2 = org.apache.commons.math.util.FastMath.pow(Double.NaN, (double) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 3.7569942127643507d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.log1p(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        mersenneTwister1.setSeed((int) (short) 100);
        long long8 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-8422692239103173864L) + "'", long8 == (-8422692239103173864L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.713324084587196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9999999999999999d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10000L, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570482167539873d + "'", double2 == 1.570482167539873d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.power10K((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.rint();
        int int10 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.18750655394138943d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 839849605);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.548733392105095d + "'", double1 == 20.548733392105095d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double2 = org.apache.commons.math.util.FastMath.pow(20.548733392105095d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        long long2 = org.apache.commons.math.util.FastMath.min(1452076054732987038L, 10000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10L);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        int int24 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.subtract(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp27.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.add(dfp38);
        boolean boolean42 = dfp41.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.000000000000002d + "'", double1 == 8.000000000000002d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 9L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.9999999999999999d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((long) (short) 1);
        double double5 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7023867716137234d) + "'", double2 == (-0.7023867716137234d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.40343496390144584d + "'", double5 == 0.40343496390144584d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16372121576841156d) + "'", double1 == (-0.16372121576841156d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.713324084587196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.968603449760514d) + "'", double1 == (-6.968603449760514d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.asinh(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000004122308d + "'", double1 == 10.000000004122308d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2);
        java.lang.String str4 = mathRuntimeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2);
        java.lang.Throwable[] throwableArray4 = mathRuntimeException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 9L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.0f + "'", float1 == 9.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.0344439357957027d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.multiply(dfp12);
        int int14 = dfp13.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Number number5 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        mersenneTwister1.setSeed(4L);
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8335762f + "'", float4 == 0.8335762f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        double double8 = mersenneTwister1.nextDouble();
        double double9 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(0);
        int int12 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36343257420573716d + "'", double8 == 0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1240944887001123d + "'", double9 == 0.1240944887001123d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1937831252) + "'", int12 == (-1937831252));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.0d + "'", double1 == 10000.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.subtract(dfp19);
        int int21 = dfp2.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.1955427247895969d, (java.lang.Number) 0.0d, false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        int int5 = dfp4.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(10);
        boolean boolean18 = dfp13.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7023867716137234d), (double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.02386770458655E-5d) + "'", double2 == (-7.02386770458655E-5d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray4);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.6321205588285577d), 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6321205588285577d) + "'", double2 == (-0.6321205588285577d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp7.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000004d + "'", double1 == 100.00000000000004d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-2.0d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 338087802, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707960310137432d + "'", double2 == 1.5707960310137432d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        boolean boolean12 = dfp11.isNaN();
        boolean boolean13 = dfp6.equals((java.lang.Object) dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp6.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfpField14);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.subtract(dfp10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 1452076054732987038L, (java.lang.Number) (short) 1, false);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn5Split();
        java.lang.Object[] objArray33 = new java.lang.Object[] { dfp5, numberIsTooSmallException16, dfp25, dfpArray31, 0.6483608274590866d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable36 = mathRuntimeException35.getSpecificPattern();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNull(localizable36);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((int) (short) 0);
        boolean boolean17 = dfp15.equals((java.lang.Object) 16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            boolean boolean5 = dfp3.greaterThan(dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 8, (long) (-32767));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-32766.999999999996d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-32766.999999999996d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.exp(10.000000004122308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.46588560659d + "'", double1 == 22026.46588560659d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.417022f + "'", float2 == 0.417022f);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1874150068 + "'", int1 == 1874150068);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        double double4 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0553194731804223d + "'", double4 == 1.0553194731804223d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        int int24 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.subtract(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp27.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp21.power10(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp21.power10(338087802);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1874150068);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710089363075618E7d + "'", double1 == 3.2710089363075618E7d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.442869058442769d + "'", double0 == 0.442869058442769d);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        int int8 = dfp2.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 4L, 0.1240944887001123d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.539782651927684d + "'", double2 == 1.539782651927684d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math.util.FastMath.min(1.539782651927684d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.539782651927684d + "'", double2 == 1.539782651927684d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.1955427247895969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int[] intArray6 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        int[] intArray13 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister7.setSeed(intArray13);
        int[] intArray21 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister(intArray21);
        int[] intArray28 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister22.setSeed(intArray28);
        mersenneTwister7.setSeed(intArray28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister(intArray28);
        int int32 = mersenneTwister31.nextInt();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1319820174) + "'", int32 == (-1319820174));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.ceil();
        java.lang.String str22 = dfp18.toString();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = dfp23.getField();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.newInstance(dfp27);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2.718281828459" + "'", str22.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpField24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590449d + "'", double1 == 1.7182818284590449d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray8);
        double double10 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.36343257420573716d + "'", double10 == 0.36343257420573716d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.000000004122308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232965503259d + "'", double1 == 11013.232965503259d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4L, (java.lang.Number) 338087802, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 338087802 + "'", number4.equals(338087802));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.multiply(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getTwo();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.ceil();
        int int46 = dfp45.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getE();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp36.dotrap((-1), "", dfp45, dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp2.divide(dfp53);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray8);
        float float10 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.36343253f + "'", float10 == 0.36343253f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 0, (-0.8582226493088282d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int[] intArray6 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        float float8 = mersenneTwister7.nextFloat();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.98069644f + "'", float8 == 0.98069644f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((int) (short) 0);
        boolean boolean17 = dfp15.equals((java.lang.Object) 16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.rint();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp15.multiply(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getPi();
        org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.DfpField.computeExp(dfp29, dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        mersenneTwister1.setSeed(10000);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 9L, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (-0.6321205588285577d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16227760542015932d) + "'", double1 == (-0.16227760542015932d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((long) (short) 1);
        int int5 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7023867716137234d) + "'", double2 == (-0.7023867716137234d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 485306839 + "'", int5 == 485306839);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1425465430742778d) + "'", double1 == (-0.1425465430742778d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.subtract(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.multiply(dfp20);
        boolean boolean22 = dfp7.equals((java.lang.Object) dfp16);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp7.ceil();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable4, objArray7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((int) 'a');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.log(57.29577951308233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0482269650408105d + "'", double1 == 4.0482269650408105d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4382578779560865d + "'", double1 == 0.4382578779560865d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (long) 32760);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32760L + "'", long2 == 32760L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((long) (short) 1);
        int[] intArray11 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        int[] intArray18 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister12.setSeed(intArray18);
        int[] intArray26 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister(intArray26);
        int[] intArray33 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister27.setSeed(intArray33);
        mersenneTwister12.setSeed(intArray33);
        mersenneTwister1.setSeed(intArray33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7023867716137234d) + "'", double2 == (-0.7023867716137234d));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.subtract(dfp19);
        boolean boolean21 = dfp2.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10L);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.36343253f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.198846600540652d + "'", double1 == 1.198846600540652d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.570482167539873d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1195587395, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        dfpField8.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp(10.000000004122308d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.36343253f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43825780947013526d + "'", double1 == 0.43825780947013526d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 16, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) -1, (byte) 10, (byte) 10, (byte) 0, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray10);
        int int12 = mersenneTwister1.nextInt();
        double double13 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 839849605 + "'", int12 == 839849605);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.7949034000231544d + "'", double13 == 0.7949034000231544d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1937831252));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.9378313E9f + "'", float1 == 1.9378313E9f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister3.setSeed(0L);
        byte[] byteArray12 = new byte[] { (byte) 10, (byte) -1, (byte) 10, (byte) 10, (byte) 0, (byte) 100 };
        mersenneTwister3.nextBytes(byteArray12);
        mersenneTwister1.nextBytes(byteArray12);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.ceil();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.multiply(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.subtract(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.sqrt();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp33.multiply(dfp43);
        boolean boolean45 = dfp29.lessThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp29.power10((int) (byte) 10);
        boolean boolean48 = dfp12.greaterThan(dfp47);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister2.setSeed(0L);
        mersenneTwister2.setSeed((long) (byte) 0);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        mersenneTwister2.nextBytes(byteArray9);
        mersenneTwister0.nextBytes(byteArray9);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.log(2.0344439357957027d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7102225313316719d + "'", double1 == 0.7102225313316719d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1319820174));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("2.718281828459");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        boolean boolean18 = dfp6.equals((java.lang.Object) dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.198846600540652d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8755850776451444d + "'", double1 == 0.8755850776451444d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        int int6 = dfp5.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.220446049250313E-16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp13.newInstance((byte) 0, (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField6.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((double) 0);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField13.getRoundingMode();
        dfpField6.setRoundingMode(roundingMode16);
        dfpField1.setRoundingMode(roundingMode16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.ceil();
        int int25 = dfp24.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp15.dotrap((-1), "", dfp24, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getE();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getLn2();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getE();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.newInstance(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getE();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp49.subtract(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getE();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getE();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp58.subtract(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getE();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp67.sqrt();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp58.multiply(dfp68);
        boolean boolean70 = dfp54.lessThan(dfp68);
        int int71 = dfp68.classify();
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField73.getE();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp74.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getE();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp74.subtract(dfp79);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField82.getE();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp83.sqrt();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp74.multiply(dfp84);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp85.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp88 = dfp68.add(dfp85);
        org.apache.commons.math.dfp.Dfp dfp89 = org.apache.commons.math.dfp.Dfp.copysign(dfp46, dfp85);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp31.divide(dfp85);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp85.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfp3.intValue();
        int int5 = dfp3.intValue();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.power10K((int) ' ');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        double double8 = mersenneTwister1.nextDouble();
        double double9 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36343257420573716d + "'", double8 == 0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7949034000231544d + "'", double9 == 0.7949034000231544d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        float float2 = org.apache.commons.math.util.FastMath.max(8.0f, (float) (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.539782651927684d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (-1));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp11);
        boolean boolean15 = dfp11.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int1 = org.apache.commons.math.util.FastMath.round(10000.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        int int6 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance(9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.18750655394138943d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double2 = org.apache.commons.math.util.FastMath.min(3.2710089363075618E7d, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8414709848078965d + "'", double2 == 0.8414709848078965d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        double double8 = mersenneTwister1.nextDouble();
        double double9 = mersenneTwister1.nextDouble();
        long long10 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((-32767));
        int int13 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36343257420573716d + "'", double8 == 0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1240944887001123d + "'", double9 == 0.1240944887001123d);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-8570567046494473423L) + "'", long10 == (-8570567046494473423L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-442622323) + "'", int13 == (-442622323));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int2 = org.apache.commons.math.util.FastMath.max(1874150068, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1874150068 + "'", int2 == 1874150068);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.expm1(11013.232965503259d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5198420997897464d + "'", double1 == 2.5198420997897464d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) -1);
        java.lang.Class<?> wildcardClass8 = dfp7.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfp3.intValue();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.sqrt();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp16.multiply(dfp26);
        boolean boolean28 = dfp12.lessThan(dfp26);
        int int29 = dfp26.classify();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.subtract(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp32.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp26.add(dfp43);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp26.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getE();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getE();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp51.subtract(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.newInstance((double) 0L);
        boolean boolean60 = dfp48.unequal(dfp57);
        boolean boolean61 = dfp3.lessThan(dfp48);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp48.ceil();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp62.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance("hi!");
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        boolean boolean26 = dfp9.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.subtract(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((double) 0L);
        boolean boolean38 = dfp9.lessThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp37.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        boolean boolean26 = dfp9.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.subtract(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((double) 0L);
        boolean boolean38 = dfp9.lessThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.floor();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp35, dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp9.newInstance(dfp35);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp9.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        boolean boolean4 = dfp3.isNaN();
        double double5 = dfp3.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7071067811865d + "'", double5 == 0.7071067811865d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.subtract(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField1.newDfp(dfp20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int2 = org.apache.commons.math.util.FastMath.min(32768, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.log(1.5707960310137432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45158251698930657d + "'", double1 == 0.45158251698930657d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.sqrt();
        int int4 = dfp3.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.multiply(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.power10((int) (short) 0);
        boolean boolean38 = dfp36.equals((java.lang.Object) 16);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp36.add(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp20.multiply(dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp20.newInstance((double) 0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8755850776451444d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97.0d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable throwable3 = null;
        try {
            notStrictlyPositiveException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        dfpField8.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7071067811865d, (double) 32768);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7071067811865002d + "'", double2 == 0.7071067811865002d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1452076054732987038L, (java.lang.Number) (short) 1, false);
        mathRuntimeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Object[] objArray10 = mathRuntimeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.subtract(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.rint();
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp2, dfp20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.713324084587196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1420456923699077d) + "'", double1 == (-0.1420456923699077d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 3.7569942127643507d, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfp3.intValue();
        int int5 = dfp3.intValue();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.30561438888825215d) + "'", double1 == (-0.30561438888825215d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-32767));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32767) + "'", int1 == (-32767));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.nextAfter(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("2.718281828459");
        int int9 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp((byte) 100);
        dfpField1.setIEEEFlagsBits(16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (short) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.multiply((int) (byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        long long8 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 6704147859145430661L + "'", long8 == 6704147859145430661L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        boolean boolean26 = dfp9.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.subtract(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((double) 0L);
        boolean boolean38 = dfp9.lessThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp37.multiply(16);
        double double41 = dfp37.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.NEGATIVE_INFINITY + "'", double41 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9971848088551236d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9985914123680033d + "'", double1 == 0.9985914123680033d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        int[] intArray0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
//        int int2 = mersenneTwister1.nextInt();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 393091421 + "'", int2 == 393091421);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1874150068, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.subtract(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.sqrt();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp25.multiply(dfp35);
        boolean boolean37 = dfp21.lessThan(dfp35);
        int int38 = dfp35.classify();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp41.subtract(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getE();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.sqrt();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.multiply(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp35.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp52);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField59.getSqr3();
        dfpField59.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getE();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp68.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp68.ceil();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField59.newDfp(dfp68);
        boolean boolean75 = dfp52.unequal(dfp74);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.abs(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) 0);
        int int7 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.acosh(41.81952596821637d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.426367559562508d + "'", double1 == 4.426367559562508d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.4382578779560865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.417022f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.34855747916426966d + "'", double1 == 0.34855747916426966d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        mersenneTwister1.setSeed((int) (short) 100);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister9.setSeed(0L);
        byte[] byteArray18 = new byte[] { (byte) 10, (byte) -1, (byte) 10, (byte) 10, (byte) 0, (byte) 100 };
        mersenneTwister9.nextBytes(byteArray18);
        mersenneTwister1.nextBytes(byteArray18);
        int int21 = mersenneTwister1.nextInt();
        double double22 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1195587395 + "'", int21 == 1195587395);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.4120463941174386d + "'", double22 == 0.4120463941174386d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.8582226493088282d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-8422692239103173864L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97.0d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray5);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException6);
        java.lang.Number number8 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 97.0d + "'", number8.equals(97.0d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField4.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp((double) 0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField11.getRoundingMode();
        dfpField4.setRoundingMode(roundingMode14);
        dfpField1.setRoundingMode(roundingMode14);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32L, (java.lang.Number) 0.8813735870195429d, false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 9.0f, (double) 32768);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.000000000000002d + "'", double2 == 9.000000000000002d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0553194731804223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2624058062919357d + "'", double1 == 1.2624058062919357d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.16227760542015932d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8502051502188213d + "'", double1 == 0.8502051502188213d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6704147859145430661L, (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.7041479E18f + "'", float2 == 6.7041479E18f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1874150068);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.ceil();
        int int25 = dfp24.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp15.dotrap((-1), "", dfp24, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp37.subtract(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.rint();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getE();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp47.subtract(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getE();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp56.sqrt();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp47.multiply(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.power10((int) (short) 0);
        boolean boolean61 = dfp44.greaterThan(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField63.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode65 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField63.setRoundingMode(roundingMode65);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode67 = dfpField63.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField63.getLn2();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField63.getE();
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getE();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField76.getE();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp72.subtract(dfp77);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField80.getE();
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.multiply(dfp82);
        boolean boolean84 = dfp69.equals((java.lang.Object) dfp78);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp24.dotrap((int) (byte) 3, "org.apache.commons.math.exception.MathRuntimeException: ", dfp44, dfp78);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + roundingMode65 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode65.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode67 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode67.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(dfp85);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.floor();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp35, dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp9.newInstance(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode49 = dfpField46.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.getLn10();
        java.lang.String str51 = dfp50.toString();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp44.subtract(dfp50);
        boolean boolean53 = dfp52.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + roundingMode49 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode49.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2.302585092994" + "'", str51.equals("2.302585092994"));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7893184915864662d) + "'", double1 == (-0.7893184915864662d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        long long1 = org.apache.commons.math.util.FastMath.abs(6704147859145430661L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6704147859145430661L + "'", long1 == 6704147859145430661L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.floor();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp35, dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp9.newInstance(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode49 = dfpField46.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.getLn10();
        java.lang.String str51 = dfp50.toString();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp44.subtract(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp50.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + roundingMode49 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode49.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2.302585092994" + "'", str51.equals("2.302585092994"));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        double double8 = mersenneTwister1.nextDouble();
        float float9 = mersenneTwister1.nextFloat();
        int[] intArray16 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        int[] intArray23 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister17.setSeed(intArray23);
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        mersenneTwister1.setSeed(intArray23);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36343257420573716d + "'", double8 == 0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.124094486f + "'", float9 == 0.124094486f);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 198.99499987499382d + "'", double1 == 198.99499987499382d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        boolean boolean26 = dfp9.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.subtract(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((double) 0L);
        boolean boolean38 = dfp9.lessThan(dfp37);
        int int39 = dfp9.classify();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp9.newInstance(10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextDouble();
        java.lang.Class<?> wildcardClass4 = mersenneTwister1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971848088551236d + "'", double3 == 0.9971848088551236d);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        int int24 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.subtract(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp27.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp21.power10(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp21.ceil();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp44.subtract(dfp51);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.subtract(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.sqrt();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp10.multiply(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10((int) (short) 0);
        boolean boolean25 = dfp23.equals((java.lang.Object) 16);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.add(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp7.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp7.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1319820174));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((byte) 0);
        java.lang.String str11 = dfp2.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2.718281828459" + "'", str11.equals("2.718281828459"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn2();
        boolean boolean13 = dfp12.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.power10K((int) '#');
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp17);
        boolean boolean20 = dfp7.greaterThan(dfp19);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp9.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp2.subtract(dfp19);
        int int21 = dfp19.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        boolean boolean9 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.sqrt();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.multiply(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10((int) (short) 0);
        boolean boolean26 = dfp9.greaterThan(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.getSqr3();
        dfpField28.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp37.ceil();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField28.newDfp(dfp37);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp9.subtract(dfp37);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp37.newInstance("3.");
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getE();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp49.subtract(dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp55.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp55.newInstance(Double.POSITIVE_INFINITY);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp46.multiply(dfp61);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 52L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.36343253f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9346821219057783d + "'", double1 == 0.9346821219057783d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 6704147859145430661L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.704147859145431E18d + "'", double1 == 6.704147859145431E18d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796106d + "'", double1 == 9.848857801796106d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 10000);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp6.subtract(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.sqrt();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp15.multiply(dfp25);
        boolean boolean27 = dfp11.lessThan(dfp25);
        int int28 = dfp25.classify();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp31.subtract(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getE();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.sqrt();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp31.multiply(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp25.add(dfp42);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp25.power10(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp25.ceil();
        boolean boolean49 = dfp3.unequal(dfp25);
        int int50 = dfp3.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.570482167539873d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8089663623377104d + "'", double1 == 3.8089663623377104d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfp3.intValue();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.sqrt();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp16.multiply(dfp26);
        boolean boolean28 = dfp12.lessThan(dfp26);
        int int29 = dfp26.classify();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.subtract(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp32.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp26.add(dfp43);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp26.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getE();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getE();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp51.subtract(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.newInstance((double) 0L);
        boolean boolean60 = dfp48.unequal(dfp57);
        boolean boolean61 = dfp3.lessThan(dfp48);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp48.ceil();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getE();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp65.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getE();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp65.subtract(dfp70);
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField73.getE();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp74.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getE();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp74.subtract(dfp79);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField82.getE();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp83.sqrt();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp74.multiply(dfp84);
        boolean boolean86 = dfp70.lessThan(dfp84);
        int int87 = dfp84.classify();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp62.add(dfp84);
        org.apache.commons.math.dfp.DfpField dfpField89 = dfp84.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfpField89);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((byte) 100);
        boolean boolean14 = dfp7.lessThan(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp((long) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp11.newInstance(dfp22);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9376558078861459d + "'", double1 == 0.9376558078861459d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        double double8 = mersenneTwister1.nextDouble();
        double double9 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(0);
        long long12 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36343257420573716d + "'", double8 == 0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1240944887001123d + "'", double9 == 0.1240944887001123d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-8322921849960486353L) + "'", long12 == (-8322921849960486353L));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.signum(100.00000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1452076054732987038L, (java.lang.Number) (short) 1, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 1 + "'", number6.equals((short) 1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1071487177940904d + "'", double1 == 1.1071487177940904d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        mersenneTwister1.setSeed(4L);
        long long4 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3069976470462491033L) + "'", long4 == (-3069976470462491033L));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.power10K((int) '#');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField12);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.divide((int) (short) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int[] intArray6 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1195587395);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1195587395L + "'", long1 == 1195587395L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp7.power10((int) (byte) 10);
        int int26 = dfp7.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.multiply(8);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.ceil();
        double double26 = dfp25.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.newInstance(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.ceil();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.sqrt();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp24.multiply(dfp34);
        boolean boolean36 = dfp20.lessThan(dfp34);
        int int37 = dfp34.classify();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getE();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.subtract(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getE();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.sqrt();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp40.multiply(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp34.add(dfp51);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp34.power10(0);
        boolean boolean57 = dfp12.greaterThan(dfp56);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp6.multiply(dfp56);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.18750655394138943d), (java.lang.Number) (short) 1, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32760);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr2Reciprocal();
        int int18 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathIllegalArgumentException2.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException2.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean7 = notStrictlyPositiveException6.getBoundIsAllowed();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        java.lang.Number number9 = notStrictlyPositiveException6.getMin();
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.16372121576841156d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.multiply(3);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.ceil();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.subtract(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.sqrt();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp33.multiply(dfp43);
        boolean boolean45 = dfp29.lessThan(dfp43);
        int int46 = dfp43.classify();
        boolean boolean47 = dfp21.unequal(dfp43);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp13.remainder(dfp43);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.rint();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((long) (short) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) -1, (byte) 10, (byte) 10, (byte) 0, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray10);
        double double12 = mersenneTwister1.nextDouble();
        boolean boolean13 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1955427247895969d + "'", double12 == 0.1955427247895969d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        int int24 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.subtract(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp27.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp21.power10(0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp21.ceil();
        int int45 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp46 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp47 = dfp21.subtract(dfp46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        dfpField1.setIEEEFlagsBits((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((int) 'a');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.multiply((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.45158251698930657d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42319896713992267d + "'", double1 == 0.42319896713992267d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(3.141592653589793d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7323676290027762d) + "'", double1 == (-0.7323676290027762d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        java.lang.String str8 = dfp7.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1." + "'", str8.equals("1."));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (byte) 3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.ceil();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp12.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.power10((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int[] intArray6 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        int[] intArray13 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister7.setSeed(intArray13);
        int[] intArray21 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister(intArray21);
        int[] intArray28 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister22.setSeed(intArray28);
        mersenneTwister7.setSeed(intArray28);
        double double31 = mersenneTwister7.nextGaussian();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-0.7991300611819521d) + "'", double31 == (-0.7991300611819521d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.sqrt();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp13.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getTwo();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.ceil();
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getE();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp26.dotrap((-1), "", dfp35, dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp10.subtract(dfp43);
        boolean boolean45 = dfp43.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField9.setRoundingMode(roundingMode11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((double) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField16.getRoundingMode();
        dfpField9.setRoundingMode(roundingMode19);
        dfpField1.setRoundingMode(roundingMode19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.newInstance(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.subtract(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.sqrt();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp25.multiply(dfp35);
        boolean boolean37 = dfp21.lessThan(dfp35);
        int int38 = dfp35.classify();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp41.subtract(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getE();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.sqrt();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.multiply(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp35.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.Dfp.copysign(dfp13, dfp52);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.newInstance();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp52.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) (byte) 0);
        int int7 = mersenneTwister1.nextInt(10);
        double double8 = mersenneTwister1.nextDouble();
        double double9 = mersenneTwister1.nextDouble();
        int int11 = mersenneTwister1.nextInt(4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36343257420573716d + "'", double8 == 0.36343257420573716d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.1240944887001123d + "'", double9 == 0.1240944887001123d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField7.setRoundingMode(roundingMode9);
        dfpField7.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp((long) 10000);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.newInstance(dfp16);
        int int18 = dfp5.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.floor();
        int int10 = dfp2.classify();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField4.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.584967478670572d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable throwable4 = null;
        try {
            notStrictlyPositiveException1.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10L);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException6.getGeneralPattern();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException6);
        java.lang.Throwable[] throwableArray10 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.multiply(8);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.ceil();
        double double26 = dfp25.toDouble();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.newInstance(dfp25);
        java.lang.String str28 = dfp27.toString();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp27.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "3." + "'", str28.equals("3."));
        org.junit.Assert.assertNotNull(dfpField29);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10L);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) 839849605);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-7.02386770458655E-5d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed(3L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.8813735870195429d, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean7 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) dfpArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 0.36343257420573716d, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField18.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) dfpArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 10L);
        java.lang.Object[] objArray27 = notStrictlyPositiveException26.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean32 = notStrictlyPositiveException31.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable33 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, (java.lang.Object[]) dfpArray36);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 0.36343257420573716d, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField43.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, (java.lang.Object[]) dfpArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 10L);
        java.lang.Object[] objArray52 = notStrictlyPositiveException51.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray52);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4, localizable8, localizable29, objArray52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) dfpArray6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 1874150068, (java.lang.Number) 1.539782651927684d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (-1937831252), (java.lang.Number) 485306839, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) 57.29577951308233d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32768 + "'", number4.equals(32768));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.multiply(3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.getTwo();
        boolean boolean19 = dfp15.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.7182818284590449d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1977461928657023d + "'", double1 == 1.1977461928657023d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.16227760542015932d), 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.004273421904811461d) + "'", double2 == (-0.004273421904811461d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.011032585021104841d) + "'", double1 == (-0.011032585021104841d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.7182818284590449d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField8.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("2.718281828459");
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.newDfp("hi!");
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3Reciprocal();
        int int21 = dfp20.intValue();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.subtract(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.sqrt();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp33.multiply(dfp43);
        boolean boolean45 = dfp29.lessThan(dfp43);
        int int46 = dfp43.classify();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getE();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp49.subtract(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getE();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.sqrt();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp49.multiply(dfp59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp43.add(dfp60);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp43.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getE();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp68.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getE();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp68.subtract(dfp73);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp74.newInstance((double) 0L);
        boolean boolean77 = dfp65.unequal(dfp74);
        boolean boolean78 = dfp20.lessThan(dfp65);
        org.apache.commons.math.dfp.Dfp dfp79 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp16, dfp65);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1.9378313E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((int) (short) 0);
        boolean boolean17 = dfp15.equals((java.lang.Object) 16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.add(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.rint();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp15.multiply(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.subtract(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.sqrt();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp32.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.power10((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.Dfp.copysign(dfp28, dfp45);
        java.lang.Class<?> wildcardClass47 = dfp45.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9346821219057783d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.subtract(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.sqrt();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.multiply(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp19);
        int int25 = dfp5.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.signum((-7.02386770458655E-5d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp10.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) dfpArray6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 0.36343257420573716d, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) dfpArray17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField26.setRoundingMode(roundingMode28);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField26.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField26.getLn2Split();
        java.lang.Object[] objArray33 = new java.lang.Object[] { dfp24, dfpArray32 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) dfpArray32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.multiply(9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 338087802);
        java.lang.Object[] objArray3 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        int int9 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-4) + "'", int9 == (-4));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.7071067811865d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        java.lang.String str6 = dfp5.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2." + "'", str6.equals("2."));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-1937831252));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10L);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean6 = notStrictlyPositiveException5.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) dfpArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.36343257420573716d, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField17.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) dfpArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean25 = notStrictlyPositiveException24.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException24.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, (java.lang.Object[]) dfpArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 57.29577951308233d, (java.lang.Number) (byte) 2, false);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 1452076054732987038L, (java.lang.Number) (short) 1, false);
        java.lang.Throwable[] throwableArray40 = numberIsTooSmallException39.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable7, localizable26, (java.lang.Object[]) throwableArray40);
        java.lang.String str42 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10L + "'", number3.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)" + "'", str42.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1937831252));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.937831252E9d) + "'", double1 == (-1.937831252E9d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp2.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.newInstance("hi!");
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.ceil();
        int int25 = dfp24.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp15.dotrap((-1), "", dfp24, dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp15.power10(16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) dfpArray6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 0.36343257420573716d, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean14 = notStrictlyPositiveException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.36343257420573716d);
        boolean boolean22 = notStrictlyPositiveException21.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.36343257420573716d, (java.lang.Number) (byte) 10, false);
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable23, objArray32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.ceil();
        java.lang.String str40 = dfp36.toString();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.ceil();
        org.apache.commons.math.dfp.DfpField dfpField42 = dfp41.getField();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getLn2();
        dfpField42.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField42.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable15, (java.lang.Object[]) dfpArray46);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2.718281828459" + "'", str40.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpField42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpArray46);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int[] intArray6 = new int[] { 839849605, (-32767), 839849605, (short) -1, (short) 0, (byte) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        int[] intArray13 = new int[] { (byte) 1, '4', 1, 8, (short) 0 };
        mersenneTwister7.setSeed(intArray13);
        int int16 = mersenneTwister7.nextInt(338087802);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 290792562 + "'", int16 == 290792562);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.multiply(dfp21);
        boolean boolean23 = dfp7.lessThan(dfp21);
        int int24 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(9);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.subtract(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp27.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.newInstance((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.add(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getE();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.ceil();
        boolean boolean48 = dfp38.greaterThan(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getE();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp((double) (-1));
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField50.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp60.sqrt();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.ceil();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField50.newDfp(dfp60);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp47.subtract(dfp60);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        boolean boolean7 = dfp6.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.16227760542015932d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16087522385484967d) + "'", double1 == (-0.16087522385484967d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (byte) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        boolean boolean9 = dfp7.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-8570567046494473423L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance(9);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        java.lang.String str6 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.ceil();
        int int8 = dfp7.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.718281828459" + "'", str6.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.718281828459");
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
    }
}

