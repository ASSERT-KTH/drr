import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray35 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        org.apache.commons.math3.linear.RealVector realVector39 = realVector37.mapAdd(100.00639823915624d);
        try {
            array2DRowRealMatrix20.setColumnVector(10, realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector39);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (0,97) and (97,0) is larger than 35", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(9800.841470984808d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2424042573435614E34d + "'", double2 == 1.2424042573435614E34d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor25 = null;
        try {
            double double30 = array2DRowRealMatrix20.walkInColumnOrder(realMatrixChangingVisitor25, 87412023, (int) (byte) 100, (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (87,412,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math3.util.FastMath.log(120.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.787491742782046d + "'", double1 == 4.787491742782046d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((-1), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.map(univariateFunction26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        try {
            arrayRealVector27.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix5.transpose();
        double double7 = blockRealMatrix6.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.multiply(blockRealMatrix6);
        double[] doubleArray14 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray20 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray26 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray26 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray14, doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector31 = array2DRowRealMatrix29.getRowVector(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix8.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector31);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double double49 = arrayRealVector48.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector52.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector65.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector65.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector57.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector73.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction76 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector73.map(univariateFunction76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, arrayRealVector77);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector77.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, realVector80);
        org.apache.commons.math3.linear.RealVector realVector82 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector48.subtract(realVector82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector80);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append((double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor14 = null;
        try {
            double double15 = arrayRealVector10.walkInDefaultOrder(realVectorChangingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "hi!");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = arrayRealVector6.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray23 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray23);
        boolean boolean26 = arrayRealVector24.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector30.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray47 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41, doubleArray47);
        boolean boolean50 = arrayRealVector48.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, arrayRealVector48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector24.append(arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivide(Double.NEGATIVE_INFINITY);
        java.lang.String str55 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        java.lang.String str56 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0hi!1hi!10hi!108.6692228738hi!0" + "'", str55.equals("0hi!1hi!10hi!108.6692228738hi!0"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix20.scalarAdd((double) '4');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor26 = null;
        try {
            double double31 = array2DRowRealMatrix20.walkInColumnOrder(realMatrixChangingVisitor26, (int) (byte) -1, 35, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math3.util.FastMath.log(492.04028441077287d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        double[][] doubleArray71 = array2DRowRealMatrix44.getData();
        double double72 = array2DRowRealMatrix44.getNorm();
        int int73 = array2DRowRealMatrix44.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 203.0d + "'", double72 == 203.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}", "hi!", "0hi!1hi!10hi!108.6692228738hi!0", "Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}", "org.apache.commons.math3.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations");
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        boolean boolean3 = blockRealMatrix2.isTransposable();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector10.mapMultiplyToSelf(22025.465794806718d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.copy();
        boolean boolean16 = arrayRealVector15.isNaN();
        org.apache.commons.math3.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0f, 35, (byte) -1 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector15, localizable17, objArray21);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 0, (int) '#', (int) (byte) -1, (int) (byte) -1);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int8 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = blockRealMatrix4.scalarMultiply((double) 5);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double double4 = blockRealMatrix3.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix3.scalarAdd((-0.8813735870195429d));
        int[] intArray9 = new int[] { (short) 1, 87412023 };
        int[] intArray15 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray22 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double23 = org.apache.commons.math3.util.MathArrays.distance(intArray15, intArray22);
        int[] intArray24 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15);
        int[] intArray31 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int32 = org.apache.commons.math3.util.MathArrays.distance1(intArray24, intArray31);
        int[] intArray34 = org.apache.commons.math3.util.MathArrays.copyOf(intArray31, (int) (byte) 0);
        int[] intArray40 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray47 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double48 = org.apache.commons.math3.util.MathArrays.distance(intArray40, intArray47);
        double double49 = org.apache.commons.math3.util.MathArrays.distance(intArray34, intArray40);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix6.getSubMatrix(intArray9, intArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 108.66922287382016d + "'", double23 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 120 + "'", int32 == 120);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 108.66922287382016d + "'", double48 == 108.66922287382016d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray19);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor25 = null;
        try {
            double double30 = array2DRowRealMatrix24.walkInColumnOrder(realMatrixChangingVisitor25, (int) (byte) 100, (-1), 52, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix35.transpose();
        double[] doubleArray42 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray48 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray54 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray55 = new double[][] { doubleArray48, doubleArray54 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray42, doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor58 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double59 = array2DRowRealMatrix57.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        defaultRealMatrixPreservingVisitor58.visit(3, 6, (double) 0L);
        double double64 = blockRealMatrix35.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix35.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix2.subtract(blockRealMatrix65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x36 but expected 36x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        double double45 = array2DRowRealMatrix20.getFrobeniusNorm();
        org.apache.commons.math3.exception.MathParseException mathParseException48 = new org.apache.commons.math3.exception.MathParseException("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", (int) (byte) 0);
        boolean boolean49 = array2DRowRealMatrix20.equals((java.lang.Object) mathParseException48);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 141.43196244130957d + "'", double45 == 141.43196244130957d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        double[] doubleArray14 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1401562416);
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        int[] intArray8 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray15 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray15);
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
        int[] intArray24 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int25 = org.apache.commons.math3.util.MathArrays.distance1(intArray17, intArray24);
        int[] intArray27 = org.apache.commons.math3.util.MathArrays.copyOf(intArray24, (int) (byte) 0);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        org.apache.commons.math3.exception.util.Localizable localizable29 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray38 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray38);
        org.apache.commons.math3.linear.RealVector realVector40 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray38);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38);
        java.lang.Object[] objArray43 = new java.lang.Object[] { doubleArray42 };
        org.apache.commons.math3.exception.ZeroException zeroException44 = new org.apache.commons.math3.exception.ZeroException(localizable29, objArray43);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) intArray27, localizable28, objArray43);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException1, localizable2, objArray43);
        java.lang.Number number47 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 108.66922287382016d + "'", double16 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 120 + "'", int25 == 120);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 1401562416 + "'", number47.equals(1401562416));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray52 = array2DRowRealMatrix44.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix20.add(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor54 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double55 = defaultRealMatrixPreservingVisitor54.end();
        double double56 = array2DRowRealMatrix44.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor54);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor14 = null;
        try {
            double double17 = arrayRealVector13.walkInDefaultOrder(realVectorChangingVisitor14, (int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        org.apache.commons.math3.linear.RealVector realVector72 = arrayRealVector70.mapSubtract(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector75.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector80.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector75.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector83.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector83.mapMultiplyToSelf(22025.465794806718d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector83.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector70.append(arrayRealVector83);
        org.apache.commons.math3.linear.RealVector realVector91 = arrayRealVector70.mapAddToSelf((-0.0d));
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor92 = null;
        try {
            double double93 = arrayRealVector70.walkInOptimizedOrder(realVectorPreservingVisitor92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(arrayRealVector88);
        org.junit.Assert.assertNotNull(arrayRealVector89);
        org.junit.Assert.assertNotNull(realVector91);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(5.648986636264298d, (double) (byte) 0, (double) 0.0f, 0.0d, 5.648986636264298d, 100.0d, 3.141592653589793d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        double[][] doubleArray28 = array2DRowRealMatrix20.getData();
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray46 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray47 = new double[][] { doubleArray40, doubleArray46 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray34, doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor50 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double51 = array2DRowRealMatrix49.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor50);
        defaultRealMatrixPreservingVisitor50.visit(3, 6, (double) 0L);
        double double56 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor50);
        double double57 = defaultRealMatrixPreservingVisitor50.end();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        boolean boolean24 = array2DRowRealMatrix20.isSquare();
        try {
            double double27 = array2DRowRealMatrix20.getEntry(10, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = array2DRowRealMatrix45.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix45);
        java.lang.Class<?> wildcardClass49 = array2DRowRealMatrix48.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5288560945221015d + "'", double2 == 0.5288560945221015d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix20.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = array2DRowRealMatrix44.createMatrix(97, 4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix55);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector23.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray40 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        boolean boolean43 = arrayRealVector41.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector20.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, realVector45);
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector2.append(arrayRealVector48);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor52 = null;
        try {
            double double53 = arrayRealVector48.walkInDefaultOrder(realVectorPreservingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(arrayRealVector51);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector33.mapSubtractToSelf((double) 36);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector33.mapSubtractToSelf(0.0d);
        double double40 = arrayRealVector33.getEntry(3);
        int int41 = arrayRealVector33.getMinIndex();
        arrayRealVector33.set((double) 1.4E-45f);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 72.66922287382016d + "'", double40 == 72.66922287382016d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray54, (double) '4');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor75 = null;
        try {
            double double76 = array2DRowRealMatrix74.walkInRowOrder(realMatrixChangingVisitor75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray7 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray13 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray19 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray19 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, doubleArray20);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(120, 1, doubleArray20, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 52");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, false);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}", 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat0.getFormat();
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) realVectorFormat0, "{}", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector34.mapMultiplyToSelf(22025.465794806718d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector34.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double double49 = arrayRealVector48.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector48.mapMultiplyToSelf(0.14896799111995784d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        try {
            double double25 = arrayRealVector2.getEntry((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor24 = null;
        try {
            double double25 = arrayRealVector20.walkInOptimizedOrder(realVectorChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) 1);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 1 + "'", number3.equals((byte) 1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) '4', (double) (-1L), 2.2825470172998332d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 176.2547017299833d + "'", double4 == 176.2547017299833d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat7);
        java.text.ParsePosition parsePosition11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = realVectorFormat9.parse("", parsePosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        boolean boolean24 = array2DRowRealMatrix20.isSquare();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector27.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray44 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, doubleArray44);
        boolean boolean47 = arrayRealVector45.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector51.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray68 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62, doubleArray68);
        boolean boolean71 = arrayRealVector69.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector45.append(arrayRealVector51);
        double[] doubleArray74 = arrayRealVector45.getDataRef();
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74, 35);
        double[] doubleArray77 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74);
        double[] doubleArray78 = array2DRowRealMatrix20.preMultiply(doubleArray77);
        double double79 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(arrayRealVector73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 109.13294644606641d + "'", double79 == 109.13294644606641d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.015204713975260888d), (java.lang.Number) 0.5288560945221015d, (int) (short) 10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray52 = array2DRowRealMatrix44.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix20.add(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor54 = null;
        try {
            double double59 = array2DRowRealMatrix53.walkInRowOrder(realMatrixChangingVisitor54, (int) (short) 1, 52, 52, 87412023);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector51.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector64.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector56.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector20.append(arrayRealVector56);
        int int71 = arrayRealVector70.getDimension();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 5 + "'", int71 == 5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.015204713975260888d), 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.015204713975260888d) + "'", double2 == (-0.015204713975260888d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double[] doubleArray8 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray14 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray20 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray21 = new double[][] { doubleArray14, doubleArray20 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, doubleArray21);
        double double23 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray30);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray24, doubleArray30);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection47 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray24, orderDirection47, false);
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.4E-45f, (java.lang.Number) 138.63982111933063d, (int) (byte) 1, orderDirection47, false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 141.43196244130957d + "'", double23 == 141.43196244130957d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 141.43196244130957d + "'", double45 == 141.43196244130957d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.text.ParsePosition parsePosition9 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat6.parse("{}", parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(3, (int) 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.0d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector26.mapMultiplyToSelf(108.66922287382016d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray28 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray37 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray37);
        int int39 = org.apache.commons.math3.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = array2DRowRealMatrix20.preMultiply(doubleArray37);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray37, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 87412023 + "'", int39 == 87412023);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 35, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}", 36);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector23.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray40 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        boolean boolean43 = arrayRealVector41.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector20.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector44.mapSubtractToSelf((double) 36);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector44.mapSubtractToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, realVector49);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(realVector49);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math3.util.FastMath.log(108.66922287382016d, (-0.8414709848078965d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.transpose();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix20.power((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: invalid exponent -1 (must be positive)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = mathIllegalStateExceptionPair4.getKey();
        org.apache.commons.math3.random.RandomGenerator randomGenerator6 = mathIllegalStateExceptionPair4.getSecond();
        org.apache.commons.math3.random.RandomGenerator randomGenerator7 = mathIllegalStateExceptionPair4.getSecond();
        org.apache.commons.math3.random.RandomGenerator randomGenerator8 = mathIllegalStateExceptionPair4.getValue();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair9 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>(mathIllegalStateExceptionPair4);
        org.junit.Assert.assertNotNull(mathIllegalStateException5);
        org.junit.Assert.assertNotNull(randomGenerator6);
        org.junit.Assert.assertNotNull(randomGenerator7);
        org.junit.Assert.assertNotNull(randomGenerator8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray33 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray33);
        boolean boolean36 = arrayRealVector34.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector40.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray57 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, doubleArray57);
        boolean boolean60 = arrayRealVector58.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector40, arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector34.append(arrayRealVector40);
        double[] doubleArray63 = arrayRealVector34.getDataRef();
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray63, 35);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition66 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray63);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1401562416, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,401,562,416 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray49 = arrayRealVector20.getDataRef();
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49, 35);
        double[] doubleArray57 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray63 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray69 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray70 = new double[][] { doubleArray63, doubleArray69 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray57, doubleArray70);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, doubleArray57);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector23 = array2DRowRealMatrix21.getRowVector(0);
        boolean boolean24 = array2DRowRealMatrix21.isTransposable();
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector47 = array2DRowRealMatrix45.getRowVector(0);
        double[] doubleArray53 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray59 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray65 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray66 = new double[][] { doubleArray59, doubleArray65 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray53, doubleArray66);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray53);
        double[] doubleArray69 = array2DRowRealMatrix45.preMultiply(doubleArray53);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = array2DRowRealMatrix21.subtract(array2DRowRealMatrix45);
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = array2DRowRealMatrix45.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix74.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix74.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix76.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor78 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double79 = blockRealMatrix76.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor78);
        double double80 = array2DRowRealMatrix45.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor78);
        double double81 = array2DRowRealMatrix0.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor78);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix82 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix70);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(4.149485889338074E180d, 1.709975946676697d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7034835968908073d + "'", double2 == 0.7034835968908073d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray49 = arrayRealVector20.getDataRef();
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray60 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector54, doubleArray60);
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray60);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double double65 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray51, doubleArray64);
        org.apache.commons.math3.linear.RealVector realVector66 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray51);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 120L, (float) (short) 10, (float) 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (-1549408969), (double) 36);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.5494089E9f) + "'", float2 == (-1.5494089E9f));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.8813735870195429d), (double) (short) 10, 1.0d, 1.5422326689561365d, 120.0d, (double) 120L, 1.709975946676697d, 492.04028441077287d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 15234.105547937143d + "'", double8 == 15234.105547937143d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(97, 6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.965595617591995d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 36.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        double[][] doubleArray5 = blockRealMatrix2.getData();
        java.lang.Class<?> wildcardClass6 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix44, 0);
        double[] doubleArray76 = new double[] { (-1.0f), (-0.0d), 0.5288560945221015d, 100L };
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray76);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44, (org.apache.commons.math3.linear.RealVector) arrayRealVector78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.00639823915624d + "'", double77 == 100.00639823915624d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) 35, 0, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) ' ');
        int int2 = mersenneTwister1.nextInt();
        int[] intArray8 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray15 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray15);
        int[] intArray17 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
        int[] intArray24 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int25 = org.apache.commons.math3.util.MathArrays.distance1(intArray17, intArray24);
        int[] intArray31 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray38 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double39 = org.apache.commons.math3.util.MathArrays.distance(intArray31, intArray38);
        int[] intArray40 = org.apache.commons.math3.util.MathArrays.copyOf(intArray31);
        int[] intArray47 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int48 = org.apache.commons.math3.util.MathArrays.distance1(intArray40, intArray47);
        int int49 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray17, intArray47);
        mersenneTwister1.setSeed(intArray17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1549408969) + "'", int2 == (-1549408969));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 108.66922287382016d + "'", double16 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 120 + "'", int25 == 120);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 108.66922287382016d + "'", double39 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 120 + "'", int48 == 120);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 36 + "'", int49 == 36);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.scalarAdd(0.0d);
        double[] doubleArray14 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray20 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray26 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray26 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray14, doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix29.createMatrix(36, (int) (short) 10);
        boolean boolean33 = array2DRowRealMatrix29.isSquare();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector36.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray53 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector47, doubleArray53);
        boolean boolean56 = arrayRealVector54.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector60.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector65.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector60.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray77 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector71, doubleArray77);
        boolean boolean80 = arrayRealVector78.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector60, arrayRealVector78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector54.append(arrayRealVector60);
        double[] doubleArray83 = arrayRealVector54.getDataRef();
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83, 35);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray86);
        blockRealMatrix4.setRow((int) (byte) 10, doubleArray87);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix89 = blockRealMatrix4.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix89, 4, 120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(blockRealMatrix89);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append((double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        boolean boolean14 = arrayRealVector13.isNaN();
        int int15 = arrayRealVector13.getDimension();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        mersenneTwister0.setSeed(35);
        java.lang.Class<?> wildcardClass3 = mersenneTwister0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix2.transpose();
        double[][] doubleArray33 = blockRealMatrix32.getData();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat13 = realMatrixFormat12.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat14 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "hi!", "", "", "hi!", numberFormat13);
        java.lang.String str15 = realMatrixFormat14.getRowSeparator();
        java.text.ParsePosition parsePosition17 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = realMatrixFormat14.parse("", parsePosition17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) '4', 10);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException4 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-0.5872139151569291d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix4.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix13.transpose();
        double double15 = blockRealMatrix14.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix10.multiply(blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix4.subtract(blockRealMatrix14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix14.createMatrix((int) (short) 10, 52);
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }
}

