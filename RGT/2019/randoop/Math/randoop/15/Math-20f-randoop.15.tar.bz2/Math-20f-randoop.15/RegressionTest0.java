import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(2.718281828459045d, (double) (byte) 0, (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        try {
            arrayRealVector2.addToEntry((int) '#', 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector3 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector2.subtract(realVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray20 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray20);
        try {
            arrayRealVector7.setSubVector((int) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray17 = new int[] { '#', 100, (short) -1 };
        try {
            double double18 = org.apache.commons.math3.util.MathArrays.distance(intArray12, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) 0.0f, (double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (short) -1, (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 0L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex(anyMatrix0, (int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) (short) 0, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String[] strArray3 = new java.lang.String[] { "", "hi!", "" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = null;
        try {
            boolean boolean6 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray3, orderDirection4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 0, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(100.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector12.mapDivideToSelf((double) 1);
        try {
            double double17 = arrayRealVector9.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 1.0d, 108.66922287382016d, (-0.0d), (-0.0d), 10.0d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) '#', (double) (short) 100, 0.5288560945221015d, (double) (-1.0f), (double) 0L, (double) 'a', (double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3499.4711439054777d + "'", double8 == 3499.4711439054777d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.map(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray15 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray15);
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) 10L);
        try {
            org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector6.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (byte) 100, 10.0d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = null;
        try {
            boolean boolean13 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray8, orderDirection11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 87412023 + "'", int10 == 87412023);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math3.util.FastMath.cos(3499.4711439054777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.965595617591995d + "'", double1 == 0.965595617591995d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor10 = null;
        try {
            double double11 = arrayRealVector9.walkInOptimizedOrder(realVectorChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        double[] doubleArray5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (-1.0f), (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor10 = null;
        try {
            double double13 = arrayRealVector9.walkInOptimizedOrder(realVectorChangingVisitor10, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat5 = realVectorFormat4.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat5);
        java.text.ParsePosition parsePosition7 = null;
        try {
            java.lang.Number number8 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat5, parsePosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (short) 1, (double) 1.4E-45f, (double) (byte) 1, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble(108.66922287382016d, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector2.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray15 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray15);
        boolean boolean18 = arrayRealVector16.equals((java.lang.Object) 10L);
        try {
            double double19 = arrayRealVector2.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = null;
        try {
            boolean boolean15 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8, orderDirection12, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_STOPFITNESS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble(0.965595617591995d, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "hi!");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        java.io.ObjectInputStream objectInputStream13 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray8, "hi!", objectInputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 10, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.subtract(realMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 10x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector51.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector59.append((double) 10);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector26.subtract(realVector61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(realVector61);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(141.43196244130957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 142.0d + "'", double1 == 142.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (byte) -1, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor21 = null;
        try {
            double double22 = array2DRowRealMatrix20.walkInRowOrder(realMatrixPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 100L, 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 10L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double26 = array2DRowRealMatrix20.walkInColumnOrder(realMatrixChangingVisitor21, (int) (short) -1, 97, 87412023, 87412023);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray0, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = null;
        try {
            boolean boolean13 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray8, orderDirection11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 87412023 + "'", int10 == 87412023);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor5 = null;
        try {
            double double8 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor5, (int) (byte) 10, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[] doubleArray26 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray32 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray38 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray39 = new double[][] { doubleArray32, doubleArray38 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray26, doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix20.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivide(1.0d);
        org.apache.commons.math3.linear.RealVector realVector13 = realVector11.mapDivide((-0.9999999999999999d));
        int int14 = realVector13.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray9 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, doubleArray9);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray9, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition21 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        try {
            double double12 = arrayRealVector7.getEntry((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double26 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21, 97, 0, (int) (short) -1, 87412023);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        float float3 = org.apache.commons.math3.util.Precision.round((float) (byte) -1, (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-2.0f) + "'", float3 == (-2.0f));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-2.0f), (float) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector23.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray40 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        boolean boolean43 = arrayRealVector41.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray64 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector58, doubleArray64);
        boolean boolean67 = arrayRealVector65.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector47, arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector41.append(arrayRealVector47);
        try {
            org.apache.commons.math3.linear.RealVector realVector70 = array2DRowRealMatrix20.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(arrayRealVector69);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector15.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = array2DRowRealMatrix20.walkInRowOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor12 = null;
        try {
            double double13 = arrayRealVector9.walkInDefaultOrder(realVectorPreservingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math3.util.FastMath.log(141.43196244130957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9518187706436265d + "'", double1 == 4.9518187706436265d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) '4', (int) (short) 10);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray49 = arrayRealVector20.getDataRef();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor50 = null;
        try {
            double double53 = arrayRealVector20.walkInDefaultOrder(realVectorPreservingVisitor50, (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_RANDOMGENERATOR;
        org.junit.Assert.assertNotNull(randomGenerator0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.exception.util.Localizable localizable21 = null;
        double[] doubleArray27 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray33 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray39 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray40 = new double[][] { doubleArray33, doubleArray39 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray27, doubleArray40);
        double[][] doubleArray42 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray40);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException43 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable21, (java.lang.Object[]) doubleArray40);
        try {
            array2DRowRealMatrix20.setSubMatrix(doubleArray40, 36, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector25.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray42 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray42);
        boolean boolean45 = arrayRealVector43.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, arrayRealVector43);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector15.combine(0.0d, 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        float float1 = org.apache.commons.math3.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[] doubleArray33 = new double[] { 10L, 10.0f, 3, 1, 100.0f, 0.0f };
        double[] doubleArray40 = new double[] { 10L, 10.0f, 3, 1, 100.0f, 0.0f };
        double[] doubleArray47 = new double[] { 10L, 10.0f, 3, 1, 100.0f, 0.0f };
        double[] doubleArray54 = new double[] { 10L, 10.0f, 3, 1, 100.0f, 0.0f };
        double[] doubleArray61 = new double[] { 10L, 10.0f, 3, 1, 100.0f, 0.0f };
        double[] doubleArray68 = new double[] { 10L, 10.0f, 3, 1, 100.0f, 0.0f };
        double[][] doubleArray69 = new double[][] { doubleArray33, doubleArray40, doubleArray47, doubleArray54, doubleArray61, doubleArray68 };
        try {
            array2DRowRealMatrix20.copySubMatrix(0, 3, (int) (byte) 100, 97, doubleArray69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = array2DRowRealMatrix20.walkInRowOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        try {
            java.lang.StringBuffer stringBuffer11 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 1, numberFormat8, stringBuffer9, fieldPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector10.mapAdd(3499.4711439054777d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        try {
            double double20 = arrayRealVector10.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray32 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        try {
            array2DRowRealMatrix20.setColumn((int) (byte) -1, doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 87412023 + "'", int34 == 87412023);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(2.718281828459045d, (double) 87412023, 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 10, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 3, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.text.NumberFormat numberFormat2 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray11 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector15.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray32 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray32);
        boolean boolean35 = arrayRealVector33.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector12.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        java.lang.StringBuffer stringBuffer38 = null;
        java.text.FieldPosition fieldPosition39 = null;
        try {
            java.lang.StringBuffer stringBuffer40 = realVectorFormat0.format(realVector37, stringBuffer38, fieldPosition39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat4);
        java.text.NumberFormat numberFormat6 = realVectorFormat5.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.999998f + "'", float2 == 31.999998f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat4);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = realVectorFormat5.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) '#', (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector2.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double8 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        double[][] doubleArray44 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        try {
            array2DRowRealMatrix20.setSubMatrix(doubleArray42, 52, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector23 = array2DRowRealMatrix21.getRowVector(0);
        boolean boolean24 = array2DRowRealMatrix21.isTransposable();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix11, 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 87412023 + "'", int10 == 87412023);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        double[] doubleArray24 = null;
        try {
            double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) 10, (double) 100, 4.9518187706436265d, 2.2250738585072014E-306d, (double) 3, 3.141592653589793d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 492.04028441077287d + "'", double8 == 492.04028441077287d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector36.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray53 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector47, doubleArray53);
        boolean boolean56 = arrayRealVector54.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector30.append(arrayRealVector36);
        double[] doubleArray64 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray70 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray76 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray77 = new double[][] { doubleArray70, doubleArray76 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray64, doubleArray77);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray64);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector80.mapSubtract(0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector82);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        double[] doubleArray21 = new double[] {};
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray21, (double) 120);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 141.43196244130957d + "'", double20 == 141.43196244130957d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.965595617591995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.015204713975260888d) + "'", double1 == (-0.015204713975260888d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector23.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray40 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector49.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector44.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray61 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray61);
        boolean boolean64 = arrayRealVector62.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector44, arrayRealVector62);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector41.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, realVector66);
        try {
            org.apache.commons.math3.linear.RealVector realVector68 = array2DRowRealMatrix20.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(realVector66);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int[] intArray15 = null;
        try {
            int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor11 = null;
        try {
            double double14 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor11, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 31.999998f, 120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.149485889338074E180d + "'", double2 == 4.149485889338074E180d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix20.walkInRowOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray7 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray13 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray19 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray19 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix((int) '#', 0, doubleArray22, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '#', 87412023, (double) '#');
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0, (-0.0d), 3.141592653589793d, (-1.0d), Double.NaN, (double) 87412023);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector55.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector50.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray67 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector61, doubleArray67);
        boolean boolean70 = arrayRealVector68.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector44.append(arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector75.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector80.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector75.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector88.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector92 = arrayRealVector88.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector80.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector88);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = arrayRealVector44.append(arrayRealVector80);
        try {
            array2DRowRealMatrix20.setColumnVector((int) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertNotNull(realVector92);
        org.junit.Assert.assertNotNull(arrayRealVector93);
        org.junit.Assert.assertNotNull(arrayRealVector94);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) (short) 100);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 0L, 108.66922287382016d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 108.66922287382016d + "'", double2 == 108.66922287382016d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 120, (double) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 119.99999f + "'", float2 == 119.99999f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.clear();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5288560945221015d + "'", double2 == 0.5288560945221015d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        long long1 = org.apache.commons.math3.util.FastMath.round(1.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) 1.0f);
        java.lang.StringBuffer stringBuffer11 = null;
        java.text.FieldPosition fieldPosition12 = null;
        try {
            java.lang.StringBuffer stringBuffer13 = realVectorFormat5.format((org.apache.commons.math3.linear.RealVector) arrayRealVector8, stringBuffer11, fieldPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat10 = realVectorFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat11 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!", numberFormat10);
        java.text.ParsePosition parsePosition15 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = realVectorFormat13.parse("", parsePosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        org.apache.commons.math3.exception.util.Localizable localizable28 = null;
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray46 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray47 = new double[][] { doubleArray40, doubleArray46 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray34, doubleArray47);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable28, (java.lang.Object[]) doubleArray47);
        try {
            array2DRowRealMatrix20.copySubMatrix((int) '4', 100, (int) (short) 0, (int) 'a', doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (byte) 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 1, (double) 100, (double) (short) 100, (double) 97, (-0.8414709848078965d), (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9800.841470984808d + "'", double6 == 9800.841470984808d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { (-0.015204713975260888d) };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.util.MathUtils.checkFinite(108.66922287382016d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray45);
        try {
            org.apache.commons.math3.linear.RealVector realVector47 = array2DRowRealMatrix20.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 1, (int) (byte) 100, 4.149485889338074E180d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 100L, 36, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        float float1 = org.apache.commons.math3.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(Double.NEGATIVE_INFINITY, (double) (short) 100, 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        double[] doubleArray8 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray14 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray20 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray21 = new double[][] { doubleArray14, doubleArray20 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = array2DRowRealMatrix23.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        try {
            double double30 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24, (int) 'a', (int) (short) 10, 52, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray13 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray19 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray19 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) (-0.0d), (java.lang.Object[]) doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(100.00639823915624d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        int[] intArray9 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray16 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double17 = org.apache.commons.math3.util.MathArrays.distance(intArray9, intArray16);
        int[] intArray23 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray30 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance(intArray23, intArray30);
        int[] intArray32 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        int[] intArray39 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int40 = org.apache.commons.math3.util.MathArrays.distance1(intArray32, intArray39);
        int[] intArray42 = org.apache.commons.math3.util.MathArrays.copyOf(intArray39, (int) (byte) 0);
        double[][] doubleArray43 = null;
        try {
            blockRealMatrix2.copySubMatrix(intArray9, intArray39, doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 108.66922287382016d + "'", double17 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 108.66922287382016d + "'", double31 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 120 + "'", int40 == 120);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor3, (int) (byte) 10, (int) (short) -1, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector47.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.RealVector realVector57 = arrayRealVector55.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector55.mapAdd(3499.4711439054777d);
        try {
            org.apache.commons.math3.linear.RealVector realVector60 = array2DRowRealMatrix20.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100.0d, (java.lang.Number) 52, (java.lang.Number) 6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_DIAGONALONLY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        float[] floatArray0 = null;
        float[] floatArray1 = null;
        boolean boolean2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            blockRealMatrix2.multiplyEntry(52, 0, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getPrefix();
        java.lang.String str9 = realMatrixFormat6.getRowSeparator();
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        double double3 = mersenneTwister2.nextDouble();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>(mathIllegalStateException0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister2);
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = mathIllegalStateExceptionPair4.getSecond();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5288560945221015d + "'", double3 == 0.5288560945221015d);
        org.junit.Assert.assertNotNull(randomGenerator5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 3 and 4 are not strictly increasing (108.669 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector8.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray25 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, doubleArray25);
        boolean boolean28 = arrayRealVector26.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector32.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray49 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector43, doubleArray49);
        boolean boolean52 = arrayRealVector50.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector26.append(arrayRealVector32);
        double[] doubleArray60 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray72 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray73 = new double[][] { doubleArray66, doubleArray72 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray60, doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32, doubleArray60);
        try {
            blockRealMatrix4.setColumn((int) '4', doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 100.0f, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix20.getColumnMatrix(87412023);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (87,412,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        double double22 = arrayRealVector7.getLInfNorm();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math3.util.FastMath.max(Double.NEGATIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector37.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector50.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector42.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction61 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector58.map(univariateFunction61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, arrayRealVector62);
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector62.mapDivideToSelf((double) (short) 10);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector65);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(6);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(9800.841470984808d, 9800.841470984808d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9800.841470984808d + "'", double2 == 9800.841470984808d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, true);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        java.text.ParsePosition parsePosition9 = null;
        try {
            java.lang.Number number10 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat8, parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor44 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double45 = array2DRowRealMatrix43.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        try {
            double double50 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44, (int) '#', (int) ' ', 52, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        boolean boolean11 = arrayRealVector9.equals((java.lang.Object) 10L);
        int int12 = arrayRealVector9.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray28, doubleArray29, doubleArray30 };
        try {
            array2DRowRealMatrix20.setSubMatrix(doubleArray31, 100, 120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) 10, 492.04028441077287d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.subtract(blockRealMatrix4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        org.apache.commons.math3.exception.util.Localizable localizable24 = null;
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = array2DRowRealMatrix45.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix45.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray53 = array2DRowRealMatrix45.getDataRef();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable24, (java.lang.Object[]) doubleArray53);
        try {
            array2DRowRealMatrix20.setSubMatrix(doubleArray53, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector23.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray40 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, doubleArray40);
        boolean boolean43 = arrayRealVector41.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector20.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, realVector45);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector46);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(realVector45);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = realVectorFormat0.format(realVector2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, 87412023);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix20.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44);
        double[] doubleArray58 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray70 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray71 = new double[][] { doubleArray64, doubleArray70 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray58, doubleArray71);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = array2DRowRealMatrix73.createMatrix(36, (int) (short) 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix77 = array2DRowRealMatrix20.subtract(realMatrix76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 36x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(realMatrix76);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 10 };
        mersenneTwister0.nextBytes(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) 0.5288560945221015d, true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 1.0f, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat13 = realMatrixFormat12.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat14 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "hi!", "", "", "hi!", numberFormat13);
        java.lang.String str15 = realMatrixFormat14.getRowSeparator();
        java.lang.String str16 = realMatrixFormat14.getRowSuffix();
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(4.9518187706436265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2825470172998332d + "'", double1 == 2.2825470172998332d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) 10);
        incrementor1.incrementCount(0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        try {
            array2DRowRealMatrix20.multiplyEntry((int) (short) 10, (int) (short) 10, (double) 1.4E-45f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor70 = null;
        try {
            double double71 = array2DRowRealMatrix44.walkInRowOrder(realMatrixChangingVisitor70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, (int) 'a', (double) '#');
        int int4 = nonSymmetricMatrixException3.getColumn();
        int int5 = nonSymmetricMatrixException3.getRow();
        double double6 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double6 = blockRealMatrix4.walkInOptimizedOrder(realMatrixChangingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection21 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection21, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getRowSeparator();
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(72.66922287382016d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat4);
        java.lang.String str6 = realVectorFormat5.getSuffix();
        java.text.ParsePosition parsePosition8 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = realVectorFormat5.parse("hi!", parsePosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        java.lang.String str9 = realMatrixFormat6.getRowSeparator();
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 52, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, (int) 'a', (double) '#');
        java.lang.String str4 = nonSymmetricMatrixException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (0,97) and (97,0) is larger than 35" + "'", str4.equals("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (0,97) and (97,0) is larger than 35"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(6, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        try {
            array2DRowRealMatrix69.multiplyEntry(87412023, 87412023, (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (87,412,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor3, (int) (short) 10, (int) (byte) 0, 6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix20.walkInOptimizedOrder(realMatrixChangingVisitor24, 35, (int) (short) 0, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 119.99999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 120.0d + "'", double1 == 120.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        try {
            double[] doubleArray25 = array2DRowRealMatrix20.getColumn(6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) (-1L));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getColumnMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        double[] doubleArray5 = null;
        try {
            double[] doubleArray6 = blockRealMatrix4.operate(doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-0.7805794640849414d), 0.965595617591995d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) 10);
        boolean boolean2 = incrementor1.canIncrement();
        incrementor1.resetCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError0);
        java.lang.String str2 = mathInternalError1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH" + "'", str2.equals("org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector24.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.append((double) 10);
        try {
            double double35 = arrayRealVector21.cosine(realVector34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix20.walkInOptimizedOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix75 = array2DRowRealMatrix44.getSubMatrix(6, 0, 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor5 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double6 = defaultRealMatrixPreservingVisitor5.end();
        try {
            double double11 = blockRealMatrix4.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor5, 100, 0, 4, 120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { 36, 100, (short) 1, 6, (byte) 10, (byte) 0 };
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray7);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) '4', (float) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector49 = null;
        try {
            double double50 = arrayRealVector20.cosine(realVector49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        try {
            double double12 = arrayRealVector2.getEntry(3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.map(univariateFunction5);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double10 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor7, 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (4)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 87412023);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 10, (double) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0.5288560945221015d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix3.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int[] intArray21 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int22 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray21);
        int[] intArray28 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray35 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double36 = org.apache.commons.math3.util.MathArrays.distance(intArray28, intArray35);
        int[] intArray37 = org.apache.commons.math3.util.MathArrays.copyOf(intArray28);
        int[] intArray44 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int45 = org.apache.commons.math3.util.MathArrays.distance1(intArray37, intArray44);
        int int46 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray14, intArray44);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister47 = new org.apache.commons.math3.random.MersenneTwister(intArray14);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 120 + "'", int22 == 120);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 108.66922287382016d + "'", double36 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 120 + "'", int45 == 120);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 36 + "'", int46 == 36);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor45 = null;
        try {
            double double50 = array2DRowRealMatrix20.walkInOptimizedOrder(realMatrixChangingVisitor45, (int) (byte) -1, (int) (short) 0, (int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        org.apache.commons.math3.optimization.GoalType goalType3 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray12 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, doubleArray12);
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector18.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray35 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, doubleArray35);
        boolean boolean38 = arrayRealVector36.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector42.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray59 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector53, doubleArray59);
        boolean boolean62 = arrayRealVector60.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector36.append(arrayRealVector42);
        double[] doubleArray70 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray76 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray82 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray83 = new double[][] { doubleArray76, doubleArray82 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray70, doubleArray83);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, doubleArray70);
        double[] doubleArray88 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray70, (double) '4');
        double[] doubleArray89 = null;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair90 = cMAESOptimizer0.optimize((int) (short) 10, multivariateFunction2, goalType3, doubleArray12, doubleArray70, doubleArray89);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType3 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType3.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(arrayRealVector64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            double[] doubleArray6 = blockRealMatrix2.getRow(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix21.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix21.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray29 = array2DRowRealMatrix21.getDataRef();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = mathIllegalArgumentException30.getContext();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(exceptionContext31);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector33.mapSubtractToSelf((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector39.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray56 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, doubleArray56);
        boolean boolean59 = arrayRealVector57.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector39, arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector65 = arrayRealVector63.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector70 = arrayRealVector68.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector63.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray80 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector74, doubleArray80);
        boolean boolean83 = arrayRealVector81.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector63, arrayRealVector81);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = arrayRealVector57.append(arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(realVector36, arrayRealVector57);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector86);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction88 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector86.map(univariateFunction88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(arrayRealVector85);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        org.apache.commons.math3.exception.util.Localizable localizable71 = null;
        double[] doubleArray77 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray83 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray89 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray90 = new double[][] { doubleArray83, doubleArray89 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray77, doubleArray90);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable71, (java.lang.Object[]) doubleArray90);
        double[][] doubleArray93 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray90);
        try {
            array2DRowRealMatrix44.setSubMatrix(doubleArray90, (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray54, (double) '4');
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray54, 10.0d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector10.mapAdd(3499.4711439054777d);
        try {
            arrayRealVector10.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray7 = new double[] { (byte) -1, (short) -1, 100L, Double.NaN, 1L, (byte) -1 };
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer8 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) 'a', doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix20.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray61 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, doubleArray61);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20, (org.apache.commons.math3.linear.RealVector) arrayRealVector62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        double double25 = arrayRealVector20.getNorm();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 109.13294644606641d + "'", double25 == 109.13294644606641d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 4, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray28 = array2DRowRealMatrix20.getDataRef();
        try {
            org.apache.commons.math3.linear.RealVector realVector30 = array2DRowRealMatrix20.getColumnVector((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0);
        mersenneTwister1.setSeed(0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        boolean boolean5 = mersenneTwister3.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor25 = null;
        try {
            double double26 = arrayRealVector24.walkInOptimizedOrder(realVectorChangingVisitor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray14 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8, doubleArray14);
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray14);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14);
        try {
            arrayRealVector2.setSubVector((int) ' ', doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int[] intArray21 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int22 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray21);
        int[] intArray28 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray35 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double36 = org.apache.commons.math3.util.MathArrays.distance(intArray28, intArray35);
        int[] intArray37 = org.apache.commons.math3.util.MathArrays.copyOf(intArray28);
        int[] intArray44 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int45 = org.apache.commons.math3.util.MathArrays.distance1(intArray37, intArray44);
        int int46 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray14, intArray44);
        int[] intArray52 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray59 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double60 = org.apache.commons.math3.util.MathArrays.distance(intArray52, intArray59);
        double double61 = org.apache.commons.math3.util.MathArrays.distance(intArray44, intArray59);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 120 + "'", int22 == 120);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 108.66922287382016d + "'", double36 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 120 + "'", int45 == 120);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 36 + "'", int46 == 36);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 108.66922287382016d + "'", double60 == 108.66922287382016d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 138.63982111933063d + "'", double61 == 138.63982111933063d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) Double.POSITIVE_INFINITY);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        double double45 = array2DRowRealMatrix20.getFrobeniusNorm();
        int int46 = array2DRowRealMatrix20.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 141.43196244130957d + "'", double45 == 141.43196244130957d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 5 + "'", int46 == 5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.map(univariateFunction26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray41 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector52 = arrayRealVector50.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector45.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray62 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector56, doubleArray62);
        boolean boolean65 = arrayRealVector63.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, arrayRealVector63);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector42.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector66.mapSubtractToSelf((double) 36);
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector66.mapSubtractToSelf(0.0d);
        double double73 = arrayRealVector66.getEntry(3);
        int int74 = arrayRealVector66.getMinIndex();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector27.combineToSelf((double) 4, (double) 35, (org.apache.commons.math3.linear.RealVector) arrayRealVector66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 72.66922287382016d + "'", double73 == 72.66922287382016d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 4 + "'", int74 == 4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 120);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 120L + "'", long1 == 120L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        org.apache.commons.math3.optimization.GoalType goalType2 = cMAESOptimizer1.getGoalType();
        org.junit.Assert.assertNull(goalType2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        boolean boolean5 = blockRealMatrix2.isTransposable();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        java.io.ObjectOutputStream objectOutputStream24 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, objectOutputStream24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) '#', (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5422326689561365d + "'", double2 == 1.5422326689561365d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray13 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray19 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray19 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray7, doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double24 = array2DRowRealMatrix22.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        double[][] doubleArray25 = array2DRowRealMatrix22.getDataRef();
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (short) 100, localizable1, (java.lang.Object[]) doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.append((double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector16.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray33 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector37.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray54 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, doubleArray54);
        boolean boolean57 = arrayRealVector55.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, arrayRealVector55);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector34.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, realVector59);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = arrayRealVector13.ebeMultiply(realVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(realVector59);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = array2DRowRealMatrix45.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix45);
        try {
            array2DRowRealMatrix45.multiplyEntry((int) ' ', (int) (byte) -1, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        double double45 = array2DRowRealMatrix20.getFrobeniusNorm();
        try {
            array2DRowRealMatrix20.multiplyEntry(87412023, (int) (short) 100, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (87,412,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 141.43196244130957d + "'", double45 == 141.43196244130957d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 36, number1, true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivide(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray20 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray20);
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector25);
        try {
            arrayRealVector26.setEntry((int) 'a', (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(109.13294644606641d, (double) 87412023, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 110.13294644606641d + "'", double3 == 110.13294644606641d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = defaultRealMatrixPreservingVisitor3.end();
        try {
            double double9 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3, (int) 'a', (int) (byte) 10, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        try {
            array2DRowRealMatrix20.setEntry(1, (int) ' ', (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 10L, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9867717342662448d + "'", double2 == 1.9867717342662448d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList1 = cMAESOptimizer0.getStatisticsMeanHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = null;
        double[] doubleArray10 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray16 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray22 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray23 = new double[][] { doubleArray16, doubleArray22 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray10, doubleArray23);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector27 = array2DRowRealMatrix25.getRowVector(0);
        double[] doubleArray33 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray39 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray45 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray46 = new double[][] { doubleArray39, doubleArray45 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray33, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray49 = array2DRowRealMatrix25.preMultiply(doubleArray33);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair50 = cMAESOptimizer0.optimize(97, multivariateFunction3, goalType4, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixList1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = mathIllegalStateExceptionPair4.getKey();
        org.apache.commons.math3.random.RandomGenerator randomGenerator6 = mathIllegalStateExceptionPair4.getSecond();
        org.apache.commons.math3.random.RandomGenerator randomGenerator7 = mathIllegalStateExceptionPair4.getSecond();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = mathIllegalStateExceptionPair4.getKey();
        org.junit.Assert.assertNotNull(mathIllegalStateException5);
        org.junit.Assert.assertNotNull(randomGenerator6);
        org.junit.Assert.assertNotNull(randomGenerator7);
        org.junit.Assert.assertNotNull(mathIllegalStateException8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) 100, 5);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(100.0d, (double) '#', 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor35 = null;
        try {
            double double38 = arrayRealVector33.walkInDefaultOrder(realVectorPreservingVisitor35, 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 100L, (float) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        int int11 = arrayRealVector10.getMinIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int1 = org.apache.commons.math3.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat10 = realVectorFormat9.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat11 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat12 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!", numberFormat10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat14 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(141.43196244130957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 141.4319624413096d + "'", double1 == 141.4319624413096d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        boolean boolean24 = array2DRowRealMatrix20.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector33.mapSubtractToSelf((double) 36);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector33.mapSubtractToSelf(0.0d);
        double double40 = arrayRealVector33.getEntry(3);
        java.io.ObjectInputStream objectInputStream42 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) arrayRealVector33, "hi!", objectInputStream42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 72.66922287382016d + "'", double40 == 72.66922287382016d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray52 = array2DRowRealMatrix44.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix20.add(array2DRowRealMatrix44);
        double[] doubleArray60 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray72 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray73 = new double[][] { doubleArray66, doubleArray72 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray60, doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = array2DRowRealMatrix75.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix75.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray83 = array2DRowRealMatrix75.getDataRef();
        try {
            array2DRowRealMatrix53.setRowMatrix((int) (byte) 1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        double double72 = array2DRowRealMatrix69.getEntry(4, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(0.52885604f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.5288561f + "'", float1 == 0.5288561f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int int16 = mersenneTwister15.nextInt();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1401562416 + "'", int16 == 1401562416);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0);
        mersenneTwister1.setSeed((long) 1);
        mersenneTwister1.setSeed(1L);
        float float6 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.112994194f + "'", float6 == 0.112994194f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (0,97) and (97,0) is larger than 35", "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", "", numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(142.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.648986636264298d + "'", double1 == 5.648986636264298d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) -1, (int) (short) 100);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = mathInternalError1.getContext();
        java.lang.Class<?> wildcardClass6 = mathInternalError1.getClass();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix11.walkInRowOrder(realMatrixChangingVisitor12, (int) (short) 0, (int) (short) -1, (int) '4', 1401562416);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = mathIllegalStateExceptionPair4.getKey();
        java.io.ObjectInputStream objectInputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) mathIllegalStateException5, "org.apache.commons.math3.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", objectInputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mathIllegalStateException5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtractToSelf(0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix20.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44);
        int[] intArray53 = null;
        int[] intArray59 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray66 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double67 = org.apache.commons.math3.util.MathArrays.distance(intArray59, intArray66);
        int[] intArray68 = org.apache.commons.math3.util.MathArrays.copyOf(intArray59);
        int[] intArray75 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int76 = org.apache.commons.math3.util.MathArrays.distance1(intArray68, intArray75);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix77 = array2DRowRealMatrix20.getSubMatrix(intArray53, intArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 108.66922287382016d + "'", double67 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 120 + "'", int76 == 120);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 36, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 0);
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException7 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, (int) 'a', (double) '#');
        int int8 = nonSymmetricMatrixException7.getColumn();
        int int9 = nonSymmetricMatrixException7.getRow();
        outOfRangeException3.addSuppressed((java.lang.Throwable) nonSymmetricMatrixException7);
        java.lang.Number number11 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        double double22 = arrayRealVector7.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector7.mapToSelf(univariateFunction23);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector24);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        double[] doubleArray37 = new double[] { 3.141592653589793d, 87412023, (byte) -1, (byte) 1, ' ' };
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        try {
            double[] doubleArray39 = blockRealMatrix2.operate(doubleArray38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 36");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.map(univariateFunction26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        try {
            org.apache.commons.math3.linear.RealVector realVector31 = realVector30.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        org.apache.commons.math3.linear.RealVector realVector71 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray54);
        realVector71.unitize();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector71);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.exception.util.Localizable localizable70 = null;
        double[] doubleArray76 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray82 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray88 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray89 = new double[][] { doubleArray82, doubleArray88 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray76, doubleArray89);
        double[][] doubleArray91 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray89);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException92 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable70, (java.lang.Object[]) doubleArray89);
        try {
            array2DRowRealMatrix69.setSubMatrix(doubleArray89, (int) (short) 10, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        double[] doubleArray22 = null;
        try {
            double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray21, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 141.43196244130957d + "'", double20 == 141.43196244130957d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix2.transpose();
        try {
            blockRealMatrix2.multiplyEntry((int) (byte) 100, 35, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        java.io.ObjectInputStream objectInputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) throwable0, "Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}", objectInputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        try {
            double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 87412023 + "'", int10 == 87412023);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor6 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double11 = blockRealMatrix5.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor6, 120, 0, (int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException5 = mathIllegalStateExceptionPair4.getKey();
        org.apache.commons.math3.random.RandomGenerator randomGenerator6 = mathIllegalStateExceptionPair4.getValue();
        org.junit.Assert.assertNotNull(mathIllegalStateException5);
        org.junit.Assert.assertNotNull(randomGenerator6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor22 = null;
        try {
            double double23 = arrayRealVector21.walkInOptimizedOrder(realVectorPreservingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 119.99999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6875.493104437772d + "'", double1 == 6875.493104437772d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathInternalError1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 3 and 4 are not strictly increasing (108.669 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-0.8813735870195429d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        double[] doubleArray37 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray43 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray49 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray50 = new double[][] { doubleArray43, doubleArray49 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray37, doubleArray50);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.RealVector realVector54 = array2DRowRealMatrix52.getRowVector(0);
        boolean boolean55 = array2DRowRealMatrix52.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister57 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double58 = mersenneTwister57.nextGaussian();
        boolean boolean59 = array2DRowRealMatrix52.equals((java.lang.Object) double58);
        double[][] doubleArray60 = array2DRowRealMatrix52.getData();
        try {
            blockRealMatrix2.setSubMatrix(doubleArray60, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-0.7805794640849414d) + "'", double58 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(109.13294644606641d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = blockRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(142.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) ' ', 35);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100, (java.lang.Number) 10, (java.lang.Number) (short) -1);
        java.lang.Throwable[] throwableArray6 = outOfRangeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex(anyMatrix0, 6, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double33 = array2DRowRealMatrix20.walkInOptimizedOrder(realMatrixChangingVisitor28, (int) (byte) 10, 0, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) 'a', 87412023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87412023 + "'", int2 == 87412023);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        double[] doubleArray33 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray42 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector36, doubleArray42);
        org.apache.commons.math3.linear.RealVector realVector44 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray42);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray33, doubleArray42);
        try {
            blockRealMatrix2.setColumn(87412023, doubleArray42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (87,412,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair4 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError1, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister3);
        float float5 = mersenneTwister3.nextFloat();
        double double6 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.52885604f + "'", float5 == 0.52885604f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.045539817184800005d) + "'", double6 == (-0.045539817184800005d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 102400.0f + "'", float2 == 102400.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        try {
            double[] doubleArray25 = array2DRowRealMatrix20.getColumn(6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray10 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        java.lang.Object[] objArray15 = new java.lang.Object[] { doubleArray14 };
        org.apache.commons.math3.exception.ZeroException zeroException16 = new org.apache.commons.math3.exception.ZeroException(localizable1, objArray15);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-0.8414709848078965d), objArray15);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition5 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (36x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(6, (-1));
        java.lang.Number number3 = nonSquareMatrixException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 6 + "'", number3.equals(6));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivide(1.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray20 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray20);
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector25);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor27 = null;
        try {
            double double30 = arrayRealVector25.walkInDefaultOrder(realVectorPreservingVisitor27, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) 100);
        boolean boolean2 = incrementor1.canIncrement();
        incrementor1.setMaximalCount(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivide(1.0d);
        org.apache.commons.math3.linear.RealVector realVector13 = realVector11.mapDivide((-0.9999999999999999d));
        org.apache.commons.math3.linear.RealVector realVector15 = realVector13.mapDivide(0.965595617591995d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.14896799111995784d + "'", double0 == 0.14896799111995784d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList1 = cMAESOptimizer0.getStatisticsMeanHistory();
        org.apache.commons.math3.optimization.GoalType goalType2 = cMAESOptimizer0.getGoalType();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker3 = cMAESOptimizer0.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList4 = cMAESOptimizer0.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(realMatrixList1);
        org.junit.Assert.assertNull(goalType2);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker3);
        org.junit.Assert.assertNotNull(doubleList4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        java.lang.String str1 = arrayRealVector0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{}" + "'", str1.equals("{}"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector23 = array2DRowRealMatrix21.getRowVector(0);
        boolean boolean24 = array2DRowRealMatrix21.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double27 = mersenneTwister26.nextGaussian();
        boolean boolean28 = array2DRowRealMatrix21.equals((java.lang.Object) double27);
        double[][] doubleArray29 = array2DRowRealMatrix21.getData();
        org.apache.commons.math3.exception.MathInternalError mathInternalError30 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray29);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError31 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathInternalError30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-0.7805794640849414d) + "'", double27 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            blockRealMatrix4.setEntry((int) (short) 100, (int) 'a', (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        double[][] doubleArray71 = array2DRowRealMatrix44.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix75.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix75.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix77.copy();
        try {
            array2DRowRealMatrix44.setColumnMatrix((int) (byte) 10, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix44, 0);
        try {
            array2DRowRealMatrix44.addToEntry(1, 52, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = array2DRowRealMatrix45.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix45);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix52.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix52.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.copy();
        try {
            array2DRowRealMatrix48.setColumnMatrix((int) (short) 1, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        double[][] doubleArray28 = array2DRowRealMatrix20.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix20.scalarMultiply((double) (short) 0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix33.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix33.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix35.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double38 = blockRealMatrix35.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        try {
            double double43 = array2DRowRealMatrix20.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37, (int) (short) 1, 6, 4, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(3, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList1 = cMAESOptimizer0.getStatisticsMeanHistory();
        org.apache.commons.math3.optimization.GoalType goalType2 = cMAESOptimizer0.getGoalType();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker3 = cMAESOptimizer0.getConvergenceChecker();
        int int4 = cMAESOptimizer0.getMaxEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction6 = null;
        org.apache.commons.math3.optimization.GoalType goalType7 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray13 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray19 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray25 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray26 = new double[][] { doubleArray19, doubleArray25 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray13, doubleArray26);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = cMAESOptimizer0.optimize((int) 'a', multivariateFunction6, goalType7, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixList1);
        org.junit.Assert.assertNull(goalType2);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + goalType7 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType7.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray5 = new double[] { 3.141592653589793d, 87412023, (byte) -1, (byte) 1, ' ' };
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 97, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 96 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        double[][] doubleArray71 = array2DRowRealMatrix44.getData();
        double[][] doubleArray72 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection0.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        try {
            double[] doubleArray25 = blockRealMatrix3.operate(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = array2DRowRealMatrix44.scalarAdd((-1.0d));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor73 = null;
        try {
            double double78 = array2DRowRealMatrix44.walkInColumnOrder(realMatrixChangingVisitor73, (int) 'a', (int) (byte) 0, (int) (byte) 0, 120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) 10);
        int int2 = incrementor1.getMaximalCount();
        int int3 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-44.72390886665076d) + "'", double1 == (-44.72390886665076d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 0.112994194f, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        double[][] doubleArray71 = array2DRowRealMatrix44.getData();
        double[] doubleArray76 = new double[] { (-1.0f), (-0.0d), 0.5288560945221015d, 100L };
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray76);
        try {
            double[] doubleArray78 = array2DRowRealMatrix44.operate(doubleArray76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.00639823915624d + "'", double77 == 100.00639823915624d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double double49 = arrayRealVector48.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector52.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector65.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector65.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector57.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector73.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction76 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector73.map(univariateFunction76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, arrayRealVector77);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector77.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, realVector80);
        org.apache.commons.math3.linear.RealVector realVector83 = null;
        try {
            arrayRealVector81.setSubVector((int) (short) 100, realVector83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector80);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = array2DRowRealMatrix44.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix44.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = array2DRowRealMatrix20.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix44);
        double[] doubleArray60 = new double[] { 2.2825470172998332d, 0.0f, 0.112994194f, 1.5422326689561365d, 3L, 2.2250738585072014E-308d };
        try {
            array2DRowRealMatrix20.setColumn(1, doubleArray60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList1 = cMAESOptimizer0.getStatisticsMeanHistory();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker2 = cMAESOptimizer0.getConvergenceChecker();
        int int3 = cMAESOptimizer0.getEvaluations();
        org.junit.Assert.assertNotNull(realMatrixList1);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        int int5 = blockRealMatrix2.getRowDimension();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray2 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 3, (java.lang.Object[]) doubleArray2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        double[] doubleArray30 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray36 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray42 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray30, doubleArray43);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = array2DRowRealMatrix45.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix45);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor49 = null;
        try {
            double double50 = array2DRowRealMatrix45.walkInOptimizedOrder(realMatrixChangingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double double49 = arrayRealVector48.getMinValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector54 = arrayRealVector52.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector52.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector67 = arrayRealVector65.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector65.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector57.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector73.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction76 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector73.map(univariateFunction76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector65, arrayRealVector77);
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector77.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, realVector80);
        int int82 = arrayRealVector48.getMinIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 4 + "'", int82 == 4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 72.66922287382016d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.append((double) 10);
        array2DRowRealMatrix20.setRowVector(1, realVector41);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = array2DRowRealMatrix20.copy();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.append((double) 10);
        array2DRowRealMatrix20.setRowVector(1, realVector41);
        org.apache.commons.math3.linear.RealVector realVector44 = realVector41.mapSubtract(100.00639823915624d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((-0.015204713975260888d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01532149085696153d) + "'", double1 == (-0.01532149085696153d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        java.lang.String str8 = realMatrixFormat6.getPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix10 = realMatrixFormat6.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray30 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector34.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray51 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, doubleArray51);
        boolean boolean54 = arrayRealVector52.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, arrayRealVector52);
        org.apache.commons.math3.linear.RealVector realVector56 = arrayRealVector31.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix57 = arrayRealVector7.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realVector56);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray28 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray37 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray37);
        int int39 = org.apache.commons.math3.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = array2DRowRealMatrix20.preMultiply(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector43.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector43.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.append((double) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51);
        try {
            org.apache.commons.math3.linear.RealVector realVector55 = array2DRowRealMatrix20.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 87412023 + "'", int39 == 87412023);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix4.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor6, 0, 120, (int) (short) 10, 87412023);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        try {
            arrayRealVector1.addToEntry((int) ' ', (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector24.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray41 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, doubleArray41);
        boolean boolean44 = arrayRealVector42.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector53.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector48.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray65 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector59, doubleArray65);
        boolean boolean68 = arrayRealVector66.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, arrayRealVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector42.append(arrayRealVector48);
        double[] doubleArray76 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray82 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray88 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray89 = new double[][] { doubleArray82, doubleArray88 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray76, doubleArray89);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, doubleArray76);
        double[] doubleArray94 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray76, (double) '4');
        double double95 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray5, doubleArray76);
        double double96 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 141.43196244130957d + "'", double96 == 141.43196244130957d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.2250738585072014E-308d, 203.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0960954968016E-310d + "'", double2 == 1.0960954968016E-310d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector3.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray20 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, doubleArray20);
        boolean boolean23 = arrayRealVector21.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector3, arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector27.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray44 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, doubleArray44);
        boolean boolean47 = arrayRealVector45.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector21.append(arrayRealVector27);
        double[] doubleArray55 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray61 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray67 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray68 = new double[][] { doubleArray61, doubleArray67 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray55, doubleArray68);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, doubleArray55);
        org.apache.commons.math3.linear.RealVector realVector72 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        java.lang.Throwable throwable79 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError80 = new org.apache.commons.math3.exception.MathInternalError(throwable79);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister82 = new org.apache.commons.math3.random.MersenneTwister((long) 'a');
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator> mathIllegalStateExceptionPair83 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.exception.MathIllegalStateException, org.apache.commons.math3.random.RandomGenerator>((org.apache.commons.math3.exception.MathIllegalStateException) mathInternalError80, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister82);
        float float84 = mersenneTwister82.nextFloat();
        int[] intArray85 = null;
        mersenneTwister82.setSeed(intArray85);
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker88 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double double89 = simpleValueChecker88.getAbsoluteThreshold();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer90 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(0, doubleArray55, 36, 0.0d, true, (int) (short) -1, 4, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister82, true, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker88);
        try {
            double[] doubleArray91 = cMAESOptimizer90.getLowerBound();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertTrue("'" + float84 + "' != '" + 0.52885604f + "'", float84 == 0.52885604f);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.2250738585072014E-306d + "'", double89 == 2.2250738585072014E-306d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        double[][] doubleArray28 = array2DRowRealMatrix20.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix20.scalarMultiply((double) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix20.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (5x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.map(univariateFunction26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15, arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector27.mapDivideToSelf((double) (short) 10);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector27.mapSubtract(Double.NaN);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix73.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix73.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix75.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor77 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double78 = blockRealMatrix75.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor77);
        double double79 = array2DRowRealMatrix44.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor77);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor80 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double85 = array2DRowRealMatrix44.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor80, (int) (byte) 0, (int) (short) 0, 5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (byte) 10, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector14.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray31 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray31);
        boolean boolean34 = arrayRealVector32.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14, arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector43.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector38.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray55 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray55);
        boolean boolean58 = arrayRealVector56.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector32.append(arrayRealVector38);
        org.apache.commons.math3.linear.RealVector realVector62 = arrayRealVector60.mapDivide(Double.NEGATIVE_INFINITY);
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector60.mapAddToSelf((double) 3L);
        try {
            arrayRealVector7.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(realVector64);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double2 = org.apache.commons.math3.util.Precision.round(1.1102230246251565E-16d, 120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100, (double) 10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 0, (long) 120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray18 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector22.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray39 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector33, doubleArray39);
        boolean boolean42 = arrayRealVector40.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, arrayRealVector40);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector19.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector43.mapSubtractToSelf((double) 36);
        org.apache.commons.math3.linear.RealVector realVector48 = arrayRealVector43.mapSubtractToSelf(0.0d);
        double double50 = arrayRealVector43.getEntry(3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, (org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 72.66922287382016d + "'", double50 == 72.66922287382016d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double double4 = blockRealMatrix3.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix3.scalarAdd((-0.8813735870195429d));
        double[][] doubleArray7 = blockRealMatrix3.getData();
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray28 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray37 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray37);
        int int39 = org.apache.commons.math3.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = array2DRowRealMatrix20.preMultiply(doubleArray37);
        int[] intArray42 = new int[] { 97 };
        int[] intArray48 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray55 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double56 = org.apache.commons.math3.util.MathArrays.distance(intArray48, intArray55);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister57 = new org.apache.commons.math3.random.MersenneTwister(intArray48);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix58 = array2DRowRealMatrix20.getSubMatrix(intArray42, intArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 87412023 + "'", int39 == 87412023);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 108.66922287382016d + "'", double56 == 108.66922287382016d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.map(univariateFunction5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray15 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapDivide(1.0d);
        org.apache.commons.math3.linear.RealVector realVector20 = realVector18.mapDivide((-0.9999999999999999d));
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector6.projection(realVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) 10, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double double4 = blockRealMatrix3.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix3.scalarAdd((-0.8813735870195429d));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = blockRealMatrix6.walkInOptimizedOrder(realMatrixChangingVisitor7, 1, 52, (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = array2DRowRealMatrix44.scalarAdd((-1.0d));
        java.lang.String str73 = array2DRowRealMatrix44.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor74 = null;
        try {
            double double75 = array2DRowRealMatrix44.walkInColumnOrder(realMatrixChangingVisitor74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(realMatrix72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}" + "'", str73.equals("Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = array2DRowRealMatrix20.walkInRowOrder(realMatrixChangingVisitor24, 0, 87412023, 97, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (87,412,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        double double45 = array2DRowRealMatrix20.getFrobeniusNorm();
        double[] doubleArray46 = null;
        try {
            double[] doubleArray47 = array2DRowRealMatrix20.preMultiply(doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 141.43196244130957d + "'", double45 == 141.43196244130957d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double37 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor32, 52, (int) ' ', 1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.lang.Class<?> wildcardClass2 = cMAESOptimizer1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32);
        try {
            org.apache.commons.math3.linear.RealVector realVector34 = blockRealMatrix2.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble(141.4319624413096d, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5488135008937807d + "'", double2 == 0.5488135008937807d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray2 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 3, (java.lang.Object[]) doubleArray2);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, (int) (short) 1, 120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 121 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix4.walkInOptimizedOrder(realMatrixChangingVisitor5, (int) (byte) 10, (int) '#', (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math3.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double6 = blockRealMatrix4.walkInColumnOrder(realMatrixPreservingVisitor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.append((double) 10);
        array2DRowRealMatrix20.setRowVector(1, realVector41);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray55 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray61 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray62 = new double[][] { doubleArray55, doubleArray61 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray49, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = array2DRowRealMatrix64.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix20.setColumnMatrix(0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat13 = realMatrixFormat12.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat14 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "hi!", "", "", "hi!", numberFormat13);
        java.lang.String str15 = realMatrixFormat14.getRowSeparator();
        java.lang.String str16 = realMatrixFormat14.getColumnSeparator();
        java.lang.String str17 = realMatrixFormat14.getRowSeparator();
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.map(univariateFunction2);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector1.mapMultiplyToSelf(Double.POSITIVE_INFINITY);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector1.mapDivide((double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 10, (int) '#');
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix4.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (int) (byte) 0, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat7 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat("", "", "", numberFormat7);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat9 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat7);
        java.lang.String str10 = realVectorFormat9.getPrefix();
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        double[] doubleArray28 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray34 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray28, doubleArray41);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray44 = array2DRowRealMatrix20.preMultiply(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix47.transpose();
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor70 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double71 = array2DRowRealMatrix69.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70);
        defaultRealMatrixPreservingVisitor70.visit(3, 6, (double) 0L);
        double double76 = blockRealMatrix47.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70);
        try {
            double double81 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor70, (-1), 0, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '#', 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 0, (int) '#', (int) (byte) -1, (int) (byte) -1);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("Array2DRowRealMatrix{{-1.0},{-1.0},{-1.0},{100.0},{100.0}}", 6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector7.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector20.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector12.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction31 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector28.map(univariateFunction31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, arrayRealVector32);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix34 = arrayRealVector2.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 31.999998f, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.999998092651367d + "'", double2 == 31.999998092651367d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 1.9867717342662448d, objArray1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.map(univariateFunction2);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector1.mapMultiplyToSelf(Double.POSITIVE_INFINITY);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector1.mapSubtractToSelf(31.999998092651367d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector25.map(univariateFunction26);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = arrayRealVector20.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(arrayRealVector27);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker(0.0d, 100.00639823915624d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair4 = null;
        org.apache.commons.math3.optimization.PointValuePair pointValuePair5 = null;
        try {
            boolean boolean6 = simpleValueChecker2.converged((int) 'a', pointValuePair4, pointValuePair5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor0 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double1 = defaultRealMatrixPreservingVisitor0.end();
        defaultRealMatrixPreservingVisitor0.visit((int) (short) -1, 5, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 36);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.7853981633974483d, (double) 36, (double) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) ' ', 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((-0.01532149085696153d), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.01532149085696153d) + "'", double2 == (-0.01532149085696153d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 109.13294644606641d + "'", double11 == 109.13294644606641d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double[] doubleArray9 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray15 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray21 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor25 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double26 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        defaultRealMatrixPreservingVisitor25.visit(3, 6, (double) 0L);
        double double31 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector13.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray30 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24, doubleArray30);
        boolean boolean33 = arrayRealVector31.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector37.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray54 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector48, doubleArray54);
        boolean boolean57 = arrayRealVector55.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector31.append(arrayRealVector37);
        double[] doubleArray65 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray71 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray77 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray78 = new double[][] { doubleArray71, doubleArray77 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray65, doubleArray78);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray65);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray65, (double) '4');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray83);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray83);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition86 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray8, doubleArray83);
        double double88 = eigenDecomposition86.getImagEigenvalue(0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray49 = arrayRealVector20.getDataRef();
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49, 35);
        org.apache.commons.math3.linear.RealVector realVector52 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector52);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 100, (int) (byte) 0, 142.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray1 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.exception.ZeroException zeroException3 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        double[][] doubleArray28 = array2DRowRealMatrix20.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix20.walkInOptimizedOrder(realMatrixChangingVisitor29, 1, (-1), 0, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) 100, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix44.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = array2DRowRealMatrix44.scalarAdd((-1.0d));
        org.apache.commons.math3.linear.RealVector realVector73 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector74 = array2DRowRealMatrix44.operateTranspose(realVector73);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList1 = cMAESOptimizer0.getStatisticsDHistory();
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer0.getStatisticsFitnessHistory();
        int int3 = cMAESOptimizer0.getEvaluations();
        org.junit.Assert.assertNotNull(realMatrixList1);
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 120);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        int[] intArray21 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int22 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray21);
        int[] intArray23 = new int[] {};
        try {
            double double24 = org.apache.commons.math3.util.MathArrays.distance(intArray14, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 120 + "'", int22 == 120);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(97, (int) '#');
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) '#', "org.apache.commons.math3.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister(0);
        double double26 = mersenneTwister25.nextGaussian();
        boolean boolean27 = array2DRowRealMatrix20.equals((java.lang.Object) double26);
        double[][] doubleArray28 = array2DRowRealMatrix20.getData();
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray40 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray46 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray47 = new double[][] { doubleArray40, doubleArray46 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray34, doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor50 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double51 = array2DRowRealMatrix49.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor50);
        defaultRealMatrixPreservingVisitor50.visit(3, 6, (double) 0L);
        double double56 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor50);
        org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20, 4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.7805794640849414d) + "'", double26 == (-0.7805794640849414d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 10);
        java.lang.String str2 = tooManyEvaluationsException1.toString();
        java.lang.Number number3 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math3.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations" + "'", str2.equals("org.apache.commons.math3.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10 + "'", number3.equals(10));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(36, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 0, (int) '#', (int) (byte) -1, (int) (byte) -1);
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        java.lang.Integer[] intArray7 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 2.718281828459045d, objArray1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1.4E-45f, 1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.69135769622964E-70d + "'", double2 == 6.69135769622964E-70d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(31.999998092651367d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3743894528E11d + "'", double2 == 1.3743894528E11d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        double[] doubleArray16 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray22 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray28 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray29 = new double[][] { doubleArray22, doubleArray28 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray16, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector33 = array2DRowRealMatrix31.getRowVector(0);
        org.apache.commons.math3.linear.RealVector realVector35 = array2DRowRealMatrix31.getRowVector(3);
        try {
            double double36 = arrayRealVector7.cosine(realVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.709975946676697d + "'", double1 == 1.709975946676697d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 53 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "hi!", "", "");
        java.text.NumberFormat numberFormat13 = realMatrixFormat12.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat14 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "hi!", "", "", "hi!", numberFormat13);
        java.lang.String str15 = realMatrixFormat14.getRowSeparator();
        java.lang.String str16 = realMatrixFormat14.getColumnSeparator();
        java.lang.String str17 = realMatrixFormat14.getRowSuffix();
        java.lang.String str18 = realMatrixFormat14.getRowPrefix();
        java.lang.String str19 = realMatrixFormat14.getRowPrefix();
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("org.apache.commons.math3.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations", (int) (byte) 1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector22 = array2DRowRealMatrix20.getRowVector(0);
        boolean boolean23 = array2DRowRealMatrix20.isTransposable();
        double[] doubleArray29 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray35 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray41 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray42 = new double[][] { doubleArray35, doubleArray41 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray29, doubleArray42);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix44.getRowVector(0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray58 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray64 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray65 = new double[][] { doubleArray58, doubleArray64 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray52, doubleArray65);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray68 = array2DRowRealMatrix44.preMultiply(doubleArray52);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix44);
        double[] doubleArray79 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray85 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray91 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray92 = new double[][] { doubleArray85, doubleArray91 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray79, doubleArray92);
        try {
            array2DRowRealMatrix20.copySubMatrix((int) (byte) -1, 10, 0, 36, doubleArray92);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix69);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        org.apache.commons.math3.linear.RealVector realVector72 = arrayRealVector70.mapSubtract(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector75.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector80.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector75.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector83.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector83.mapMultiplyToSelf(22025.465794806718d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector83.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector70.append(arrayRealVector83);
        int int90 = arrayRealVector83.getMaxIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(arrayRealVector88);
        org.junit.Assert.assertNotNull(arrayRealVector89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray54);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray12 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray18 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray60 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray66 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray67 = new double[][] { doubleArray60, doubleArray66 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray54, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, doubleArray54);
        org.apache.commons.math3.linear.RealVector realVector72 = arrayRealVector70.mapSubtract(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector77 = arrayRealVector75.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector80.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector75.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector83.append((double) 10);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector83.mapMultiplyToSelf(22025.465794806718d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector83.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector70.append(arrayRealVector83);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor90 = null;
        try {
            double double91 = arrayRealVector83.walkInDefaultOrder(realVectorChangingVisitor90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(arrayRealVector88);
        org.junit.Assert.assertNotNull(arrayRealVector89);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = array2DRowRealMatrix20.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        double[][] doubleArray23 = array2DRowRealMatrix20.getDataRef();
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 1, 36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = blockRealMatrix2.transpose();
        double double4 = blockRealMatrix3.getFrobeniusNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector7.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray24 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray24);
        boolean boolean27 = arrayRealVector25.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector31.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray48 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, doubleArray48);
        boolean boolean51 = arrayRealVector49.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector25.append(arrayRealVector31);
        double[] doubleArray59 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray65 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray71 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray72 = new double[][] { doubleArray65, doubleArray71 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray59, doubleArray72);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, doubleArray59);
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray59);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix3.subtract(realMatrix76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 36x1 but expected 1x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix76);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int[] intArray5 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray12 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray12);
        int[] intArray19 = new int[] { (short) 10, ' ', (short) 0, (byte) -1, ' ' };
        int[] intArray26 = new int[] { (byte) 0, 10, ' ', 100, ' ', 0 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance(intArray19, intArray26);
        int[] intArray28 = org.apache.commons.math3.util.MathArrays.copyOf(intArray19);
        int[] intArray35 = new int[] { (byte) 0, 1, 36, (byte) 10, 0, (byte) 100 };
        int int36 = org.apache.commons.math3.util.MathArrays.distance1(intArray28, intArray35);
        int[] intArray38 = org.apache.commons.math3.util.MathArrays.copyOf(intArray35, (int) (byte) 0);
        try {
            int int39 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 108.66922287382016d + "'", double13 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 108.66922287382016d + "'", double27 == 108.66922287382016d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 120 + "'", int36 == 120);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.NumberFormat numberFormat5 = realVectorFormat4.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "", "", numberFormat5);
        java.lang.String str7 = realVectorFormat6.getSuffix();
        java.text.NumberFormat numberFormat8 = realVectorFormat6.getFormat();
        java.text.ParsePosition parsePosition9 = null;
        try {
            java.lang.Number number10 = org.apache.commons.math3.util.CompositeFormat.parseNumber("org.apache.commons.math3.exception.TooManyEvaluationsException: illegal state: maximal count (10) exceeded: evaluations", numberFormat8, parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[] doubleArray26 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray32 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray38 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray39 = new double[][] { doubleArray32, doubleArray38 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray26, doubleArray39);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = array2DRowRealMatrix41.createMatrix(36, (int) (short) 10);
        array2DRowRealMatrix41.setEntry((int) (byte) 1, 0, 72.66922287382016d);
        double[][] doubleArray49 = array2DRowRealMatrix41.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray58 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector52, doubleArray58);
        int int60 = org.apache.commons.math3.util.MathUtils.hash(doubleArray58);
        double[] doubleArray61 = array2DRowRealMatrix41.preMultiply(doubleArray58);
        double double62 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray5, doubleArray58);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 87412023 + "'", int60 == 87412023);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10855.922287382016d + "'", double62 == 10855.922287382016d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 6, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 1L, 1.0f, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray8 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray29 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray29);
        boolean boolean32 = arrayRealVector30.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, arrayRealVector30);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector9.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        double[] doubleArray40 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray46 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray52 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray53 = new double[][] { doubleArray46, doubleArray52 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray40, doubleArray53);
        double double55 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray40);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40);
        double[] doubleArray62 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray68 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray74 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray75 = new double[][] { doubleArray68, doubleArray74 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray62, doubleArray75);
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray62);
        boolean boolean78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray56, doubleArray62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, arrayRealVector79);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 141.43196244130957d + "'", double55 == 141.43196244130957d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 141.43196244130957d + "'", double77 == 141.43196244130957d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), (-1L), 100.0f, (short) 100 };
        double[] doubleArray11 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[] doubleArray17 = new double[] { 1.0d, 0, (short) -1, (-1L), (short) 0 };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray5, doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = array2DRowRealMatrix20.createMatrix(36, (int) (short) 10);
        boolean boolean24 = array2DRowRealMatrix20.isSquare();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector27.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray44 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector38, doubleArray44);
        boolean boolean47 = arrayRealVector45.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27, arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector51.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray68 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62, doubleArray68);
        boolean boolean71 = arrayRealVector69.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector51, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = arrayRealVector45.append(arrayRealVector51);
        double[] doubleArray74 = arrayRealVector45.getDataRef();
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74, 35);
        double[] doubleArray77 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray74);
        double[] doubleArray78 = array2DRowRealMatrix20.preMultiply(doubleArray77);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(arrayRealVector73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 0, (int) '#', (int) (byte) -1, (int) (byte) -1);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getWrongColumnDimension();
        int int7 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray19 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray19);
        boolean boolean22 = arrayRealVector20.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector26.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        double[] doubleArray43 = new double[] { 0, (byte) 1, 10.0f, 108.66922287382016d, 0.0f };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray43);
        boolean boolean46 = arrayRealVector44.equals((java.lang.Object) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.append(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector58 = arrayRealVector56.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector51.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector64.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector56.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector20.append(arrayRealVector56);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor71 = null;
        try {
            double double72 = arrayRealVector20.walkInDefaultOrder(realVectorPreservingVisitor71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker0 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double double1 = simpleValueChecker0.getAbsoluteThreshold();
        double double2 = simpleValueChecker0.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-306d + "'", double1 == 2.2250738585072014E-306d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-14d + "'", double2 == 1.1102230246251565E-14d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector2.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 1.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector15.mapDivideToSelf((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector7.combine((-0.0d), 0.0d, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction21 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector15.map(univariateFunction21);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }
}

