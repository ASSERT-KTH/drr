import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException(3, (int) ' ');
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable3, objArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException15 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0, "hi!", objArray11);
        java.lang.String str16 = maxEvaluationsExceededException15.toString();
        int int17 = maxEvaluationsExceededException15.getMaxEvaluations();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: hi!" + "'", str16.equals("org.apache.commons.math.MaxEvaluationsExceededException: hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(bigMatrix6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker4 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker4);
        java.lang.Class<?> wildcardClass6 = levenbergMarquardtOptimizer0.getClass();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction7 = null;
        double[] doubleArray9 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector10 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray9);
        double[] doubleArray12 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector13 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray12);
        double[] doubleArray15 = vectorialPointValuePair14.getValueRef();
        java.lang.Throwable throwable16 = null;
        double[] doubleArray20 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable16, doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException27 = new org.apache.commons.math.optimization.OptimizationException(localizable24, objArray26);
        java.lang.Throwable[] throwableArray28 = optimizationException27.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, "org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray28);
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray49 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix56.copy();
        java.lang.String str58 = blockRealMatrix56.toString();
        double[] doubleArray64 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray65 = blockRealMatrix56.preMultiply(doubleArray64);
        java.lang.Object[] objArray73 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException74 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray73);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException("", objArray73);
        org.apache.commons.math.exception.Localizable localizable76 = mathRuntimeException75.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix79 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray87 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException88 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray87);
        org.apache.commons.math.MathRuntimeException mathRuntimeException89 = new org.apache.commons.math.MathRuntimeException("", objArray87);
        java.lang.Object[] objArray90 = new java.lang.Object[] { (short) 1, objArray87 };
        java.util.NoSuchElementException noSuchElementException91 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray90);
        java.io.EOFException eOFException92 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable76, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray95 = new java.lang.Object[] { convergenceException94 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException96 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray95);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException97 = new org.apache.commons.math.FunctionEvaluationException(doubleArray65, localizable76, objArray95);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair98 = levenbergMarquardtOptimizer0.optimize(differentiableMultivariateVectorialFunction7, doubleArray15, doubleArray20, doubleArray65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: dimensions mismatch 1 != 3");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str58.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(arithmeticException74);
        org.junit.Assert.assertNotNull(localizable76);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(arithmeticException88);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(noSuchElementException91);
        org.junit.Assert.assertNotNull(eOFException92);
        org.junit.Assert.assertNotNull(objArray95);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException96);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix25 = array2DRowRealMatrix22.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(100);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix25, (org.apache.commons.math.linear.AnyMatrix) realMatrix27);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.getColumnMatrix((int) (short) 0);
        double[] doubleArray12 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector13 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math.linear.RealVector realVector14 = array2DRowRealMatrix6.preMultiply(realVector13);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarMultiply((double) 52);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, 0);
        java.io.ObjectOutputStream objectOutputStream19 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6, objectOutputStream19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        boolean boolean23 = array2DRowRealMatrix22.isSquare();
        try {
            double double26 = array2DRowRealMatrix22.getEntry(36, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (36, 100) in a 4x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray6 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.Object[] objArray8 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException9 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable11 = mathRuntimeException10.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray22 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException23 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray22);
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException("", objArray22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { (short) 1, objArray22 };
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        java.io.EOFException eOFException27 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable11, objArray25);
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math.exception.Localizable localizable29 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray39);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable31, objArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(throwable28, localizable29, objArray39);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException44 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable11, objArray39);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException(0.0d, localizable11, objArray52);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(arithmeticException9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(arithmeticException23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(eOFException27);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException44);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix30.solve(realMatrix31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double[] doubleArray5 = new double[] { (short) 1 };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, true);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl14 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray52 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[][] doubleArray54 = blockRealMatrix53.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix56 = blockRealMatrix53.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix26.subtract(blockRealMatrix53);
        try {
            blockRealMatrix26.multiplyEntry((int) (byte) 10, 52, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (10, 52) in a 5x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 10);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = blockRealMatrix26.getRowVector(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double43 = blockRealMatrix26.walkInRowOrder(realMatrixChangingVisitor38, 5, (int) (byte) 1, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 5 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Throwable throwable0 = null;
        java.lang.Throwable throwable1 = null;
        double[] doubleArray5 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5);
        java.lang.Object[] objArray16 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException17 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException("", objArray16);
        org.apache.commons.math.exception.Localizable localizable19 = mathRuntimeException18.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray30 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException31 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException("", objArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 1, objArray30 };
        java.util.NoSuchElementException noSuchElementException34 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray33);
        java.io.EOFException eOFException35 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable19, objArray33);
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(4, (int) (byte) 0);
        java.io.EOFException eOFException39 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable19, (java.lang.Object[]) doubleArray38);
        java.lang.Object[] objArray40 = null;
        java.util.ConcurrentModificationException concurrentModificationException41 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable19, objArray40);
        double[] doubleArray44 = new double[] { (short) 1 };
        double[] doubleArray46 = new double[] { (short) 1 };
        double[] doubleArray48 = new double[] { (short) 1 };
        double[][] doubleArray49 = new double[][] { doubleArray44, doubleArray46, doubleArray48 };
        org.apache.commons.math.linear.BigMatrix bigMatrix50 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException52 = new org.apache.commons.math.linear.InvalidMatrixException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray5, localizable19, (java.lang.Object[]) doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(arithmeticException17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(arithmeticException31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(noSuchElementException34);
        org.junit.Assert.assertNotNull(eOFException35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(eOFException39);
        org.junit.Assert.assertNotNull(concurrentModificationException41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(bigMatrix50);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        java.lang.Object[] objArray14 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException("", objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException17);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException17, 100.0d, "", objArray26);
        double[] doubleArray29 = functionEvaluationException28.getArgument();
        double[] doubleArray31 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector32 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector35 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray34);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray34);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray31, true);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException43 = new org.apache.commons.math.optimization.OptimizationException(localizable40, objArray42);
        java.lang.Throwable[] throwableArray44 = optimizationException43.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31, "hi!", (java.lang.Object[]) throwableArray44);
        try {
            double[] doubleArray46 = array2DRowRealMatrix6.preMultiply(doubleArray31);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = blockRealMatrix26.getRowVector(0);
        double double38 = blockRealMatrix26.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor39 = null;
        try {
            double double40 = blockRealMatrix26.walkInOptimizedOrder(realMatrixPreservingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 500.0d + "'", double38 == 500.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix6.getColumnMatrix((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Object[] objArray6 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        double[] doubleArray9 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector10 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray9);
        double[] doubleArray12 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector13 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray12);
        double[] doubleArray15 = vectorialPointValuePair14.getValueRef();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) arithmeticException7, doubleArray15);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 0.0f);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker3 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker3);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) (short) -1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        try {
            blockRealMatrix26.addToEntry((int) (short) 100, (int) ' ', (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, 32) in a 5x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        java.lang.IllegalStateException illegalStateException28 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        int int30 = array2DRowRealMatrix29.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix29.scalarAdd((double) (short) 0);
        org.apache.commons.math.linear.RealVector realVector34 = null;
        try {
            array2DRowRealMatrix29.setRowVector(3, realVector34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String[] strArray4 = new java.lang.String[] { "org.apache.commons.math.FunctionEvaluationException: ", "org.apache.commons.math.FunctionEvaluationException: ", "org.apache.commons.math.FunctionEvaluationException: hi!", "org.apache.commons.math.FunctionEvaluationException: hi!" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Object[] objArray2 = null;
        java.text.ParseException parseException3 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, "org.apache.commons.math.FunctionEvaluationException: ", objArray2);
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException3);
        org.junit.Assert.assertNotNull(parseException3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl31 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(20.29778313018444d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        double double37 = blockRealMatrix26.getFrobeniusNorm();
        double[] doubleArray38 = null;
        try {
            double[] doubleArray39 = blockRealMatrix26.preMultiply(doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 317.02523558858843d + "'", double37 == 317.02523558858843d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray7 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray16);
        java.lang.Object[] objArray25 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException26 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException17, "hi!", objArray25);
        org.apache.commons.math.optimization.OptimizationException optimizationException28 = new org.apache.commons.math.optimization.OptimizationException(localizable10, objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "hi!", objArray25);
        java.io.EOFException eOFException30 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray25);
        java.io.IOException iOException31 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) eOFException30);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(arithmeticException26);
        org.junit.Assert.assertNotNull(eOFException30);
        org.junit.Assert.assertNotNull(iOException31);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer25 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int26 = levenbergMarquardtOptimizer25.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker27 = null;
        levenbergMarquardtOptimizer25.setConvergenceChecker(vectorialConvergenceChecker27);
        double double29 = levenbergMarquardtOptimizer25.getRMS();
        boolean boolean30 = array2DRowRealMatrix22.equals((java.lang.Object) levenbergMarquardtOptimizer25);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray7 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        java.lang.Object[] objArray16 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException17 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException("", objArray16);
        org.apache.commons.math.exception.Localizable localizable19 = mathRuntimeException18.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray30 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException31 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException("", objArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 1, objArray30 };
        java.util.NoSuchElementException noSuchElementException34 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray33);
        java.io.EOFException eOFException35 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable19, objArray33);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray47);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException50 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable39, objArray47);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(throwable36, localizable37, objArray47);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException52 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable19, objArray47);
        java.lang.Object[] objArray61 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray61);
        java.lang.NullPointerException nullPointerException64 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException0, doubleArray7, localizable19, objArray61);
        double[] doubleArray72 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix73 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray72);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair75 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray72, true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(arithmeticException17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(arithmeticException31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(noSuchElementException34);
        org.junit.Assert.assertNotNull(eOFException35);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException52);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(nullPointerException64);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable2, objArray10);
        java.lang.IllegalStateException illegalStateException14 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) illegalStateException14);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(illegalStateException14);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 0.0f);
        double double3 = levenbergMarquardtOptimizer0.getChiSquare();
        int int4 = levenbergMarquardtOptimizer0.getIterations();
        int int5 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1000 + "'", int5 == 1000);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) '#');
        double[] doubleArray7 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray12 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray17 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray22 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray27 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix29.copy();
        java.lang.String str31 = blockRealMatrix29.toString();
        double[] doubleArray37 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray38 = blockRealMatrix29.preMultiply(doubleArray37);
        java.lang.Object[] objArray46 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException47 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray46);
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException("", objArray46);
        org.apache.commons.math.exception.Localizable localizable49 = mathRuntimeException48.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix52 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray60 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException61 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray60);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException("", objArray60);
        java.lang.Object[] objArray63 = new java.lang.Object[] { (short) 1, objArray60 };
        java.util.NoSuchElementException noSuchElementException64 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray63);
        java.io.EOFException eOFException65 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable49, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray68 = new java.lang.Object[] { convergenceException67 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException69 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray68);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38, localizable49, objArray68);
        try {
            double[] doubleArray71 = array2DRowRealMatrix2.operate(doubleArray38);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str31.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(arithmeticException47);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(arithmeticException61);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(noSuchElementException64);
        org.junit.Assert.assertNotNull(eOFException65);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException69);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        double[][] doubleArray25 = array2DRowRealMatrix22.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(5, 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix22.preMultiply(realMatrix28);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.getColumnMatrix((int) (short) 0);
        double[] doubleArray12 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector13 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math.linear.RealVector realVector14 = array2DRowRealMatrix6.preMultiply(realVector13);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarMultiply((double) 52);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, 0);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix6.copy();
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray29 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray45 = new double[][] { doubleArray24, doubleArray29, doubleArray34, doubleArray39, doubleArray44 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix46.copy();
        double double48 = blockRealMatrix47.getNorm();
        double double49 = blockRealMatrix47.getFrobeniusNorm();
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray59 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray64 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray69 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray74 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray75 = new double[][] { doubleArray54, doubleArray59, doubleArray64, doubleArray69, doubleArray74 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray75);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix76.copy();
        java.lang.String str78 = blockRealMatrix76.toString();
        double[] doubleArray84 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray85 = blockRealMatrix76.preMultiply(doubleArray84);
        org.apache.commons.math.linear.RealVector realVector87 = blockRealMatrix76.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix47.subtract(blockRealMatrix76);
        org.apache.commons.math.linear.RealVector realVector90 = blockRealMatrix88.getRowVector((int) (short) 0);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix19, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix88);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(blockRealMatrix47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 500.0d + "'", double48 == 500.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 317.02523558858843d + "'", double49 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str78.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
        org.junit.Assert.assertNotNull(realVector90);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        int int9 = array2DRowRealMatrix6.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix6.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double double68 = blockRealMatrix26.getFrobeniusNorm();
        double[] doubleArray73 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray78 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray83 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray88 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray89 = new double[][] { doubleArray73, doubleArray78, doubleArray83, doubleArray88 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89, false);
        double double92 = array2DRowRealMatrix91.getTrace();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix93 = blockRealMatrix26.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix91);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor94 = null;
        try {
            double double95 = array2DRowRealMatrix91.walkInRowOrder(realMatrixPreservingVisitor94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 317.02523558858843d + "'", double68 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 13.0d + "'", double92 == 13.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix93);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getColumnDimension();
        double[] doubleArray41 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector42 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray41);
        try {
            blockRealMatrix26.setRowVector(0, realVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x3 but expected 1x4");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        int[] intArray3 = lUDecompositionImpl2.getPivot();
        int[] intArray4 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = lUDecompositionImpl2.getP();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = lUDecompositionImpl2.getL();
        int[] intArray7 = lUDecompositionImpl2.getPivot();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray5);
        java.lang.Object[] objArray14 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException6, "hi!", objArray14);
        java.lang.String str17 = functionEvaluationException6.toString();
        java.lang.String str18 = functionEvaluationException6.getPattern();
        double[] doubleArray19 = functionEvaluationException6.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray27 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray27);
        java.lang.Object[] objArray36 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException("", objArray36);
        org.apache.commons.math.exception.Localizable localizable39 = mathRuntimeException38.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix42 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray50 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException51 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray50);
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException("", objArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { (short) 1, objArray50 };
        java.util.NoSuchElementException noSuchElementException54 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray53);
        java.io.EOFException eOFException55 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable39, objArray53);
        java.lang.Throwable throwable56 = null;
        org.apache.commons.math.exception.Localizable localizable57 = null;
        org.apache.commons.math.exception.Localizable localizable59 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray67);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException70 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable59, objArray67);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(throwable56, localizable57, objArray67);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException72 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable39, objArray67);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray81);
        java.lang.NullPointerException nullPointerException84 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException85 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException20, doubleArray27, localizable39, objArray81);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair86 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray27);
        org.apache.commons.math.linear.BigMatrix bigMatrix87 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray27);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(arithmeticException15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: hi!" + "'", str17.equals("org.apache.commons.math.FunctionEvaluationException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(arithmeticException51);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(noSuchElementException54);
        org.junit.Assert.assertNotNull(eOFException55);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException72);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(nullPointerException84);
        org.junit.Assert.assertNotNull(bigMatrix87);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double[] doubleArray29 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray29);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray38);
        java.lang.Object[] objArray47 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException48 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException39, "hi!", objArray47);
        org.apache.commons.math.optimization.OptimizationException optimizationException50 = new org.apache.commons.math.optimization.OptimizationException(localizable32, objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, "hi!", objArray47);
        org.apache.commons.math.linear.BigMatrix bigMatrix52 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray29);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix53);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(arithmeticException48);
        org.junit.Assert.assertNotNull(bigMatrix52);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        double double4 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) '4');
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((-1.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, true);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.scalarMultiply((double) 100L);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 10, (int) (short) 1);
        boolean boolean34 = array2DRowRealMatrix28.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl11 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix10);
        int[] intArray12 = lUDecompositionImpl11.getPivot();
        int[] intArray13 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = lUDecompositionImpl11.getP();
        int[] intArray15 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl18 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix17);
        int[] intArray19 = lUDecompositionImpl18.getPivot();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray27);
        java.lang.Object[] objArray36 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException28, "hi!", objArray36);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray36);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray43 = new java.lang.Object[] { convergenceException42 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException44 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException39, localizable40, objArray43);
        org.apache.commons.math.exception.Localizable localizable46 = matrixIndexException39.getLocalizablePattern();
        double[] doubleArray51 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray56 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray61 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray66 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray67 = new double[][] { doubleArray51, doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67, false);
        double[][] doubleArray70 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException71 = new org.apache.commons.math.linear.MatrixIndexException(localizable46, (java.lang.Object[]) doubleArray67);
        java.util.ConcurrentModificationException concurrentModificationException72 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException$10: ", (java.lang.Object[]) doubleArray67);
        array2DRowRealMatrix7.copySubMatrix(intArray15, intArray19, doubleArray67);
        java.io.ObjectInputStream objectInputStream75 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) intArray15, "", objectInputStream75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException44);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(concurrentModificationException72);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        int int9 = array2DRowRealMatrix6.getRowDimension();
        try {
            array2DRowRealMatrix6.multiplyEntry((int) (short) -1, (int) (short) 1, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 1) in a 3x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        double[] doubleArray21 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector22 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector25 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray24);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray24);
        double[] doubleArray27 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray28 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray29 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray30 = vectorialPointValuePair26.getValue();
        double[] doubleArray31 = vectorialPointValuePair26.getPointRef();
        double[] doubleArray32 = vectorialPointValuePair26.getValueRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32);
        double double34 = array2DRowRealMatrix33.getNorm();
        int int35 = array2DRowRealMatrix33.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix6.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        java.lang.Object[] objArray44 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray44);
        double[] doubleArray47 = functionEvaluationException46.getArgument();
        org.apache.commons.math.linear.RealMatrix realMatrix48 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix33.operate(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.0d + "'", double34 == 52.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray8);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray8);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray18);
        java.lang.Object[] objArray27 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException28 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException19, "hi!", objArray27);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException30 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray27);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray34 = new java.lang.Object[] { convergenceException33 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException35 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException30, localizable31, objArray34);
        org.apache.commons.math.exception.Localizable localizable37 = matrixIndexException30.getLocalizablePattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray44);
        java.lang.Object[] objArray53 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException54 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException45, "hi!", objArray53);
        java.io.EOFException eOFException56 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray53);
        java.lang.ArithmeticException arithmeticException57 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable37, objArray53);
        java.lang.Object[] objArray58 = null;
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException11, localizable37, objArray58);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray67);
        double[] doubleArray70 = functionEvaluationException69.getArgument();
        org.apache.commons.math.linear.RealMatrix realMatrix71 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        org.apache.commons.math.exception.Localizable localizable77 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray85);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray85);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException88 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable77, objArray85);
        maxIterationsExceededException75.addSuppressed((java.lang.Throwable) maxEvaluationsExceededException88);
        java.lang.Object[] objArray90 = maxEvaluationsExceededException88.getArguments();
        java.lang.NullPointerException nullPointerException91 = org.apache.commons.math.MathRuntimeException.createNullPointerException("matrix is singular", objArray90);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalArgumentException11, doubleArray70, "org.apache.commons.math.MathRuntimeException$5: ", objArray90);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(arithmeticException28);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException35);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(arithmeticException54);
        org.junit.Assert.assertNotNull(eOFException56);
        org.junit.Assert.assertNotNull(arithmeticException57);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(nullPointerException91);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException2 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        int int9 = array2DRowRealMatrix6.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl12 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix11);
        int[] intArray13 = lUDecompositionImpl12.getPivot();
        int[] intArray14 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix6.getSubMatrix(intArray13, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 10, 36);
        java.lang.Throwable throwable4 = null;
        double[] doubleArray8 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable4, doubleArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.getColumnMatrix((int) (short) 0);
        double[] doubleArray16 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector17 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray16);
        org.apache.commons.math.linear.RealVector realVector18 = array2DRowRealMatrix10.preMultiply(realVector17);
        try {
            blockRealMatrix2.setColumnVector(4, realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 3x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double[] doubleArray0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray8);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("", objArray8);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray8);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException11);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException11, 100.0d, "", objArray20);
        double[] doubleArray23 = functionEvaluationException22.getArgument();
        double[] doubleArray25 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector26 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray25);
        double[] doubleArray28 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector29 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray28);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray25, doubleArray28);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray25, true);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray25, true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[] doubleArray7 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray17 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        java.lang.Object[] objArray26 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException27 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray26);
        org.apache.commons.math.exception.Localizable localizable29 = mathRuntimeException28.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray40 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException41 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray40);
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException("", objArray40);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) 1, objArray40 };
        java.util.NoSuchElementException noSuchElementException44 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray43);
        java.io.EOFException eOFException45 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable29, objArray43);
        java.lang.Throwable throwable46 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray57);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException60 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable49, objArray57);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(throwable46, localizable47, objArray57);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException62 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable29, objArray57);
        java.lang.Object[] objArray71 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray71);
        java.lang.NullPointerException nullPointerException74 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException10, doubleArray17, localizable29, objArray71);
        double[] doubleArray77 = new double[] { (short) 1 };
        double[] doubleArray79 = new double[] { (short) 1 };
        double[] doubleArray81 = new double[] { (short) 1 };
        double[][] doubleArray82 = new double[][] { doubleArray77, doubleArray79, doubleArray81 };
        org.apache.commons.math.linear.BigMatrix bigMatrix83 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray82);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable29, (java.lang.Object[]) doubleArray82);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix85 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException86 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(bigMatrix9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(arithmeticException27);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(arithmeticException41);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(noSuchElementException44);
        org.junit.Assert.assertNotNull(eOFException45);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException62);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(nullPointerException74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(bigMatrix83);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable1, objArray9);
        int int13 = maxEvaluationsExceededException12.getMaxEvaluations();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray24);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable16, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException12, "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}", objArray24);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        double[][] doubleArray18 = array2DRowRealMatrix6.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver3 = lUDecompositionImpl2.getSolver();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = lUDecompositionImpl2.getU();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = lUDecompositionImpl2.getL();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = lUDecompositionImpl2.getP();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(decompositionSolver3);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double[] doubleArray72 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray77 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray82 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray87 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray92 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray93 = new double[][] { doubleArray72, doubleArray77, doubleArray82, doubleArray87, doubleArray92 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix94 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray93);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix95 = blockRealMatrix94.copy();
        int int96 = blockRealMatrix95.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix97 = blockRealMatrix67.subtract(blockRealMatrix95);
        try {
            org.apache.commons.math.linear.RealVector realVector99 = blockRealMatrix67.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(blockRealMatrix95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 5 + "'", int96 == 5);
        org.junit.Assert.assertNotNull(blockRealMatrix97);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray31 = blockRealMatrix27.getColumn((int) (short) 1);
        double[] doubleArray35 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector36 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray35);
        try {
            org.apache.commons.math.linear.RealVector realVector37 = blockRealMatrix27.preMultiply(realVector36);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = blockRealMatrix26.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix(obj0, "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Object[] objArray7 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException("", objArray7);
        org.apache.commons.math.exception.Localizable localizable10 = mathRuntimeException9.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray21 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException("", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) 1, objArray21 };
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray24);
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable10, objArray24);
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.Localizable localizable28 = null;
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray38);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException41 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable30, objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(throwable27, localizable28, objArray38);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable10, objArray38);
        double[] doubleArray50 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray55 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray60 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray65 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray70 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray71 = new double[][] { doubleArray50, doubleArray55, doubleArray60, doubleArray65, doubleArray70 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix72.copy();
        org.apache.commons.math.linear.RealVector realVector75 = blockRealMatrix73.getColumnVector(0);
        double[][] doubleArray76 = blockRealMatrix73.getData();
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException77 = new org.apache.commons.math.linear.MatrixIndexException("hi!", (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException43, "", (java.lang.Object[]) doubleArray76);
        java.io.IOException iOException79 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) mathException78);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arithmeticException22);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(noSuchElementException25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(iOException79);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray6 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix9.copy();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        double double4 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) '4');
        levenbergMarquardtOptimizer0.setMaxEvaluations(100);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker9 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        java.io.ObjectInputStream objectInputStream11 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) vectorialConvergenceChecker9, "org.apache.commons.math.MaxEvaluationsExceededException: hi!", objectInputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix21);
        int[] intArray23 = lUDecompositionImpl22.getPivot();
        int[] intArray24 = lUDecompositionImpl22.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix25 = lUDecompositionImpl22.getP();
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix25, (org.apache.commons.math.linear.AnyMatrix) realMatrix27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix6.multiply(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException("", objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray7);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException10);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException21 = new org.apache.commons.math.optimization.OptimizationException("", objArray19);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException22);
        optimizationException10.addSuppressed((java.lang.Throwable) optimizationException22);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) optimizationException10);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) optimizationException10);
        java.lang.IllegalArgumentException illegalArgumentException27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) optimizationException10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(illegalArgumentException27);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray31 = blockRealMatrix27.getColumn((int) (short) 1);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix27.createMatrix((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix31 = blockRealMatrix27.scalarMultiply(0.0d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double33 = blockRealMatrix27.walkInRowOrder(realMatrixPreservingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxEvaluations((-1));
        int int3 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double34 = blockRealMatrix26.walkInOptimizedOrder(realMatrixPreservingVisitor29, (int) (short) 0, 1, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray49 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix56.copy();
        java.lang.String str58 = blockRealMatrix56.toString();
        double[] doubleArray64 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray65 = blockRealMatrix56.preMultiply(doubleArray64);
        org.apache.commons.math.linear.RealVector realVector67 = blockRealMatrix56.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix27.subtract(blockRealMatrix56);
        org.apache.commons.math.linear.RealVector realVector70 = blockRealMatrix68.getRowVector((int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix68.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str58.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray15 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        java.lang.Object[] objArray24 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = mathRuntimeException26.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray38 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException39 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray38);
        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException("", objArray38);
        java.lang.Object[] objArray41 = new java.lang.Object[] { (short) 1, objArray38 };
        java.util.NoSuchElementException noSuchElementException42 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray41);
        java.io.EOFException eOFException43 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable27, objArray41);
        java.lang.Throwable throwable44 = null;
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable47 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray55);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable47, objArray55);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(throwable44, localizable45, objArray55);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException60 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable27, objArray55);
        java.lang.Object[] objArray69 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray69);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray69);
        java.lang.NullPointerException nullPointerException72 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray69);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException8, doubleArray15, localizable27, objArray69);
        org.apache.commons.math.exception.Localizable localizable74 = null;
        java.lang.Object[] objArray80 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException81 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray80);
        java.lang.Object[] objArray89 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException90 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray89);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException81, "hi!", objArray89);
        org.apache.commons.math.optimization.OptimizationException optimizationException92 = new org.apache.commons.math.optimization.OptimizationException(localizable74, objArray89);
        java.lang.Object[] objArray93 = optimizationException92.getArguments();
        java.text.ParseException parseException94 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, localizable27, objArray93);
        boolean boolean95 = array2DRowRealMatrix6.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor96 = null;
        try {
            double double97 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixChangingVisitor96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arithmeticException25);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arithmeticException39);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(noSuchElementException42);
        org.junit.Assert.assertNotNull(eOFException43);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException60);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(nullPointerException72);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(arithmeticException90);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(parseException94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray10 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException11 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 1, objArray10 };
        java.util.NoSuchElementException noSuchElementException14 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray27);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException30 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable19, objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(throwable16, localizable17, objArray27);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException34 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        org.apache.commons.math.exception.Localizable localizable35 = nonSquareMatrixException34.getLocalizablePattern();
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException(throwable16, localizable35, objArray36);
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray45);
        java.text.ParseException parseException47 = org.apache.commons.math.MathRuntimeException.createParseException(1, "", objArray45);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException48 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), localizable35, objArray45);
        java.lang.Object[] objArray54 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException14, localizable35, objArray54);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray63);
        java.lang.Object[] objArray72 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException73 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray72);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException64, "hi!", objArray72);
        org.apache.commons.math.optimization.OptimizationException optimizationException75 = new org.apache.commons.math.optimization.OptimizationException(localizable57, objArray72);
        java.lang.Class<?> wildcardClass76 = objArray72.getClass();
        java.lang.NullPointerException nullPointerException77 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable35, objArray72);
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(arithmeticException11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException14);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizable35.equals(org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(parseException47);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(arithmeticException73);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(nullPointerException77);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix27.scalarAdd((double) '4');
        double[] doubleArray37 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray58 = new double[][] { doubleArray37, doubleArray42, doubleArray47, doubleArray52, doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix59.copy();
        java.lang.String str61 = blockRealMatrix59.toString();
        double[] doubleArray67 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray68 = blockRealMatrix59.preMultiply(doubleArray67);
        int int69 = blockRealMatrix59.getColumnDimension();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix32.multiply(blockRealMatrix59);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str61.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 4 + "'", int69 == 4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray5 = new double[] { 10, 100, (short) 1 };
        double[] doubleArray9 = new double[] { 10, 100, (short) 1 };
        double[] doubleArray13 = new double[] { 10, 100, (short) 1 };
        double[] doubleArray17 = new double[] { 10, 100, (short) 1 };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', 0, doubleArray18, false);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(10);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl4 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1, 10.0d);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 100);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException3 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) convergenceException2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector36 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray35);
        java.io.ObjectOutputStream objectOutputStream37 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector36, objectOutputStream37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (byte) 100, (double) 36);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker6);
        int int8 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Object[] objArray9 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException10 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException("", objArray9);
        org.apache.commons.math.exception.Localizable localizable12 = mathRuntimeException11.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException(localizable14, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray16);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable12, objArray16);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray26);
        java.lang.Object[] objArray35 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException36 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException27, "hi!", objArray35);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException38 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray35);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray42 = new java.lang.Object[] { convergenceException41 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException38, localizable39, objArray42);
        java.text.ParseException parseException45 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) -1, localizable12, objArray42);
        java.lang.IllegalArgumentException illegalArgumentException46 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) parseException45);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(arithmeticException10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(arithmeticException36);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
        org.junit.Assert.assertNotNull(parseException45);
        org.junit.Assert.assertNotNull(illegalArgumentException46);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray52 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[][] doubleArray54 = blockRealMatrix53.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix56 = blockRealMatrix53.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix26.subtract(blockRealMatrix53);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix26.getRowMatrix(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix27.scalarAdd((double) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) 3);
        double double35 = blockRealMatrix34.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector37 = null;
        try {
            blockRealMatrix34.setRowVector((int) (short) 0, realVector37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 526.3601428679797d + "'", double35 == 526.3601428679797d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        double double18 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[][] doubleArray19 = array2DRowRealMatrix6.getDataRef();
        int int20 = array2DRowRealMatrix6.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.04987562112089d + "'", double18 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray7);
//        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException("", objArray7);
//        try {
//            java.util.ConcurrentModificationException concurrentModificationException10 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable0, objArray7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(objArray7);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        java.lang.IllegalStateException illegalStateException28 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix29.transpose();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix29, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException28);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray3 = new double[] { (short) 1 };
        double[] doubleArray5 = new double[] { (short) 1 };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(bigMatrix9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix27.scalarAdd((double) '4');
        double[] doubleArray38 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray43 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray48 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray53 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray54 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54, false);
        double[] doubleArray58 = array2DRowRealMatrix56.getColumn(1);
        try {
            blockRealMatrix27.setRowMatrix(4, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 4x4 but expected 1x4");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException("", objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray7);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException10);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException10, 100.0d, "", objArray19);
        double[] doubleArray26 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray47 = new double[][] { doubleArray26, doubleArray31, doubleArray36, doubleArray41, doubleArray46 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix48.copy();
        java.lang.String str50 = blockRealMatrix48.toString();
        double[] doubleArray56 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray57 = blockRealMatrix48.preMultiply(doubleArray56);
        double[] doubleArray64 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray69 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray74 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray79 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray84 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray85 = new double[][] { doubleArray64, doubleArray69, doubleArray74, doubleArray79, doubleArray84 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray85);
        java.lang.IllegalStateException illegalStateException87 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray85);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix88 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException10, doubleArray56, "matrix is singular", (java.lang.Object[]) doubleArray85);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str50.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(illegalStateException87);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl11 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix10);
        int[] intArray12 = lUDecompositionImpl11.getPivot();
        int[] intArray13 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = lUDecompositionImpl11.getP();
        int[] intArray15 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl18 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix17);
        int[] intArray19 = lUDecompositionImpl18.getPivot();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray27);
        java.lang.Object[] objArray36 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException28, "hi!", objArray36);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray36);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray43 = new java.lang.Object[] { convergenceException42 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException44 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException39, localizable40, objArray43);
        org.apache.commons.math.exception.Localizable localizable46 = matrixIndexException39.getLocalizablePattern();
        double[] doubleArray51 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray56 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray61 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray66 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray67 = new double[][] { doubleArray51, doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67, false);
        double[][] doubleArray70 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException71 = new org.apache.commons.math.linear.MatrixIndexException(localizable46, (java.lang.Object[]) doubleArray67);
        java.util.ConcurrentModificationException concurrentModificationException72 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MathRuntimeException$10: ", (java.lang.Object[]) doubleArray67);
        array2DRowRealMatrix7.copySubMatrix(intArray15, intArray19, doubleArray67);
        java.lang.String str74 = array2DRowRealMatrix7.toString();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException44);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(concurrentModificationException72);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Array2DRowRealMatrix{{-1.0},{100.0},{0.0}}" + "'", str74.equals("Array2DRowRealMatrix{{-1.0},{100.0},{0.0}}"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        java.lang.IllegalStateException illegalStateException28 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix29.transpose();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix29.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException28);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        double double4 = levenbergMarquardtOptimizer0.getRMS();
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) levenbergMarquardtOptimizer0, "org.apache.commons.math.FunctionEvaluationException: ", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix26.transpose();
        java.lang.Throwable throwable33 = null;
        double[] doubleArray37 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(throwable33, doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix39.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix39.transpose();
        double[] doubleArray47 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector48 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray47);
        array2DRowRealMatrix39.setColumnVector((int) (byte) 0, realVector48);
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix39.copy();
        double double51 = array2DRowRealMatrix39.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix39.scalarMultiply((-1.0d));
        try {
            array2DRowRealMatrix26.setColumnMatrix(3, realMatrix53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 3 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.04987562112089d + "'", double51 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray49 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix56.copy();
        java.lang.String str58 = blockRealMatrix56.toString();
        double[] doubleArray64 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray65 = blockRealMatrix56.preMultiply(doubleArray64);
        org.apache.commons.math.linear.RealVector realVector67 = blockRealMatrix56.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix27.subtract(blockRealMatrix56);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor69 = null;
        try {
            double double70 = blockRealMatrix27.walkInRowOrder(realMatrixChangingVisitor69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str58.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix(0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix27.scalarAdd((double) '4');
        double[] doubleArray35 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector36 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray35);
        try {
            blockRealMatrix27.setColumnVector((int) '#', realVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray5);
        java.lang.Object[] objArray14 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException6, "hi!", objArray14);
        java.lang.String str17 = functionEvaluationException6.getPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(arithmeticException15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        double[][] doubleArray25 = array2DRowRealMatrix22.getData();
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        double[][] doubleArray25 = array2DRowRealMatrix22.getData();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix22, (int) (byte) -1, (int) (short) 1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        int[] intArray3 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = lUDecompositionImpl2.getL();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, (int) (short) -1, 0, 4, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        double double25 = array2DRowRealMatrix22.getFrobeniusNorm();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl27 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22, 13.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 20.29778313018444d + "'", double25 == 20.29778313018444d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray13);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException16 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable5, objArray13);
        maxIterationsExceededException3.addSuppressed((java.lang.Throwable) maxEvaluationsExceededException16);
        java.lang.Object[] objArray18 = maxEvaluationsExceededException16.getArguments();
        java.lang.NullPointerException nullPointerException19 = org.apache.commons.math.MathRuntimeException.createNullPointerException("matrix is singular", objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}", objArray18);
        java.lang.Class<?> wildcardClass21 = matrixIndexException20.getClass();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(nullPointerException19);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[][] doubleArray27 = blockRealMatrix26.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix26.scalarAdd(1.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = blockRealMatrix26.scalarMultiply(0.0d);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix26.walkInOptimizedOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (byte) 0);
        double[] doubleArray23 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray28 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray33 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray38 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray43 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray44 = new double[][] { doubleArray23, doubleArray28, doubleArray33, doubleArray38, doubleArray43 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray44);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44, true);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix47.scalarMultiply((double) 100L);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = array2DRowRealMatrix6.multiply(array2DRowRealMatrix47);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix27.scalarAdd((double) '4');
        double double33 = blockRealMatrix27.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 317.02523558858843d + "'", double33 == 317.02523558858843d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.getColumnMatrix((int) (short) 0);
        double[] doubleArray12 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector13 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math.linear.RealVector realVector14 = array2DRowRealMatrix6.preMultiply(realVector13);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarMultiply((double) 52);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, 0);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        org.apache.commons.math.linear.RealMatrix realMatrix3 = lUDecompositionImpl2.getU();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = lUDecompositionImpl2.getP();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver5 = lUDecompositionImpl2.getSolver();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertNotNull(decompositionSolver5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        double[][] doubleArray29 = null;
        try {
            array2DRowRealMatrix22.copySubMatrix(0, (int) (short) 1, (int) '#', (int) (byte) 100, doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException(10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix25 = array2DRowRealMatrix22.copy();
        double[][] doubleArray26 = array2DRowRealMatrix22.getData();
        double[] doubleArray28 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector29 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray28);
        org.apache.commons.math.linear.BigMatrix bigMatrix30 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray28);
        try {
            double[] doubleArray31 = array2DRowRealMatrix22.operate(doubleArray28);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(bigMatrix30);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix6.createMatrix(3, 3);
        org.apache.commons.math.linear.AnyMatrix anyMatrix13 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix12, anyMatrix13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray35.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix6.createMatrix(3, 3);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix6.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[][] doubleArray27 = blockRealMatrix26.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix26.scalarAdd(1.0d);
        double double30 = blockRealMatrix26.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix26.createMatrix((int) (short) 10, (int) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix35 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl36 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix35);
        int[] intArray37 = lUDecompositionImpl36.getPivot();
        int[] intArray38 = lUDecompositionImpl36.getPivot();
        int[] intArray39 = lUDecompositionImpl36.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix41 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl42 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix41);
        int[] intArray43 = lUDecompositionImpl42.getPivot();
        int[] intArray44 = lUDecompositionImpl42.getPivot();
        int[] intArray45 = lUDecompositionImpl42.getPivot();
        org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix33, intArray39, intArray45);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 500.0d + "'", double30 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, true);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix28.scalarMultiply((double) 100L);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor31 = null;
        try {
            double double32 = array2DRowRealMatrix28.walkInColumnOrder(realMatrixChangingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix26.scalarAdd(52.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        try {
            boolean boolean36 = blockRealMatrix26.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 5x4 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.scalarAdd((double) 1000);
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray56 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray57 = new double[][] { doubleArray36, doubleArray41, doubleArray46, doubleArray51, doubleArray56 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray57);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix58.copy();
        int int60 = blockRealMatrix59.getRowDimension();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix27.multiply(blockRealMatrix59);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) '#');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.Object[] objArray9 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException10 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException("", objArray9);
        org.apache.commons.math.exception.Localizable localizable12 = mathRuntimeException11.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException(localizable14, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray16);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable12, objArray16);
        java.lang.Object[] objArray28 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException29 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray28);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException("", objArray28);
        org.apache.commons.math.exception.Localizable localizable31 = mathRuntimeException30.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException36 = new org.apache.commons.math.optimization.OptimizationException(localizable33, objArray35);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException37 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray35);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException38 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable31, objArray35);
        double[] doubleArray40 = new double[] { (short) 1 };
        double[] doubleArray42 = new double[] { (short) 1 };
        double[] doubleArray44 = new double[] { (short) 1 };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray42, doubleArray44 };
        org.apache.commons.math.linear.BigMatrix bigMatrix46 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException19, localizable31, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray52 = new java.lang.Object[] { convergenceException51 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException53 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray52);
        java.util.NoSuchElementException noSuchElementException54 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.FunctionEvaluationException: ", objArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((double) 0, localizable31, objArray52);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(arithmeticException10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(arithmeticException29);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(bigMatrix46);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException53);
        org.junit.Assert.assertNotNull(noSuchElementException54);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray52 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[][] doubleArray54 = blockRealMatrix53.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix56 = blockRealMatrix53.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix26.subtract(blockRealMatrix53);
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray67 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray72 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray77 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray82 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray83 = new double[][] { doubleArray62, doubleArray67, doubleArray72, doubleArray77, doubleArray82 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray83);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix84.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix53.add(blockRealMatrix84);
        org.apache.commons.math.linear.RealMatrix realMatrix87 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix84.add(realMatrix87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor37 = null;
        try {
            double double38 = blockRealMatrix26.walkInRowOrder(realMatrixPreservingVisitor37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[][] doubleArray27 = blockRealMatrix26.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix26.scalarAdd(1.0d);
        double double30 = blockRealMatrix26.getNorm();
        try {
            blockRealMatrix26.addToEntry((int) (byte) -1, 100, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 100) in a 5x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 500.0d + "'", double30 == 500.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix26.transpose();
        double[][] doubleArray32 = array2DRowRealMatrix26.getData();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        double double18 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[][] doubleArray19 = array2DRowRealMatrix6.getDataRef();
        try {
            array2DRowRealMatrix6.addToEntry((int) 'a', 5, 317.02523558858843d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, 5) in a 3x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.04987562112089d + "'", double18 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray49 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix56.copy();
        java.lang.String str58 = blockRealMatrix56.toString();
        double[] doubleArray64 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray65 = blockRealMatrix56.preMultiply(doubleArray64);
        org.apache.commons.math.linear.RealVector realVector67 = blockRealMatrix56.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix27.subtract(blockRealMatrix56);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix68, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str58.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        int int28 = blockRealMatrix27.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray7);
        java.lang.Object[] objArray16 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException17 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException8, "hi!", objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray16);
        double[] doubleArray20 = null;
        try {
            org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException19, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(arithmeticException17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray52 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[][] doubleArray54 = blockRealMatrix53.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix56 = blockRealMatrix53.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix26.subtract(blockRealMatrix53);
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray67 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray72 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray77 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray82 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray83 = new double[][] { doubleArray62, doubleArray67, doubleArray72, doubleArray77, doubleArray82 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray83);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix84.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix53.add(blockRealMatrix84);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix87 = blockRealMatrix86.copy();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(blockRealMatrix87);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        java.lang.Throwable throwable30 = null;
        double[] doubleArray34 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(throwable30, doubleArray34);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix39 = array2DRowRealMatrix36.transpose();
        double[] doubleArray44 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector45 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray44);
        array2DRowRealMatrix36.setColumnVector((int) (byte) 0, realVector45);
        org.apache.commons.math.linear.RealMatrix realMatrix47 = array2DRowRealMatrix36.copy();
        int int48 = array2DRowRealMatrix36.getRowDimension();
        java.lang.Throwable throwable50 = null;
        double[] doubleArray54 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException(throwable50, doubleArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix56.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix56.transpose();
        double[] doubleArray64 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector65 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray64);
        array2DRowRealMatrix56.setColumnVector((int) (byte) 0, realVector65);
        array2DRowRealMatrix36.setColumnVector(0, realVector65);
        try {
            org.apache.commons.math.linear.RealVector realVector68 = blockRealMatrix27.preMultiply(realVector65);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 3 + "'", int48 == 3);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.Throwable throwable1 = null;
        double[] doubleArray5 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException(localizable9, objArray11);
        java.lang.Throwable[] throwableArray13 = optimizationException12.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException15 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray13);
        double[] doubleArray17 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector18 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray20 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector21 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray20);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray20);
        double[] doubleArray23 = vectorialPointValuePair22.getValueRef();
        double[] doubleArray24 = vectorialPointValuePair22.getValueRef();
        double[] doubleArray25 = vectorialPointValuePair22.getValueRef();
        double[] doubleArray26 = vectorialPointValuePair22.getValue();
        double[] doubleArray27 = vectorialPointValuePair22.getValueRef();
        double[] doubleArray28 = vectorialPointValuePair22.getPoint();
        double[] doubleArray29 = vectorialPointValuePair22.getPoint();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray38 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix39 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray38);
        java.lang.Object[] objArray47 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException48 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray47);
        org.apache.commons.math.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.MathRuntimeException("", objArray47);
        org.apache.commons.math.exception.Localizable localizable50 = mathRuntimeException49.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix53 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray61 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException62 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray61);
        org.apache.commons.math.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.MathRuntimeException("", objArray61);
        java.lang.Object[] objArray64 = new java.lang.Object[] { (short) 1, objArray61 };
        java.util.NoSuchElementException noSuchElementException65 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray64);
        java.io.EOFException eOFException66 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable50, objArray64);
        java.lang.Throwable throwable67 = null;
        org.apache.commons.math.exception.Localizable localizable68 = null;
        org.apache.commons.math.exception.Localizable localizable70 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray78);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray78);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException81 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable70, objArray78);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException(throwable67, localizable68, objArray78);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException83 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable50, objArray78);
        java.lang.Object[] objArray92 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException93 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray92);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException94 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray92);
        java.lang.NullPointerException nullPointerException95 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray92);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException96 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException31, doubleArray38, localizable50, objArray92);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException97 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) arrayIndexOutOfBoundsException15, doubleArray29, "org.apache.commons.math.MathRuntimeException$5: ", objArray92);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(arithmeticException48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(arithmeticException62);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(noSuchElementException65);
        org.junit.Assert.assertNotNull(eOFException66);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException83);
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertNotNull(nullPointerException95);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (short) 1, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray2 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, true);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray7);
        java.lang.IllegalStateException illegalStateException13 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray7);
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable14);
        org.apache.commons.math.exception.Localizable localizable16 = convergenceException15.getLocalizablePattern();
        double[] doubleArray21 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray26 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray42 = new double[][] { doubleArray21, doubleArray26, doubleArray31, doubleArray36, doubleArray41 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray42);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = blockRealMatrix43.copy();
        org.apache.commons.math.linear.RealVector realVector46 = blockRealMatrix44.getColumnVector(0);
        double[][] doubleArray47 = blockRealMatrix44.getData();
        org.apache.commons.math.linear.BigMatrix bigMatrix48 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) illegalStateException13, localizable16, (java.lang.Object[]) doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(illegalStateException13);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(blockRealMatrix44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(bigMatrix48);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double double68 = blockRealMatrix65.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix65.createMatrix(5, (int) 'a');
        double[] doubleArray73 = blockRealMatrix65.getColumn(0);
        org.apache.commons.math.linear.RealMatrix realMatrix75 = blockRealMatrix65.getRowMatrix((int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 317.02523558858843d + "'", double68 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix75);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray8 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray9 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray10 = vectorialPointValuePair6.getValue();
        double[] doubleArray11 = vectorialPointValuePair6.getPointRef();
        double[] doubleArray12 = vectorialPointValuePair6.getValueRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        java.lang.Object[] objArray10 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
//        java.lang.ArithmeticException arithmeticException11 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray10);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("", objArray10);
//        org.apache.commons.math.exception.Localizable localizable13 = mathRuntimeException12.getLocalizablePattern();
//        org.apache.commons.math.exception.Localizable localizable15 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0f };
//        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException(localizable15, objArray17);
//        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray17);
//        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException20 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable13, objArray17);
//        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray27);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
//        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray36);
//        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException28, "hi!", objArray36);
//        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray36);
//        org.apache.commons.math.exception.Localizable localizable40 = null;
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
//        java.lang.Object[] objArray43 = new java.lang.Object[] { convergenceException42 };
//        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException44 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray43);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException39, localizable40, objArray43);
//        java.text.ParseException parseException46 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) -1, localizable13, objArray43);
//        try {
//            java.util.NoSuchElementException noSuchElementException47 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable0, objArray43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(arithmeticException11);
//        org.junit.Assert.assertNotNull(localizable13);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertNotNull(arithmeticException37);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException44);
//        org.junit.Assert.assertNotNull(parseException46);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray8 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray9 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray10 = vectorialPointValuePair6.getValue();
        double[] doubleArray11 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray12 = vectorialPointValuePair6.getPoint();
        double[] doubleArray13 = vectorialPointValuePair6.getPoint();
        double[] doubleArray14 = vectorialPointValuePair6.getValue();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor68 = null;
        try {
            double double73 = blockRealMatrix65.walkInRowOrder(realMatrixChangingVisitor68, (int) 'a', 2147483647, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        java.lang.IllegalStateException illegalStateException28 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix29.inverse();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 5x4 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException28);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix26.transpose();
        try {
            array2DRowRealMatrix26.multiplyEntry((int) (byte) -1, 10, 317.02523558858843d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 10) in a 3x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray8);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("", objArray8);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("maximal number of iterations ({0}) exceeded", objArray8);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException("", objArray7);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray7);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException10);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException10, 100.0d, "", objArray19);
        double[] doubleArray22 = functionEvaluationException21.getArgument();
        org.apache.commons.math.linear.RealMatrix realMatrix23 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray22);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxEvaluations((-1));
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 0);
        int int5 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setMaxIterations(0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix22.copy();
        int int25 = array2DRowRealMatrix22.getRowDimension();
        boolean boolean26 = array2DRowRealMatrix22.isSingular();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        double[][] doubleArray28 = blockRealMatrix27.getData();
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        java.lang.IllegalArgumentException illegalArgumentException31 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(illegalArgumentException31);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (short) 0);
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray13 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray18 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray23 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray28 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray29 = new double[][] { doubleArray13, doubleArray18, doubleArray23, doubleArray28 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        double double32 = array2DRowRealMatrix31.getTrace();
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix31.copy();
        org.apache.commons.math.linear.RealVector realVector35 = array2DRowRealMatrix31.getColumnVector(0);
        try {
            array2DRowRealMatrix7.setRowVector(4, realVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 4 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 13.0d + "'", double32 == 13.0d);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray5);
        java.lang.Object[] objArray14 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException6, "hi!", objArray14);
        java.lang.String str17 = functionEvaluationException6.toString();
        java.lang.String str18 = functionEvaluationException6.getPattern();
        double[] doubleArray19 = functionEvaluationException6.getArgument();
        java.lang.RuntimeException runtimeException20 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) functionEvaluationException6);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray32);
        java.lang.NullPointerException nullPointerException35 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray32);
        java.io.EOFException eOFException36 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) runtimeException20, (double) ' ', "hi!", objArray32);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(arithmeticException15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: hi!" + "'", str17.equals("org.apache.commons.math.FunctionEvaluationException: hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(runtimeException20);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(nullPointerException35);
        org.junit.Assert.assertNotNull(eOFException36);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double double68 = blockRealMatrix65.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix65.createMatrix(5, (int) 'a');
        org.apache.commons.math.linear.RealMatrix realMatrix73 = blockRealMatrix65.scalarMultiply((double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 317.02523558858843d + "'", double68 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 100.0f);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        java.lang.IllegalStateException illegalStateException28 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException28);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        try {
            org.apache.commons.math.linear.RealVector realVector32 = blockRealMatrix27.getColumnVector((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException5 = new org.apache.commons.math.optimization.OptimizationException(localizable2, objArray4);
        java.lang.Throwable[] throwableArray6 = optimizationException5.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException("hi!", (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException8 = new org.apache.commons.math.linear.InvalidMatrixException("Array2DRowRealMatrix{{-1.0},{100.0},{0.0}}", (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray7 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray7);
        java.lang.Object[] objArray16 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException17 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException("", objArray16);
        org.apache.commons.math.exception.Localizable localizable19 = mathRuntimeException18.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray30 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException31 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException("", objArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 1, objArray30 };
        java.util.NoSuchElementException noSuchElementException34 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray33);
        java.io.EOFException eOFException35 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable19, objArray33);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.exception.Localizable localizable39 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray47);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException50 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable39, objArray47);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(throwable36, localizable37, objArray47);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException52 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable19, objArray47);
        java.lang.Object[] objArray61 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray61);
        java.lang.NullPointerException nullPointerException64 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException0, doubleArray7, localizable19, objArray61);
        double[] doubleArray70 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray75 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray80 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray85 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray90 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray91 = new double[][] { doubleArray70, doubleArray75, doubleArray80, doubleArray85, doubleArray90 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix92 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray91);
        org.apache.commons.math.MathRuntimeException mathRuntimeException93 = new org.apache.commons.math.MathRuntimeException(localizable19, (java.lang.Object[]) doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(arithmeticException17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(arithmeticException31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(noSuchElementException34);
        org.junit.Assert.assertNotNull(eOFException35);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException52);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(nullPointerException64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Throwable throwable1 = null;
        double[] doubleArray5 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException(localizable9, objArray11);
        java.lang.Throwable[] throwableArray13 = optimizationException12.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException15 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) arrayIndexOutOfBoundsException15);
        double[] doubleArray22 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray27 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray32 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray37 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray38 = new double[][] { doubleArray22, doubleArray27, doubleArray32, doubleArray37 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38, false);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException15, "org.apache.commons.math.MathRuntimeException$10: ", (java.lang.Object[]) doubleArray38);
        java.lang.RuntimeException runtimeException42 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(runtimeException42);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.linear.RealMatrix realMatrix3 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray11 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException12 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException("", objArray11);
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 1, objArray11 };
        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray14);
        java.lang.Throwable throwable17 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray28);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException31 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable20, objArray28);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(throwable17, localizable18, objArray28);
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException35 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        org.apache.commons.math.exception.Localizable localizable36 = nonSquareMatrixException35.getLocalizablePattern();
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException(throwable17, localizable36, objArray37);
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray46);
        java.text.ParseException parseException48 = org.apache.commons.math.MathRuntimeException.createParseException(1, "", objArray46);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException49 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), localizable36, objArray46);
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) noSuchElementException15, localizable36, objArray55);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException58 = new org.apache.commons.math.linear.InvalidMatrixException("a {0}x{1} matrix was provided instead of a square matrix", objArray55);
        org.junit.Assert.assertNotNull(realMatrix3);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arithmeticException12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(noSuchElementException15);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizable36.equals(org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(parseException48);
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = blockRealMatrix26.getRowVector(0);
        double[] doubleArray43 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray48 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray53 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray58 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray63 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray64 = new double[][] { doubleArray43, doubleArray48, doubleArray53, doubleArray58, doubleArray63 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray64);
        java.lang.IllegalStateException illegalStateException66 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray64);
        int int68 = array2DRowRealMatrix67.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix70 = array2DRowRealMatrix67.scalarAdd((double) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix26.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix67);
        java.lang.Throwable throwable72 = null;
        double[] doubleArray76 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException(throwable72, doubleArray76);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math.linear.RealMatrix realMatrix80 = array2DRowRealMatrix78.getColumnMatrix((int) (short) 0);
        double[] doubleArray84 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector85 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray84);
        org.apache.commons.math.linear.RealVector realVector86 = array2DRowRealMatrix78.preMultiply(realVector85);
        try {
            org.apache.commons.math.linear.RealVector realVector87 = blockRealMatrix71.operate(realVector85);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(illegalStateException66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(realVector86);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        int[] intArray3 = lUDecompositionImpl2.getPivot();
        int[] intArray4 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = lUDecompositionImpl2.getP();
        int[] intArray6 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = lUDecompositionImpl2.getP();
        int[] intArray8 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = lUDecompositionImpl2.getU();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double[] doubleArray7 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray12 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray17 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray22 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray27 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray28 = new double[][] { doubleArray7, doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix29.copy();
        org.apache.commons.math.linear.RealVector realVector32 = blockRealMatrix30.getColumnVector(0);
        double[][] doubleArray33 = blockRealMatrix30.getData();
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException34 = new org.apache.commons.math.linear.MatrixIndexException("hi!", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Object[] objArray8 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException9 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException("", objArray8);
        org.apache.commons.math.exception.Localizable localizable11 = mathRuntimeException10.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException(localizable13, objArray15);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray15);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable11, objArray15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable11, objArray19);
        java.lang.Object[] objArray27 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException28 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray27);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException29 = new org.apache.commons.math.linear.MatrixIndexException(localizable11, objArray27);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(arithmeticException9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(arithmeticException28);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException15 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable4, objArray12);
        maxIterationsExceededException2.addSuppressed((java.lang.Throwable) maxEvaluationsExceededException15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException15);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray25);
        java.lang.Object[] objArray34 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException35 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException26, "hi!", objArray34);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException37 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray34);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException17, "org.apache.commons.math.FunctionEvaluationException: hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(arithmeticException35);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        int int3 = levenbergMarquardtOptimizer0.getEvaluations();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker4 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setMaxIterations((int) ' ');
        double double8 = levenbergMarquardtOptimizer0.getRMS();
        try {
            double[] doubleArray9 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray7);
        java.lang.Object[] objArray16 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException17 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException8, "hi!", objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray16);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = new java.lang.Object[] { convergenceException22 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException24 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray23);
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException19, localizable20, objArray23);
        org.apache.commons.math.exception.Localizable localizable26 = matrixIndexException19.getLocalizablePattern();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray33);
        java.lang.Object[] objArray42 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException43 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException34, "hi!", objArray42);
        java.io.EOFException eOFException45 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray42);
        java.lang.ArithmeticException arithmeticException46 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable26, objArray42);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException47 = new org.apache.commons.math.linear.MatrixIndexException("a {0}x{1} matrix was provided instead of a square matrix", objArray42);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(arithmeticException17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException24);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(arithmeticException43);
        org.junit.Assert.assertNotNull(eOFException45);
        org.junit.Assert.assertNotNull(arithmeticException46);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double[] doubleArray6 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean10 = array2DRowRealMatrix9.isSquare();
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray30 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray35 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray36 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix37.copy();
        java.lang.String str39 = blockRealMatrix37.toString();
        double[] doubleArray45 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray46 = blockRealMatrix37.preMultiply(doubleArray45);
        int int47 = blockRealMatrix37.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix48 = array2DRowRealMatrix9.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix37);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(blockRealMatrix38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str39.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray49 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix56.copy();
        java.lang.String str58 = blockRealMatrix56.toString();
        double[] doubleArray64 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray65 = blockRealMatrix56.preMultiply(doubleArray64);
        org.apache.commons.math.linear.RealVector realVector67 = blockRealMatrix56.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix27.subtract(blockRealMatrix56);
        org.apache.commons.math.linear.RealMatrix realMatrix70 = blockRealMatrix56.scalarMultiply(0.0d);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor71 = null;
        try {
            double double72 = blockRealMatrix56.walkInOptimizedOrder(realMatrixChangingVisitor71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str58.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
        org.junit.Assert.assertNotNull(realMatrix70);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray8 = new double[] { 1, 10.0f, 100.0f, 0, 100.0d, 100.0d };
        double[] doubleArray15 = new double[] { 1, 10.0f, 100.0f, 0, 100.0d, 100.0d };
        double[] doubleArray22 = new double[] { 1, 10.0f, 100.0f, 0, 100.0d, 100.0d };
        double[][] doubleArray23 = new double[][] { doubleArray8, doubleArray15, doubleArray22 };
        org.apache.commons.math.linear.RealMatrix realMatrix24 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray23);
        java.util.ConcurrentModificationException concurrentModificationException25 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray23);
        java.lang.IllegalStateException illegalStateException26 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(concurrentModificationException25);
        org.junit.Assert.assertNotNull(illegalStateException26);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        int int18 = array2DRowRealMatrix6.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        double double37 = blockRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor38 = null;
        try {
            double double43 = blockRealMatrix26.walkInColumnOrder(realMatrixChangingVisitor38, (int) (byte) 10, 0, (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 317.02523558858843d + "'", double37 == 317.02523558858843d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray52 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[][] doubleArray54 = blockRealMatrix53.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix56 = blockRealMatrix53.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix26.subtract(blockRealMatrix53);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix26.getSubMatrix((int) '#', (int) (byte) 1, 1000, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        double double24 = array2DRowRealMatrix22.getDeterminant();
        double[][] doubleArray25 = array2DRowRealMatrix22.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor26 = null;
        try {
            double double31 = array2DRowRealMatrix22.walkInRowOrder(realMatrixPreservingVisitor26, 2147483647, (int) (short) -1, (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(1000, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (byte) 100, (double) 36);
        double[] doubleArray5 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector6 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray8 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector9 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray8);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray8);
        double[] doubleArray11 = vectorialPointValuePair10.getValueRef();
        double[] doubleArray13 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector14 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray13);
        double[] doubleArray16 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector17 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray16);
        double[] doubleArray19 = vectorialPointValuePair18.getValueRef();
        double[] doubleArray20 = vectorialPointValuePair18.getValueRef();
        double[] doubleArray21 = vectorialPointValuePair18.getValueRef();
        double[] doubleArray22 = vectorialPointValuePair18.getValue();
        double[] doubleArray23 = vectorialPointValuePair18.getPointRef();
        double[] doubleArray24 = vectorialPointValuePair18.getValueRef();
        boolean boolean25 = simpleVectorialValueChecker2.converged(1, vectorialPointValuePair10, vectorialPointValuePair18);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair27 = null;
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker30 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (byte) 100, (double) 36);
        double[] doubleArray33 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector34 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray33);
        double[] doubleArray36 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector37 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray36);
        double[] doubleArray39 = vectorialPointValuePair38.getValueRef();
        double[] doubleArray41 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector42 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray41);
        double[] doubleArray44 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector45 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray41, doubleArray44);
        double[] doubleArray47 = vectorialPointValuePair46.getValueRef();
        double[] doubleArray48 = vectorialPointValuePair46.getValueRef();
        double[] doubleArray49 = vectorialPointValuePair46.getValueRef();
        double[] doubleArray50 = vectorialPointValuePair46.getValue();
        double[] doubleArray51 = vectorialPointValuePair46.getPointRef();
        double[] doubleArray52 = vectorialPointValuePair46.getValueRef();
        boolean boolean53 = simpleVectorialValueChecker30.converged(1, vectorialPointValuePair38, vectorialPointValuePair46);
        try {
            boolean boolean54 = simpleVectorialValueChecker2.converged((int) (short) 0, vectorialPointValuePair27, vectorialPointValuePair46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(13.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        org.apache.commons.math.linear.RealVector realVector7 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        java.lang.Object[] objArray15 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException("", objArray15);
        org.apache.commons.math.exception.Localizable localizable18 = mathRuntimeException17.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray29 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException30 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException("", objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 1, objArray29 };
        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray32);
        java.io.EOFException eOFException34 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable18, objArray32);
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray46);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException49 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable38, objArray46);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(throwable35, localizable36, objArray46);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException51 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable18, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray55 = new java.lang.Object[] { convergenceException54 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException56 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray55);
        java.util.NoSuchElementException noSuchElementException57 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.FunctionEvaluationException: ", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable18, objArray55);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException(localizable18, objArray59);
        java.lang.Throwable throwable61 = null;
        org.apache.commons.math.exception.Localizable localizable62 = null;
        org.apache.commons.math.exception.Localizable localizable64 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray72);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException75 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable64, objArray72);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(throwable61, localizable62, objArray72);
        java.lang.ArithmeticException arithmeticException77 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable18, objArray72);
        org.apache.commons.math.optimization.OptimizationException optimizationException78 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) arithmeticException77);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arithmeticException16);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(arithmeticException30);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(noSuchElementException33);
        org.junit.Assert.assertNotNull(eOFException34);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException51);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException56);
        org.junit.Assert.assertNotNull(noSuchElementException57);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(arithmeticException77);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        double double18 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix6.copy();
        try {
            array2DRowRealMatrix6.multiplyEntry((int) (byte) -1, (int) (short) 100, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 100) in a 3x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.04987562112089d + "'", double18 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 100);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) (-1.0f));
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker8 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        levenbergMarquardtOptimizer0.setOrthoTolerance(13.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double[] doubleArray6 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix7, 1000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1,000 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = blockRealMatrix26.scalarMultiply((double) 1.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix26.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray34 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray39 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray44 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray49 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray54 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray55 = new double[][] { doubleArray34, doubleArray39, doubleArray44, doubleArray49, doubleArray54 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix56.copy();
        java.lang.String str58 = blockRealMatrix56.toString();
        double[] doubleArray64 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray65 = blockRealMatrix56.preMultiply(doubleArray64);
        org.apache.commons.math.linear.RealVector realVector67 = blockRealMatrix56.getRowVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix27.subtract(blockRealMatrix56);
        org.apache.commons.math.linear.RealVector realVector70 = null;
        try {
            blockRealMatrix56.setRowVector((-1), realVector70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str58.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Object[] objArray11 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException12 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException("", objArray11);
        org.apache.commons.math.exception.Localizable localizable14 = mathRuntimeException13.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException19 = new org.apache.commons.math.optimization.OptimizationException(localizable16, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray18);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable14, objArray18);
        java.text.ParseException parseException22 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', "org.apache.commons.math.FunctionEvaluationException: hi!", objArray18);
        java.lang.IllegalStateException illegalStateException23 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray18);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arithmeticException12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(parseException22);
        org.junit.Assert.assertNotNull(illegalStateException23);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Throwable throwable1 = null;
        double[] doubleArray5 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException(localizable9, objArray11);
        java.lang.Throwable[] throwableArray13 = optimizationException12.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray24 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = mathRuntimeException26.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException32 = new org.apache.commons.math.optimization.OptimizationException(localizable29, objArray31);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException33 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray31);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException34 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray41);
        java.lang.Object[] objArray50 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException51 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException42, "hi!", objArray50);
        org.apache.commons.math.optimization.OptimizationException optimizationException53 = new org.apache.commons.math.optimization.OptimizationException(localizable35, objArray50);
        java.lang.Object[] objArray54 = optimizationException53.getArguments();
        java.text.ParseException parseException55 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', localizable27, objArray54);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray65);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException68 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable57, objArray65);
        java.io.EOFException eOFException69 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable27, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray72 = new java.lang.Object[] { convergenceException71 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException73 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException14, localizable27, objArray72);
        java.lang.Object[] objArray75 = null;
        java.text.ParseException parseException76 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) 100, localizable27, objArray75);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arithmeticException25);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(arithmeticException51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(parseException55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(eOFException69);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException73);
        org.junit.Assert.assertNotNull(parseException76);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double30 = blockRealMatrix26.getEntry(0, 5);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix26, 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix26.getRowMatrix((int) (short) 1);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix34.createMatrix((int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor17 = null;
        try {
            double double18 = array2DRowRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        int int28 = blockRealMatrix27.getRowDimension();
        double[] doubleArray33 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray38 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray43 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray48 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray53 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray54 = new double[][] { doubleArray33, doubleArray38, doubleArray43, doubleArray48, doubleArray53 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray54);
        double[] doubleArray60 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray65 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray70 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray75 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray80 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray81 = new double[][] { doubleArray60, doubleArray65, doubleArray70, doubleArray75, doubleArray80 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix82 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray81);
        double[][] doubleArray83 = blockRealMatrix82.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix85 = blockRealMatrix82.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix55.subtract(blockRealMatrix82);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix87 = blockRealMatrix27.add(blockRealMatrix82);
        int int88 = blockRealMatrix82.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(realMatrix85);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(blockRealMatrix87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 4 + "'", int88 == 4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray8 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray9 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray10 = vectorialPointValuePair6.getValue();
        double[] doubleArray11 = vectorialPointValuePair6.getPointRef();
        double[] doubleArray12 = vectorialPointValuePair6.getValueRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double double14 = array2DRowRealMatrix13.getNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double16 = array2DRowRealMatrix13.walkInColumnOrder(realMatrixChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(5, 4);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.scalarAdd((double) (short) -1);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray8 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray9 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray10 = vectorialPointValuePair6.getValue();
        double[] doubleArray11 = vectorialPointValuePair6.getPointRef();
        double[] doubleArray12 = vectorialPointValuePair6.getPoint();
        double[] doubleArray13 = vectorialPointValuePair6.getPoint();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.Object[] objArray6 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray17);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray17);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray27);
        java.lang.Object[] objArray36 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException28, "hi!", objArray36);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray36);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray43 = new java.lang.Object[] { convergenceException42 };
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException44 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException39, localizable40, objArray43);
        org.apache.commons.math.exception.Localizable localizable46 = matrixIndexException39.getLocalizablePattern();
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray53);
        java.lang.Object[] objArray62 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException63 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException54, "hi!", objArray62);
        java.io.EOFException eOFException65 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", objArray62);
        java.lang.ArithmeticException arithmeticException66 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable46, objArray62);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException20, localizable46, objArray67);
        java.lang.Object[] objArray69 = null;
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(throwable8, localizable46, objArray69);
        org.apache.commons.math.exception.Localizable localizable73 = null;
        java.lang.Object[] objArray81 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray81);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException84 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable73, objArray81);
        java.lang.IllegalStateException illegalStateException85 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray81);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) arithmeticException7, localizable46, objArray81);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException44);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(arithmeticException63);
        org.junit.Assert.assertNotNull(eOFException65);
        org.junit.Assert.assertNotNull(arithmeticException66);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(illegalStateException85);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        double double37 = blockRealMatrix26.getFrobeniusNorm();
        double[][] doubleArray38 = blockRealMatrix26.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray38);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor40 = null;
        try {
            double double41 = blockRealMatrix39.walkInRowOrder(realMatrixPreservingVisitor40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 317.02523558858843d + "'", double37 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray4 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray9 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray14 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray19 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray20 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        double double23 = array2DRowRealMatrix22.getTrace();
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix22.copy();
        org.apache.commons.math.linear.RealVector realVector26 = array2DRowRealMatrix22.getColumnVector(0);
        java.io.ObjectOutputStream objectOutputStream27 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector26, objectOutputStream27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.0d + "'", double23 == 13.0d);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        int[] intArray3 = lUDecompositionImpl2.getPivot();
        java.lang.Class<?> wildcardClass4 = lUDecompositionImpl2.getClass();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = lUDecompositionImpl2.getL();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException(localizable8, objArray10);
        java.lang.Throwable[] throwableArray12 = optimizationException11.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, "org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.Localizable localizable14 = functionEvaluationException13.getLocalizablePattern();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(localizable14);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        double[][] doubleArray30 = blockRealMatrix27.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix27.scalarAdd((double) '4');
        double[] doubleArray34 = new double[] { (short) 1 };
        double[] doubleArray36 = new double[] { (short) 1 };
        double[] doubleArray38 = new double[] { (short) 1 };
        double[][] doubleArray39 = new double[][] { doubleArray34, doubleArray36, doubleArray38 };
        org.apache.commons.math.linear.BigMatrix bigMatrix40 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray39);
        org.apache.commons.math.linear.RealMatrix realMatrix41 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39, true);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray39);
        try {
            blockRealMatrix27.setSubMatrix(doubleArray39, 52, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(bigMatrix40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix44);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor((double) 0.0f);
        double double3 = levenbergMarquardtOptimizer0.getChiSquare();
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor(52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double[] doubleArray6 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl12 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix11);
        int[] intArray13 = lUDecompositionImpl12.getPivot();
        int[] intArray14 = lUDecompositionImpl12.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl17 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix16);
        int[] intArray18 = lUDecompositionImpl17.getPivot();
        org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix9, intArray14, intArray18);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray4 = new double[] { (short) 1 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { (short) 1 };
        double[][] doubleArray9 = new double[][] { doubleArray4, doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.BigMatrix bigMatrix10 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray9);
        java.text.ParseException parseException11 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) 10, "", (java.lang.Object[]) doubleArray9);
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray30 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray35 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray40 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray41 = new double[][] { doubleArray20, doubleArray25, doubleArray30, doubleArray35, doubleArray40 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray41);
        java.lang.IllegalStateException illegalStateException43 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray41);
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException11, 500.0d, "maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(bigMatrix10);
        org.junit.Assert.assertNotNull(parseException11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(illegalStateException43);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix6.createMatrix(3, 3);
        int int13 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException17 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        org.apache.commons.math.exception.Localizable localizable18 = nonSquareMatrixException17.getLocalizablePattern();
        org.apache.commons.math.optimization.OptimizationException optimizationException19 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) nonSquareMatrixException17);
        java.lang.Object[] objArray20 = nonSquareMatrixException17.getArguments();
        double[] doubleArray27 = new double[] { 10.0d, 13.0d, 10.0d, 0L, (byte) 100, 500.0d };
        java.lang.Object[] objArray36 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException("", objArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nonSquareMatrixException17, doubleArray27, "{0}", objArray36);
        java.lang.Object[] objArray49 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException50 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException("", objArray49);
        org.apache.commons.math.exception.Localizable localizable52 = mathRuntimeException51.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix55 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray63 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException64 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray63);
        org.apache.commons.math.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.MathRuntimeException("", objArray63);
        java.lang.Object[] objArray66 = new java.lang.Object[] { (short) 1, objArray63 };
        java.util.NoSuchElementException noSuchElementException67 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray66);
        java.io.EOFException eOFException68 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable52, objArray66);
        double[][] doubleArray71 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(4, (int) (byte) 0);
        java.io.EOFException eOFException72 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable52, (java.lang.Object[]) doubleArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException39, 52.0d, "", (java.lang.Object[]) doubleArray71);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("{0}", (java.lang.Object[]) doubleArray71);
        try {
            array2DRowRealMatrix6.setSubMatrix(doubleArray71, (int) (byte) 10, 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizable18.equals(org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(arithmeticException50);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(arithmeticException64);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(noSuchElementException67);
        org.junit.Assert.assertNotNull(eOFException68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(eOFException72);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double[] doubleArray5 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray10 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray15 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray20 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray25 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray26);
        java.lang.IllegalStateException illegalStateException28 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        try {
            boolean boolean30 = array2DRowRealMatrix29.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 5x4 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(illegalStateException28);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        java.lang.Throwable throwable20 = null;
        double[] doubleArray24 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable20, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix26.scalarMultiply((double) (byte) 100);
        int int29 = array2DRowRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix6.add(array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix26.transpose();
        double[] doubleArray33 = new double[] { (short) 1 };
        double[] doubleArray35 = new double[] { (short) 1 };
        double[] doubleArray37 = new double[] { (short) 1 };
        double[][] doubleArray38 = new double[][] { doubleArray33, doubleArray35, doubleArray37 };
        org.apache.commons.math.linear.BigMatrix bigMatrix39 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray38);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38, true);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix26.add(array2DRowRealMatrix47);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor49 = null;
        try {
            double double50 = array2DRowRealMatrix47.walkInRowOrder(realMatrixPreservingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(bigMatrix39);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix33 = blockRealMatrix27.getSubMatrix(0, (int) (byte) 1, (int) (byte) 100, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 3]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (short) 0);
        java.lang.Throwable throwable10 = null;
        double[] doubleArray14 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(throwable10, doubleArray14);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = array2DRowRealMatrix16.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix16.transpose();
        double[] doubleArray24 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector25 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray24);
        array2DRowRealMatrix16.setColumnVector((int) (byte) 0, realVector25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix16.copy();
        double double28 = array2DRowRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix16.copy();
        try {
            array2DRowRealMatrix6.setColumnMatrix((int) (byte) 10, realMatrix29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.04987562112089d + "'", double28 == 10.04987562112089d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl2 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix1);
        int[] intArray3 = lUDecompositionImpl2.getPivot();
        int[] intArray4 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = lUDecompositionImpl2.getP();
        int[] intArray6 = lUDecompositionImpl2.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = lUDecompositionImpl2.getP();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = lUDecompositionImpl2.getU();
        org.junit.Assert.assertNotNull(realMatrix1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException4 = new org.apache.commons.math.optimization.OptimizationException(localizable1, objArray3);
        java.lang.Throwable[] throwableArray5 = optimizationException4.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.MathRuntimeException("hi!", (java.lang.Object[]) throwableArray5);
        java.lang.Object[] objArray7 = mathRuntimeException6.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.Object[] objArray7 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException("", objArray7);
        org.apache.commons.math.exception.Localizable localizable10 = mathRuntimeException9.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray21 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException("", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) 1, objArray21 };
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray24);
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable10, objArray24);
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.Localizable localizable28 = null;
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray38);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException41 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable30, objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(throwable27, localizable28, objArray38);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable10, objArray38);
        double[] doubleArray50 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray55 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray60 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray65 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray70 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray71 = new double[][] { doubleArray50, doubleArray55, doubleArray60, doubleArray65, doubleArray70 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray71);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix72.copy();
        org.apache.commons.math.linear.RealVector realVector75 = blockRealMatrix73.getColumnVector(0);
        double[][] doubleArray76 = blockRealMatrix73.getData();
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException77 = new org.apache.commons.math.linear.MatrixIndexException("hi!", (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException43, "", (java.lang.Object[]) doubleArray76);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray76);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arithmeticException22);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(noSuchElementException25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(blockRealMatrix73);
        org.junit.Assert.assertNotNull(realVector75);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.getColumnMatrix((int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl11 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix10);
        int[] intArray12 = lUDecompositionImpl11.getPivot();
        int[] intArray13 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = lUDecompositionImpl11.getP();
        int[] intArray15 = lUDecompositionImpl11.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl18 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix17);
        int[] intArray19 = lUDecompositionImpl18.getPivot();
        int[] intArray20 = lUDecompositionImpl18.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = lUDecompositionImpl18.getP();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = lUDecompositionImpl18.getP();
        int[] intArray23 = lUDecompositionImpl18.getPivot();
        double[] doubleArray28 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray33 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray38 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray43 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray48 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray49 = new double[][] { doubleArray28, doubleArray33, doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[][] doubleArray51 = blockRealMatrix50.getData();
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        array2DRowRealMatrix6.copySubMatrix(intArray15, intArray23, doubleArray52);
        java.lang.Throwable throwable55 = null;
        double[] doubleArray59 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable55, doubleArray59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix61.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = array2DRowRealMatrix61.transpose();
        double[] doubleArray69 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector70 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray69);
        array2DRowRealMatrix61.setColumnVector((int) (byte) 0, realVector70);
        try {
            array2DRowRealMatrix6.setColumnVector((int) (short) 10, realVector70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.scalarMultiply((double) (byte) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.transpose();
        double[] doubleArray14 = new double[] { (-1), (byte) 0, 10 };
        org.apache.commons.math.linear.RealVector realVector15 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray14);
        array2DRowRealMatrix6.setColumnVector((int) (byte) 0, realVector15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6, (int) (short) 0);
        double[] doubleArray21 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector22 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray21);
        double[] doubleArray24 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector25 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray24);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray24);
        double[] doubleArray27 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray28 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray29 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray30 = vectorialPointValuePair26.getValue();
        double[] doubleArray31 = vectorialPointValuePair26.getPointRef();
        double[] doubleArray32 = vectorialPointValuePair26.getValueRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32);
        double double34 = array2DRowRealMatrix33.getNorm();
        int int35 = array2DRowRealMatrix33.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix6.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
        double[][] doubleArray37 = array2DRowRealMatrix6.getData();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.0d + "'", double34 == 52.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double30 = blockRealMatrix26.getEntry(0, 5);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix26, 0);
        blockRealMatrix26.addToEntry((-1), 10, (double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double[] doubleArray72 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray77 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray82 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray87 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray92 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray93 = new double[][] { doubleArray72, doubleArray77, doubleArray82, doubleArray87, doubleArray92 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix94 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray93);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix95 = blockRealMatrix94.copy();
        int int96 = blockRealMatrix95.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix97 = blockRealMatrix67.subtract(blockRealMatrix95);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor98 = null;
        try {
            double double99 = blockRealMatrix97.walkInColumnOrder(realMatrixPreservingVisitor98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(blockRealMatrix95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 5 + "'", int96 == 5);
        org.junit.Assert.assertNotNull(blockRealMatrix97);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException3 = new org.apache.commons.math.linear.NonSquareMatrixException(1, 1);
        org.apache.commons.math.exception.Localizable localizable4 = nonSquareMatrixException3.getLocalizablePattern();
        org.apache.commons.math.optimization.OptimizationException optimizationException5 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) nonSquareMatrixException3);
        java.lang.Object[] objArray6 = nonSquareMatrixException3.getArguments();
        java.io.EOFException eOFException7 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray6);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizable4.equals(org.apache.commons.math.exception.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(eOFException7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double[] doubleArray3 = new double[] { (short) 1 };
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray7 = new double[] { (short) 1 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray8);
        java.text.ParseException parseException10 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) 10, "", (java.lang.Object[]) doubleArray8);
        double[] doubleArray15 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray20 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray25 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray30 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray31 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, false);
        double[] doubleArray35 = array2DRowRealMatrix33.getColumn(1);
        double[] doubleArray37 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector38 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray37);
        double[] doubleArray40 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector41 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray40);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray40);
        double[] doubleArray43 = vectorialPointValuePair42.getValueRef();
        double[] doubleArray44 = vectorialPointValuePair42.getValueRef();
        double[] doubleArray45 = vectorialPointValuePair42.getValueRef();
        double[] doubleArray46 = vectorialPointValuePair42.getValue();
        double[] doubleArray47 = vectorialPointValuePair42.getPointRef();
        double[] doubleArray48 = vectorialPointValuePair42.getValueRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray48);
        java.lang.Object[] objArray59 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException60 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException("", objArray59);
        org.apache.commons.math.exception.Localizable localizable62 = mathRuntimeException61.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException67 = new org.apache.commons.math.optimization.OptimizationException(localizable64, objArray66);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException68 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray66);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException69 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable62, objArray66);
        java.lang.Object[] objArray70 = null;
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable62, objArray70);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray81);
        java.lang.IllegalArgumentException illegalArgumentException84 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray81);
        java.lang.ArithmeticException arithmeticException85 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException10, doubleArray35, localizable62, objArray81);
        java.lang.Object[] objArray93 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException94 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray93);
        java.lang.NullPointerException nullPointerException95 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable62, objArray93);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(bigMatrix9);
        org.junit.Assert.assertNotNull(parseException10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(arithmeticException60);
        org.junit.Assert.assertNotNull(localizable62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(illegalArgumentException84);
        org.junit.Assert.assertNotNull(arithmeticException85);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(arithmeticException94);
        org.junit.Assert.assertNotNull(nullPointerException95);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.optimization.OptimizationException optimizationException3 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray2);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("", objArray2);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray8 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray9 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray10 = vectorialPointValuePair6.getValue();
        double[] doubleArray11 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray12 = vectorialPointValuePair6.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double[] doubleArray72 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray77 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray82 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray87 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray92 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray93 = new double[][] { doubleArray72, doubleArray77, doubleArray82, doubleArray87, doubleArray92 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix94 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray93);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix95 = blockRealMatrix94.copy();
        int int96 = blockRealMatrix95.getRowDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix97 = blockRealMatrix67.subtract(blockRealMatrix95);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor98 = null;
        try {
            double double99 = blockRealMatrix95.walkInRowOrder(realMatrixChangingVisitor98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(blockRealMatrix95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 5 + "'", int96 == 5);
        org.junit.Assert.assertNotNull(blockRealMatrix97);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray31 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray36 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray41 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray46 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray51 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray52 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[][] doubleArray54 = blockRealMatrix53.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix56 = blockRealMatrix53.scalarAdd(1.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = blockRealMatrix26.subtract(blockRealMatrix53);
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray67 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray72 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray77 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray82 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray83 = new double[][] { doubleArray62, doubleArray67, doubleArray72, doubleArray77, doubleArray82 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray83);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix84.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix53.add(blockRealMatrix84);
        org.apache.commons.math.linear.RealMatrix realMatrix88 = blockRealMatrix86.scalarMultiply((double) 1000);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(blockRealMatrix57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(realMatrix88);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray4 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.00499987500625d + "'", double8 == 100.00499987500625d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray8);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray8);
        java.lang.IllegalArgumentException illegalArgumentException12 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) illegalArgumentException11);
        java.lang.Object[] objArray24 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException("", objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = mathRuntimeException26.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException32 = new org.apache.commons.math.optimization.OptimizationException(localizable29, objArray31);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException33 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray31);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException34 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable27, objArray31);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray41);
        java.lang.Object[] objArray50 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException51 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException42, "hi!", objArray50);
        org.apache.commons.math.optimization.OptimizationException optimizationException53 = new org.apache.commons.math.optimization.OptimizationException(localizable35, objArray50);
        java.lang.Object[] objArray54 = optimizationException53.getArguments();
        java.text.ParseException parseException55 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', localizable27, objArray54);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray65);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException68 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable57, objArray65);
        java.io.EOFException eOFException69 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable27, objArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalArgumentException12, (double) (-1L), "org.apache.commons.math.FunctionEvaluationException: ", objArray65);
        double[] doubleArray71 = functionEvaluationException70.getArgument();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertNotNull(illegalArgumentException12);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arithmeticException25);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(arithmeticException51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(parseException55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(eOFException69);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        double double28 = blockRealMatrix27.getNorm();
        double double29 = blockRealMatrix27.getFrobeniusNorm();
        double[] doubleArray31 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector32 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray31);
        double[] doubleArray34 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector35 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray34);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray34);
        double[] doubleArray37 = vectorialPointValuePair36.getValueRef();
        double[] doubleArray38 = vectorialPointValuePair36.getValueRef();
        double[] doubleArray39 = vectorialPointValuePair36.getValueRef();
        double[] doubleArray40 = vectorialPointValuePair36.getValue();
        double[] doubleArray41 = vectorialPointValuePair36.getPointRef();
        double[] doubleArray42 = vectorialPointValuePair36.getPoint();
        java.lang.Class<?> wildcardClass43 = doubleArray42.getClass();
        try {
            double[] doubleArray44 = blockRealMatrix27.operate(doubleArray42);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 500.0d + "'", double28 == 500.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 317.02523558858843d + "'", double29 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!", "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix3 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[][] doubleArray27 = blockRealMatrix26.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix26.scalarAdd(1.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = blockRealMatrix26.scalarMultiply(0.0d);
        double[][] doubleArray32 = blockRealMatrix26.getData();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double31 = blockRealMatrix27.walkInRowOrder(realMatrixPreservingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        double[] doubleArray42 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray47 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray52 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray57 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray62 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray63 = new double[][] { doubleArray42, doubleArray47, doubleArray52, doubleArray57, doubleArray62 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix64.copy();
        double double66 = blockRealMatrix65.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix26.add(blockRealMatrix65);
        double double68 = blockRealMatrix26.getFrobeniusNorm();
        double[] doubleArray73 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray78 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray83 = new double[] { 1L, 1L, 1.0d, 10L };
        double[] doubleArray88 = new double[] { 1L, 1L, 1.0d, 10L };
        double[][] doubleArray89 = new double[][] { doubleArray73, doubleArray78, doubleArray83, doubleArray88 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89, false);
        double double92 = array2DRowRealMatrix91.getTrace();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix93 = blockRealMatrix26.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix91);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor94 = null;
        try {
            double double95 = blockRealMatrix93.walkInOptimizedOrder(realMatrixPreservingVisitor94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 500.0d + "'", double66 == 500.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 317.02523558858843d + "'", double68 == 317.02523558858843d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 13.0d + "'", double92 == 13.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix93);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.Throwable throwable0 = null;
        java.lang.RuntimeException runtimeException1 = org.apache.commons.math.MathRuntimeException.createInternalError(throwable0);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        double[][] doubleArray41 = null;
        try {
            blockRealMatrix26.copySubMatrix(0, (int) '4', 1000, (int) (short) -1, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray8);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException10 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray8);
        java.io.EOFException eOFException11 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.FunctionEvaluationException: ", objArray8);
        java.io.EOFException eOFException12 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.MaxEvaluationsExceededException: hi!", objArray8);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException10);
        org.junit.Assert.assertNotNull(eOFException11);
        org.junit.Assert.assertNotNull(eOFException12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[][] doubleArray27 = blockRealMatrix26.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = blockRealMatrix26.scalarAdd(1.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = blockRealMatrix26.scalarMultiply(0.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = blockRealMatrix26.scalarMultiply((double) 1000);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker2);
        double double4 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) '4');
        levenbergMarquardtOptimizer0.setMaxEvaluations(100);
        double double9 = levenbergMarquardtOptimizer0.getChiSquare();
        double double10 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        org.apache.commons.math.linear.RealMatrix realMatrix30 = blockRealMatrix26.getColumnMatrix((int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor31 = null;
        try {
            double double36 = blockRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor31, (int) ' ', 3, (-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double[] doubleArray1 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector2 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray1);
        double[] doubleArray4 = new double[] { 52 };
        org.apache.commons.math.linear.RealVector realVector5 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray4);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair6 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray4);
        double[] doubleArray7 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray8 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray9 = vectorialPointValuePair6.getValueRef();
        double[] doubleArray10 = vectorialPointValuePair6.getValue();
        double[] doubleArray11 = vectorialPointValuePair6.getPointRef();
        double[] doubleArray12 = vectorialPointValuePair6.getValueRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        boolean boolean14 = array2DRowRealMatrix13.isSquare();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[][] doubleArray27 = blockRealMatrix26.getData();
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix(obj0, "Array2DRowRealMatrix{{1.0,1.0,1.0,10.0},{1.0,1.0,1.0,10.0},{1.0,1.0,1.0,10.0},{1.0,1.0,1.0,10.0}}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.Throwable throwable1 = null;
        double[] doubleArray5 = new double[] { (short) -1, 100, (short) 0 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5);
        java.lang.Object[] objArray17 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException18 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException("", objArray17);
        org.apache.commons.math.exception.Localizable localizable20 = mathRuntimeException19.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException25 = new org.apache.commons.math.optimization.OptimizationException(localizable22, objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray24);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable20, objArray24);
        org.apache.commons.math.exception.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray34);
        java.lang.Object[] objArray43 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException44 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException35, "hi!", objArray43);
        org.apache.commons.math.optimization.OptimizationException optimizationException46 = new org.apache.commons.math.optimization.OptimizationException(localizable28, objArray43);
        java.lang.Object[] objArray47 = optimizationException46.getArguments();
        java.text.ParseException parseException48 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', localizable20, objArray47);
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException61 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable50, objArray58);
        java.io.EOFException eOFException62 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable20, objArray58);
        java.lang.Object[] objArray71 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException72 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException("", objArray71);
        org.apache.commons.math.exception.Localizable localizable74 = mathRuntimeException73.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix77 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray85 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException86 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray85);
        org.apache.commons.math.MathRuntimeException mathRuntimeException87 = new org.apache.commons.math.MathRuntimeException("", objArray85);
        java.lang.Object[] objArray88 = new java.lang.Object[] { (short) 1, objArray85 };
        java.util.NoSuchElementException noSuchElementException89 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray88);
        java.io.EOFException eOFException90 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable74, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.FunctionEvaluationException: ", objArray88);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable20, objArray88);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException93 = new org.apache.commons.math.linear.MatrixIndexException("a {0}x{1} matrix was provided instead of a square matrix", objArray88);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(arithmeticException18);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(arithmeticException44);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(parseException48);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(eOFException62);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(arithmeticException72);
        org.junit.Assert.assertNotNull(localizable74);
        org.junit.Assert.assertNotNull(realMatrix77);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(arithmeticException86);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(noSuchElementException89);
        org.junit.Assert.assertNotNull(eOFException90);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        org.apache.commons.math.linear.RealVector realVector29 = blockRealMatrix27.getColumnVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = blockRealMatrix27.scalarAdd((double) 1000);
        double double32 = blockRealMatrix27.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(blockRealMatrix31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 317.02523558858843d + "'", double32 == 317.02523558858843d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double[] doubleArray4 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray9 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray14 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray19 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[] doubleArray24 = new double[] { 10.0f, 1, 100.0f, (byte) 100 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix26.copy();
        java.lang.String str28 = blockRealMatrix26.toString();
        double[] doubleArray34 = new double[] { 1, 0, 1.0d, 100.0f, 36 };
        double[] doubleArray35 = blockRealMatrix26.preMultiply(doubleArray34);
        int int36 = blockRealMatrix26.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix26.transpose();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor38 = null;
        try {
            double double39 = blockRealMatrix26.walkInOptimizedOrder(realMatrixPreservingVisitor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}" + "'", str28.equals("BlockRealMatrix{{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0},{10.0,1.0,100.0,100.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(realMatrix37);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.Object[] objArray7 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException("", objArray7);
        org.apache.commons.math.exception.Localizable localizable10 = mathRuntimeException9.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix13 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray21 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException("", objArray21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (short) 1, objArray21 };
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray24);
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable10, objArray24);
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.Localizable localizable28 = null;
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray38);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException41 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable30, objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(throwable27, localizable28, objArray38);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable10, objArray38);
        java.lang.Object[] objArray52 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException53 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray52);
        org.apache.commons.math.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.MathRuntimeException("", objArray52);
        org.apache.commons.math.exception.Localizable localizable55 = mathRuntimeException54.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 100.0f };
        org.apache.commons.math.optimization.OptimizationException optimizationException60 = new org.apache.commons.math.optimization.OptimizationException(localizable57, objArray59);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException61 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: ", objArray59);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException62 = new org.apache.commons.math.MaxEvaluationsExceededException(100, localizable55, objArray59);
        org.apache.commons.math.exception.Localizable localizable64 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray70);
        java.lang.Object[] objArray79 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException80 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray79);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException71, "hi!", objArray79);
        org.apache.commons.math.optimization.OptimizationException optimizationException82 = new org.apache.commons.math.optimization.OptimizationException(localizable64, objArray79);
        java.lang.Object[] objArray83 = optimizationException82.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException84 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray83);
        java.lang.IllegalArgumentException illegalArgumentException85 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable55, objArray83);
        java.lang.ArithmeticException arithmeticException86 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable10, objArray83);
        java.lang.Object[] objArray87 = null;
        java.lang.IllegalArgumentException illegalArgumentException88 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable10, objArray87);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(arithmeticException22);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(noSuchElementException25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(arithmeticException53);
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(arithmeticException80);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(illegalArgumentException85);
        org.junit.Assert.assertNotNull(arithmeticException86);
        org.junit.Assert.assertNotNull(illegalArgumentException88);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double[] doubleArray2 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { (short) 1 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        double[] doubleArray18 = new double[] { 'a', 0.0f, 1.0f, 1L, (short) -1, (short) 100 };
        org.apache.commons.math.linear.RealMatrix realMatrix19 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        java.lang.Object[] objArray27 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException28 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray27);
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException("", objArray27);
        org.apache.commons.math.exception.Localizable localizable30 = mathRuntimeException29.getLocalizablePattern();
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 1);
        java.lang.Object[] objArray41 = new java.lang.Object[] { true, 1, (short) 1, 10L, (-1) };
        java.lang.ArithmeticException arithmeticException42 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray41);
        org.apache.commons.math.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.MathRuntimeException("", objArray41);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (short) 1, objArray41 };
        java.util.NoSuchElementException noSuchElementException45 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray44);
        java.io.EOFException eOFException46 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable30, objArray44);
        java.lang.Throwable throwable47 = null;
        org.apache.commons.math.exception.Localizable localizable48 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException61 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, localizable50, objArray58);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(throwable47, localizable48, objArray58);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException63 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable30, objArray58);
        java.lang.Object[] objArray72 = new java.lang.Object[] { 0, (byte) 1, 1.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((double) 0, "hi!", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0, "", objArray72);
        java.lang.NullPointerException nullPointerException75 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException11, doubleArray18, localizable30, objArray72);
        double[] doubleArray77 = functionEvaluationException76.getArgument();
        double[] doubleArray78 = functionEvaluationException76.getArgument();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException10, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(arithmeticException28);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(arithmeticException42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(noSuchElementException45);
        org.junit.Assert.assertNotNull(eOFException46);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException63);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(nullPointerException75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
    }
}

